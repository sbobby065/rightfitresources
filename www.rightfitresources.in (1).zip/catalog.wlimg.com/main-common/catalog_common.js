/*################ jquery.latest.min.js starts ###################*/
/*! jQuery v1.8.3 jquery.com | jquery.org/license */

(function (e, t) {
  function _(e) {
    var t = (M[e] = {});
    return (
      v.each(e.split(y), function (e, n) {
        t[n] = !0;
      }),
      t
    );
  }
  function H(e, n, r) {
    if (r === t && e.nodeType === 1) {
      var i = "data-" + n.replace(P, "-$1").toLowerCase();
      r = e.getAttribute(i);
      if (typeof r == "string") {
        try {
          r =
            r === "true"
              ? !0
              : r === "false"
              ? !1
              : r === "null"
              ? null
              : +r + "" === r
              ? +r
              : D.test(r)
              ? v.parseJSON(r)
              : r;
        } catch (s) {}
        v.data(e, n, r);
      } else r = t;
    }
    return r;
  }
  function B(e) {
    var t;
    for (t in e) {
      if (t === "data" && v.isEmptyObject(e[t])) continue;
      if (t !== "toJSON") return !1;
    }
    return !0;
  }
  function et() {
    return !1;
  }
  function tt() {
    return !0;
  }
  function ut(e) {
    return !e || !e.parentNode || e.parentNode.nodeType === 11;
  }
  function at(e, t) {
    do e = e[t];
    while (e && e.nodeType !== 1);
    return e;
  }
  function ft(e, t, n) {
    t = t || 0;
    if (v.isFunction(t))
      return v.grep(e, function (e, r) {
        var i = !!t.call(e, r, e);
        return i === n;
      });
    if (t.nodeType)
      return v.grep(e, function (e, r) {
        return (e === t) === n;
      });
    if (typeof t == "string") {
      var r = v.grep(e, function (e) {
        return e.nodeType === 1;
      });
      if (it.test(t)) return v.filter(t, r, !n);
      t = v.filter(t, r);
    }
    return v.grep(e, function (e, r) {
      return v.inArray(e, t) >= 0 === n;
    });
  }
  function lt(e) {
    var t = ct.split("|"),
      n = e.createDocumentFragment();
    if (n.createElement) while (t.length) n.createElement(t.pop());
    return n;
  }
  function Lt(e, t) {
    return (
      e.getElementsByTagName(t)[0] ||
      e.appendChild(e.ownerDocument.createElement(t))
    );
  }
  function At(e, t) {
    if (t.nodeType !== 1 || !v.hasData(e)) return;
    var n,
      r,
      i,
      s = v._data(e),
      o = v._data(t, s),
      u = s.events;
    if (u) {
      delete o.handle, (o.events = {});
      for (n in u)
        for (r = 0, i = u[n].length; r < i; r++) v.event.add(t, n, u[n][r]);
    }
    o.data && (o.data = v.extend({}, o.data));
  }
  function Ot(e, t) {
    var n;
    if (t.nodeType !== 1) return;
    t.clearAttributes && t.clearAttributes(),
      t.mergeAttributes && t.mergeAttributes(e),
      (n = t.nodeName.toLowerCase()),
      n === "object"
        ? (t.parentNode && (t.outerHTML = e.outerHTML),
          v.support.html5Clone &&
            e.innerHTML &&
            !v.trim(t.innerHTML) &&
            (t.innerHTML = e.innerHTML))
        : n === "input" && Et.test(e.type)
        ? ((t.defaultChecked = t.checked = e.checked),
          t.value !== e.value && (t.value = e.value))
        : n === "option"
        ? (t.selected = e.defaultSelected)
        : n === "input" || n === "textarea"
        ? (t.defaultValue = e.defaultValue)
        : n === "script" && t.text !== e.text && (t.text = e.text),
      t.removeAttribute(v.expando);
  }
  function Mt(e) {
    return typeof e.getElementsByTagName != "undefined"
      ? e.getElementsByTagName("*")
      : typeof e.querySelectorAll != "undefined"
      ? e.querySelectorAll("*")
      : [];
  }
  function _t(e) {
    Et.test(e.type) && (e.defaultChecked = e.checked);
  }
  function Qt(e, t) {
    if (t in e) return t;
    var n = t.charAt(0).toUpperCase() + t.slice(1),
      r = t,
      i = Jt.length;
    while (i--) {
      t = Jt[i] + n;
      if (t in e) return t;
    }
    return r;
  }
  function Gt(e, t) {
    return (
      (e = t || e),
      v.css(e, "display") === "none" || !v.contains(e.ownerDocument, e)
    );
  }
  function Yt(e, t) {
    var n,
      r,
      i = [],
      s = 0,
      o = e.length;
    for (; s < o; s++) {
      n = e[s];
      if (!n.style) continue;
      (i[s] = v._data(n, "olddisplay")),
        t
          ? (!i[s] && n.style.display === "none" && (n.style.display = ""),
            n.style.display === "" &&
              Gt(n) &&
              (i[s] = v._data(n, "olddisplay", nn(n.nodeName))))
          : ((r = Dt(n, "display")),
            !i[s] && r !== "none" && v._data(n, "olddisplay", r));
    }
    for (s = 0; s < o; s++) {
      n = e[s];
      if (!n.style) continue;
      if (!t || n.style.display === "none" || n.style.display === "")
        n.style.display = t ? i[s] || "" : "none";
    }
    return e;
  }
  function Zt(e, t, n) {
    var r = Rt.exec(t);
    return r ? Math.max(0, r[1] - (n || 0)) + (r[2] || "px") : t;
  }
  function en(e, t, n, r) {
    var i = n === (r ? "border" : "content") ? 4 : t === "width" ? 1 : 0,
      s = 0;
    for (; i < 4; i += 2)
      n === "margin" && (s += v.css(e, n + $t[i], !0)),
        r
          ? (n === "content" &&
              (s -= parseFloat(Dt(e, "padding" + $t[i])) || 0),
            n !== "margin" &&
              (s -= parseFloat(Dt(e, "border" + $t[i] + "Width")) || 0))
          : ((s += parseFloat(Dt(e, "padding" + $t[i])) || 0),
            n !== "padding" &&
              (s += parseFloat(Dt(e, "border" + $t[i] + "Width")) || 0));
    return s;
  }
  function tn(e, t, n) {
    var r = t === "width" ? e.offsetWidth : e.offsetHeight,
      i = !0,
      s = v.support.boxSizing && v.css(e, "boxSizing") === "border-box";
    if (r <= 0 || r == null) {
      r = Dt(e, t);
      if (r < 0 || r == null) r = e.style[t];
      if (Ut.test(r)) return r;
      (i = s && (v.support.boxSizingReliable || r === e.style[t])),
        (r = parseFloat(r) || 0);
    }
    return r + en(e, t, n || (s ? "border" : "content"), i) + "px";
  }
  function nn(e) {
    if (Wt[e]) return Wt[e];
    var t = v("<" + e + ">").appendTo(i.body),
      n = t.css("display");
    t.remove();
    if (n === "none" || n === "") {
      Pt = i.body.appendChild(
        Pt ||
          v.extend(i.createElement("iframe"), {
            frameBorder: 0,
            width: 0,
            height: 0,
          })
      );
      if (!Ht || !Pt.createElement)
        (Ht = (Pt.contentWindow || Pt.contentDocument).document),
          Ht.write("<!doctype html><html><body>"),
          Ht.close();
      (t = Ht.body.appendChild(Ht.createElement(e))),
        (n = Dt(t, "display")),
        i.body.removeChild(Pt);
    }
    return (Wt[e] = n), n;
  }
  function fn(e, t, n, r) {
    var i;
    if (v.isArray(t))
      v.each(t, function (t, i) {
        n || sn.test(e)
          ? r(e, i)
          : fn(e + "[" + (typeof i == "object" ? t : "") + "]", i, n, r);
      });
    else if (!n && v.type(t) === "object")
      for (i in t) fn(e + "[" + i + "]", t[i], n, r);
    else r(e, t);
  }
  function Cn(e) {
    return function (t, n) {
      typeof t != "string" && ((n = t), (t = "*"));
      var r,
        i,
        s,
        o = t.toLowerCase().split(y),
        u = 0,
        a = o.length;
      if (v.isFunction(n))
        for (; u < a; u++)
          (r = o[u]),
            (s = /^\+/.test(r)),
            s && (r = r.substr(1) || "*"),
            (i = e[r] = e[r] || []),
            i[s ? "unshift" : "push"](n);
    };
  }
  function kn(e, n, r, i, s, o) {
    (s = s || n.dataTypes[0]), (o = o || {}), (o[s] = !0);
    var u,
      a = e[s],
      f = 0,
      l = a ? a.length : 0,
      c = e === Sn;
    for (; f < l && (c || !u); f++)
      (u = a[f](n, r, i)),
        typeof u == "string" &&
          (!c || o[u]
            ? (u = t)
            : (n.dataTypes.unshift(u), (u = kn(e, n, r, i, u, o))));
    return (c || !u) && !o["*"] && (u = kn(e, n, r, i, "*", o)), u;
  }
  function Ln(e, n) {
    var r,
      i,
      s = v.ajaxSettings.flatOptions || {};
    for (r in n) n[r] !== t && ((s[r] ? e : i || (i = {}))[r] = n[r]);
    i && v.extend(!0, e, i);
  }
  function An(e, n, r) {
    var i,
      s,
      o,
      u,
      a = e.contents,
      f = e.dataTypes,
      l = e.responseFields;
    for (s in l) s in r && (n[l[s]] = r[s]);
    while (f[0] === "*")
      f.shift(),
        i === t && (i = e.mimeType || n.getResponseHeader("content-type"));
    if (i)
      for (s in a)
        if (a[s] && a[s].test(i)) {
          f.unshift(s);
          break;
        }
    if (f[0] in r) o = f[0];
    else {
      for (s in r) {
        if (!f[0] || e.converters[s + " " + f[0]]) {
          o = s;
          break;
        }
        u || (u = s);
      }
      o = o || u;
    }
    if (o) return o !== f[0] && f.unshift(o), r[o];
  }
  function On(e, t) {
    var n,
      r,
      i,
      s,
      o = e.dataTypes.slice(),
      u = o[0],
      a = {},
      f = 0;
    e.dataFilter && (t = e.dataFilter(t, e.dataType));
    if (o[1]) for (n in e.converters) a[n.toLowerCase()] = e.converters[n];
    for (; (i = o[++f]); )
      if (i !== "*") {
        if (u !== "*" && u !== i) {
          n = a[u + " " + i] || a["* " + i];
          if (!n)
            for (r in a) {
              s = r.split(" ");
              if (s[1] === i) {
                n = a[u + " " + s[0]] || a["* " + s[0]];
                if (n) {
                  n === !0
                    ? (n = a[r])
                    : a[r] !== !0 && ((i = s[0]), o.splice(f--, 0, i));
                  break;
                }
              }
            }
          if (n !== !0)
            if (n && e["throws"]) t = n(t);
            else
              try {
                t = n(t);
              } catch (l) {
                return {
                  state: "parsererror",
                  error: n ? l : "No conversion from " + u + " to " + i,
                };
              }
        }
        u = i;
      }
    return { state: "success", data: t };
  }
  function Fn() {
    try {
      return new e.XMLHttpRequest();
    } catch (t) {}
  }
  function In() {
    try {
      return new e.ActiveXObject("Microsoft.XMLHTTP");
    } catch (t) {}
  }
  function $n() {
    return (
      setTimeout(function () {
        qn = t;
      }, 0),
      (qn = v.now())
    );
  }
  function Jn(e, t) {
    v.each(t, function (t, n) {
      var r = (Vn[t] || []).concat(Vn["*"]),
        i = 0,
        s = r.length;
      for (; i < s; i++) if (r[i].call(e, t, n)) return;
    });
  }
  function Kn(e, t, n) {
    var r,
      i = 0,
      s = 0,
      o = Xn.length,
      u = v.Deferred().always(function () {
        delete a.elem;
      }),
      a = function () {
        var t = qn || $n(),
          n = Math.max(0, f.startTime + f.duration - t),
          r = n / f.duration || 0,
          i = 1 - r,
          s = 0,
          o = f.tweens.length;
        for (; s < o; s++) f.tweens[s].run(i);
        return (
          u.notifyWith(e, [f, i, n]),
          i < 1 && o ? n : (u.resolveWith(e, [f]), !1)
        );
      },
      f = u.promise({
        elem: e,
        props: v.extend({}, t),
        opts: v.extend(!0, { specialEasing: {} }, n),
        originalProperties: t,
        originalOptions: n,
        startTime: qn || $n(),
        duration: n.duration,
        tweens: [],
        createTween: function (t, n, r) {
          var i = v.Tween(
            e,
            f.opts,
            t,
            n,
            f.opts.specialEasing[t] || f.opts.easing
          );
          return f.tweens.push(i), i;
        },
        stop: function (t) {
          var n = 0,
            r = t ? f.tweens.length : 0;
          for (; n < r; n++) f.tweens[n].run(1);
          return t ? u.resolveWith(e, [f, t]) : u.rejectWith(e, [f, t]), this;
        },
      }),
      l = f.props;
    Qn(l, f.opts.specialEasing);
    for (; i < o; i++) {
      r = Xn[i].call(f, e, l, f.opts);
      if (r) return r;
    }
    return (
      Jn(f, l),
      v.isFunction(f.opts.start) && f.opts.start.call(e, f),
      v.fx.timer(v.extend(a, { anim: f, queue: f.opts.queue, elem: e })),
      f
        .progress(f.opts.progress)
        .done(f.opts.done, f.opts.complete)
        .fail(f.opts.fail)
        .always(f.opts.always)
    );
  }
  function Qn(e, t) {
    var n, r, i, s, o;
    for (n in e) {
      (r = v.camelCase(n)),
        (i = t[r]),
        (s = e[n]),
        v.isArray(s) && ((i = s[1]), (s = e[n] = s[0])),
        n !== r && ((e[r] = s), delete e[n]),
        (o = v.cssHooks[r]);
      if (o && "expand" in o) {
        (s = o.expand(s)), delete e[r];
        for (n in s) n in e || ((e[n] = s[n]), (t[n] = i));
      } else t[r] = i;
    }
  }
  function Gn(e, t, n) {
    var r,
      i,
      s,
      o,
      u,
      a,
      f,
      l,
      c,
      h = this,
      p = e.style,
      d = {},
      m = [],
      g = e.nodeType && Gt(e);
    n.queue ||
      ((l = v._queueHooks(e, "fx")),
      l.unqueued == null &&
        ((l.unqueued = 0),
        (c = l.empty.fire),
        (l.empty.fire = function () {
          l.unqueued || c();
        })),
      l.unqueued++,
      h.always(function () {
        h.always(function () {
          l.unqueued--, v.queue(e, "fx").length || l.empty.fire();
        });
      })),
      e.nodeType === 1 &&
        ("height" in t || "width" in t) &&
        ((n.overflow = [p.overflow, p.overflowX, p.overflowY]),
        v.css(e, "display") === "inline" &&
          v.css(e, "float") === "none" &&
          (!v.support.inlineBlockNeedsLayout || nn(e.nodeName) === "inline"
            ? (p.display = "inline-block")
            : (p.zoom = 1))),
      n.overflow &&
        ((p.overflow = "hidden"),
        v.support.shrinkWrapBlocks ||
          h.done(function () {
            (p.overflow = n.overflow[0]),
              (p.overflowX = n.overflow[1]),
              (p.overflowY = n.overflow[2]);
          }));
    for (r in t) {
      s = t[r];
      if (Un.exec(s)) {
        delete t[r], (a = a || s === "toggle");
        if (s === (g ? "hide" : "show")) continue;
        m.push(r);
      }
    }
    o = m.length;
    if (o) {
      (u = v._data(e, "fxshow") || v._data(e, "fxshow", {})),
        "hidden" in u && (g = u.hidden),
        a && (u.hidden = !g),
        g
          ? v(e).show()
          : h.done(function () {
              v(e).hide();
            }),
        h.done(function () {
          var t;
          v.removeData(e, "fxshow", !0);
          for (t in d) v.style(e, t, d[t]);
        });
      for (r = 0; r < o; r++)
        (i = m[r]),
          (f = h.createTween(i, g ? u[i] : 0)),
          (d[i] = u[i] || v.style(e, i)),
          i in u ||
            ((u[i] = f.start),
            g &&
              ((f.end = f.start),
              (f.start = i === "width" || i === "height" ? 1 : 0)));
    }
  }
  function Yn(e, t, n, r, i) {
    return new Yn.prototype.init(e, t, n, r, i);
  }
  function Zn(e, t) {
    var n,
      r = { height: e },
      i = 0;
    t = t ? 1 : 0;
    for (; i < 4; i += 2 - t)
      (n = $t[i]), (r["margin" + n] = r["padding" + n] = e);
    return t && (r.opacity = r.width = e), r;
  }
  function tr(e) {
    return v.isWindow(e)
      ? e
      : e.nodeType === 9
      ? e.defaultView || e.parentWindow
      : !1;
  }
  var n,
    r,
    i = e.document,
    s = e.location,
    o = e.navigator,
    u = e.jQuery,
    a = e.$,
    f = Array.prototype.push,
    l = Array.prototype.slice,
    c = Array.prototype.indexOf,
    h = Object.prototype.toString,
    p = Object.prototype.hasOwnProperty,
    d = String.prototype.trim,
    v = function (e, t) {
      return new v.fn.init(e, t, n);
    },
    m = /[\-+]?(?:\d*\.|)\d+(?:[eE][\-+]?\d+|)/.source,
    g = /\S/,
    y = /\s+/,
    b = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
    w = /^(?:[^#<]*(<[\w\W]+>)[^>]*$|#([\w\-]*)$)/,
    E = /^<(\w+)\s*\/?>(?:<\/\1>|)$/,
    S = /^[\],:{}\s]*$/,
    x = /(?:^|:|,)(?:\s*\[)+/g,
    T = /\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g,
    N = /"[^"\\\r\n]*"|true|false|null|-?(?:\d\d*\.|)\d+(?:[eE][\-+]?\d+|)/g,
    C = /^-ms-/,
    k = /-([\da-z])/gi,
    L = function (e, t) {
      return (t + "").toUpperCase();
    },
    A = function () {
      i.addEventListener
        ? (i.removeEventListener("DOMContentLoaded", A, !1), v.ready())
        : i.readyState === "complete" &&
          (i.detachEvent("onreadystatechange", A), v.ready());
    },
    O = {};
  (v.fn = v.prototype =
    {
      constructor: v,
      init: function (e, n, r) {
        var s, o, u, a;
        if (!e) return this;
        if (e.nodeType)
          return (this.context = this[0] = e), (this.length = 1), this;
        if (typeof e == "string") {
          e.charAt(0) === "<" && e.charAt(e.length - 1) === ">" && e.length >= 3
            ? (s = [null, e, null])
            : (s = w.exec(e));
          if (s && (s[1] || !n)) {
            if (s[1])
              return (
                (n = n instanceof v ? n[0] : n),
                (a = n && n.nodeType ? n.ownerDocument || n : i),
                (e = v.parseHTML(s[1], a, !0)),
                E.test(s[1]) && v.isPlainObject(n) && this.attr.call(e, n, !0),
                v.merge(this, e)
              );
            o = i.getElementById(s[2]);
            if (o && o.parentNode) {
              if (o.id !== s[2]) return r.find(e);
              (this.length = 1), (this[0] = o);
            }
            return (this.context = i), (this.selector = e), this;
          }
          return !n || n.jquery
            ? (n || r).find(e)
            : this.constructor(n).find(e);
        }
        return v.isFunction(e)
          ? r.ready(e)
          : (e.selector !== t &&
              ((this.selector = e.selector), (this.context = e.context)),
            v.makeArray(e, this));
      },
      selector: "",
      jquery: "1.8.3",
      length: 0,
      size: function () {
        return this.length;
      },
      toArray: function () {
        return l.call(this);
      },
      get: function (e) {
        return e == null
          ? this.toArray()
          : e < 0
          ? this[this.length + e]
          : this[e];
      },
      pushStack: function (e, t, n) {
        var r = v.merge(this.constructor(), e);
        return (
          (r.prevObject = this),
          (r.context = this.context),
          t === "find"
            ? (r.selector = this.selector + (this.selector ? " " : "") + n)
            : t && (r.selector = this.selector + "." + t + "(" + n + ")"),
          r
        );
      },
      each: function (e, t) {
        return v.each(this, e, t);
      },
      ready: function (e) {
        return v.ready.promise().done(e), this;
      },
      eq: function (e) {
        return (e = +e), e === -1 ? this.slice(e) : this.slice(e, e + 1);
      },
      first: function () {
        return this.eq(0);
      },
      last: function () {
        return this.eq(-1);
      },
      slice: function () {
        return this.pushStack(
          l.apply(this, arguments),
          "slice",
          l.call(arguments).join(",")
        );
      },
      map: function (e) {
        return this.pushStack(
          v.map(this, function (t, n) {
            return e.call(t, n, t);
          })
        );
      },
      end: function () {
        return this.prevObject || this.constructor(null);
      },
      push: f,
      sort: [].sort,
      splice: [].splice,
    }),
    (v.fn.init.prototype = v.fn),
    (v.extend = v.fn.extend =
      function () {
        var e,
          n,
          r,
          i,
          s,
          o,
          u = arguments[0] || {},
          a = 1,
          f = arguments.length,
          l = !1;
        typeof u == "boolean" && ((l = u), (u = arguments[1] || {}), (a = 2)),
          typeof u != "object" && !v.isFunction(u) && (u = {}),
          f === a && ((u = this), --a);
        for (; a < f; a++)
          if ((e = arguments[a]) != null)
            for (n in e) {
              (r = u[n]), (i = e[n]);
              if (u === i) continue;
              l && i && (v.isPlainObject(i) || (s = v.isArray(i)))
                ? (s
                    ? ((s = !1), (o = r && v.isArray(r) ? r : []))
                    : (o = r && v.isPlainObject(r) ? r : {}),
                  (u[n] = v.extend(l, o, i)))
                : i !== t && (u[n] = i);
            }
        return u;
      }),
    v.extend({
      noConflict: function (t) {
        return e.$ === v && (e.$ = a), t && e.jQuery === v && (e.jQuery = u), v;
      },
      isReady: !1,
      readyWait: 1,
      holdReady: function (e) {
        e ? v.readyWait++ : v.ready(!0);
      },
      ready: function (e) {
        if (e === !0 ? --v.readyWait : v.isReady) return;
        if (!i.body) return setTimeout(v.ready, 1);
        v.isReady = !0;
        if (e !== !0 && --v.readyWait > 0) return;
        r.resolveWith(i, [v]),
          v.fn.trigger && v(i).trigger("ready").off("ready");
      },
      isFunction: function (e) {
        return v.type(e) === "function";
      },
      isArray:
        Array.isArray ||
        function (e) {
          return v.type(e) === "array";
        },
      isWindow: function (e) {
        return e != null && e == e.window;
      },
      isNumeric: function (e) {
        return !isNaN(parseFloat(e)) && isFinite(e);
      },
      type: function (e) {
        return e == null ? String(e) : O[h.call(e)] || "object";
      },
      isPlainObject: function (e) {
        if (!e || v.type(e) !== "object" || e.nodeType || v.isWindow(e))
          return !1;
        try {
          if (
            e.constructor &&
            !p.call(e, "constructor") &&
            !p.call(e.constructor.prototype, "isPrototypeOf")
          )
            return !1;
        } catch (n) {
          return !1;
        }
        var r;
        for (r in e);
        return r === t || p.call(e, r);
      },
      isEmptyObject: function (e) {
        var t;
        for (t in e) return !1;
        return !0;
      },
      error: function (e) {
        throw new Error(e);
      },
      parseHTML: function (e, t, n) {
        var r;
        return !e || typeof e != "string"
          ? null
          : (typeof t == "boolean" && ((n = t), (t = 0)),
            (t = t || i),
            (r = E.exec(e))
              ? [t.createElement(r[1])]
              : ((r = v.buildFragment([e], t, n ? null : [])),
                v.merge(
                  [],
                  (r.cacheable ? v.clone(r.fragment) : r.fragment).childNodes
                )));
      },
      parseJSON: function (t) {
        if (!t || typeof t != "string") return null;
        t = v.trim(t);
        if (e.JSON && e.JSON.parse) return e.JSON.parse(t);
        if (S.test(t.replace(T, "@").replace(N, "]").replace(x, "")))
          return new Function("return " + t)();
        v.error("Invalid JSON: " + t);
      },
      parseXML: function (n) {
        var r, i;
        if (!n || typeof n != "string") return null;
        try {
          e.DOMParser
            ? ((i = new DOMParser()), (r = i.parseFromString(n, "text/xml")))
            : ((r = new ActiveXObject("Microsoft.XMLDOM")),
              (r.async = "false"),
              r.loadXML(n));
        } catch (s) {
          r = t;
        }
        return (
          (!r ||
            !r.documentElement ||
            r.getElementsByTagName("parsererror").length) &&
            v.error("Invalid XML: " + n),
          r
        );
      },
      noop: function () {},
      globalEval: function (t) {
        t &&
          g.test(t) &&
          (
            e.execScript ||
            function (t) {
              e.eval.call(e, t);
            }
          )(t);
      },
      camelCase: function (e) {
        return e.replace(C, "ms-").replace(k, L);
      },
      nodeName: function (e, t) {
        return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase();
      },
      each: function (e, n, r) {
        var i,
          s = 0,
          o = e.length,
          u = o === t || v.isFunction(e);
        if (r) {
          if (u) {
            for (i in e) if (n.apply(e[i], r) === !1) break;
          } else for (; s < o; ) if (n.apply(e[s++], r) === !1) break;
        } else if (u) {
          for (i in e) if (n.call(e[i], i, e[i]) === !1) break;
        } else for (; s < o; ) if (n.call(e[s], s, e[s++]) === !1) break;
        return e;
      },
      trim:
        d && !d.call("\ufeff\u00a0")
          ? function (e) {
              return e == null ? "" : d.call(e);
            }
          : function (e) {
              return e == null ? "" : (e + "").replace(b, "");
            },
      makeArray: function (e, t) {
        var n,
          r = t || [];
        return (
          e != null &&
            ((n = v.type(e)),
            e.length == null ||
            n === "string" ||
            n === "function" ||
            n === "regexp" ||
            v.isWindow(e)
              ? f.call(r, e)
              : v.merge(r, e)),
          r
        );
      },
      inArray: function (e, t, n) {
        var r;
        if (t) {
          if (c) return c.call(t, e, n);
          (r = t.length), (n = n ? (n < 0 ? Math.max(0, r + n) : n) : 0);
          for (; n < r; n++) if (n in t && t[n] === e) return n;
        }
        return -1;
      },
      merge: function (e, n) {
        var r = n.length,
          i = e.length,
          s = 0;
        if (typeof r == "number") for (; s < r; s++) e[i++] = n[s];
        else while (n[s] !== t) e[i++] = n[s++];
        return (e.length = i), e;
      },
      grep: function (e, t, n) {
        var r,
          i = [],
          s = 0,
          o = e.length;
        n = !!n;
        for (; s < o; s++) (r = !!t(e[s], s)), n !== r && i.push(e[s]);
        return i;
      },
      map: function (e, n, r) {
        var i,
          s,
          o = [],
          u = 0,
          a = e.length,
          f =
            e instanceof v ||
            (a !== t &&
              typeof a == "number" &&
              ((a > 0 && e[0] && e[a - 1]) || a === 0 || v.isArray(e)));
        if (f)
          for (; u < a; u++)
            (i = n(e[u], u, r)), i != null && (o[o.length] = i);
        else for (s in e) (i = n(e[s], s, r)), i != null && (o[o.length] = i);
        return o.concat.apply([], o);
      },
      guid: 1,
      proxy: function (e, n) {
        var r, i, s;
        return (
          typeof n == "string" && ((r = e[n]), (n = e), (e = r)),
          v.isFunction(e)
            ? ((i = l.call(arguments, 2)),
              (s = function () {
                return e.apply(n, i.concat(l.call(arguments)));
              }),
              (s.guid = e.guid = e.guid || v.guid++),
              s)
            : t
        );
      },
      access: function (e, n, r, i, s, o, u) {
        var a,
          f = r == null,
          l = 0,
          c = e.length;
        if (r && typeof r == "object") {
          for (l in r) v.access(e, n, l, r[l], 1, o, i);
          s = 1;
        } else if (i !== t) {
          (a = u === t && v.isFunction(i)),
            f &&
              (a
                ? ((a = n),
                  (n = function (e, t, n) {
                    return a.call(v(e), n);
                  }))
                : (n.call(e, i), (n = null)));
          if (n)
            for (; l < c; l++)
              n(e[l], r, a ? i.call(e[l], l, n(e[l], r)) : i, u);
          s = 1;
        }
        return s ? e : f ? n.call(e) : c ? n(e[0], r) : o;
      },
      now: function () {
        return new Date().getTime();
      },
    }),
    (v.ready.promise = function (t) {
      if (!r) {
        r = v.Deferred();
        if (i.readyState === "complete") setTimeout(v.ready, 1);
        else if (i.addEventListener)
          i.addEventListener("DOMContentLoaded", A, !1),
            e.addEventListener("load", v.ready, !1);
        else {
          i.attachEvent("onreadystatechange", A),
            e.attachEvent("onload", v.ready);
          var n = !1;
          try {
            n = e.frameElement == null && i.documentElement;
          } catch (s) {}
          n &&
            n.doScroll &&
            (function o() {
              if (!v.isReady) {
                try {
                  n.doScroll("left");
                } catch (e) {
                  return setTimeout(o, 50);
                }
                v.ready();
              }
            })();
        }
      }
      return r.promise(t);
    }),
    v.each(
      "Boolean Number String Function Array Date RegExp Object".split(" "),
      function (e, t) {
        O["[object " + t + "]"] = t.toLowerCase();
      }
    ),
    (n = v(i));
  var M = {};
  (v.Callbacks = function (e) {
    e = typeof e == "string" ? M[e] || _(e) : v.extend({}, e);
    var n,
      r,
      i,
      s,
      o,
      u,
      a = [],
      f = !e.once && [],
      l = function (t) {
        (n = e.memory && t),
          (r = !0),
          (u = s || 0),
          (s = 0),
          (o = a.length),
          (i = !0);
        for (; a && u < o; u++)
          if (a[u].apply(t[0], t[1]) === !1 && e.stopOnFalse) {
            n = !1;
            break;
          }
        (i = !1),
          a && (f ? f.length && l(f.shift()) : n ? (a = []) : c.disable());
      },
      c = {
        add: function () {
          if (a) {
            var t = a.length;
            (function r(t) {
              v.each(t, function (t, n) {
                var i = v.type(n);
                i === "function"
                  ? (!e.unique || !c.has(n)) && a.push(n)
                  : n && n.length && i !== "string" && r(n);
              });
            })(arguments),
              i ? (o = a.length) : n && ((s = t), l(n));
          }
          return this;
        },
        remove: function () {
          return (
            a &&
              v.each(arguments, function (e, t) {
                var n;
                while ((n = v.inArray(t, a, n)) > -1)
                  a.splice(n, 1), i && (n <= o && o--, n <= u && u--);
              }),
            this
          );
        },
        has: function (e) {
          return v.inArray(e, a) > -1;
        },
        empty: function () {
          return (a = []), this;
        },
        disable: function () {
          return (a = f = n = t), this;
        },
        disabled: function () {
          return !a;
        },
        lock: function () {
          return (f = t), n || c.disable(), this;
        },
        locked: function () {
          return !f;
        },
        fireWith: function (e, t) {
          return (
            (t = t || []),
            (t = [e, t.slice ? t.slice() : t]),
            a && (!r || f) && (i ? f.push(t) : l(t)),
            this
          );
        },
        fire: function () {
          return c.fireWith(this, arguments), this;
        },
        fired: function () {
          return !!r;
        },
      };
    return c;
  }),
    v.extend({
      Deferred: function (e) {
        var t = [
            ["resolve", "done", v.Callbacks("once memory"), "resolved"],
            ["reject", "fail", v.Callbacks("once memory"), "rejected"],
            ["notify", "progress", v.Callbacks("memory")],
          ],
          n = "pending",
          r = {
            state: function () {
              return n;
            },
            always: function () {
              return i.done(arguments).fail(arguments), this;
            },
            then: function () {
              var e = arguments;
              return v
                .Deferred(function (n) {
                  v.each(t, function (t, r) {
                    var s = r[0],
                      o = e[t];
                    i[r[1]](
                      v.isFunction(o)
                        ? function () {
                            var e = o.apply(this, arguments);
                            e && v.isFunction(e.promise)
                              ? e
                                  .promise()
                                  .done(n.resolve)
                                  .fail(n.reject)
                                  .progress(n.notify)
                              : n[s + "With"](this === i ? n : this, [e]);
                          }
                        : n[s]
                    );
                  }),
                    (e = null);
                })
                .promise();
            },
            promise: function (e) {
              return e != null ? v.extend(e, r) : r;
            },
          },
          i = {};
        return (
          (r.pipe = r.then),
          v.each(t, function (e, s) {
            var o = s[2],
              u = s[3];
            (r[s[1]] = o.add),
              u &&
                o.add(
                  function () {
                    n = u;
                  },
                  t[e ^ 1][2].disable,
                  t[2][2].lock
                ),
              (i[s[0]] = o.fire),
              (i[s[0] + "With"] = o.fireWith);
          }),
          r.promise(i),
          e && e.call(i, i),
          i
        );
      },
      when: function (e) {
        var t = 0,
          n = l.call(arguments),
          r = n.length,
          i = r !== 1 || (e && v.isFunction(e.promise)) ? r : 0,
          s = i === 1 ? e : v.Deferred(),
          o = function (e, t, n) {
            return function (r) {
              (t[e] = this),
                (n[e] = arguments.length > 1 ? l.call(arguments) : r),
                n === u ? s.notifyWith(t, n) : --i || s.resolveWith(t, n);
            };
          },
          u,
          a,
          f;
        if (r > 1) {
          (u = new Array(r)), (a = new Array(r)), (f = new Array(r));
          for (; t < r; t++)
            n[t] && v.isFunction(n[t].promise)
              ? n[t]
                  .promise()
                  .done(o(t, f, n))
                  .fail(s.reject)
                  .progress(o(t, a, u))
              : --i;
        }
        return i || s.resolveWith(f, n), s.promise();
      },
    }),
    (v.support = (function () {
      var t,
        n,
        r,
        s,
        o,
        u,
        a,
        f,
        l,
        c,
        h,
        p = i.createElement("div");
      p.setAttribute("className", "t"),
        (p.innerHTML =
          "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>"),
        (n = p.getElementsByTagName("*")),
        (r = p.getElementsByTagName("a")[0]);
      if (!n || !r || !n.length) return {};
      (s = i.createElement("select")),
        (o = s.appendChild(i.createElement("option"))),
        (u = p.getElementsByTagName("input")[0]),
        (r.style.cssText = "top:1px;float:left;opacity:.5"),
        (t = {
          leadingWhitespace: p.firstChild.nodeType === 3,
          tbody: !p.getElementsByTagName("tbody").length,
          htmlSerialize: !!p.getElementsByTagName("link").length,
          style: /top/.test(r.getAttribute("style")),
          hrefNormalized: r.getAttribute("href") === "/a",
          opacity: /^0.5/.test(r.style.opacity),
          cssFloat: !!r.style.cssFloat,
          checkOn: u.value === "on",
          optSelected: o.selected,
          getSetAttribute: p.className !== "t",
          enctype: !!i.createElement("form").enctype,
          html5Clone:
            i.createElement("nav").cloneNode(!0).outerHTML !== "<:nav></:nav>",
          boxModel: i.compatMode === "CSS1Compat",
          submitBubbles: !0,
          changeBubbles: !0,
          focusinBubbles: !1,
          deleteExpando: !0,
          noCloneEvent: !0,
          inlineBlockNeedsLayout: !1,
          shrinkWrapBlocks: !1,
          reliableMarginRight: !0,
          boxSizingReliable: !0,
          pixelPosition: !1,
        }),
        (u.checked = !0),
        (t.noCloneChecked = u.cloneNode(!0).checked),
        (s.disabled = !0),
        (t.optDisabled = !o.disabled);
      try {
        delete p.test;
      } catch (d) {
        t.deleteExpando = !1;
      }
      !p.addEventListener &&
        p.attachEvent &&
        p.fireEvent &&
        (p.attachEvent(
          "onclick",
          (h = function () {
            t.noCloneEvent = !1;
          })
        ),
        p.cloneNode(!0).fireEvent("onclick"),
        p.detachEvent("onclick", h)),
        (u = i.createElement("input")),
        (u.value = "t"),
        u.setAttribute("type", "radio"),
        (t.radioValue = u.value === "t"),
        u.setAttribute("checked", "checked"),
        u.setAttribute("name", "t"),
        p.appendChild(u),
        (a = i.createDocumentFragment()),
        a.appendChild(p.lastChild),
        (t.checkClone = a.cloneNode(!0).cloneNode(!0).lastChild.checked),
        (t.appendChecked = u.checked),
        a.removeChild(u),
        a.appendChild(p);
      if (p.attachEvent)
        for (l in { submit: !0, change: !0, focusin: !0 })
          (f = "on" + l),
            (c = f in p),
            c ||
              (p.setAttribute(f, "return;"), (c = typeof p[f] == "function")),
            (t[l + "Bubbles"] = c);
      return (
        v(function () {
          var n,
            r,
            s,
            o,
            u = "padding:0;margin:0;border:0;display:block;overflow:hidden;",
            a = i.getElementsByTagName("body")[0];
          if (!a) return;
          (n = i.createElement("div")),
            (n.style.cssText =
              "visibility:hidden;border:0;width:0;height:0;position:static;top:0;margin-top:1px"),
            a.insertBefore(n, a.firstChild),
            (r = i.createElement("div")),
            n.appendChild(r),
            (r.innerHTML = "<table><tr><td></td><td>t</td></tr></table>"),
            (s = r.getElementsByTagName("td")),
            (s[0].style.cssText = "padding:0;margin:0;border:0;display:none"),
            (c = s[0].offsetHeight === 0),
            (s[0].style.display = ""),
            (s[1].style.display = "none"),
            (t.reliableHiddenOffsets = c && s[0].offsetHeight === 0),
            (r.innerHTML = ""),
            (r.style.cssText =
              "box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;position:absolute;top:1%;"),
            (t.boxSizing = r.offsetWidth === 4),
            (t.doesNotIncludeMarginInBodyOffset = a.offsetTop !== 1),
            e.getComputedStyle &&
              ((t.pixelPosition =
                (e.getComputedStyle(r, null) || {}).top !== "1%"),
              (t.boxSizingReliable =
                (e.getComputedStyle(r, null) || { width: "4px" }).width ===
                "4px"),
              (o = i.createElement("div")),
              (o.style.cssText = r.style.cssText = u),
              (o.style.marginRight = o.style.width = "0"),
              (r.style.width = "1px"),
              r.appendChild(o),
              (t.reliableMarginRight = !parseFloat(
                (e.getComputedStyle(o, null) || {}).marginRight
              ))),
            typeof r.style.zoom != "undefined" &&
              ((r.innerHTML = ""),
              (r.style.cssText =
                u + "width:1px;padding:1px;display:inline;zoom:1"),
              (t.inlineBlockNeedsLayout = r.offsetWidth === 3),
              (r.style.display = "block"),
              (r.style.overflow = "visible"),
              (r.innerHTML = "<div></div>"),
              (r.firstChild.style.width = "5px"),
              (t.shrinkWrapBlocks = r.offsetWidth !== 3),
              (n.style.zoom = 1)),
            a.removeChild(n),
            (n = r = s = o = null);
        }),
        a.removeChild(p),
        (n = r = s = o = u = a = p = null),
        t
      );
    })());
  var D = /(?:\{[\s\S]*\}|\[[\s\S]*\])$/,
    P = /([A-Z])/g;
  v.extend({
    cache: {},
    deletedIds: [],
    uuid: 0,
    expando: "jQuery" + (v.fn.jquery + Math.random()).replace(/\D/g, ""),
    noData: {
      embed: !0,
      object: "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000",
      applet: !0,
    },
    hasData: function (e) {
      return (
        (e = e.nodeType ? v.cache[e[v.expando]] : e[v.expando]), !!e && !B(e)
      );
    },
    data: function (e, n, r, i) {
      if (!v.acceptData(e)) return;
      var s,
        o,
        u = v.expando,
        a = typeof n == "string",
        f = e.nodeType,
        l = f ? v.cache : e,
        c = f ? e[u] : e[u] && u;
      if ((!c || !l[c] || (!i && !l[c].data)) && a && r === t) return;
      c || (f ? (e[u] = c = v.deletedIds.pop() || v.guid++) : (c = u)),
        l[c] || ((l[c] = {}), f || (l[c].toJSON = v.noop));
      if (typeof n == "object" || typeof n == "function")
        i ? (l[c] = v.extend(l[c], n)) : (l[c].data = v.extend(l[c].data, n));
      return (
        (s = l[c]),
        i || (s.data || (s.data = {}), (s = s.data)),
        r !== t && (s[v.camelCase(n)] = r),
        a ? ((o = s[n]), o == null && (o = s[v.camelCase(n)])) : (o = s),
        o
      );
    },
    removeData: function (e, t, n) {
      if (!v.acceptData(e)) return;
      var r,
        i,
        s,
        o = e.nodeType,
        u = o ? v.cache : e,
        a = o ? e[v.expando] : v.expando;
      if (!u[a]) return;
      if (t) {
        r = n ? u[a] : u[a].data;
        if (r) {
          v.isArray(t) ||
            (t in r
              ? (t = [t])
              : ((t = v.camelCase(t)),
                t in r ? (t = [t]) : (t = t.split(" "))));
          for (i = 0, s = t.length; i < s; i++) delete r[t[i]];
          if (!(n ? B : v.isEmptyObject)(r)) return;
        }
      }
      if (!n) {
        delete u[a].data;
        if (!B(u[a])) return;
      }
      o
        ? v.cleanData([e], !0)
        : v.support.deleteExpando || u != u.window
        ? delete u[a]
        : (u[a] = null);
    },
    _data: function (e, t, n) {
      return v.data(e, t, n, !0);
    },
    acceptData: function (e) {
      var t = e.nodeName && v.noData[e.nodeName.toLowerCase()];
      return !t || (t !== !0 && e.getAttribute("classid") === t);
    },
  }),
    v.fn.extend({
      data: function (e, n) {
        var r,
          i,
          s,
          o,
          u,
          a = this[0],
          f = 0,
          l = null;
        if (e === t) {
          if (this.length) {
            l = v.data(a);
            if (a.nodeType === 1 && !v._data(a, "parsedAttrs")) {
              s = a.attributes;
              for (u = s.length; f < u; f++)
                (o = s[f].name),
                  o.indexOf("data-") ||
                    ((o = v.camelCase(o.substring(5))), H(a, o, l[o]));
              v._data(a, "parsedAttrs", !0);
            }
          }
          return l;
        }
        return typeof e == "object"
          ? this.each(function () {
              v.data(this, e);
            })
          : ((r = e.split(".", 2)),
            (r[1] = r[1] ? "." + r[1] : ""),
            (i = r[1] + "!"),
            v.access(
              this,
              function (n) {
                if (n === t)
                  return (
                    (l = this.triggerHandler("getData" + i, [r[0]])),
                    l === t && a && ((l = v.data(a, e)), (l = H(a, e, l))),
                    l === t && r[1] ? this.data(r[0]) : l
                  );
                (r[1] = n),
                  this.each(function () {
                    var t = v(this);
                    t.triggerHandler("setData" + i, r),
                      v.data(this, e, n),
                      t.triggerHandler("changeData" + i, r);
                  });
              },
              null,
              n,
              arguments.length > 1,
              null,
              !1
            ));
      },
      removeData: function (e) {
        return this.each(function () {
          v.removeData(this, e);
        });
      },
    }),
    v.extend({
      queue: function (e, t, n) {
        var r;
        if (e)
          return (
            (t = (t || "fx") + "queue"),
            (r = v._data(e, t)),
            n &&
              (!r || v.isArray(n)
                ? (r = v._data(e, t, v.makeArray(n)))
                : r.push(n)),
            r || []
          );
      },
      dequeue: function (e, t) {
        t = t || "fx";
        var n = v.queue(e, t),
          r = n.length,
          i = n.shift(),
          s = v._queueHooks(e, t),
          o = function () {
            v.dequeue(e, t);
          };
        i === "inprogress" && ((i = n.shift()), r--),
          i &&
            (t === "fx" && n.unshift("inprogress"),
            delete s.stop,
            i.call(e, o, s)),
          !r && s && s.empty.fire();
      },
      _queueHooks: function (e, t) {
        var n = t + "queueHooks";
        return (
          v._data(e, n) ||
          v._data(e, n, {
            empty: v.Callbacks("once memory").add(function () {
              v.removeData(e, t + "queue", !0), v.removeData(e, n, !0);
            }),
          })
        );
      },
    }),
    v.fn.extend({
      queue: function (e, n) {
        var r = 2;
        return (
          typeof e != "string" && ((n = e), (e = "fx"), r--),
          arguments.length < r
            ? v.queue(this[0], e)
            : n === t
            ? this
            : this.each(function () {
                var t = v.queue(this, e, n);
                v._queueHooks(this, e),
                  e === "fx" && t[0] !== "inprogress" && v.dequeue(this, e);
              })
        );
      },
      dequeue: function (e) {
        return this.each(function () {
          v.dequeue(this, e);
        });
      },
      delay: function (e, t) {
        return (
          (e = v.fx ? v.fx.speeds[e] || e : e),
          (t = t || "fx"),
          this.queue(t, function (t, n) {
            var r = setTimeout(t, e);
            n.stop = function () {
              clearTimeout(r);
            };
          })
        );
      },
      clearQueue: function (e) {
        return this.queue(e || "fx", []);
      },
      promise: function (e, n) {
        var r,
          i = 1,
          s = v.Deferred(),
          o = this,
          u = this.length,
          a = function () {
            --i || s.resolveWith(o, [o]);
          };
        typeof e != "string" && ((n = e), (e = t)), (e = e || "fx");
        while (u--)
          (r = v._data(o[u], e + "queueHooks")),
            r && r.empty && (i++, r.empty.add(a));
        return a(), s.promise(n);
      },
    });
  var j,
    F,
    I,
    q = /[\t\r\n]/g,
    R = /\r/g,
    U = /^(?:button|input)$/i,
    z = /^(?:button|input|object|select|textarea)$/i,
    W = /^a(?:rea|)$/i,
    X =
      /^(?:autofocus|autoplay|async|checked|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped|selected)$/i,
    V = v.support.getSetAttribute;
  v.fn.extend({
    attr: function (e, t) {
      return v.access(this, v.attr, e, t, arguments.length > 1);
    },
    removeAttr: function (e) {
      return this.each(function () {
        v.removeAttr(this, e);
      });
    },
    prop: function (e, t) {
      return v.access(this, v.prop, e, t, arguments.length > 1);
    },
    removeProp: function (e) {
      return (
        (e = v.propFix[e] || e),
        this.each(function () {
          try {
            (this[e] = t), delete this[e];
          } catch (n) {}
        })
      );
    },
    addClass: function (e) {
      var t, n, r, i, s, o, u;
      if (v.isFunction(e))
        return this.each(function (t) {
          v(this).addClass(e.call(this, t, this.className));
        });
      if (e && typeof e == "string") {
        t = e.split(y);
        for (n = 0, r = this.length; n < r; n++) {
          i = this[n];
          if (i.nodeType === 1)
            if (!i.className && t.length === 1) i.className = e;
            else {
              s = " " + i.className + " ";
              for (o = 0, u = t.length; o < u; o++)
                s.indexOf(" " + t[o] + " ") < 0 && (s += t[o] + " ");
              i.className = v.trim(s);
            }
        }
      }
      return this;
    },
    removeClass: function (e) {
      var n, r, i, s, o, u, a;
      if (v.isFunction(e))
        return this.each(function (t) {
          v(this).removeClass(e.call(this, t, this.className));
        });
      if ((e && typeof e == "string") || e === t) {
        n = (e || "").split(y);
        for (u = 0, a = this.length; u < a; u++) {
          i = this[u];
          if (i.nodeType === 1 && i.className) {
            r = (" " + i.className + " ").replace(q, " ");
            for (s = 0, o = n.length; s < o; s++)
              while (r.indexOf(" " + n[s] + " ") >= 0)
                r = r.replace(" " + n[s] + " ", " ");
            i.className = e ? v.trim(r) : "";
          }
        }
      }
      return this;
    },
    toggleClass: function (e, t) {
      var n = typeof e,
        r = typeof t == "boolean";
      return v.isFunction(e)
        ? this.each(function (n) {
            v(this).toggleClass(e.call(this, n, this.className, t), t);
          })
        : this.each(function () {
            if (n === "string") {
              var i,
                s = 0,
                o = v(this),
                u = t,
                a = e.split(y);
              while ((i = a[s++]))
                (u = r ? u : !o.hasClass(i)),
                  o[u ? "addClass" : "removeClass"](i);
            } else if (n === "undefined" || n === "boolean") this.className && v._data(this, "__className__", this.className), (this.className = this.className || e === !1 ? "" : v._data(this, "__className__") || "");
          });
    },
    hasClass: function (e) {
      var t = " " + e + " ",
        n = 0,
        r = this.length;
      for (; n < r; n++)
        if (
          this[n].nodeType === 1 &&
          (" " + this[n].className + " ").replace(q, " ").indexOf(t) >= 0
        )
          return !0;
      return !1;
    },
    val: function (e) {
      var n,
        r,
        i,
        s = this[0];
      if (!arguments.length) {
        if (s)
          return (
            (n = v.valHooks[s.type] || v.valHooks[s.nodeName.toLowerCase()]),
            n && "get" in n && (r = n.get(s, "value")) !== t
              ? r
              : ((r = s.value),
                typeof r == "string" ? r.replace(R, "") : r == null ? "" : r)
          );
        return;
      }
      return (
        (i = v.isFunction(e)),
        this.each(function (r) {
          var s,
            o = v(this);
          if (this.nodeType !== 1) return;
          i ? (s = e.call(this, r, o.val())) : (s = e),
            s == null
              ? (s = "")
              : typeof s == "number"
              ? (s += "")
              : v.isArray(s) &&
                (s = v.map(s, function (e) {
                  return e == null ? "" : e + "";
                })),
            (n =
              v.valHooks[this.type] || v.valHooks[this.nodeName.toLowerCase()]);
          if (!n || !("set" in n) || n.set(this, s, "value") === t)
            this.value = s;
        })
      );
    },
  }),
    v.extend({
      valHooks: {
        option: {
          get: function (e) {
            var t = e.attributes.value;
            return !t || t.specified ? e.value : e.text;
          },
        },
        select: {
          get: function (e) {
            var t,
              n,
              r = e.options,
              i = e.selectedIndex,
              s = e.type === "select-one" || i < 0,
              o = s ? null : [],
              u = s ? i + 1 : r.length,
              a = i < 0 ? u : s ? i : 0;
            for (; a < u; a++) {
              n = r[a];
              if (
                (n.selected || a === i) &&
                (v.support.optDisabled
                  ? !n.disabled
                  : n.getAttribute("disabled") === null) &&
                (!n.parentNode.disabled ||
                  !v.nodeName(n.parentNode, "optgroup"))
              ) {
                t = v(n).val();
                if (s) return t;
                o.push(t);
              }
            }
            return o;
          },
          set: function (e, t) {
            var n = v.makeArray(t);
            return (
              v(e)
                .find("option")
                .each(function () {
                  this.selected = v.inArray(v(this).val(), n) >= 0;
                }),
              n.length || (e.selectedIndex = -1),
              n
            );
          },
        },
      },
      attrFn: {},
      attr: function (e, n, r, i) {
        var s,
          o,
          u,
          a = e.nodeType;
        if (!e || a === 3 || a === 8 || a === 2) return;
        if (i && v.isFunction(v.fn[n])) return v(e)[n](r);
        if (typeof e.getAttribute == "undefined") return v.prop(e, n, r);
        (u = a !== 1 || !v.isXMLDoc(e)),
          u &&
            ((n = n.toLowerCase()),
            (o = v.attrHooks[n] || (X.test(n) ? F : j)));
        if (r !== t) {
          if (r === null) {
            v.removeAttr(e, n);
            return;
          }
          return o && "set" in o && u && (s = o.set(e, r, n)) !== t
            ? s
            : (e.setAttribute(n, r + ""), r);
        }
        return o && "get" in o && u && (s = o.get(e, n)) !== null
          ? s
          : ((s = e.getAttribute(n)), s === null ? t : s);
      },
      removeAttr: function (e, t) {
        var n,
          r,
          i,
          s,
          o = 0;
        if (t && e.nodeType === 1) {
          r = t.split(y);
          for (; o < r.length; o++)
            (i = r[o]),
              i &&
                ((n = v.propFix[i] || i),
                (s = X.test(i)),
                s || v.attr(e, i, ""),
                e.removeAttribute(V ? i : n),
                s && n in e && (e[n] = !1));
        }
      },
      attrHooks: {
        type: {
          set: function (e, t) {
            if (U.test(e.nodeName) && e.parentNode)
              v.error("type property can't be changed");
            else if (
              !v.support.radioValue &&
              t === "radio" &&
              v.nodeName(e, "input")
            ) {
              var n = e.value;
              return e.setAttribute("type", t), n && (e.value = n), t;
            }
          },
        },
        value: {
          get: function (e, t) {
            return j && v.nodeName(e, "button")
              ? j.get(e, t)
              : t in e
              ? e.value
              : null;
          },
          set: function (e, t, n) {
            if (j && v.nodeName(e, "button")) return j.set(e, t, n);
            e.value = t;
          },
        },
      },
      propFix: {
        tabindex: "tabIndex",
        readonly: "readOnly",
        for: "htmlFor",
        class: "className",
        maxlength: "maxLength",
        cellspacing: "cellSpacing",
        cellpadding: "cellPadding",
        rowspan: "rowSpan",
        colspan: "colSpan",
        usemap: "useMap",
        frameborder: "frameBorder",
        contenteditable: "contentEditable",
      },
      prop: function (e, n, r) {
        var i,
          s,
          o,
          u = e.nodeType;
        if (!e || u === 3 || u === 8 || u === 2) return;
        return (
          (o = u !== 1 || !v.isXMLDoc(e)),
          o && ((n = v.propFix[n] || n), (s = v.propHooks[n])),
          r !== t
            ? s && "set" in s && (i = s.set(e, r, n)) !== t
              ? i
              : (e[n] = r)
            : s && "get" in s && (i = s.get(e, n)) !== null
            ? i
            : e[n]
        );
      },
      propHooks: {
        tabIndex: {
          get: function (e) {
            var n = e.getAttributeNode("tabindex");
            return n && n.specified
              ? parseInt(n.value, 10)
              : z.test(e.nodeName) || (W.test(e.nodeName) && e.href)
              ? 0
              : t;
          },
        },
      },
    }),
    (F = {
      get: function (e, n) {
        var r,
          i = v.prop(e, n);
        return i === !0 ||
          (typeof i != "boolean" &&
            (r = e.getAttributeNode(n)) &&
            r.nodeValue !== !1)
          ? n.toLowerCase()
          : t;
      },
      set: function (e, t, n) {
        var r;
        return (
          t === !1
            ? v.removeAttr(e, n)
            : ((r = v.propFix[n] || n),
              r in e && (e[r] = !0),
              e.setAttribute(n, n.toLowerCase())),
          n
        );
      },
    }),
    V ||
      ((I = { name: !0, id: !0, coords: !0 }),
      (j = v.valHooks.button =
        {
          get: function (e, n) {
            var r;
            return (
              (r = e.getAttributeNode(n)),
              r && (I[n] ? r.value !== "" : r.specified) ? r.value : t
            );
          },
          set: function (e, t, n) {
            var r = e.getAttributeNode(n);
            return (
              r || ((r = i.createAttribute(n)), e.setAttributeNode(r)),
              (r.value = t + "")
            );
          },
        }),
      v.each(["width", "height"], function (e, t) {
        v.attrHooks[t] = v.extend(v.attrHooks[t], {
          set: function (e, n) {
            if (n === "") return e.setAttribute(t, "auto"), n;
          },
        });
      }),
      (v.attrHooks.contenteditable = {
        get: j.get,
        set: function (e, t, n) {
          t === "" && (t = "false"), j.set(e, t, n);
        },
      })),
    v.support.hrefNormalized ||
      v.each(["href", "src", "width", "height"], function (e, n) {
        v.attrHooks[n] = v.extend(v.attrHooks[n], {
          get: function (e) {
            var r = e.getAttribute(n, 2);
            return r === null ? t : r;
          },
        });
      }),
    v.support.style ||
      (v.attrHooks.style = {
        get: function (e) {
          return e.style.cssText.toLowerCase() || t;
        },
        set: function (e, t) {
          return (e.style.cssText = t + "");
        },
      }),
    v.support.optSelected ||
      (v.propHooks.selected = v.extend(v.propHooks.selected, {
        get: function (e) {
          var t = e.parentNode;
          return (
            t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex),
            null
          );
        },
      })),
    v.support.enctype || (v.propFix.enctype = "encoding"),
    v.support.checkOn ||
      v.each(["radio", "checkbox"], function () {
        v.valHooks[this] = {
          get: function (e) {
            return e.getAttribute("value") === null ? "on" : e.value;
          },
        };
      }),
    v.each(["radio", "checkbox"], function () {
      v.valHooks[this] = v.extend(v.valHooks[this], {
        set: function (e, t) {
          if (v.isArray(t)) return (e.checked = v.inArray(v(e).val(), t) >= 0);
        },
      });
    });
  var $ = /^(?:textarea|input|select)$/i,
    J = /^([^\.]*|)(?:\.(.+)|)$/,
    K = /(?:^|\s)hover(\.\S+|)\b/,
    Q = /^key/,
    G = /^(?:mouse|contextmenu)|click/,
    Y = /^(?:focusinfocus|focusoutblur)$/,
    Z = function (e) {
      return v.event.special.hover
        ? e
        : e.replace(K, "mouseenter$1 mouseleave$1");
    };
  (v.event = {
    add: function (e, n, r, i, s) {
      var o, u, a, f, l, c, h, p, d, m, g;
      if (e.nodeType === 3 || e.nodeType === 8 || !n || !r || !(o = v._data(e)))
        return;
      r.handler && ((d = r), (r = d.handler), (s = d.selector)),
        r.guid || (r.guid = v.guid++),
        (a = o.events),
        a || (o.events = a = {}),
        (u = o.handle),
        u ||
          ((o.handle = u =
            function (e) {
              return typeof v == "undefined" ||
                (!!e && v.event.triggered === e.type)
                ? t
                : v.event.dispatch.apply(u.elem, arguments);
            }),
          (u.elem = e)),
        (n = v.trim(Z(n)).split(" "));
      for (f = 0; f < n.length; f++) {
        (l = J.exec(n[f]) || []),
          (c = l[1]),
          (h = (l[2] || "").split(".").sort()),
          (g = v.event.special[c] || {}),
          (c = (s ? g.delegateType : g.bindType) || c),
          (g = v.event.special[c] || {}),
          (p = v.extend(
            {
              type: c,
              origType: l[1],
              data: i,
              handler: r,
              guid: r.guid,
              selector: s,
              needsContext: s && v.expr.match.needsContext.test(s),
              namespace: h.join("."),
            },
            d
          )),
          (m = a[c]);
        if (!m) {
          (m = a[c] = []), (m.delegateCount = 0);
          if (!g.setup || g.setup.call(e, i, h, u) === !1)
            e.addEventListener
              ? e.addEventListener(c, u, !1)
              : e.attachEvent && e.attachEvent("on" + c, u);
        }
        g.add &&
          (g.add.call(e, p), p.handler.guid || (p.handler.guid = r.guid)),
          s ? m.splice(m.delegateCount++, 0, p) : m.push(p),
          (v.event.global[c] = !0);
      }
      e = null;
    },
    global: {},
    remove: function (e, t, n, r, i) {
      var s,
        o,
        u,
        a,
        f,
        l,
        c,
        h,
        p,
        d,
        m,
        g = v.hasData(e) && v._data(e);
      if (!g || !(h = g.events)) return;
      t = v.trim(Z(t || "")).split(" ");
      for (s = 0; s < t.length; s++) {
        (o = J.exec(t[s]) || []), (u = a = o[1]), (f = o[2]);
        if (!u) {
          for (u in h) v.event.remove(e, u + t[s], n, r, !0);
          continue;
        }
        (p = v.event.special[u] || {}),
          (u = (r ? p.delegateType : p.bindType) || u),
          (d = h[u] || []),
          (l = d.length),
          (f = f
            ? new RegExp(
                "(^|\\.)" +
                  f.split(".").sort().join("\\.(?:.*\\.|)") +
                  "(\\.|$)"
              )
            : null);
        for (c = 0; c < d.length; c++)
          (m = d[c]),
            (i || a === m.origType) &&
              (!n || n.guid === m.guid) &&
              (!f || f.test(m.namespace)) &&
              (!r || r === m.selector || (r === "**" && m.selector)) &&
              (d.splice(c--, 1),
              m.selector && d.delegateCount--,
              p.remove && p.remove.call(e, m));
        d.length === 0 &&
          l !== d.length &&
          ((!p.teardown || p.teardown.call(e, f, g.handle) === !1) &&
            v.removeEvent(e, u, g.handle),
          delete h[u]);
      }
      v.isEmptyObject(h) && (delete g.handle, v.removeData(e, "events", !0));
    },
    customEvent: { getData: !0, setData: !0, changeData: !0 },
    trigger: function (n, r, s, o) {
      if (!s || (s.nodeType !== 3 && s.nodeType !== 8)) {
        var u,
          a,
          f,
          l,
          c,
          h,
          p,
          d,
          m,
          g,
          y = n.type || n,
          b = [];
        if (Y.test(y + v.event.triggered)) return;
        y.indexOf("!") >= 0 && ((y = y.slice(0, -1)), (a = !0)),
          y.indexOf(".") >= 0 &&
            ((b = y.split(".")), (y = b.shift()), b.sort());
        if ((!s || v.event.customEvent[y]) && !v.event.global[y]) return;
        (n =
          typeof n == "object"
            ? n[v.expando]
              ? n
              : new v.Event(y, n)
            : new v.Event(y)),
          (n.type = y),
          (n.isTrigger = !0),
          (n.exclusive = a),
          (n.namespace = b.join(".")),
          (n.namespace_re = n.namespace
            ? new RegExp("(^|\\.)" + b.join("\\.(?:.*\\.|)") + "(\\.|$)")
            : null),
          (h = y.indexOf(":") < 0 ? "on" + y : "");
        if (!s) {
          u = v.cache;
          for (f in u)
            u[f].events &&
              u[f].events[y] &&
              v.event.trigger(n, r, u[f].handle.elem, !0);
          return;
        }
        (n.result = t),
          n.target || (n.target = s),
          (r = r != null ? v.makeArray(r) : []),
          r.unshift(n),
          (p = v.event.special[y] || {});
        if (p.trigger && p.trigger.apply(s, r) === !1) return;
        m = [[s, p.bindType || y]];
        if (!o && !p.noBubble && !v.isWindow(s)) {
          (g = p.delegateType || y), (l = Y.test(g + y) ? s : s.parentNode);
          for (c = s; l; l = l.parentNode) m.push([l, g]), (c = l);
          c === (s.ownerDocument || i) &&
            m.push([c.defaultView || c.parentWindow || e, g]);
        }
        for (f = 0; f < m.length && !n.isPropagationStopped(); f++)
          (l = m[f][0]),
            (n.type = m[f][1]),
            (d = (v._data(l, "events") || {})[n.type] && v._data(l, "handle")),
            d && d.apply(l, r),
            (d = h && l[h]),
            d &&
              v.acceptData(l) &&
              d.apply &&
              d.apply(l, r) === !1 &&
              n.preventDefault();
        return (
          (n.type = y),
          !o &&
            !n.isDefaultPrevented() &&
            (!p._default || p._default.apply(s.ownerDocument, r) === !1) &&
            (y !== "click" || !v.nodeName(s, "a")) &&
            v.acceptData(s) &&
            h &&
            s[y] &&
            ((y !== "focus" && y !== "blur") || n.target.offsetWidth !== 0) &&
            !v.isWindow(s) &&
            ((c = s[h]),
            c && (s[h] = null),
            (v.event.triggered = y),
            s[y](),
            (v.event.triggered = t),
            c && (s[h] = c)),
          n.result
        );
      }
      return;
    },
    dispatch: function (n) {
      n = v.event.fix(n || e.event);
      var r,
        i,
        s,
        o,
        u,
        a,
        f,
        c,
        h,
        p,
        d = (v._data(this, "events") || {})[n.type] || [],
        m = d.delegateCount,
        g = l.call(arguments),
        y = !n.exclusive && !n.namespace,
        b = v.event.special[n.type] || {},
        w = [];
      (g[0] = n), (n.delegateTarget = this);
      if (b.preDispatch && b.preDispatch.call(this, n) === !1) return;
      if (m && (!n.button || n.type !== "click"))
        for (s = n.target; s != this; s = s.parentNode || this)
          if (s.disabled !== !0 || n.type !== "click") {
            (u = {}), (f = []);
            for (r = 0; r < m; r++)
              (c = d[r]),
                (h = c.selector),
                u[h] === t &&
                  (u[h] = c.needsContext
                    ? v(h, this).index(s) >= 0
                    : v.find(h, this, null, [s]).length),
                u[h] && f.push(c);
            f.length && w.push({ elem: s, matches: f });
          }
      d.length > m && w.push({ elem: this, matches: d.slice(m) });
      for (r = 0; r < w.length && !n.isPropagationStopped(); r++) {
        (a = w[r]), (n.currentTarget = a.elem);
        for (
          i = 0;
          i < a.matches.length && !n.isImmediatePropagationStopped();
          i++
        ) {
          c = a.matches[i];
          if (
            y ||
            (!n.namespace && !c.namespace) ||
            (n.namespace_re && n.namespace_re.test(c.namespace))
          )
            (n.data = c.data),
              (n.handleObj = c),
              (o = (
                (v.event.special[c.origType] || {}).handle || c.handler
              ).apply(a.elem, g)),
              o !== t &&
                ((n.result = o),
                o === !1 && (n.preventDefault(), n.stopPropagation()));
        }
      }
      return b.postDispatch && b.postDispatch.call(this, n), n.result;
    },
    props:
      "attrChange attrName relatedNode srcElement altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(
        " "
      ),
    fixHooks: {},
    keyHooks: {
      props: "char charCode key keyCode".split(" "),
      filter: function (e, t) {
        return (
          e.which == null &&
            (e.which = t.charCode != null ? t.charCode : t.keyCode),
          e
        );
      },
    },
    mouseHooks: {
      props:
        "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(
          " "
        ),
      filter: function (e, n) {
        var r,
          s,
          o,
          u = n.button,
          a = n.fromElement;
        return (
          e.pageX == null &&
            n.clientX != null &&
            ((r = e.target.ownerDocument || i),
            (s = r.documentElement),
            (o = r.body),
            (e.pageX =
              n.clientX +
              ((s && s.scrollLeft) || (o && o.scrollLeft) || 0) -
              ((s && s.clientLeft) || (o && o.clientLeft) || 0)),
            (e.pageY =
              n.clientY +
              ((s && s.scrollTop) || (o && o.scrollTop) || 0) -
              ((s && s.clientTop) || (o && o.clientTop) || 0))),
          !e.relatedTarget &&
            a &&
            (e.relatedTarget = a === e.target ? n.toElement : a),
          !e.which &&
            u !== t &&
            (e.which = u & 1 ? 1 : u & 2 ? 3 : u & 4 ? 2 : 0),
          e
        );
      },
    },
    fix: function (e) {
      if (e[v.expando]) return e;
      var t,
        n,
        r = e,
        s = v.event.fixHooks[e.type] || {},
        o = s.props ? this.props.concat(s.props) : this.props;
      e = v.Event(r);
      for (t = o.length; t; ) (n = o[--t]), (e[n] = r[n]);
      return (
        e.target || (e.target = r.srcElement || i),
        e.target.nodeType === 3 && (e.target = e.target.parentNode),
        (e.metaKey = !!e.metaKey),
        s.filter ? s.filter(e, r) : e
      );
    },
    special: {
      load: { noBubble: !0 },
      focus: { delegateType: "focusin" },
      blur: { delegateType: "focusout" },
      beforeunload: {
        setup: function (e, t, n) {
          v.isWindow(this) && (this.onbeforeunload = n);
        },
        teardown: function (e, t) {
          this.onbeforeunload === t && (this.onbeforeunload = null);
        },
      },
    },
    simulate: function (e, t, n, r) {
      var i = v.extend(new v.Event(), n, {
        type: e,
        isSimulated: !0,
        originalEvent: {},
      });
      r ? v.event.trigger(i, null, t) : v.event.dispatch.call(t, i),
        i.isDefaultPrevented() && n.preventDefault();
    },
  }),
    (v.event.handle = v.event.dispatch),
    (v.removeEvent = i.removeEventListener
      ? function (e, t, n) {
          e.removeEventListener && e.removeEventListener(t, n, !1);
        }
      : function (e, t, n) {
          var r = "on" + t;
          e.detachEvent &&
            (typeof e[r] == "undefined" && (e[r] = null), e.detachEvent(r, n));
        }),
    (v.Event = function (e, t) {
      if (!(this instanceof v.Event)) return new v.Event(e, t);
      e && e.type
        ? ((this.originalEvent = e),
          (this.type = e.type),
          (this.isDefaultPrevented =
            e.defaultPrevented ||
            e.returnValue === !1 ||
            (e.getPreventDefault && e.getPreventDefault())
              ? tt
              : et))
        : (this.type = e),
        t && v.extend(this, t),
        (this.timeStamp = (e && e.timeStamp) || v.now()),
        (this[v.expando] = !0);
    }),
    (v.Event.prototype = {
      preventDefault: function () {
        this.isDefaultPrevented = tt;
        var e = this.originalEvent;
        if (!e) return;
        e.preventDefault ? e.preventDefault() : (e.returnValue = !1);
      },
      stopPropagation: function () {
        this.isPropagationStopped = tt;
        var e = this.originalEvent;
        if (!e) return;
        e.stopPropagation && e.stopPropagation(), (e.cancelBubble = !0);
      },
      stopImmediatePropagation: function () {
        (this.isImmediatePropagationStopped = tt), this.stopPropagation();
      },
      isDefaultPrevented: et,
      isPropagationStopped: et,
      isImmediatePropagationStopped: et,
    }),
    v.each(
      { mouseenter: "mouseover", mouseleave: "mouseout" },
      function (e, t) {
        v.event.special[e] = {
          delegateType: t,
          bindType: t,
          handle: function (e) {
            var n,
              r = this,
              i = e.relatedTarget,
              s = e.handleObj,
              o = s.selector;
            if (!i || (i !== r && !v.contains(r, i)))
              (e.type = s.origType),
                (n = s.handler.apply(this, arguments)),
                (e.type = t);
            return n;
          },
        };
      }
    ),
    v.support.submitBubbles ||
      (v.event.special.submit = {
        setup: function () {
          if (v.nodeName(this, "form")) return !1;
          v.event.add(this, "click._submit keypress._submit", function (e) {
            var n = e.target,
              r =
                v.nodeName(n, "input") || v.nodeName(n, "button") ? n.form : t;
            r &&
              !v._data(r, "_submit_attached") &&
              (v.event.add(r, "submit._submit", function (e) {
                e._submit_bubble = !0;
              }),
              v._data(r, "_submit_attached", !0));
          });
        },
        postDispatch: function (e) {
          e._submit_bubble &&
            (delete e._submit_bubble,
            this.parentNode &&
              !e.isTrigger &&
              v.event.simulate("submit", this.parentNode, e, !0));
        },
        teardown: function () {
          if (v.nodeName(this, "form")) return !1;
          v.event.remove(this, "._submit");
        },
      }),
    v.support.changeBubbles ||
      (v.event.special.change = {
        setup: function () {
          if ($.test(this.nodeName)) {
            if (this.type === "checkbox" || this.type === "radio")
              v.event.add(this, "propertychange._change", function (e) {
                e.originalEvent.propertyName === "checked" &&
                  (this._just_changed = !0);
              }),
                v.event.add(this, "click._change", function (e) {
                  this._just_changed &&
                    !e.isTrigger &&
                    (this._just_changed = !1),
                    v.event.simulate("change", this, e, !0);
                });
            return !1;
          }
          v.event.add(this, "beforeactivate._change", function (e) {
            var t = e.target;
            $.test(t.nodeName) &&
              !v._data(t, "_change_attached") &&
              (v.event.add(t, "change._change", function (e) {
                this.parentNode &&
                  !e.isSimulated &&
                  !e.isTrigger &&
                  v.event.simulate("change", this.parentNode, e, !0);
              }),
              v._data(t, "_change_attached", !0));
          });
        },
        handle: function (e) {
          var t = e.target;
          if (
            this !== t ||
            e.isSimulated ||
            e.isTrigger ||
            (t.type !== "radio" && t.type !== "checkbox")
          )
            return e.handleObj.handler.apply(this, arguments);
        },
        teardown: function () {
          return v.event.remove(this, "._change"), !$.test(this.nodeName);
        },
      }),
    v.support.focusinBubbles ||
      v.each({ focus: "focusin", blur: "focusout" }, function (e, t) {
        var n = 0,
          r = function (e) {
            v.event.simulate(t, e.target, v.event.fix(e), !0);
          };
        v.event.special[t] = {
          setup: function () {
            n++ === 0 && i.addEventListener(e, r, !0);
          },
          teardown: function () {
            --n === 0 && i.removeEventListener(e, r, !0);
          },
        };
      }),
    v.fn.extend({
      on: function (e, n, r, i, s) {
        var o, u;
        if (typeof e == "object") {
          typeof n != "string" && ((r = r || n), (n = t));
          for (u in e) this.on(u, n, r, e[u], s);
          return this;
        }
        r == null && i == null
          ? ((i = n), (r = n = t))
          : i == null &&
            (typeof n == "string"
              ? ((i = r), (r = t))
              : ((i = r), (r = n), (n = t)));
        if (i === !1) i = et;
        else if (!i) return this;
        return (
          s === 1 &&
            ((o = i),
            (i = function (e) {
              return v().off(e), o.apply(this, arguments);
            }),
            (i.guid = o.guid || (o.guid = v.guid++))),
          this.each(function () {
            v.event.add(this, e, i, r, n);
          })
        );
      },
      one: function (e, t, n, r) {
        return this.on(e, t, n, r, 1);
      },
      off: function (e, n, r) {
        var i, s;
        if (e && e.preventDefault && e.handleObj)
          return (
            (i = e.handleObj),
            v(e.delegateTarget).off(
              i.namespace ? i.origType + "." + i.namespace : i.origType,
              i.selector,
              i.handler
            ),
            this
          );
        if (typeof e == "object") {
          for (s in e) this.off(s, n, e[s]);
          return this;
        }
        if (n === !1 || typeof n == "function") (r = n), (n = t);
        return (
          r === !1 && (r = et),
          this.each(function () {
            v.event.remove(this, e, r, n);
          })
        );
      },
      bind: function (e, t, n) {
        return this.on(e, null, t, n);
      },
      unbind: function (e, t) {
        return this.off(e, null, t);
      },
      live: function (e, t, n) {
        return v(this.context).on(e, this.selector, t, n), this;
      },
      die: function (e, t) {
        return v(this.context).off(e, this.selector || "**", t), this;
      },
      delegate: function (e, t, n, r) {
        return this.on(t, e, n, r);
      },
      undelegate: function (e, t, n) {
        return arguments.length === 1
          ? this.off(e, "**")
          : this.off(t, e || "**", n);
      },
      trigger: function (e, t) {
        return this.each(function () {
          v.event.trigger(e, t, this);
        });
      },
      triggerHandler: function (e, t) {
        if (this[0]) return v.event.trigger(e, t, this[0], !0);
      },
      toggle: function (e) {
        var t = arguments,
          n = e.guid || v.guid++,
          r = 0,
          i = function (n) {
            var i = (v._data(this, "lastToggle" + e.guid) || 0) % r;
            return (
              v._data(this, "lastToggle" + e.guid, i + 1),
              n.preventDefault(),
              t[i].apply(this, arguments) || !1
            );
          };
        i.guid = n;
        while (r < t.length) t[r++].guid = n;
        return this.click(i);
      },
      hover: function (e, t) {
        return this.mouseenter(e).mouseleave(t || e);
      },
    }),
    v.each(
      "blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(
        " "
      ),
      function (e, t) {
        (v.fn[t] = function (e, n) {
          return (
            n == null && ((n = e), (e = null)),
            arguments.length > 0 ? this.on(t, null, e, n) : this.trigger(t)
          );
        }),
          Q.test(t) && (v.event.fixHooks[t] = v.event.keyHooks),
          G.test(t) && (v.event.fixHooks[t] = v.event.mouseHooks);
      }
    ),
    (function (e, t) {
      function nt(e, t, n, r) {
        (n = n || []), (t = t || g);
        var i,
          s,
          a,
          f,
          l = t.nodeType;
        if (!e || typeof e != "string") return n;
        if (l !== 1 && l !== 9) return [];
        a = o(t);
        if (!a && !r)
          if ((i = R.exec(e)))
            if ((f = i[1])) {
              if (l === 9) {
                s = t.getElementById(f);
                if (!s || !s.parentNode) return n;
                if (s.id === f) return n.push(s), n;
              } else if (
                t.ownerDocument &&
                (s = t.ownerDocument.getElementById(f)) &&
                u(t, s) &&
                s.id === f
              )
                return n.push(s), n;
            } else {
              if (i[2])
                return S.apply(n, x.call(t.getElementsByTagName(e), 0)), n;
              if ((f = i[3]) && Z && t.getElementsByClassName)
                return S.apply(n, x.call(t.getElementsByClassName(f), 0)), n;
            }
        return vt(e.replace(j, "$1"), t, n, r, a);
      }
      function rt(e) {
        return function (t) {
          var n = t.nodeName.toLowerCase();
          return n === "input" && t.type === e;
        };
      }
      function it(e) {
        return function (t) {
          var n = t.nodeName.toLowerCase();
          return (n === "input" || n === "button") && t.type === e;
        };
      }
      function st(e) {
        return N(function (t) {
          return (
            (t = +t),
            N(function (n, r) {
              var i,
                s = e([], n.length, t),
                o = s.length;
              while (o--) n[(i = s[o])] && (n[i] = !(r[i] = n[i]));
            })
          );
        });
      }
      function ot(e, t, n) {
        if (e === t) return n;
        var r = e.nextSibling;
        while (r) {
          if (r === t) return -1;
          r = r.nextSibling;
        }
        return 1;
      }
      function ut(e, t) {
        var n,
          r,
          s,
          o,
          u,
          a,
          f,
          l = L[d][e + " "];
        if (l) return t ? 0 : l.slice(0);
        (u = e), (a = []), (f = i.preFilter);
        while (u) {
          if (!n || (r = F.exec(u)))
            r && (u = u.slice(r[0].length) || u), a.push((s = []));
          n = !1;
          if ((r = I.exec(u)))
            s.push((n = new m(r.shift()))),
              (u = u.slice(n.length)),
              (n.type = r[0].replace(j, " "));
          for (o in i.filter)
            (r = J[o].exec(u)) &&
              (!f[o] || (r = f[o](r))) &&
              (s.push((n = new m(r.shift()))),
              (u = u.slice(n.length)),
              (n.type = o),
              (n.matches = r));
          if (!n) break;
        }
        return t ? u.length : u ? nt.error(e) : L(e, a).slice(0);
      }
      function at(e, t, r) {
        var i = t.dir,
          s = r && t.dir === "parentNode",
          o = w++;
        return t.first
          ? function (t, n, r) {
              while ((t = t[i])) if (s || t.nodeType === 1) return e(t, n, r);
            }
          : function (t, r, u) {
              if (!u) {
                var a,
                  f = b + " " + o + " ",
                  l = f + n;
                while ((t = t[i]))
                  if (s || t.nodeType === 1) {
                    if ((a = t[d]) === l) return t.sizset;
                    if (typeof a == "string" && a.indexOf(f) === 0) {
                      if (t.sizset) return t;
                    } else {
                      t[d] = l;
                      if (e(t, r, u)) return (t.sizset = !0), t;
                      t.sizset = !1;
                    }
                  }
              } else
                while ((t = t[i]))
                  if (s || t.nodeType === 1) if (e(t, r, u)) return t;
            };
      }
      function ft(e) {
        return e.length > 1
          ? function (t, n, r) {
              var i = e.length;
              while (i--) if (!e[i](t, n, r)) return !1;
              return !0;
            }
          : e[0];
      }
      function lt(e, t, n, r, i) {
        var s,
          o = [],
          u = 0,
          a = e.length,
          f = t != null;
        for (; u < a; u++)
          if ((s = e[u])) if (!n || n(s, r, i)) o.push(s), f && t.push(u);
        return o;
      }
      function ct(e, t, n, r, i, s) {
        return (
          r && !r[d] && (r = ct(r)),
          i && !i[d] && (i = ct(i, s)),
          N(function (s, o, u, a) {
            var f,
              l,
              c,
              h = [],
              p = [],
              d = o.length,
              v = s || dt(t || "*", u.nodeType ? [u] : u, []),
              m = e && (s || !t) ? lt(v, h, e, u, a) : v,
              g = n ? (i || (s ? e : d || r) ? [] : o) : m;
            n && n(m, g, u, a);
            if (r) {
              (f = lt(g, p)), r(f, [], u, a), (l = f.length);
              while (l--) if ((c = f[l])) g[p[l]] = !(m[p[l]] = c);
            }
            if (s) {
              if (i || e) {
                if (i) {
                  (f = []), (l = g.length);
                  while (l--) (c = g[l]) && f.push((m[l] = c));
                  i(null, (g = []), f, a);
                }
                l = g.length;
                while (l--)
                  (c = g[l]) &&
                    (f = i ? T.call(s, c) : h[l]) > -1 &&
                    (s[f] = !(o[f] = c));
              }
            } else (g = lt(g === o ? g.splice(d, g.length) : g)), i ? i(null, o, g, a) : S.apply(o, g);
          })
        );
      }
      function ht(e) {
        var t,
          n,
          r,
          s = e.length,
          o = i.relative[e[0].type],
          u = o || i.relative[" "],
          a = o ? 1 : 0,
          f = at(
            function (e) {
              return e === t;
            },
            u,
            !0
          ),
          l = at(
            function (e) {
              return T.call(t, e) > -1;
            },
            u,
            !0
          ),
          h = [
            function (e, n, r) {
              return (
                (!o && (r || n !== c)) ||
                ((t = n).nodeType ? f(e, n, r) : l(e, n, r))
              );
            },
          ];
        for (; a < s; a++)
          if ((n = i.relative[e[a].type])) h = [at(ft(h), n)];
          else {
            n = i.filter[e[a].type].apply(null, e[a].matches);
            if (n[d]) {
              r = ++a;
              for (; r < s; r++) if (i.relative[e[r].type]) break;
              return ct(
                a > 1 && ft(h),
                a > 1 &&
                  e
                    .slice(0, a - 1)
                    .join("")
                    .replace(j, "$1"),
                n,
                a < r && ht(e.slice(a, r)),
                r < s && ht((e = e.slice(r))),
                r < s && e.join("")
              );
            }
            h.push(n);
          }
        return ft(h);
      }
      function pt(e, t) {
        var r = t.length > 0,
          s = e.length > 0,
          o = function (u, a, f, l, h) {
            var p,
              d,
              v,
              m = [],
              y = 0,
              w = "0",
              x = u && [],
              T = h != null,
              N = c,
              C = u || (s && i.find.TAG("*", (h && a.parentNode) || a)),
              k = (b += N == null ? 1 : Math.E);
            T && ((c = a !== g && a), (n = o.el));
            for (; (p = C[w]) != null; w++) {
              if (s && p) {
                for (d = 0; (v = e[d]); d++)
                  if (v(p, a, f)) {
                    l.push(p);
                    break;
                  }
                T && ((b = k), (n = ++o.el));
              }
              r && ((p = !v && p) && y--, u && x.push(p));
            }
            y += w;
            if (r && w !== y) {
              for (d = 0; (v = t[d]); d++) v(x, m, a, f);
              if (u) {
                if (y > 0) while (w--) !x[w] && !m[w] && (m[w] = E.call(l));
                m = lt(m);
              }
              S.apply(l, m),
                T && !u && m.length > 0 && y + t.length > 1 && nt.uniqueSort(l);
            }
            return T && ((b = k), (c = N)), x;
          };
        return (o.el = 0), r ? N(o) : o;
      }
      function dt(e, t, n) {
        var r = 0,
          i = t.length;
        for (; r < i; r++) nt(e, t[r], n);
        return n;
      }
      function vt(e, t, n, r, s) {
        var o,
          u,
          f,
          l,
          c,
          h = ut(e),
          p = h.length;
        if (!r && h.length === 1) {
          u = h[0] = h[0].slice(0);
          if (
            u.length > 2 &&
            (f = u[0]).type === "ID" &&
            t.nodeType === 9 &&
            !s &&
            i.relative[u[1].type]
          ) {
            t = i.find.ID(f.matches[0].replace($, ""), t, s)[0];
            if (!t) return n;
            e = e.slice(u.shift().length);
          }
          for (o = J.POS.test(e) ? -1 : u.length - 1; o >= 0; o--) {
            f = u[o];
            if (i.relative[(l = f.type)]) break;
            if ((c = i.find[l]))
              if (
                (r = c(
                  f.matches[0].replace($, ""),
                  (z.test(u[0].type) && t.parentNode) || t,
                  s
                ))
              ) {
                u.splice(o, 1), (e = r.length && u.join(""));
                if (!e) return S.apply(n, x.call(r, 0)), n;
                break;
              }
          }
        }
        return a(e, h)(r, t, s, n, z.test(e)), n;
      }
      function mt() {}
      var n,
        r,
        i,
        s,
        o,
        u,
        a,
        f,
        l,
        c,
        h = !0,
        p = "undefined",
        d = ("sizcache" + Math.random()).replace(".", ""),
        m = String,
        g = e.document,
        y = g.documentElement,
        b = 0,
        w = 0,
        E = [].pop,
        S = [].push,
        x = [].slice,
        T =
          [].indexOf ||
          function (e) {
            var t = 0,
              n = this.length;
            for (; t < n; t++) if (this[t] === e) return t;
            return -1;
          },
        N = function (e, t) {
          return (e[d] = t == null || t), e;
        },
        C = function () {
          var e = {},
            t = [];
          return N(function (n, r) {
            return (
              t.push(n) > i.cacheLength && delete e[t.shift()], (e[n + " "] = r)
            );
          }, e);
        },
        k = C(),
        L = C(),
        A = C(),
        O = "[\\x20\\t\\r\\n\\f]",
        M = "(?:\\\\.|[-\\w]|[^\\x00-\\xa0])+",
        _ = M.replace("w", "w#"),
        D = "([*^$|!~]?=)",
        P =
          "\\[" +
          O +
          "*(" +
          M +
          ")" +
          O +
          "*(?:" +
          D +
          O +
          "*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|(" +
          _ +
          ")|)|)" +
          O +
          "*\\]",
        H =
          ":(" +
          M +
          ")(?:\\((?:(['\"])((?:\\\\.|[^\\\\])*?)\\2|([^()[\\]]*|(?:(?:" +
          P +
          ")|[^:]|\\\\.)*|.*))\\)|)",
        B =
          ":(even|odd|eq|gt|lt|nth|first|last)(?:\\(" +
          O +
          "*((?:-\\d)?\\d*)" +
          O +
          "*\\)|)(?=[^-]|$)",
        j = new RegExp("^" + O + "+|((?:^|[^\\\\])(?:\\\\.)*)" + O + "+$", "g"),
        F = new RegExp("^" + O + "*," + O + "*"),
        I = new RegExp("^" + O + "*([\\x20\\t\\r\\n\\f>+~])" + O + "*"),
        q = new RegExp(H),
        R = /^(?:#([\w\-]+)|(\w+)|\.([\w\-]+))$/,
        U = /^:not/,
        z = /[\x20\t\r\n\f]*[+~]/,
        W = /:not\($/,
        X = /h\d/i,
        V = /input|select|textarea|button/i,
        $ = /\\(?!\\)/g,
        J = {
          ID: new RegExp("^#(" + M + ")"),
          CLASS: new RegExp("^\\.(" + M + ")"),
          NAME: new RegExp("^\\[name=['\"]?(" + M + ")['\"]?\\]"),
          TAG: new RegExp("^(" + M.replace("w", "w*") + ")"),
          ATTR: new RegExp("^" + P),
          PSEUDO: new RegExp("^" + H),
          POS: new RegExp(B, "i"),
          CHILD: new RegExp(
            "^:(only|nth|first|last)-child(?:\\(" +
              O +
              "*(even|odd|(([+-]|)(\\d*)n|)" +
              O +
              "*(?:([+-]|)" +
              O +
              "*(\\d+)|))" +
              O +
              "*\\)|)",
            "i"
          ),
          needsContext: new RegExp("^" + O + "*[>+~]|" + B, "i"),
        },
        K = function (e) {
          var t = g.createElement("div");
          try {
            return e(t);
          } catch (n) {
            return !1;
          } finally {
            t = null;
          }
        },
        Q = K(function (e) {
          return (
            e.appendChild(g.createComment("")),
            !e.getElementsByTagName("*").length
          );
        }),
        G = K(function (e) {
          return (
            (e.innerHTML = "<a href='#'></a>"),
            e.firstChild &&
              typeof e.firstChild.getAttribute !== p &&
              e.firstChild.getAttribute("href") === "#"
          );
        }),
        Y = K(function (e) {
          e.innerHTML = "<select></select>";
          var t = typeof e.lastChild.getAttribute("multiple");
          return t !== "boolean" && t !== "string";
        }),
        Z = K(function (e) {
          return (
            (e.innerHTML =
              "<div class='hidden e'></div><div class='hidden'></div>"),
            !e.getElementsByClassName || !e.getElementsByClassName("e").length
              ? !1
              : ((e.lastChild.className = "e"),
                e.getElementsByClassName("e").length === 2)
          );
        }),
        et = K(function (e) {
          (e.id = d + 0),
            (e.innerHTML =
              "<a name='" + d + "'></a><div name='" + d + "'></div>"),
            y.insertBefore(e, y.firstChild);
          var t =
            g.getElementsByName &&
            g.getElementsByName(d).length ===
              2 + g.getElementsByName(d + 0).length;
          return (r = !g.getElementById(d)), y.removeChild(e), t;
        });
      try {
        x.call(y.childNodes, 0)[0].nodeType;
      } catch (tt) {
        x = function (e) {
          var t,
            n = [];
          for (; (t = this[e]); e++) n.push(t);
          return n;
        };
      }
      (nt.matches = function (e, t) {
        return nt(e, null, null, t);
      }),
        (nt.matchesSelector = function (e, t) {
          return nt(t, null, null, [e]).length > 0;
        }),
        (s = nt.getText =
          function (e) {
            var t,
              n = "",
              r = 0,
              i = e.nodeType;
            if (i) {
              if (i === 1 || i === 9 || i === 11) {
                if (typeof e.textContent == "string") return e.textContent;
                for (e = e.firstChild; e; e = e.nextSibling) n += s(e);
              } else if (i === 3 || i === 4) return e.nodeValue;
            } else for (; (t = e[r]); r++) n += s(t);
            return n;
          }),
        (o = nt.isXML =
          function (e) {
            var t = e && (e.ownerDocument || e).documentElement;
            return t ? t.nodeName !== "HTML" : !1;
          }),
        (u = nt.contains =
          y.contains
            ? function (e, t) {
                var n = e.nodeType === 9 ? e.documentElement : e,
                  r = t && t.parentNode;
                return (
                  e === r ||
                  !!(r && r.nodeType === 1 && n.contains && n.contains(r))
                );
              }
            : y.compareDocumentPosition
            ? function (e, t) {
                return t && !!(e.compareDocumentPosition(t) & 16);
              }
            : function (e, t) {
                while ((t = t.parentNode)) if (t === e) return !0;
                return !1;
              }),
        (nt.attr = function (e, t) {
          var n,
            r = o(e);
          return (
            r || (t = t.toLowerCase()),
            (n = i.attrHandle[t])
              ? n(e)
              : r || Y
              ? e.getAttribute(t)
              : ((n = e.getAttributeNode(t)),
                n
                  ? typeof e[t] == "boolean"
                    ? e[t]
                      ? t
                      : null
                    : n.specified
                    ? n.value
                    : null
                  : null)
          );
        }),
        (i = nt.selectors =
          {
            cacheLength: 50,
            createPseudo: N,
            match: J,
            attrHandle: G
              ? {}
              : {
                  href: function (e) {
                    return e.getAttribute("href", 2);
                  },
                  type: function (e) {
                    return e.getAttribute("type");
                  },
                },
            find: {
              ID: r
                ? function (e, t, n) {
                    if (typeof t.getElementById !== p && !n) {
                      var r = t.getElementById(e);
                      return r && r.parentNode ? [r] : [];
                    }
                  }
                : function (e, n, r) {
                    if (typeof n.getElementById !== p && !r) {
                      var i = n.getElementById(e);
                      return i
                        ? i.id === e ||
                          (typeof i.getAttributeNode !== p &&
                            i.getAttributeNode("id").value === e)
                          ? [i]
                          : t
                        : [];
                    }
                  },
              TAG: Q
                ? function (e, t) {
                    if (typeof t.getElementsByTagName !== p)
                      return t.getElementsByTagName(e);
                  }
                : function (e, t) {
                    var n = t.getElementsByTagName(e);
                    if (e === "*") {
                      var r,
                        i = [],
                        s = 0;
                      for (; (r = n[s]); s++) r.nodeType === 1 && i.push(r);
                      return i;
                    }
                    return n;
                  },
              NAME:
                et &&
                function (e, t) {
                  if (typeof t.getElementsByName !== p)
                    return t.getElementsByName(name);
                },
              CLASS:
                Z &&
                function (e, t, n) {
                  if (typeof t.getElementsByClassName !== p && !n)
                    return t.getElementsByClassName(e);
                },
            },
            relative: {
              ">": { dir: "parentNode", first: !0 },
              " ": { dir: "parentNode" },
              "+": { dir: "previousSibling", first: !0 },
              "~": { dir: "previousSibling" },
            },
            preFilter: {
              ATTR: function (e) {
                return (
                  (e[1] = e[1].replace($, "")),
                  (e[3] = (e[4] || e[5] || "").replace($, "")),
                  e[2] === "~=" && (e[3] = " " + e[3] + " "),
                  e.slice(0, 4)
                );
              },
              CHILD: function (e) {
                return (
                  (e[1] = e[1].toLowerCase()),
                  e[1] === "nth"
                    ? (e[2] || nt.error(e[0]),
                      (e[3] = +(e[3]
                        ? e[4] + (e[5] || 1)
                        : 2 * (e[2] === "even" || e[2] === "odd"))),
                      (e[4] = +(e[6] + e[7] || e[2] === "odd")))
                    : e[2] && nt.error(e[0]),
                  e
                );
              },
              PSEUDO: function (e) {
                var t, n;
                if (J.CHILD.test(e[0])) return null;
                if (e[3]) e[2] = e[3];
                else if ((t = e[4]))
                  q.test(t) &&
                    (n = ut(t, !0)) &&
                    (n = t.indexOf(")", t.length - n) - t.length) &&
                    ((t = t.slice(0, n)), (e[0] = e[0].slice(0, n))),
                    (e[2] = t);
                return e.slice(0, 3);
              },
            },
            filter: {
              ID: r
                ? function (e) {
                    return (
                      (e = e.replace($, "")),
                      function (t) {
                        return t.getAttribute("id") === e;
                      }
                    );
                  }
                : function (e) {
                    return (
                      (e = e.replace($, "")),
                      function (t) {
                        var n =
                          typeof t.getAttributeNode !== p &&
                          t.getAttributeNode("id");
                        return n && n.value === e;
                      }
                    );
                  },
              TAG: function (e) {
                return e === "*"
                  ? function () {
                      return !0;
                    }
                  : ((e = e.replace($, "").toLowerCase()),
                    function (t) {
                      return t.nodeName && t.nodeName.toLowerCase() === e;
                    });
              },
              CLASS: function (e) {
                var t = k[d][e + " "];
                return (
                  t ||
                  ((t = new RegExp("(^|" + O + ")" + e + "(" + O + "|$)")) &&
                    k(e, function (e) {
                      return t.test(
                        e.className ||
                          (typeof e.getAttribute !== p &&
                            e.getAttribute("class")) ||
                          ""
                      );
                    }))
                );
              },
              ATTR: function (e, t, n) {
                return function (r, i) {
                  var s = nt.attr(r, e);
                  return s == null
                    ? t === "!="
                    : t
                    ? ((s += ""),
                      t === "="
                        ? s === n
                        : t === "!="
                        ? s !== n
                        : t === "^="
                        ? n && s.indexOf(n) === 0
                        : t === "*="
                        ? n && s.indexOf(n) > -1
                        : t === "$="
                        ? n && s.substr(s.length - n.length) === n
                        : t === "~="
                        ? (" " + s + " ").indexOf(n) > -1
                        : t === "|="
                        ? s === n || s.substr(0, n.length + 1) === n + "-"
                        : !1)
                    : !0;
                };
              },
              CHILD: function (e, t, n, r) {
                return e === "nth"
                  ? function (e) {
                      var t,
                        i,
                        s = e.parentNode;
                      if (n === 1 && r === 0) return !0;
                      if (s) {
                        i = 0;
                        for (t = s.firstChild; t; t = t.nextSibling)
                          if (t.nodeType === 1) {
                            i++;
                            if (e === t) break;
                          }
                      }
                      return (i -= r), i === n || (i % n === 0 && i / n >= 0);
                    }
                  : function (t) {
                      var n = t;
                      switch (e) {
                        case "only":
                        case "first":
                          while ((n = n.previousSibling))
                            if (n.nodeType === 1) return !1;
                          if (e === "first") return !0;
                          n = t;
                        case "last":
                          while ((n = n.nextSibling))
                            if (n.nodeType === 1) return !1;
                          return !0;
                      }
                    };
              },
              PSEUDO: function (e, t) {
                var n,
                  r =
                    i.pseudos[e] ||
                    i.setFilters[e.toLowerCase()] ||
                    nt.error("unsupported pseudo: " + e);
                return r[d]
                  ? r(t)
                  : r.length > 1
                  ? ((n = [e, e, "", t]),
                    i.setFilters.hasOwnProperty(e.toLowerCase())
                      ? N(function (e, n) {
                          var i,
                            s = r(e, t),
                            o = s.length;
                          while (o--)
                            (i = T.call(e, s[o])), (e[i] = !(n[i] = s[o]));
                        })
                      : function (e) {
                          return r(e, 0, n);
                        })
                  : r;
              },
            },
            pseudos: {
              not: N(function (e) {
                var t = [],
                  n = [],
                  r = a(e.replace(j, "$1"));
                return r[d]
                  ? N(function (e, t, n, i) {
                      var s,
                        o = r(e, null, i, []),
                        u = e.length;
                      while (u--) if ((s = o[u])) e[u] = !(t[u] = s);
                    })
                  : function (e, i, s) {
                      return (t[0] = e), r(t, null, s, n), !n.pop();
                    };
              }),
              has: N(function (e) {
                return function (t) {
                  return nt(e, t).length > 0;
                };
              }),
              contains: N(function (e) {
                return function (t) {
                  return (t.textContent || t.innerText || s(t)).indexOf(e) > -1;
                };
              }),
              enabled: function (e) {
                return e.disabled === !1;
              },
              disabled: function (e) {
                return e.disabled === !0;
              },
              checked: function (e) {
                var t = e.nodeName.toLowerCase();
                return (
                  (t === "input" && !!e.checked) ||
                  (t === "option" && !!e.selected)
                );
              },
              selected: function (e) {
                return (
                  e.parentNode && e.parentNode.selectedIndex, e.selected === !0
                );
              },
              parent: function (e) {
                return !i.pseudos.empty(e);
              },
              empty: function (e) {
                var t;
                e = e.firstChild;
                while (e) {
                  if (e.nodeName > "@" || (t = e.nodeType) === 3 || t === 4)
                    return !1;
                  e = e.nextSibling;
                }
                return !0;
              },
              header: function (e) {
                return X.test(e.nodeName);
              },
              text: function (e) {
                var t, n;
                return (
                  e.nodeName.toLowerCase() === "input" &&
                  (t = e.type) === "text" &&
                  ((n = e.getAttribute("type")) == null ||
                    n.toLowerCase() === t)
                );
              },
              radio: rt("radio"),
              checkbox: rt("checkbox"),
              file: rt("file"),
              password: rt("password"),
              image: rt("image"),
              submit: it("submit"),
              reset: it("reset"),
              button: function (e) {
                var t = e.nodeName.toLowerCase();
                return (t === "input" && e.type === "button") || t === "button";
              },
              input: function (e) {
                return V.test(e.nodeName);
              },
              focus: function (e) {
                var t = e.ownerDocument;
                return (
                  e === t.activeElement &&
                  (!t.hasFocus || t.hasFocus()) &&
                  !!(e.type || e.href || ~e.tabIndex)
                );
              },
              active: function (e) {
                return e === e.ownerDocument.activeElement;
              },
              first: st(function () {
                return [0];
              }),
              last: st(function (e, t) {
                return [t - 1];
              }),
              eq: st(function (e, t, n) {
                return [n < 0 ? n + t : n];
              }),
              even: st(function (e, t) {
                for (var n = 0; n < t; n += 2) e.push(n);
                return e;
              }),
              odd: st(function (e, t) {
                for (var n = 1; n < t; n += 2) e.push(n);
                return e;
              }),
              lt: st(function (e, t, n) {
                for (var r = n < 0 ? n + t : n; --r >= 0; ) e.push(r);
                return e;
              }),
              gt: st(function (e, t, n) {
                for (var r = n < 0 ? n + t : n; ++r < t; ) e.push(r);
                return e;
              }),
            },
          }),
        (f = y.compareDocumentPosition
          ? function (e, t) {
              return e === t
                ? ((l = !0), 0)
                : (
                    !e.compareDocumentPosition || !t.compareDocumentPosition
                      ? e.compareDocumentPosition
                      : e.compareDocumentPosition(t) & 4
                  )
                ? -1
                : 1;
            }
          : function (e, t) {
              if (e === t) return (l = !0), 0;
              if (e.sourceIndex && t.sourceIndex)
                return e.sourceIndex - t.sourceIndex;
              var n,
                r,
                i = [],
                s = [],
                o = e.parentNode,
                u = t.parentNode,
                a = o;
              if (o === u) return ot(e, t);
              if (!o) return -1;
              if (!u) return 1;
              while (a) i.unshift(a), (a = a.parentNode);
              a = u;
              while (a) s.unshift(a), (a = a.parentNode);
              (n = i.length), (r = s.length);
              for (var f = 0; f < n && f < r; f++)
                if (i[f] !== s[f]) return ot(i[f], s[f]);
              return f === n ? ot(e, s[f], -1) : ot(i[f], t, 1);
            }),
        [0, 0].sort(f),
        (h = !l),
        (nt.uniqueSort = function (e) {
          var t,
            n = [],
            r = 1,
            i = 0;
          (l = h), e.sort(f);
          if (l) {
            for (; (t = e[r]); r++) t === e[r - 1] && (i = n.push(r));
            while (i--) e.splice(n[i], 1);
          }
          return e;
        }),
        (nt.error = function (e) {
          throw new Error("Syntax error, unrecognized expression: " + e);
        }),
        (a = nt.compile =
          function (e, t) {
            var n,
              r = [],
              i = [],
              s = A[d][e + " "];
            if (!s) {
              t || (t = ut(e)), (n = t.length);
              while (n--) (s = ht(t[n])), s[d] ? r.push(s) : i.push(s);
              s = A(e, pt(i, r));
            }
            return s;
          }),
        g.querySelectorAll &&
          (function () {
            var e,
              t = vt,
              n = /'|\\/g,
              r = /\=[\x20\t\r\n\f]*([^'"\]]*)[\x20\t\r\n\f]*\]/g,
              i = [":focus"],
              s = [":active"],
              u =
                y.matchesSelector ||
                y.mozMatchesSelector ||
                y.webkitMatchesSelector ||
                y.oMatchesSelector ||
                y.msMatchesSelector;
            K(function (e) {
              (e.innerHTML = "<select><option selected=''></option></select>"),
                e.querySelectorAll("[selected]").length ||
                  i.push(
                    "\\[" +
                      O +
                      "*(?:checked|disabled|ismap|multiple|readonly|selected|value)"
                  ),
                e.querySelectorAll(":checked").length || i.push(":checked");
            }),
              K(function (e) {
                (e.innerHTML = "<p test=''></p>"),
                  e.querySelectorAll("[test^='']").length &&
                    i.push("[*^$]=" + O + "*(?:\"\"|'')"),
                  (e.innerHTML = "<input type='hidden'/>"),
                  e.querySelectorAll(":enabled").length ||
                    i.push(":enabled", ":disabled");
              }),
              (i = new RegExp(i.join("|"))),
              (vt = function (e, r, s, o, u) {
                if (!o && !u && !i.test(e)) {
                  var a,
                    f,
                    l = !0,
                    c = d,
                    h = r,
                    p = r.nodeType === 9 && e;
                  if (
                    r.nodeType === 1 &&
                    r.nodeName.toLowerCase() !== "object"
                  ) {
                    (a = ut(e)),
                      (l = r.getAttribute("id"))
                        ? (c = l.replace(n, "\\$&"))
                        : r.setAttribute("id", c),
                      (c = "[id='" + c + "'] "),
                      (f = a.length);
                    while (f--) a[f] = c + a[f].join("");
                    (h = (z.test(e) && r.parentNode) || r), (p = a.join(","));
                  }
                  if (p)
                    try {
                      return S.apply(s, x.call(h.querySelectorAll(p), 0)), s;
                    } catch (v) {
                    } finally {
                      l || r.removeAttribute("id");
                    }
                }
                return t(e, r, s, o, u);
              }),
              u &&
                (K(function (t) {
                  e = u.call(t, "div");
                  try {
                    u.call(t, "[test!='']:sizzle"), s.push("!=", H);
                  } catch (n) {}
                }),
                (s = new RegExp(s.join("|"))),
                (nt.matchesSelector = function (t, n) {
                  n = n.replace(r, "='$1']");
                  if (!o(t) && !s.test(n) && !i.test(n))
                    try {
                      var a = u.call(t, n);
                      if (a || e || (t.document && t.document.nodeType !== 11))
                        return a;
                    } catch (f) {}
                  return nt(n, null, null, [t]).length > 0;
                }));
          })(),
        (i.pseudos.nth = i.pseudos.eq),
        (i.filters = mt.prototype = i.pseudos),
        (i.setFilters = new mt()),
        (nt.attr = v.attr),
        (v.find = nt),
        (v.expr = nt.selectors),
        (v.expr[":"] = v.expr.pseudos),
        (v.unique = nt.uniqueSort),
        (v.text = nt.getText),
        (v.isXMLDoc = nt.isXML),
        (v.contains = nt.contains);
    })(e);
  var nt = /Until$/,
    rt = /^(?:parents|prev(?:Until|All))/,
    it = /^.[^:#\[\.,]*$/,
    st = v.expr.match.needsContext,
    ot = { children: !0, contents: !0, next: !0, prev: !0 };
  v.fn.extend({
    find: function (e) {
      var t,
        n,
        r,
        i,
        s,
        o,
        u = this;
      if (typeof e != "string")
        return v(e).filter(function () {
          for (t = 0, n = u.length; t < n; t++)
            if (v.contains(u[t], this)) return !0;
        });
      o = this.pushStack("", "find", e);
      for (t = 0, n = this.length; t < n; t++) {
        (r = o.length), v.find(e, this[t], o);
        if (t > 0)
          for (i = r; i < o.length; i++)
            for (s = 0; s < r; s++)
              if (o[s] === o[i]) {
                o.splice(i--, 1);
                break;
              }
      }
      return o;
    },
    has: function (e) {
      var t,
        n = v(e, this),
        r = n.length;
      return this.filter(function () {
        for (t = 0; t < r; t++) if (v.contains(this, n[t])) return !0;
      });
    },
    not: function (e) {
      return this.pushStack(ft(this, e, !1), "not", e);
    },
    filter: function (e) {
      return this.pushStack(ft(this, e, !0), "filter", e);
    },
    is: function (e) {
      return (
        !!e &&
        (typeof e == "string"
          ? st.test(e)
            ? v(e, this.context).index(this[0]) >= 0
            : v.filter(e, this).length > 0
          : this.filter(e).length > 0)
      );
    },
    closest: function (e, t) {
      var n,
        r = 0,
        i = this.length,
        s = [],
        o = st.test(e) || typeof e != "string" ? v(e, t || this.context) : 0;
      for (; r < i; r++) {
        n = this[r];
        while (n && n.ownerDocument && n !== t && n.nodeType !== 11) {
          if (o ? o.index(n) > -1 : v.find.matchesSelector(n, e)) {
            s.push(n);
            break;
          }
          n = n.parentNode;
        }
      }
      return (
        (s = s.length > 1 ? v.unique(s) : s), this.pushStack(s, "closest", e)
      );
    },
    index: function (e) {
      return e
        ? typeof e == "string"
          ? v.inArray(this[0], v(e))
          : v.inArray(e.jquery ? e[0] : e, this)
        : this[0] && this[0].parentNode
        ? this.prevAll().length
        : -1;
    },
    add: function (e, t) {
      var n =
          typeof e == "string"
            ? v(e, t)
            : v.makeArray(e && e.nodeType ? [e] : e),
        r = v.merge(this.get(), n);
      return this.pushStack(ut(n[0]) || ut(r[0]) ? r : v.unique(r));
    },
    addBack: function (e) {
      return this.add(e == null ? this.prevObject : this.prevObject.filter(e));
    },
  }),
    (v.fn.andSelf = v.fn.addBack),
    v.each(
      {
        parent: function (e) {
          var t = e.parentNode;
          return t && t.nodeType !== 11 ? t : null;
        },
        parents: function (e) {
          return v.dir(e, "parentNode");
        },
        parentsUntil: function (e, t, n) {
          return v.dir(e, "parentNode", n);
        },
        next: function (e) {
          return at(e, "nextSibling");
        },
        prev: function (e) {
          return at(e, "previousSibling");
        },
        nextAll: function (e) {
          return v.dir(e, "nextSibling");
        },
        prevAll: function (e) {
          return v.dir(e, "previousSibling");
        },
        nextUntil: function (e, t, n) {
          return v.dir(e, "nextSibling", n);
        },
        prevUntil: function (e, t, n) {
          return v.dir(e, "previousSibling", n);
        },
        siblings: function (e) {
          return v.sibling((e.parentNode || {}).firstChild, e);
        },
        children: function (e) {
          return v.sibling(e.firstChild);
        },
        contents: function (e) {
          return v.nodeName(e, "iframe")
            ? e.contentDocument || e.contentWindow.document
            : v.merge([], e.childNodes);
        },
      },
      function (e, t) {
        v.fn[e] = function (n, r) {
          var i = v.map(this, t, n);
          return (
            nt.test(e) || (r = n),
            r && typeof r == "string" && (i = v.filter(r, i)),
            (i = this.length > 1 && !ot[e] ? v.unique(i) : i),
            this.length > 1 && rt.test(e) && (i = i.reverse()),
            this.pushStack(i, e, l.call(arguments).join(","))
          );
        };
      }
    ),
    v.extend({
      filter: function (e, t, n) {
        return (
          n && (e = ":not(" + e + ")"),
          t.length === 1
            ? v.find.matchesSelector(t[0], e)
              ? [t[0]]
              : []
            : v.find.matches(e, t)
        );
      },
      dir: function (e, n, r) {
        var i = [],
          s = e[n];
        while (
          s &&
          s.nodeType !== 9 &&
          (r === t || s.nodeType !== 1 || !v(s).is(r))
        )
          s.nodeType === 1 && i.push(s), (s = s[n]);
        return i;
      },
      sibling: function (e, t) {
        var n = [];
        for (; e; e = e.nextSibling) e.nodeType === 1 && e !== t && n.push(e);
        return n;
      },
    });
  var ct =
      "abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",
    ht = / jQuery\d+="(?:null|\d+)"/g,
    pt = /^\s+/,
    dt =
      /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,
    vt = /<([\w:]+)/,
    mt = /<tbody/i,
    gt = /<|&#?\w+;/,
    yt = /<(?:script|style|link)/i,
    bt = /<(?:script|object|embed|option|style)/i,
    wt = new RegExp("<(?:" + ct + ")[\\s/>]", "i"),
    Et = /^(?:checkbox|radio)$/,
    St = /checked\s*(?:[^=]|=\s*.checked.)/i,
    xt = /\/(java|ecma)script/i,
    Tt = /^\s*<!(?:\[CDATA\[|\-\-)|[\]\-]{2}>\s*$/g,
    Nt = {
      option: [1, "<select multiple='multiple'>", "</select>"],
      legend: [1, "<fieldset>", "</fieldset>"],
      thead: [1, "<table>", "</table>"],
      tr: [2, "<table><tbody>", "</tbody></table>"],
      td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
      col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
      area: [1, "<map>", "</map>"],
      _default: [0, "", ""],
    },
    Ct = lt(i),
    kt = Ct.appendChild(i.createElement("div"));
  (Nt.optgroup = Nt.option),
    (Nt.tbody = Nt.tfoot = Nt.colgroup = Nt.caption = Nt.thead),
    (Nt.th = Nt.td),
    v.support.htmlSerialize || (Nt._default = [1, "X<div>", "</div>"]),
    v.fn.extend({
      text: function (e) {
        return v.access(
          this,
          function (e) {
            return e === t
              ? v.text(this)
              : this.empty().append(
                  ((this[0] && this[0].ownerDocument) || i).createTextNode(e)
                );
          },
          null,
          e,
          arguments.length
        );
      },
      wrapAll: function (e) {
        if (v.isFunction(e))
          return this.each(function (t) {
            v(this).wrapAll(e.call(this, t));
          });
        if (this[0]) {
          var t = v(e, this[0].ownerDocument).eq(0).clone(!0);
          this[0].parentNode && t.insertBefore(this[0]),
            t
              .map(function () {
                var e = this;
                while (e.firstChild && e.firstChild.nodeType === 1)
                  e = e.firstChild;
                return e;
              })
              .append(this);
        }
        return this;
      },
      wrapInner: function (e) {
        return v.isFunction(e)
          ? this.each(function (t) {
              v(this).wrapInner(e.call(this, t));
            })
          : this.each(function () {
              var t = v(this),
                n = t.contents();
              n.length ? n.wrapAll(e) : t.append(e);
            });
      },
      wrap: function (e) {
        var t = v.isFunction(e);
        return this.each(function (n) {
          v(this).wrapAll(t ? e.call(this, n) : e);
        });
      },
      unwrap: function () {
        return this.parent()
          .each(function () {
            v.nodeName(this, "body") || v(this).replaceWith(this.childNodes);
          })
          .end();
      },
      append: function () {
        return this.domManip(arguments, !0, function (e) {
          (this.nodeType === 1 || this.nodeType === 11) && this.appendChild(e);
        });
      },
      prepend: function () {
        return this.domManip(arguments, !0, function (e) {
          (this.nodeType === 1 || this.nodeType === 11) &&
            this.insertBefore(e, this.firstChild);
        });
      },
      before: function () {
        if (!ut(this[0]))
          return this.domManip(arguments, !1, function (e) {
            this.parentNode.insertBefore(e, this);
          });
        if (arguments.length) {
          var e = v.clean(arguments);
          return this.pushStack(v.merge(e, this), "before", this.selector);
        }
      },
      after: function () {
        if (!ut(this[0]))
          return this.domManip(arguments, !1, function (e) {
            this.parentNode.insertBefore(e, this.nextSibling);
          });
        if (arguments.length) {
          var e = v.clean(arguments);
          return this.pushStack(v.merge(this, e), "after", this.selector);
        }
      },
      remove: function (e, t) {
        var n,
          r = 0;
        for (; (n = this[r]) != null; r++)
          if (!e || v.filter(e, [n]).length)
            !t &&
              n.nodeType === 1 &&
              (v.cleanData(n.getElementsByTagName("*")), v.cleanData([n])),
              n.parentNode && n.parentNode.removeChild(n);
        return this;
      },
      empty: function () {
        var e,
          t = 0;
        for (; (e = this[t]) != null; t++) {
          e.nodeType === 1 && v.cleanData(e.getElementsByTagName("*"));
          while (e.firstChild) e.removeChild(e.firstChild);
        }
        return this;
      },
      clone: function (e, t) {
        return (
          (e = e == null ? !1 : e),
          (t = t == null ? e : t),
          this.map(function () {
            return v.clone(this, e, t);
          })
        );
      },
      html: function (e) {
        return v.access(
          this,
          function (e) {
            var n = this[0] || {},
              r = 0,
              i = this.length;
            if (e === t)
              return n.nodeType === 1 ? n.innerHTML.replace(ht, "") : t;
            if (
              typeof e == "string" &&
              !yt.test(e) &&
              (v.support.htmlSerialize || !wt.test(e)) &&
              (v.support.leadingWhitespace || !pt.test(e)) &&
              !Nt[(vt.exec(e) || ["", ""])[1].toLowerCase()]
            ) {
              e = e.replace(dt, "<$1></$2>");
              try {
                for (; r < i; r++)
                  (n = this[r] || {}),
                    n.nodeType === 1 &&
                      (v.cleanData(n.getElementsByTagName("*")),
                      (n.innerHTML = e));
                n = 0;
              } catch (s) {}
            }
            n && this.empty().append(e);
          },
          null,
          e,
          arguments.length
        );
      },
      replaceWith: function (e) {
        return ut(this[0])
          ? this.length
            ? this.pushStack(v(v.isFunction(e) ? e() : e), "replaceWith", e)
            : this
          : v.isFunction(e)
          ? this.each(function (t) {
              var n = v(this),
                r = n.html();
              n.replaceWith(e.call(this, t, r));
            })
          : (typeof e != "string" && (e = v(e).detach()),
            this.each(function () {
              var t = this.nextSibling,
                n = this.parentNode;
              v(this).remove(), t ? v(t).before(e) : v(n).append(e);
            }));
      },
      detach: function (e) {
        return this.remove(e, !0);
      },
      domManip: function (e, n, r) {
        e = [].concat.apply([], e);
        var i,
          s,
          o,
          u,
          a = 0,
          f = e[0],
          l = [],
          c = this.length;
        if (
          !v.support.checkClone &&
          c > 1 &&
          typeof f == "string" &&
          St.test(f)
        )
          return this.each(function () {
            v(this).domManip(e, n, r);
          });
        if (v.isFunction(f))
          return this.each(function (i) {
            var s = v(this);
            (e[0] = f.call(this, i, n ? s.html() : t)), s.domManip(e, n, r);
          });
        if (this[0]) {
          (i = v.buildFragment(e, this, l)),
            (o = i.fragment),
            (s = o.firstChild),
            o.childNodes.length === 1 && (o = s);
          if (s) {
            n = n && v.nodeName(s, "tr");
            for (u = i.cacheable || c - 1; a < c; a++)
              r.call(
                n && v.nodeName(this[a], "table")
                  ? Lt(this[a], "tbody")
                  : this[a],
                a === u ? o : v.clone(o, !0, !0)
              );
          }
          (o = s = null),
            l.length &&
              v.each(l, function (e, t) {
                t.src
                  ? v.ajax
                    ? v.ajax({
                        url: t.src,
                        type: "GET",
                        dataType: "script",
                        async: !1,
                        global: !1,
                        throws: !0,
                      })
                    : v.error("no ajax")
                  : v.globalEval(
                      (t.text || t.textContent || t.innerHTML || "").replace(
                        Tt,
                        ""
                      )
                    ),
                  t.parentNode && t.parentNode.removeChild(t);
              });
        }
        return this;
      },
    }),
    (v.buildFragment = function (e, n, r) {
      var s,
        o,
        u,
        a = e[0];
      return (
        (n = n || i),
        (n = (!n.nodeType && n[0]) || n),
        (n = n.ownerDocument || n),
        e.length === 1 &&
          typeof a == "string" &&
          a.length < 512 &&
          n === i &&
          a.charAt(0) === "<" &&
          !bt.test(a) &&
          (v.support.checkClone || !St.test(a)) &&
          (v.support.html5Clone || !wt.test(a)) &&
          ((o = !0), (s = v.fragments[a]), (u = s !== t)),
        s ||
          ((s = n.createDocumentFragment()),
          v.clean(e, n, s, r),
          o && (v.fragments[a] = u && s)),
        { fragment: s, cacheable: o }
      );
    }),
    (v.fragments = {}),
    v.each(
      {
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith",
      },
      function (e, t) {
        v.fn[e] = function (n) {
          var r,
            i = 0,
            s = [],
            o = v(n),
            u = o.length,
            a = this.length === 1 && this[0].parentNode;
          if (
            (a == null ||
              (a && a.nodeType === 11 && a.childNodes.length === 1)) &&
            u === 1
          )
            return o[t](this[0]), this;
          for (; i < u; i++)
            (r = (i > 0 ? this.clone(!0) : this).get()),
              v(o[i])[t](r),
              (s = s.concat(r));
          return this.pushStack(s, e, o.selector);
        };
      }
    ),
    v.extend({
      clone: function (e, t, n) {
        var r, i, s, o;
        v.support.html5Clone ||
        v.isXMLDoc(e) ||
        !wt.test("<" + e.nodeName + ">")
          ? (o = e.cloneNode(!0))
          : ((kt.innerHTML = e.outerHTML), kt.removeChild((o = kt.firstChild)));
        if (
          (!v.support.noCloneEvent || !v.support.noCloneChecked) &&
          (e.nodeType === 1 || e.nodeType === 11) &&
          !v.isXMLDoc(e)
        ) {
          Ot(e, o), (r = Mt(e)), (i = Mt(o));
          for (s = 0; r[s]; ++s) i[s] && Ot(r[s], i[s]);
        }
        if (t) {
          At(e, o);
          if (n) {
            (r = Mt(e)), (i = Mt(o));
            for (s = 0; r[s]; ++s) At(r[s], i[s]);
          }
        }
        return (r = i = null), o;
      },
      clean: function (e, t, n, r) {
        var s,
          o,
          u,
          a,
          f,
          l,
          c,
          h,
          p,
          d,
          m,
          g,
          y = t === i && Ct,
          b = [];
        if (!t || typeof t.createDocumentFragment == "undefined") t = i;
        for (s = 0; (u = e[s]) != null; s++) {
          typeof u == "number" && (u += "");
          if (!u) continue;
          if (typeof u == "string")
            if (!gt.test(u)) u = t.createTextNode(u);
            else {
              (y = y || lt(t)),
                (c = t.createElement("div")),
                y.appendChild(c),
                (u = u.replace(dt, "<$1></$2>")),
                (a = (vt.exec(u) || ["", ""])[1].toLowerCase()),
                (f = Nt[a] || Nt._default),
                (l = f[0]),
                (c.innerHTML = f[1] + u + f[2]);
              while (l--) c = c.lastChild;
              if (!v.support.tbody) {
                (h = mt.test(u)),
                  (p =
                    a === "table" && !h
                      ? c.firstChild && c.firstChild.childNodes
                      : f[1] === "<table>" && !h
                      ? c.childNodes
                      : []);
                for (o = p.length - 1; o >= 0; --o)
                  v.nodeName(p[o], "tbody") &&
                    !p[o].childNodes.length &&
                    p[o].parentNode.removeChild(p[o]);
              }
              !v.support.leadingWhitespace &&
                pt.test(u) &&
                c.insertBefore(t.createTextNode(pt.exec(u)[0]), c.firstChild),
                (u = c.childNodes),
                c.parentNode.removeChild(c);
            }
          u.nodeType ? b.push(u) : v.merge(b, u);
        }
        c && (u = c = y = null);
        if (!v.support.appendChecked)
          for (s = 0; (u = b[s]) != null; s++)
            v.nodeName(u, "input")
              ? _t(u)
              : typeof u.getElementsByTagName != "undefined" &&
                v.grep(u.getElementsByTagName("input"), _t);
        if (n) {
          m = function (e) {
            if (!e.type || xt.test(e.type))
              return r
                ? r.push(e.parentNode ? e.parentNode.removeChild(e) : e)
                : n.appendChild(e);
          };
          for (s = 0; (u = b[s]) != null; s++)
            if (!v.nodeName(u, "script") || !m(u))
              n.appendChild(u),
                typeof u.getElementsByTagName != "undefined" &&
                  ((g = v.grep(
                    v.merge([], u.getElementsByTagName("script")),
                    m
                  )),
                  b.splice.apply(b, [s + 1, 0].concat(g)),
                  (s += g.length));
        }
        return b;
      },
      cleanData: function (e, t) {
        var n,
          r,
          i,
          s,
          o = 0,
          u = v.expando,
          a = v.cache,
          f = v.support.deleteExpando,
          l = v.event.special;
        for (; (i = e[o]) != null; o++)
          if (t || v.acceptData(i)) {
            (r = i[u]), (n = r && a[r]);
            if (n) {
              if (n.events)
                for (s in n.events)
                  l[s] ? v.event.remove(i, s) : v.removeEvent(i, s, n.handle);
              a[r] &&
                (delete a[r],
                f
                  ? delete i[u]
                  : i.removeAttribute
                  ? i.removeAttribute(u)
                  : (i[u] = null),
                v.deletedIds.push(r));
            }
          }
      },
    }),
    (function () {
      var e, t;
      (v.uaMatch = function (e) {
        e = e.toLowerCase();
        var t =
          /(chrome)[ \/]([\w.]+)/.exec(e) ||
          /(webkit)[ \/]([\w.]+)/.exec(e) ||
          /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(e) ||
          /(msie) ([\w.]+)/.exec(e) ||
          (e.indexOf("compatible") < 0 &&
            /(mozilla)(?:.*? rv:([\w.]+)|)/.exec(e)) ||
          [];
        return { browser: t[1] || "", version: t[2] || "0" };
      }),
        (e = v.uaMatch(o.userAgent)),
        (t = {}),
        e.browser && ((t[e.browser] = !0), (t.version = e.version)),
        t.chrome ? (t.webkit = !0) : t.webkit && (t.safari = !0),
        (v.browser = t),
        (v.sub = function () {
          function e(t, n) {
            return new e.fn.init(t, n);
          }
          v.extend(!0, e, this),
            (e.superclass = this),
            (e.fn = e.prototype = this()),
            (e.fn.constructor = e),
            (e.sub = this.sub),
            (e.fn.init = function (r, i) {
              return (
                i && i instanceof v && !(i instanceof e) && (i = e(i)),
                v.fn.init.call(this, r, i, t)
              );
            }),
            (e.fn.init.prototype = e.fn);
          var t = e(i);
          return e;
        });
    })();
  var Dt,
    Pt,
    Ht,
    Bt = /alpha\([^)]*\)/i,
    jt = /opacity=([^)]*)/,
    Ft = /^(top|right|bottom|left)$/,
    It = /^(none|table(?!-c[ea]).+)/,
    qt = /^margin/,
    Rt = new RegExp("^(" + m + ")(.*)$", "i"),
    Ut = new RegExp("^(" + m + ")(?!px)[a-z%]+$", "i"),
    zt = new RegExp("^([-+])=(" + m + ")", "i"),
    Wt = { BODY: "block" },
    Xt = { position: "absolute", visibility: "hidden", display: "block" },
    Vt = { letterSpacing: 0, fontWeight: 400 },
    $t = ["Top", "Right", "Bottom", "Left"],
    Jt = ["Webkit", "O", "Moz", "ms"],
    Kt = v.fn.toggle;
  v.fn.extend({
    css: function (e, n) {
      return v.access(
        this,
        function (e, n, r) {
          return r !== t ? v.style(e, n, r) : v.css(e, n);
        },
        e,
        n,
        arguments.length > 1
      );
    },
    show: function () {
      return Yt(this, !0);
    },
    hide: function () {
      return Yt(this);
    },
    toggle: function (e, t) {
      var n = typeof e == "boolean";
      return v.isFunction(e) && v.isFunction(t)
        ? Kt.apply(this, arguments)
        : this.each(function () {
            (n ? e : Gt(this)) ? v(this).show() : v(this).hide();
          });
    },
  }),
    v.extend({
      cssHooks: {
        opacity: {
          get: function (e, t) {
            if (t) {
              var n = Dt(e, "opacity");
              return n === "" ? "1" : n;
            }
          },
        },
      },
      cssNumber: {
        fillOpacity: !0,
        fontWeight: !0,
        lineHeight: !0,
        opacity: !0,
        orphans: !0,
        widows: !0,
        zIndex: !0,
        zoom: !0,
      },
      cssProps: { float: v.support.cssFloat ? "cssFloat" : "styleFloat" },
      style: function (e, n, r, i) {
        if (!e || e.nodeType === 3 || e.nodeType === 8 || !e.style) return;
        var s,
          o,
          u,
          a = v.camelCase(n),
          f = e.style;
        (n = v.cssProps[a] || (v.cssProps[a] = Qt(f, a))),
          (u = v.cssHooks[n] || v.cssHooks[a]);
        if (r === t)
          return u && "get" in u && (s = u.get(e, !1, i)) !== t ? s : f[n];
        (o = typeof r),
          o === "string" &&
            (s = zt.exec(r)) &&
            ((r = (s[1] + 1) * s[2] + parseFloat(v.css(e, n))), (o = "number"));
        if (r == null || (o === "number" && isNaN(r))) return;
        o === "number" && !v.cssNumber[a] && (r += "px");
        if (!u || !("set" in u) || (r = u.set(e, r, i)) !== t)
          try {
            f[n] = r;
          } catch (l) {}
      },
      css: function (e, n, r, i) {
        var s,
          o,
          u,
          a = v.camelCase(n);
        return (
          (n = v.cssProps[a] || (v.cssProps[a] = Qt(e.style, a))),
          (u = v.cssHooks[n] || v.cssHooks[a]),
          u && "get" in u && (s = u.get(e, !0, i)),
          s === t && (s = Dt(e, n)),
          s === "normal" && n in Vt && (s = Vt[n]),
          r || i !== t
            ? ((o = parseFloat(s)), r || v.isNumeric(o) ? o || 0 : s)
            : s
        );
      },
      swap: function (e, t, n) {
        var r,
          i,
          s = {};
        for (i in t) (s[i] = e.style[i]), (e.style[i] = t[i]);
        r = n.call(e);
        for (i in t) e.style[i] = s[i];
        return r;
      },
    }),
    e.getComputedStyle
      ? (Dt = function (t, n) {
          var r,
            i,
            s,
            o,
            u = e.getComputedStyle(t, null),
            a = t.style;
          return (
            u &&
              ((r = u.getPropertyValue(n) || u[n]),
              r === "" &&
                !v.contains(t.ownerDocument, t) &&
                (r = v.style(t, n)),
              Ut.test(r) &&
                qt.test(n) &&
                ((i = a.width),
                (s = a.minWidth),
                (o = a.maxWidth),
                (a.minWidth = a.maxWidth = a.width = r),
                (r = u.width),
                (a.width = i),
                (a.minWidth = s),
                (a.maxWidth = o))),
            r
          );
        })
      : i.documentElement.currentStyle &&
        (Dt = function (e, t) {
          var n,
            r,
            i = e.currentStyle && e.currentStyle[t],
            s = e.style;
          return (
            i == null && s && s[t] && (i = s[t]),
            Ut.test(i) &&
              !Ft.test(t) &&
              ((n = s.left),
              (r = e.runtimeStyle && e.runtimeStyle.left),
              r && (e.runtimeStyle.left = e.currentStyle.left),
              (s.left = t === "fontSize" ? "1em" : i),
              (i = s.pixelLeft + "px"),
              (s.left = n),
              r && (e.runtimeStyle.left = r)),
            i === "" ? "auto" : i
          );
        }),
    v.each(["height", "width"], function (e, t) {
      v.cssHooks[t] = {
        get: function (e, n, r) {
          if (n)
            return e.offsetWidth === 0 && It.test(Dt(e, "display"))
              ? v.swap(e, Xt, function () {
                  return tn(e, t, r);
                })
              : tn(e, t, r);
        },
        set: function (e, n, r) {
          return Zt(
            e,
            n,
            r
              ? en(
                  e,
                  t,
                  r,
                  v.support.boxSizing && v.css(e, "boxSizing") === "border-box"
                )
              : 0
          );
        },
      };
    }),
    v.support.opacity ||
      (v.cssHooks.opacity = {
        get: function (e, t) {
          return jt.test(
            (t && e.currentStyle ? e.currentStyle.filter : e.style.filter) || ""
          )
            ? 0.01 * parseFloat(RegExp.$1) + ""
            : t
            ? "1"
            : "";
        },
        set: function (e, t) {
          var n = e.style,
            r = e.currentStyle,
            i = v.isNumeric(t) ? "alpha(opacity=" + t * 100 + ")" : "",
            s = (r && r.filter) || n.filter || "";
          n.zoom = 1;
          if (t >= 1 && v.trim(s.replace(Bt, "")) === "" && n.removeAttribute) {
            n.removeAttribute("filter");
            if (r && !r.filter) return;
          }
          n.filter = Bt.test(s) ? s.replace(Bt, i) : s + " " + i;
        },
      }),
    v(function () {
      v.support.reliableMarginRight ||
        (v.cssHooks.marginRight = {
          get: function (e, t) {
            return v.swap(e, { display: "inline-block" }, function () {
              if (t) return Dt(e, "marginRight");
            });
          },
        }),
        !v.support.pixelPosition &&
          v.fn.position &&
          v.each(["top", "left"], function (e, t) {
            v.cssHooks[t] = {
              get: function (e, n) {
                if (n) {
                  var r = Dt(e, t);
                  return Ut.test(r) ? v(e).position()[t] + "px" : r;
                }
              },
            };
          });
    }),
    v.expr &&
      v.expr.filters &&
      ((v.expr.filters.hidden = function (e) {
        return (
          (e.offsetWidth === 0 && e.offsetHeight === 0) ||
          (!v.support.reliableHiddenOffsets &&
            ((e.style && e.style.display) || Dt(e, "display")) === "none")
        );
      }),
      (v.expr.filters.visible = function (e) {
        return !v.expr.filters.hidden(e);
      })),
    v.each({ margin: "", padding: "", border: "Width" }, function (e, t) {
      (v.cssHooks[e + t] = {
        expand: function (n) {
          var r,
            i = typeof n == "string" ? n.split(" ") : [n],
            s = {};
          for (r = 0; r < 4; r++) s[e + $t[r] + t] = i[r] || i[r - 2] || i[0];
          return s;
        },
      }),
        qt.test(e) || (v.cssHooks[e + t].set = Zt);
    });
  var rn = /%20/g,
    sn = /\[\]$/,
    on = /\r?\n/g,
    un =
      /^(?:color|date|datetime|datetime-local|email|hidden|month|number|password|range|search|tel|text|time|url|week)$/i,
    an = /^(?:select|textarea)/i;
  v.fn.extend({
    serialize: function () {
      return v.param(this.serializeArray());
    },
    serializeArray: function () {
      return this.map(function () {
        return this.elements ? v.makeArray(this.elements) : this;
      })
        .filter(function () {
          return (
            this.name &&
            !this.disabled &&
            (this.checked || an.test(this.nodeName) || un.test(this.type))
          );
        })
        .map(function (e, t) {
          var n = v(this).val();
          return n == null
            ? null
            : v.isArray(n)
            ? v.map(n, function (e, n) {
                return { name: t.name, value: e.replace(on, "\r\n") };
              })
            : { name: t.name, value: n.replace(on, "\r\n") };
        })
        .get();
    },
  }),
    (v.param = function (e, n) {
      var r,
        i = [],
        s = function (e, t) {
          (t = v.isFunction(t) ? t() : t == null ? "" : t),
            (i[i.length] = encodeURIComponent(e) + "=" + encodeURIComponent(t));
        };
      n === t && (n = v.ajaxSettings && v.ajaxSettings.traditional);
      if (v.isArray(e) || (e.jquery && !v.isPlainObject(e)))
        v.each(e, function () {
          s(this.name, this.value);
        });
      else for (r in e) fn(r, e[r], n, s);
      return i.join("&").replace(rn, "+");
    });
  var ln,
    cn,
    hn = /#.*$/,
    pn = /^(.*?):[ \t]*([^\r\n]*)\r?$/gm,
    dn = /^(?:about|app|app\-storage|.+\-extension|file|res|widget):$/,
    vn = /^(?:GET|HEAD)$/,
    mn = /^\/\//,
    gn = /\?/,
    yn = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
    bn = /([?&])_=[^&]*/,
    wn = /^([\w\+\.\-]+:)(?:\/\/([^\/?#:]*)(?::(\d+)|)|)/,
    En = v.fn.load,
    Sn = {},
    xn = {},
    Tn = ["*/"] + ["*"];
  try {
    cn = s.href;
  } catch (Nn) {
    (cn = i.createElement("a")), (cn.href = ""), (cn = cn.href);
  }
  (ln = wn.exec(cn.toLowerCase()) || []),
    (v.fn.load = function (e, n, r) {
      if (typeof e != "string" && En) return En.apply(this, arguments);
      if (!this.length) return this;
      var i,
        s,
        o,
        u = this,
        a = e.indexOf(" ");
      return (
        a >= 0 && ((i = e.slice(a, e.length)), (e = e.slice(0, a))),
        v.isFunction(n)
          ? ((r = n), (n = t))
          : n && typeof n == "object" && (s = "POST"),
        v
          .ajax({
            url: e,
            type: s,
            dataType: "html",
            data: n,
            complete: function (e, t) {
              r && u.each(r, o || [e.responseText, t, e]);
            },
          })
          .done(function (e) {
            (o = arguments),
              u.html(i ? v("<div>").append(e.replace(yn, "")).find(i) : e);
          }),
        this
      );
    }),
    v.each(
      "ajaxStart ajaxStop ajaxComplete ajaxError ajaxSuccess ajaxSend".split(
        " "
      ),
      function (e, t) {
        v.fn[t] = function (e) {
          return this.on(t, e);
        };
      }
    ),
    v.each(["get", "post"], function (e, n) {
      v[n] = function (e, r, i, s) {
        return (
          v.isFunction(r) && ((s = s || i), (i = r), (r = t)),
          v.ajax({ type: n, url: e, data: r, success: i, dataType: s })
        );
      };
    }),
    v.extend({
      getScript: function (e, n) {
        return v.get(e, t, n, "script");
      },
      getJSON: function (e, t, n) {
        return v.get(e, t, n, "json");
      },
      ajaxSetup: function (e, t) {
        return (
          t ? Ln(e, v.ajaxSettings) : ((t = e), (e = v.ajaxSettings)),
          Ln(e, t),
          e
        );
      },
      ajaxSettings: {
        url: cn,
        isLocal: dn.test(ln[1]),
        global: !0,
        type: "GET",
        contentType: "application/x-www-form-urlencoded; charset=UTF-8",
        processData: !0,
        async: !0,
        accepts: {
          xml: "application/xml, text/xml",
          html: "text/html",
          text: "text/plain",
          json: "application/json, text/javascript",
          "*": Tn,
        },
        contents: { xml: /xml/, html: /html/, json: /json/ },
        responseFields: { xml: "responseXML", text: "responseText" },
        converters: {
          "* text": e.String,
          "text html": !0,
          "text json": v.parseJSON,
          "text xml": v.parseXML,
        },
        flatOptions: { context: !0, url: !0 },
      },
      ajaxPrefilter: Cn(Sn),
      ajaxTransport: Cn(xn),
      ajax: function (e, n) {
        function T(e, n, s, a) {
          var l,
            y,
            b,
            w,
            S,
            T = n;
          if (E === 2) return;
          (E = 2),
            u && clearTimeout(u),
            (o = t),
            (i = a || ""),
            (x.readyState = e > 0 ? 4 : 0),
            s && (w = An(c, x, s));
          if ((e >= 200 && e < 300) || e === 304)
            c.ifModified &&
              ((S = x.getResponseHeader("Last-Modified")),
              S && (v.lastModified[r] = S),
              (S = x.getResponseHeader("Etag")),
              S && (v.etag[r] = S)),
              e === 304
                ? ((T = "notmodified"), (l = !0))
                : ((l = On(c, w)),
                  (T = l.state),
                  (y = l.data),
                  (b = l.error),
                  (l = !b));
          else {
            b = T;
            if (!T || e) (T = "error"), e < 0 && (e = 0);
          }
          (x.status = e),
            (x.statusText = (n || T) + ""),
            l ? d.resolveWith(h, [y, T, x]) : d.rejectWith(h, [x, T, b]),
            x.statusCode(g),
            (g = t),
            f &&
              p.trigger("ajax" + (l ? "Success" : "Error"), [x, c, l ? y : b]),
            m.fireWith(h, [x, T]),
            f &&
              (p.trigger("ajaxComplete", [x, c]),
              --v.active || v.event.trigger("ajaxStop"));
        }
        typeof e == "object" && ((n = e), (e = t)), (n = n || {});
        var r,
          i,
          s,
          o,
          u,
          a,
          f,
          l,
          c = v.ajaxSetup({}, n),
          h = c.context || c,
          p = h !== c && (h.nodeType || h instanceof v) ? v(h) : v.event,
          d = v.Deferred(),
          m = v.Callbacks("once memory"),
          g = c.statusCode || {},
          b = {},
          w = {},
          E = 0,
          S = "canceled",
          x = {
            readyState: 0,
            setRequestHeader: function (e, t) {
              if (!E) {
                var n = e.toLowerCase();
                (e = w[n] = w[n] || e), (b[e] = t);
              }
              return this;
            },
            getAllResponseHeaders: function () {
              return E === 2 ? i : null;
            },
            getResponseHeader: function (e) {
              var n;
              if (E === 2) {
                if (!s) {
                  s = {};
                  while ((n = pn.exec(i))) s[n[1].toLowerCase()] = n[2];
                }
                n = s[e.toLowerCase()];
              }
              return n === t ? null : n;
            },
            overrideMimeType: function (e) {
              return E || (c.mimeType = e), this;
            },
            abort: function (e) {
              return (e = e || S), o && o.abort(e), T(0, e), this;
            },
          };
        d.promise(x),
          (x.success = x.done),
          (x.error = x.fail),
          (x.complete = m.add),
          (x.statusCode = function (e) {
            if (e) {
              var t;
              if (E < 2) for (t in e) g[t] = [g[t], e[t]];
              else (t = e[x.status]), x.always(t);
            }
            return this;
          }),
          (c.url = ((e || c.url) + "")
            .replace(hn, "")
            .replace(mn, ln[1] + "//")),
          (c.dataTypes = v
            .trim(c.dataType || "*")
            .toLowerCase()
            .split(y)),
          c.crossDomain == null &&
            ((a = wn.exec(c.url.toLowerCase())),
            (c.crossDomain = !(
              !a ||
              (a[1] === ln[1] &&
                a[2] === ln[2] &&
                (a[3] || (a[1] === "http:" ? 80 : 443)) ==
                  (ln[3] || (ln[1] === "http:" ? 80 : 443)))
            ))),
          c.data &&
            c.processData &&
            typeof c.data != "string" &&
            (c.data = v.param(c.data, c.traditional)),
          kn(Sn, c, n, x);
        if (E === 2) return x;
        (f = c.global),
          (c.type = c.type.toUpperCase()),
          (c.hasContent = !vn.test(c.type)),
          f && v.active++ === 0 && v.event.trigger("ajaxStart");
        if (!c.hasContent) {
          c.data &&
            ((c.url += (gn.test(c.url) ? "&" : "?") + c.data), delete c.data),
            (r = c.url);
          if (c.cache === !1) {
            var N = v.now(),
              C = c.url.replace(bn, "$1_=" + N);
            c.url =
              C + (C === c.url ? (gn.test(c.url) ? "&" : "?") + "_=" + N : "");
          }
        }
        ((c.data && c.hasContent && c.contentType !== !1) || n.contentType) &&
          x.setRequestHeader("Content-Type", c.contentType),
          c.ifModified &&
            ((r = r || c.url),
            v.lastModified[r] &&
              x.setRequestHeader("If-Modified-Since", v.lastModified[r]),
            v.etag[r] && x.setRequestHeader("If-None-Match", v.etag[r])),
          x.setRequestHeader(
            "Accept",
            c.dataTypes[0] && c.accepts[c.dataTypes[0]]
              ? c.accepts[c.dataTypes[0]] +
                  (c.dataTypes[0] !== "*" ? ", " + Tn + "; q=0.01" : "")
              : c.accepts["*"]
          );
        for (l in c.headers) x.setRequestHeader(l, c.headers[l]);
        if (!c.beforeSend || (c.beforeSend.call(h, x, c) !== !1 && E !== 2)) {
          S = "abort";
          for (l in { success: 1, error: 1, complete: 1 }) x[l](c[l]);
          o = kn(xn, c, n, x);
          if (!o) T(-1, "No Transport");
          else {
            (x.readyState = 1),
              f && p.trigger("ajaxSend", [x, c]),
              c.async &&
                c.timeout > 0 &&
                (u = setTimeout(function () {
                  x.abort("timeout");
                }, c.timeout));
            try {
              (E = 1), o.send(b, T);
            } catch (k) {
              if (!(E < 2)) throw k;
              T(-1, k);
            }
          }
          return x;
        }
        return x.abort();
      },
      active: 0,
      lastModified: {},
      etag: {},
    });
  var Mn = [],
    _n = /\?/,
    Dn = /(=)\?(?=&|$)|\?\?/,
    Pn = v.now();
  v.ajaxSetup({
    jsonp: "callback",
    jsonpCallback: function () {
      var e = Mn.pop() || v.expando + "_" + Pn++;
      return (this[e] = !0), e;
    },
  }),
    v.ajaxPrefilter("json jsonp", function (n, r, i) {
      var s,
        o,
        u,
        a = n.data,
        f = n.url,
        l = n.jsonp !== !1,
        c = l && Dn.test(f),
        h =
          l &&
          !c &&
          typeof a == "string" &&
          !(n.contentType || "").indexOf("application/x-www-form-urlencoded") &&
          Dn.test(a);
      if (n.dataTypes[0] === "jsonp" || c || h)
        return (
          (s = n.jsonpCallback =
            v.isFunction(n.jsonpCallback)
              ? n.jsonpCallback()
              : n.jsonpCallback),
          (o = e[s]),
          c
            ? (n.url = f.replace(Dn, "$1" + s))
            : h
            ? (n.data = a.replace(Dn, "$1" + s))
            : l && (n.url += (_n.test(f) ? "&" : "?") + n.jsonp + "=" + s),
          (n.converters["script json"] = function () {
            return u || v.error(s + " was not called"), u[0];
          }),
          (n.dataTypes[0] = "json"),
          (e[s] = function () {
            u = arguments;
          }),
          i.always(function () {
            (e[s] = o),
              n[s] && ((n.jsonpCallback = r.jsonpCallback), Mn.push(s)),
              u && v.isFunction(o) && o(u[0]),
              (u = o = t);
          }),
          "script"
        );
    }),
    v.ajaxSetup({
      accepts: {
        script:
          "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript",
      },
      contents: { script: /javascript|ecmascript/ },
      converters: {
        "text script": function (e) {
          return v.globalEval(e), e;
        },
      },
    }),
    v.ajaxPrefilter("script", function (e) {
      e.cache === t && (e.cache = !1),
        e.crossDomain && ((e.type = "GET"), (e.global = !1));
    }),
    v.ajaxTransport("script", function (e) {
      if (e.crossDomain) {
        var n,
          r = i.head || i.getElementsByTagName("head")[0] || i.documentElement;
        return {
          send: function (s, o) {
            (n = i.createElement("script")),
              (n.async = "async"),
              e.scriptCharset && (n.charset = e.scriptCharset),
              (n.src = e.url),
              (n.onload = n.onreadystatechange =
                function (e, i) {
                  if (
                    i ||
                    !n.readyState ||
                    /loaded|complete/.test(n.readyState)
                  )
                    (n.onload = n.onreadystatechange = null),
                      r && n.parentNode && r.removeChild(n),
                      (n = t),
                      i || o(200, "success");
                }),
              r.insertBefore(n, r.firstChild);
          },
          abort: function () {
            n && n.onload(0, 1);
          },
        };
      }
    });
  var Hn,
    Bn = e.ActiveXObject
      ? function () {
          for (var e in Hn) Hn[e](0, 1);
        }
      : !1,
    jn = 0;
  (v.ajaxSettings.xhr = e.ActiveXObject
    ? function () {
        return (!this.isLocal && Fn()) || In();
      }
    : Fn),
    (function (e) {
      v.extend(v.support, { ajax: !!e, cors: !!e && "withCredentials" in e });
    })(v.ajaxSettings.xhr()),
    v.support.ajax &&
      v.ajaxTransport(function (n) {
        if (!n.crossDomain || v.support.cors) {
          var r;
          return {
            send: function (i, s) {
              var o,
                u,
                a = n.xhr();
              n.username
                ? a.open(n.type, n.url, n.async, n.username, n.password)
                : a.open(n.type, n.url, n.async);
              if (n.xhrFields) for (u in n.xhrFields) a[u] = n.xhrFields[u];
              n.mimeType &&
                a.overrideMimeType &&
                a.overrideMimeType(n.mimeType),
                !n.crossDomain &&
                  !i["X-Requested-With"] &&
                  (i["X-Requested-With"] = "XMLHttpRequest");
              try {
                for (u in i) a.setRequestHeader(u, i[u]);
              } catch (f) {}
              a.send((n.hasContent && n.data) || null),
                (r = function (e, i) {
                  var u, f, l, c, h;
                  try {
                    if (r && (i || a.readyState === 4)) {
                      (r = t),
                        o &&
                          ((a.onreadystatechange = v.noop), Bn && delete Hn[o]);
                      if (i) a.readyState !== 4 && a.abort();
                      else {
                        (u = a.status),
                          (l = a.getAllResponseHeaders()),
                          (c = {}),
                          (h = a.responseXML),
                          h && h.documentElement && (c.xml = h);
                        try {
                          c.text = a.responseText;
                        } catch (p) {}
                        try {
                          f = a.statusText;
                        } catch (p) {
                          f = "";
                        }
                        !u && n.isLocal && !n.crossDomain
                          ? (u = c.text ? 200 : 404)
                          : u === 1223 && (u = 204);
                      }
                    }
                  } catch (d) {
                    i || s(-1, d);
                  }
                  c && s(u, f, c, l);
                }),
                n.async
                  ? a.readyState === 4
                    ? setTimeout(r, 0)
                    : ((o = ++jn),
                      Bn && (Hn || ((Hn = {}), v(e).unload(Bn)), (Hn[o] = r)),
                      (a.onreadystatechange = r))
                  : r();
            },
            abort: function () {
              r && r(0, 1);
            },
          };
        }
      });
  var qn,
    Rn,
    Un = /^(?:toggle|show|hide)$/,
    zn = new RegExp("^(?:([-+])=|)(" + m + ")([a-z%]*)$", "i"),
    Wn = /queueHooks$/,
    Xn = [Gn],
    Vn = {
      "*": [
        function (e, t) {
          var n,
            r,
            i = this.createTween(e, t),
            s = zn.exec(t),
            o = i.cur(),
            u = +o || 0,
            a = 1,
            f = 20;
          if (s) {
            (n = +s[2]), (r = s[3] || (v.cssNumber[e] ? "" : "px"));
            if (r !== "px" && u) {
              u = v.css(i.elem, e, !0) || n || 1;
              do (a = a || ".5"), (u /= a), v.style(i.elem, e, u + r);
              while (a !== (a = i.cur() / o) && a !== 1 && --f);
            }
            (i.unit = r),
              (i.start = u),
              (i.end = s[1] ? u + (s[1] + 1) * n : n);
          }
          return i;
        },
      ],
    };
  (v.Animation = v.extend(Kn, {
    tweener: function (e, t) {
      v.isFunction(e) ? ((t = e), (e = ["*"])) : (e = e.split(" "));
      var n,
        r = 0,
        i = e.length;
      for (; r < i; r++) (n = e[r]), (Vn[n] = Vn[n] || []), Vn[n].unshift(t);
    },
    prefilter: function (e, t) {
      t ? Xn.unshift(e) : Xn.push(e);
    },
  })),
    (v.Tween = Yn),
    (Yn.prototype = {
      constructor: Yn,
      init: function (e, t, n, r, i, s) {
        (this.elem = e),
          (this.prop = n),
          (this.easing = i || "swing"),
          (this.options = t),
          (this.start = this.now = this.cur()),
          (this.end = r),
          (this.unit = s || (v.cssNumber[n] ? "" : "px"));
      },
      cur: function () {
        var e = Yn.propHooks[this.prop];
        return e && e.get ? e.get(this) : Yn.propHooks._default.get(this);
      },
      run: function (e) {
        var t,
          n = Yn.propHooks[this.prop];
        return (
          this.options.duration
            ? (this.pos = t =
                v.easing[this.easing](
                  e,
                  this.options.duration * e,
                  0,
                  1,
                  this.options.duration
                ))
            : (this.pos = t = e),
          (this.now = (this.end - this.start) * t + this.start),
          this.options.step &&
            this.options.step.call(this.elem, this.now, this),
          n && n.set ? n.set(this) : Yn.propHooks._default.set(this),
          this
        );
      },
    }),
    (Yn.prototype.init.prototype = Yn.prototype),
    (Yn.propHooks = {
      _default: {
        get: function (e) {
          var t;
          return e.elem[e.prop] == null ||
            (!!e.elem.style && e.elem.style[e.prop] != null)
            ? ((t = v.css(e.elem, e.prop, !1, "")), !t || t === "auto" ? 0 : t)
            : e.elem[e.prop];
        },
        set: function (e) {
          v.fx.step[e.prop]
            ? v.fx.step[e.prop](e)
            : e.elem.style &&
              (e.elem.style[v.cssProps[e.prop]] != null || v.cssHooks[e.prop])
            ? v.style(e.elem, e.prop, e.now + e.unit)
            : (e.elem[e.prop] = e.now);
        },
      },
    }),
    (Yn.propHooks.scrollTop = Yn.propHooks.scrollLeft =
      {
        set: function (e) {
          e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now);
        },
      }),
    v.each(["toggle", "show", "hide"], function (e, t) {
      var n = v.fn[t];
      v.fn[t] = function (r, i, s) {
        return r == null ||
          typeof r == "boolean" ||
          (!e && v.isFunction(r) && v.isFunction(i))
          ? n.apply(this, arguments)
          : this.animate(Zn(t, !0), r, i, s);
      };
    }),
    v.fn.extend({
      fadeTo: function (e, t, n, r) {
        return this.filter(Gt)
          .css("opacity", 0)
          .show()
          .end()
          .animate({ opacity: t }, e, n, r);
      },
      animate: function (e, t, n, r) {
        var i = v.isEmptyObject(e),
          s = v.speed(t, n, r),
          o = function () {
            var t = Kn(this, v.extend({}, e), s);
            i && t.stop(!0);
          };
        return i || s.queue === !1 ? this.each(o) : this.queue(s.queue, o);
      },
      stop: function (e, n, r) {
        var i = function (e) {
          var t = e.stop;
          delete e.stop, t(r);
        };
        return (
          typeof e != "string" && ((r = n), (n = e), (e = t)),
          n && e !== !1 && this.queue(e || "fx", []),
          this.each(function () {
            var t = !0,
              n = e != null && e + "queueHooks",
              s = v.timers,
              o = v._data(this);
            if (n) o[n] && o[n].stop && i(o[n]);
            else for (n in o) o[n] && o[n].stop && Wn.test(n) && i(o[n]);
            for (n = s.length; n--; )
              s[n].elem === this &&
                (e == null || s[n].queue === e) &&
                (s[n].anim.stop(r), (t = !1), s.splice(n, 1));
            (t || !r) && v.dequeue(this, e);
          })
        );
      },
    }),
    v.each(
      {
        slideDown: Zn("show"),
        slideUp: Zn("hide"),
        slideToggle: Zn("toggle"),
        fadeIn: { opacity: "show" },
        fadeOut: { opacity: "hide" },
        fadeToggle: { opacity: "toggle" },
      },
      function (e, t) {
        v.fn[e] = function (e, n, r) {
          return this.animate(t, e, n, r);
        };
      }
    ),
    (v.speed = function (e, t, n) {
      var r =
        e && typeof e == "object"
          ? v.extend({}, e)
          : {
              complete: n || (!n && t) || (v.isFunction(e) && e),
              duration: e,
              easing: (n && t) || (t && !v.isFunction(t) && t),
            };
      r.duration = v.fx.off
        ? 0
        : typeof r.duration == "number"
        ? r.duration
        : r.duration in v.fx.speeds
        ? v.fx.speeds[r.duration]
        : v.fx.speeds._default;
      if (r.queue == null || r.queue === !0) r.queue = "fx";
      return (
        (r.old = r.complete),
        (r.complete = function () {
          v.isFunction(r.old) && r.old.call(this),
            r.queue && v.dequeue(this, r.queue);
        }),
        r
      );
    }),
    (v.easing = {
      linear: function (e) {
        return e;
      },
      swing: function (e) {
        return 0.5 - Math.cos(e * Math.PI) / 2;
      },
    }),
    (v.timers = []),
    (v.fx = Yn.prototype.init),
    (v.fx.tick = function () {
      var e,
        n = v.timers,
        r = 0;
      qn = v.now();
      for (; r < n.length; r++)
        (e = n[r]), !e() && n[r] === e && n.splice(r--, 1);
      n.length || v.fx.stop(), (qn = t);
    }),
    (v.fx.timer = function (e) {
      e() &&
        v.timers.push(e) &&
        !Rn &&
        (Rn = setInterval(v.fx.tick, v.fx.interval));
    }),
    (v.fx.interval = 13),
    (v.fx.stop = function () {
      clearInterval(Rn), (Rn = null);
    }),
    (v.fx.speeds = { slow: 600, fast: 200, _default: 400 }),
    (v.fx.step = {}),
    v.expr &&
      v.expr.filters &&
      (v.expr.filters.animated = function (e) {
        return v.grep(v.timers, function (t) {
          return e === t.elem;
        }).length;
      });
  var er = /^(?:body|html)$/i;
  (v.fn.offset = function (e) {
    if (arguments.length)
      return e === t
        ? this
        : this.each(function (t) {
            v.offset.setOffset(this, e, t);
          });
    var n,
      r,
      i,
      s,
      o,
      u,
      a,
      f = { top: 0, left: 0 },
      l = this[0],
      c = l && l.ownerDocument;
    if (!c) return;
    return (r = c.body) === l
      ? v.offset.bodyOffset(l)
      : ((n = c.documentElement),
        v.contains(n, l)
          ? (typeof l.getBoundingClientRect != "undefined" &&
              (f = l.getBoundingClientRect()),
            (i = tr(c)),
            (s = n.clientTop || r.clientTop || 0),
            (o = n.clientLeft || r.clientLeft || 0),
            (u = i.pageYOffset || n.scrollTop),
            (a = i.pageXOffset || n.scrollLeft),
            { top: f.top + u - s, left: f.left + a - o })
          : f);
  }),
    (v.offset = {
      bodyOffset: function (e) {
        var t = e.offsetTop,
          n = e.offsetLeft;
        return (
          v.support.doesNotIncludeMarginInBodyOffset &&
            ((t += parseFloat(v.css(e, "marginTop")) || 0),
            (n += parseFloat(v.css(e, "marginLeft")) || 0)),
          { top: t, left: n }
        );
      },
      setOffset: function (e, t, n) {
        var r = v.css(e, "position");
        r === "static" && (e.style.position = "relative");
        var i = v(e),
          s = i.offset(),
          o = v.css(e, "top"),
          u = v.css(e, "left"),
          a =
            (r === "absolute" || r === "fixed") &&
            v.inArray("auto", [o, u]) > -1,
          f = {},
          l = {},
          c,
          h;
        a
          ? ((l = i.position()), (c = l.top), (h = l.left))
          : ((c = parseFloat(o) || 0), (h = parseFloat(u) || 0)),
          v.isFunction(t) && (t = t.call(e, n, s)),
          t.top != null && (f.top = t.top - s.top + c),
          t.left != null && (f.left = t.left - s.left + h),
          "using" in t ? t.using.call(e, f) : i.css(f);
      },
    }),
    v.fn.extend({
      position: function () {
        if (!this[0]) return;
        var e = this[0],
          t = this.offsetParent(),
          n = this.offset(),
          r = er.test(t[0].nodeName) ? { top: 0, left: 0 } : t.offset();
        return (
          (n.top -= parseFloat(v.css(e, "marginTop")) || 0),
          (n.left -= parseFloat(v.css(e, "marginLeft")) || 0),
          (r.top += parseFloat(v.css(t[0], "borderTopWidth")) || 0),
          (r.left += parseFloat(v.css(t[0], "borderLeftWidth")) || 0),
          { top: n.top - r.top, left: n.left - r.left }
        );
      },
      offsetParent: function () {
        return this.map(function () {
          var e = this.offsetParent || i.body;
          while (e && !er.test(e.nodeName) && v.css(e, "position") === "static")
            e = e.offsetParent;
          return e || i.body;
        });
      },
    }),
    v.each(
      { scrollLeft: "pageXOffset", scrollTop: "pageYOffset" },
      function (e, n) {
        var r = /Y/.test(n);
        v.fn[e] = function (i) {
          return v.access(
            this,
            function (e, i, s) {
              var o = tr(e);
              if (s === t)
                return o
                  ? n in o
                    ? o[n]
                    : o.document.documentElement[i]
                  : e[i];
              o
                ? o.scrollTo(
                    r ? v(o).scrollLeft() : s,
                    r ? s : v(o).scrollTop()
                  )
                : (e[i] = s);
            },
            e,
            i,
            arguments.length,
            null
          );
        };
      }
    ),
    v.each({ Height: "height", Width: "width" }, function (e, n) {
      v.each(
        { padding: "inner" + e, content: n, "": "outer" + e },
        function (r, i) {
          v.fn[i] = function (i, s) {
            var o = arguments.length && (r || typeof i != "boolean"),
              u = r || (i === !0 || s === !0 ? "margin" : "border");
            return v.access(
              this,
              function (n, r, i) {
                var s;
                return v.isWindow(n)
                  ? n.document.documentElement["client" + e]
                  : n.nodeType === 9
                  ? ((s = n.documentElement),
                    Math.max(
                      n.body["scroll" + e],
                      s["scroll" + e],
                      n.body["offset" + e],
                      s["offset" + e],
                      s["client" + e]
                    ))
                  : i === t
                  ? v.css(n, r, i, u)
                  : v.style(n, r, i, u);
              },
              n,
              o ? i : t,
              o,
              null
            );
          };
        }
      );
    }),
    (e.jQuery = e.$ = v),
    typeof define == "function" &&
      define.amd &&
      define.amd.jQuery &&
      define("jquery", [], function () {
        return v;
      });
})(window);
/*################ jquery.latest.min.js ends ###################*/

/*################ bizcatglog-js.min.js starts ###################*/
function changeprice(opt, shipp_element, product_element) {
  var product_price, ship_price, total, ship_typ, x;
  if (
    ((frmobj1 = eval("document.frmproduct.qty_" + opt)),
    (frmobj2 = eval("document.frmproduct.shipp" + opt)),
    (shipp_name = document.frmproduct.shippname_name.value),
    frmobj1.length > 1)
  )
    for (var i = 0; i < frmobj1.length; i++)
      frmobj1[i].checked &&
        ((product_price = frmobj1[i].value),
        (x = i + 1),
        (shipin_price = eval(
          "document.frmproduct.qty_ship" + opt + "_" + x
        ).value),
        (document.frmproduct.cart_product.value = eval(
          "document.frmproduct.product_name" + opt + "_" + x
        ).value),
        (document.frmproduct.tree.value = eval(
          "document.frmproduct.tree" + opt + "_" + x
        ).value),
        (document.frmproduct.prodid.value = eval(
          "document.frmproduct.prodid" + opt + "_" + x
        ).value));
  else
    frmobj1.checked &&
      ((product_price = frmobj1.value),
      (x = 1),
      (shipin_price = eval(
        "document.frmproduct.qty_ship" + opt + "_" + x
      ).value),
      (document.frmproduct.cart_product.value = eval(
        "document.frmproduct.product_name" + opt + "_" + x
      ).value),
      (document.frmproduct.tree.value = eval(
        "document.frmproduct.tree" + opt + "_" + x
      ).value),
      (document.frmproduct.prodid.value = eval(
        "document.frmproduct.prodid" + opt + "_" + x
      ).value));
  for (var cnt = 0; cnt < frmobj2.length; cnt++)
    frmobj2[cnt].checked && (ship_typ = frmobj2[cnt].value);
  if (shipin_price.indexOf("~") > -1) {
    (splt = shipin_price.split("~")),
      (splt_name = shipp_name.split("~")),
      splt.length > 0 &&
        ((shipping = parseFloat(splt[0])),
        parseFloat(shipping) > 0
          ? (total = parseFloat(product_price) + shipping)
          : ((total = product_price), (shipping = "0.00")));
    var shipp_name1 = splt_name[ship_typ];
  } else {
    var shipp_name1 = shipp_name;
    (total = product_price), (shipping = "0.00");
  }
  (document.frmproduct.cart_shipping.value = shipp_name1),
    (document.frmproduct.cart_shipping_amt.value = shipping),
    (document.frmproduct.cart_price.value = parseFloat(product_price)),
    (document.getElementById(shipp_element).innerHTML = adddecimal(shipping)),
    (document.getElementById(product_element).innerHTML = adddecimal(total));
}
function changeprice_weight(opt) {
  var product_price, ship_price, total, x;
  if (((frmobj1 = eval("document.frmproduct.qty_" + opt)), frmobj1.length > 1))
    for (var i = 0; i < frmobj1.length; i++)
      frmobj1[i].checked &&
        ((product_price = frmobj1[i].value),
        (x = i + 1),
        (shipin_price = eval(
          "document.frmproduct.qty_ship" + opt + "_" + x
        ).value),
        (document.frmproduct.cart_product.value = eval(
          "document.frmproduct.product_name" + opt + "_" + x
        ).value),
        (document.frmproduct.tree.value = eval(
          "document.frmproduct.tree" + opt + "_" + x
        ).value),
        (document.frmproduct.prodid.value = eval(
          "document.frmproduct.prodid" + opt + "_" + x
        ).value),
        (document.frmproduct.product_weight.value = eval(
          "document.frmproduct.weight" + opt + "_" + x
        ).value));
  else
    frmobj1.checked &&
      ((product_price = frmobj1.value),
      (x = 1),
      (shipin_price = eval(
        "document.frmproduct.qty_ship" + opt + "_" + x
      ).value),
      (document.frmproduct.cart_product.value = eval(
        "document.frmproduct.product_name" + opt + "_" + x
      ).value),
      (document.frmproduct.tree.value = eval(
        "document.frmproduct.tree" + opt + "_" + x
      ).value),
      (document.frmproduct.prodid.value = eval(
        "document.frmproduct.prodid" + opt + "_" + x
      ).value),
      (document.frmproduct.product_weight.value = eval(
        "document.frmproduct.weight" + opt + "_" + x
      ).value));
  document.frmproduct.cart_price.value = parseFloat(product_price);
}
function changeprice_new(opt, product_element) {
  var product_price, ship_price, total, x;
  frmobj1 = eval("document.frmproduct.qty_" + opt);
  for (var i = 0; i < frmobj1.length; i++)
    frmobj1[i].checked &&
      ((product_price = frmobj1[i].value),
      (x = i + 1),
      (shipin_price = eval(
        "document.frmproduct.qty_ship" + opt + "_" + x
      ).value),
      (document.frmproduct.cart_product.value = eval(
        "document.frmproduct.product_name" + opt + "_" + x
      ).value),
      (document.frmproduct.tree.value = eval(
        "document.frmproduct.tree" + opt + "_" + x
      ).value),
      (document.frmproduct.prodid.value = eval(
        "document.frmproduct.prodid" + opt + "_" + x
      ).value));
  (document.frmproduct.cart_price.value = parseFloat(product_price)),
    (document.getElementById(product_element).innerHTML =
      "$" + adddecimal(product_price));
}
function adddecimal(e) {
  return (
    (string = "" + e),
    -1 == string.indexOf(".")
      ? string + ".00"
      : ((seperation = string.length - string.indexOf(".")),
        seperation > 3
          ? string.substring(0, string.length - seperation + 3)
          : 2 == seperation
          ? string + "0"
          : string)
  );
}
function translator(e) {
  var t = unescape(document.location.toString()),
    r = "",
    a = "";
  if (-1 != t.indexOf("translate_c?")) {
    var o = t.indexOf("u=");
    if (-1 == o) r = document.location;
    else {
      var i = t.substring(o, t.length).split("&");
      r = i[0].substring(2, i[0].length);
    }
  } else r = document.location;
  indexof_p = e.indexOf("|");
  var n,
    l = "";
  -1 == indexof_p
    ? ((indexof_p1 = e.indexOf("><")),
      -1 == indexof_p1
        ? ((a = e), "en" == e && (l = 1))
        : ((a = (n = e.split("><"))[0] + "|" + n[1]), "en" == n[1] && (l = 1)))
    : ((a = (n = e.split("|"))[0] + "|" + n[1]), "en" == n[1] && (l = 1));
  var c = "";
  (c =
    1 == l
      ? r
      : "http://translate.google.com/translate_c?langpair=" + a + "&u=" + r),
    (window.location.href = c);
}
function part_obj_inquiry_now(
  form_submit_link,
  form_submit_status,
  form_name,
  id_val,
  checkbox_checked_st,
  checkbox_name
) {
  if (
    ((form_object = eval("document." + form_name)), "Y" == checkbox_checked_st)
  )
    var formObj = eval("form_object." + checkbox_name + ".checked=1");
  if ("Y" != form_submit_status) return !0;
  (form_object.action = "" + form_submit_link),
    (form_object.id.value = "" + id_val),
    ("cart" != id_val && "basket" != id_val) ||
      (form_object.cart_action.value = "add"),
    form_object.submit();
}
function part_obj_inquiry_now_new(e, t, r, a, o, i, n) {
  var l = document.createElement("form");
  (l.name = r), l.setAttribute("method", "post"), l.setAttribute("action", e);
  var c = document.createElement("input");
  c.setAttribute("type", "hidden"),
    c.setAttribute("name", "cart_action"),
    l.appendChild(c);
  var u = document.createElement("input");
  if (
    (u.setAttribute("type", "hidden"),
    u.setAttribute("name", i),
    u.setAttribute("value", n),
    l.appendChild(u),
    "Y" == o && (formObj = l.name + "." + i + ".checked=1"),
    "Y" != t)
  )
    return !0;
  l.setAttribute("id", a),
    ("cart" != a && "basket" != a) || (l.cart_action.value = "add"),
    document.body.appendChild(l),
    l.submit();
}
function inquiry_now(
  form_submit_link,
  form_submit_status,
  form_name,
  id_val,
  price_qty_chk
) {
  var pp = 1,
    notprod = 0;
  (form_object = eval("document." + form_name)),
    (len = form_object.elements.length);
  var arr_index = 0,
    prod = "";
  for (arr_index = 0; arr_index < len; arr_index++)
    if (
      "checkbox" == form_object.elements[arr_index].type &&
      1 == form_object.elements[arr_index].checked
    )
      if ("Y" == price_qty_chk) {
        var val1 = form_object.elements[arr_index].name;
        if (((splt = val1.split("_")), splt.length > 0)) {
          var price = eval(
              "document." + form_name + ".price_" + splt[1] + ".value"
            ),
            quantity = eval(
              "document." + form_name + ".stock_" + splt[1] + ".value"
            ),
            balance_stock = eval(
              "document." + form_name + ".balance_stock_" + splt[1] + ".value"
            );
          if (
            "Y" == quantity &&
            price > 0 &&
            balance_stock > 1 &&
            0 == prod.length
          )
            pp = 2;
          else if ("Y" != quantity || price <= 0 || balance_stock < 1) {
            var prod =
              prod +
              eval(
                "document." + form_name + ".productName_" + splt[1] + ".value"
              ) +
              " ,";
            notprod = 1;
          }
        }
      } else pp = 2;
    else pp = 2;
  return 1 == pp
    ? 1 == notprod
      ? (alert("Products " + prod + " not for sale or out of stock."), !1)
      : (alert(
          "You have not selected any Product / Item.\n\nPlease select  and  proceed"
        ),
        !1)
    : (1 == notprod &&
        alert("Products " + prod + " not for sale or out of stock."),
      "Y" != form_submit_status ||
        ((form_object.action = "" + form_submit_link),
        (form_object.id.value = "" + id_val),
        ("cart" != id_val && "basket" != id_val) ||
          (form_object.cart_action.value = "add"),
        void form_object.submit()));
}
function chk_unchk(val, form_name) {
  (dml = eval("document." + form_name)), (len = dml.elements.length);
  var i = 0;
  for (i = 0; i < len; i++)
    "checkbox" == dml.elements[i].type && (dml.elements[i].checked = 1 == val);
}
function openwin(e, t, r) {
  window
    .open(
      e,
      "iypWin1",
      "x=0,y=0,toolbar=no,location=no,directories=no,status=no,scrollbars=yes, copyhistory=no,width=" +
        t +
        ",height=" +
        r +
        ",screenX=0,screenY=0,left=20,top=20"
    )
    .focus();
}
function isProhibited(e) {
  var t = e.value;
  for (
    invalidstr = new Array(
      "indiamart",
      "india mart",
      "alibaba",
      "ali baba",
      "tradeindia",
      "trade-india"
    ),
      i = 0;
    i < invalidstr.length;
    i++
  )
    if (
      chktrim(t).toLowerCase().indexOf(chktrim(invalidstr[i]).toLowerCase()) >=
      0
    )
      return (
        alert("Usage of " + invalidstr[i] + " is Prohibited on this site."),
        e.focus(),
        !0
      );
  return !1;
}
function isValid(e) {
  var t = e.value;
  for (
    invalidstr = new Array(
      "hotmail",
      "gmail",
      "indiatimes",
      "rediffmail",
      "yahoo",
      ".com",
      ".net",
      ".org",
      ".co.in",
      ".co.cn",
      ".co.ca",
      ".gov",
      ".co.uk"
    ),
      i = 0;
    i < invalidstr.length;
    i++
  )
    if (
      chktrim(t).toLowerCase().indexOf(chktrim(invalidstr[i]).toLowerCase()) >=
      0
    )
      return alert("Please don't use " + invalidstr[i] + "."), e.focus(), !1;
  return !0;
}
function dynamic_form_validation(e) {
  for (
    total_elements = e.elements.length, element_count = 0;
    element_count < total_elements;
    element_count++
  ) {
    var t = e.elements[element_count],
      r = t.id,
      a = chktrim(t.value),
      o = t.type,
      i = r.split("_"),
      n = i[0].split("-"),
      l = "" + i[1];
    if ("r" == n[0] || "rp" == n[0])
      if ("select-one" == o) {
        if (
          "Select" == t.options[t.selectedIndex].value ||
          "" == t.options[t.selectedIndex].value
        )
          return alert(l), t.focus(), !1;
      } else if ("checkbox" == o) {
        if (0 == t.checked) return alert(l), t.focus(), !1;
      } else if (a.length < 1) return alert(l), t.focus(), !1;
    if (("p" == n[0] || "rp" == n[0]) && a.length > 0)
      if ("2" == n[1]) {
        if (!/^([a-zA-Z\s])+$/.test(a)) return alert(l), t.focus(), !1;
      } else if ("3" == n[1]) {
        if (!/^([a-zA-Z0-9\s])+$/.test(a)) return alert(l), t.focus(), !1;
      } else if ("4" == n[1]) {
        if (
          !/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(
            a
          )
        )
          return alert(l), t.focus(), !1;
      } else if ("5" == n[1]) {
        if (a.length < 8) return alert(l), t.focus(), !1;
        if (!/^[0-9+\-\,]+$/.test(a)) return alert(l), t.focus(), !1;
      } else if ("6" == n[1]) {
        if (!/^(http|ftp):\/\/(www\.)?.+\.(com|net|org)$/.test(a))
          return alert(l), t.focus(), !1;
      } else if ("7" == n[1]) {
        if (!/^([0-9]){2}(\/|-){1}([0-9]){2}(\/|-)([0-9]){4}$/.test(a))
          return alert(l), t.focus(), !1;
      } else if ("8" == n[1]) {
        if (!/^([0-9])+$/.test(a)) return alert(l), t.focus(), !1;
      } else if ("9" == n[1]) {
        if (!/^([0-9\.])+$/.test(a)) return alert(l), t.focus(), !1;
      }
  }
  e.submit.disabled = !0;
}
function form_validation(e) {
  total_elements = e.elements.length;
  var t = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  for (element_count = 0; element_count < total_elements; element_count++) {
    var r = e.elements[element_count],
      a = r.id,
      o = chktrim(r.value),
      i = r.type,
      n = a.split("_");
    if (-1 != n[0].indexOf("req"))
      if ("select-one" == i) {
        if ("" == r.options[r.selectedIndex].value)
          return alert("Please Select " + n[2]), r.focus(), !1;
      } else if ("checkbox" == i) {
        if (0 == r.checked)
          return alert("Please check the  " + n[2]), r.focus(), !1;
      } else {
        if (o.length < 1) return alert("Please enter " + n[2]), r.focus(), !1;
        if (-1 != a.indexOf("_Email-id")) {
          if (!t.test(o))
            return alert("Please enter valid " + n[2]), r.focus(), !1;
        } else if (-1 != a.indexOf("_int_")) {
          if (!parseInt(o))
            return alert("Please enter valid " + n[2]), r.focus(), !1;
        } else if (-1 != n[0].indexOf("prohb")) {
          if (
            (-1 != n[0].indexOf("prohb") || -1 != n[0].indexOf("prohb1")) &&
            isProhibited(r)
          )
            return !1;
          if (
            (-1 != n[0].indexOf("prohb") || -1 != n[0].indexOf("prohb2")) &&
            !isValid(r)
          )
            return !1;
        }
      }
    else if (-1 != n[0].indexOf("prohb") && o.length > 0)
      if (-1 != a.indexOf("_int_")) {
        if (!parseInt(o))
          return alert("Please enter valid " + n[2]), r.focus(), !1;
      } else {
        if (
          (-1 != n[0].indexOf("prohb") || -1 != n[0].indexOf("prohb1")) &&
          isProhibited(r)
        )
          return !1;
        if (
          (-1 != n[0].indexOf("prohb") || -1 != n[0].indexOf("prohb2")) &&
          !isValid(r)
        )
          return !1;
      }
  }
}
function chktrim(e) {
  if ("string" != typeof e) return e;
  for (var t = e, r = t.substring(0, 1); " " == r; )
    r = (t = t.substring(1, t.length)).substring(0, 1);
  for (r = t.substring(t.length - 1, t.length); " " == r; )
    r = (t = t.substring(0, t.length - 1)).substring(t.length - 1, t.length);
  for (; -1 != t.indexOf("  "); )
    t =
      t.substring(0, t.indexOf("  ")) +
      t.substring(t.indexOf("  ") + 1, t.length);
  return t;
}
function showme(e) {
  "C" == e
    ? (document.getElementById("show").style.display = "block")
    : "Y" == e && (document.getElementById("show").style.display = "none");
}
function openWindow(e) {
  window.open(e, "mywindow", "menubar=0,resizable=1,width=550,height=500");
}
function chk_mail_to_friend(e) {
  return 0 == e.frdemailid.value
    ? (alert("Please Enter Your Freind E-MailID"), e.frdemailid.focus(), !1)
    : -1 == e.frdemailid.value.indexOf("@")
    ? (alert("Error in e-mail address"), e.frdemailid.focus(), !1)
    : -1 == e.frdemailid.value.indexOf(".")
    ? (alert("Error in e-mail address"), e.frdemailid.focus(), !1)
    : e.frdemailid.value.indexOf("@") != e.frdemailid.value.lastIndexOf("@")
    ? (alert("Please Specify One E-mail address only"),
      e.frdemailid.focus(),
      !1)
    : 0 == e.name.value
    ? (alert("Please Enter Your Name"), e.name.focus(), !1)
    : 0 == e.emailid.value
    ? (alert("Please Enter Your E-MailID"), e.emailid.focus(), !1)
    : -1 == e.emailid.value.indexOf("@")
    ? (alert("Error in e-mail address"), e.emailid.focus(), !1)
    : -1 == e.emailid.value.indexOf(".")
    ? (alert("Error in e-mail address"), e.emailid.focus(), !1)
    : void 0;
}
function event_send_enquiry(e) {
  return 0 == chktrim(e.your_name.value).length
    ? (alert("Please Enter Your Name "), e.your_name.focus(), !1)
    : 0 == chktrim(e.emailid.value).length
    ? (alert("Email-Id can't be left blank"), e.emailid.focus(), !1)
    : -1 == chktrim(e.emailid.value).indexOf("@")
    ? (alert("Error in Email-Id"), e.emailid.focus(), !1)
    : -1 == chktrim(e.emailid.value).indexOf(".")
    ? (alert("Error in Email-Id"), e.emailid.focus(), !1)
    : chktrim(e.emailid.value).indexOf("@") !=
      chktrim(e.emailid.value).lastIndexOf("@")
    ? (alert("Please Specify One Email-Id only"), e.emailid.focus(), !1)
    : 0 == chktrim(e.address.value).length
    ? (alert("Please Enter Address "), e.address.focus(), !1)
    : chktrim(e.country.value).length < 1
    ? (alert("Please Select Country"), e.country.focus(), !1)
    : chktrim(e.ph_ccode.value).length < 1
    ? (alert("Please Enter Phone No.(ISD code)"), e.ph_ccode.focus(), !1)
    : isNaN(chktrim(e.ph_ccode.value))
    ? (alert("Please Enter Correct ISD Code For Phone No.(ISD code)"),
      e.ph_ccode.focus(),
      !1)
    : chktrim(e.ph_acode.value).length < 1
    ? (alert("Please Enter Phone No.(STD code)"), e.ph_acode.focus(), !1)
    : isNaN(chktrim(e.ph_acode.value))
    ? (alert("Please Enter Correct STD Code For Phone No.(STD code)"),
      e.ph_acode.focus(),
      !1)
    : chktrim(e.ph_number.value).length < 1
    ? (alert("Please Enter Phone No.(Number)"), e.ph_number.focus(), !1)
    : isNaN(chktrim(e.ph_number.value))
    ? (alert("Please Enter Correct Number For Phone No.(Number)"),
      e.ph_number.focus(),
      !1)
    : "VR" != e.enq_type.value && 0 == chktrim(e.business_type.value).length
    ? (alert("Please Select Business Type"), e.business_type.focus(), !1)
    : void 0;
}
function chk_hotel_inq_form(e) {
  return 0 == chktrim(e.arrival_dd.value).length
    ? (alert("Please Enter Your Arrival Day "), e.arrival_dd.focus(), !1)
    : 0 == chktrim(e.arrival_mm.value).length
    ? (alert("Please Enter Your Arrival Month "), e.arrival_mm.focus(), !1)
    : 0 == chktrim(e.arrival_yyyy.value).length
    ? (alert("Please Enter Your Arrival Year "), e.arrival_yyyy.focus(), !1)
    : 0 == chktrim(e.departure_dd.value).length
    ? (alert("Please Enter Your Departure Day "), e.departure_dd.focus(), !1)
    : 0 == chktrim(e.departure_mm.value).length
    ? (alert("Please Enter Your Departure Month "), e.departure_mm.focus(), !1)
    : 0 == chktrim(e.departure_yyyy.value).length
    ? (alert("Please Enter Your Departure Year "), e.departure_yyyy.focus(), !1)
    : 0 == chktrim(e.no_rooms.value).length
    ? (alert("Please Enter No. of Rooms "), e.no_rooms.focus(), !1)
    : 0 == chktrim(e.other_req.value).length
    ? (alert("Please Enter Other Requirements "), e.other_req.focus(), !1)
    : 0 == chktrim(e.person_name.value).length
    ? (alert("Please Enter Your Name "), e.person_name.focus(), !1)
    : 0 == chktrim(e.username.value).length
    ? (alert("Please Enter Your Email ID "), e.username.focus(), !1)
    : 0 == chktrim(e.username.value).length
    ? (alert("Email-Id can't be left blank"), e.username.focus(), !1)
    : -1 == chktrim(e.username.value).indexOf("@")
    ? (alert("Error in Email-Id"), e.username.focus(), !1)
    : -1 == chktrim(e.username.value).indexOf(".")
    ? (alert("Error in Email-Id"), e.username.focus(), !1)
    : chktrim(e.username.value).indexOf("@") !=
      chktrim(e.username.value).lastIndexOf("@")
    ? (alert("Please Specify One Email-Id only"), e.emailid.focus(), !1)
    : 0 == chktrim(e.mobile.value).length
    ? (alert("Please Enter Your Mobile Number "), e.mobile.focus(), !1)
    : 0 == chktrim(e.address.value).length
    ? (alert("Please Enter Your Address "), e.address.focus(), !1)
    : 0 == chktrim(e.country.value).length
    ? (alert("Please Enter Your Country "), e.country.focus(), !1)
    : void 0;
}
function chk_project_inqform(e, t) {
  if (0 == chktrim(e.your_name.value).length)
    return alert("Please Enter Your Name "), e.your_name.focus(), !1;
  if (0 == chktrim(e.email_id.value).length)
    return alert("Please Enter Your Email ID "), e.email_id.focus(), !1;
  return /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(
    e.email_id.value
  )
    ? 0 == chktrim(e.mobile.value).length
      ? (alert("Please Enter Your Mobile Number "), e.mobile.focus(), !1)
      : 0 == chktrim(e.desc.value).length
      ? (alert("Please Enter Your Requirement "), e.desc.focus(), !1)
      : "Y" == t && 0 == chktrim(e.code.value).length
      ? (alert("Please Enter Verification Code "), e.code.focus(), !1)
      : void 0
    : (alert("Plaese enter a valid Emaail ID."), e.email_id.focus(), !1);
}
function requirement_form(e) {
  return 0 == chktrim(e.inq_subject.value).length
    ? (alert("Please Enter Subject "), e.inq_subject.focus(), !1)
    : 0 == chktrim(e.inq_desc.value).length
    ? (alert("Please Enter Your Inquiry Description. "), e.inq_desc.focus(), !1)
    : 0 == chktrim(e.your_name.value).length
    ? (alert("Please Enter Your Name. "), e.your_name.focus(), !1)
    : 0 == chktrim(e.email_id.value).length
    ? (alert("Please Enter Your Email ID "), e.email_id.focus(), !1)
    : 0 == chktrim(e.email_id.value).length
    ? (alert("Email-Id can't be left blank"), e.email_id.focus(), !1)
    : -1 == chktrim(e.email_id.value).indexOf("@")
    ? (alert("Error in Email-Id"), e.email_id.focus(), !1)
    : -1 == chktrim(e.email_id.value).indexOf(".")
    ? (alert("Error in Email-Id"), e.email_id.focus(), !1)
    : chktrim(e.email_id.value).indexOf("@") !=
      chktrim(e.email_id.value).lastIndexOf("@")
    ? (alert("Please Specify One Email-Id only"), e.emailid.focus(), !1)
    : 0 == chktrim(e.contact_no.value).length
    ? (alert("Please Enter Your Contact No. "), e.contact_no.focus(), !1)
    : 0 == chktrim(e.address.value).length
    ? (alert("Please Enter Your Full Address "), e.address.focus(), !1)
    : void 0;
}
function select_item_cart() {
  for (var e = 0, t = 0; t < document.frmproduct.qty_1.length; t++)
    document.frmproduct.qty_1[t].checked && (e = 1);
  if (0 == e)
    return (
      alert("Please Select Your Item Products "),
      document.frmproduct.qty_1[0].focus(),
      !1
    );
}
function select_item_cart_new() {
  if ("" == document.frmproduct.prodid.value)
    return alert("Please Select Your Item Products "), !1;
}
function inquiry_checkbox_select(e) {
  for (var t = !1, r = !1, a = 0; a < e.length; a++)
    "chk_" == e.elements[a].name.substr(0, 4) &&
      ("checkbox" == e.elements[a].type &&
        1 == e.elements[a].checked &&
        (t = !0),
      (r = !0));
  return 1 == t || 1 != r || (alert("Please check at least one checkbox."), !1);
}
function newsletter_validation() {
  var e = document.newsletter.news_letter_email.value;
  if ("" == e || "Enter Email" == e)
    return (
      alert("Please Enter Email"),
      document.newsletter.news_letter_email.focus(),
      !1
    );
  if ("" != e) {
    if (
      !/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(e)
    )
      return (
        alert("Please Enter Valid Email"),
        (document.newsletter.news_letter_email.value = ""),
        document.newsletter.news_letter_email.focus(),
        !1
      );
  }
  return !0;
}
/*################ bizcatglog-js.min.js ends ###################*/

/*################ country_list.min.js starts ###################*/
var countryarr = new Array(
    "Afghanistan",
    "Albania",
    "Algeria",
    "American Samoa",
    "Andorra",
    "Angola",
    "Anguilla",
    "Antigua and Barbuda",
    "Argentina",
    "Armenia",
    "Aruba",
    "Australia",
    "Austria",
    "Azerbaijan",
    "Bahamas",
    "Bahrain",
    "Bangladesh",
    "Barbados",
    "Bassas da India",
    "Belarus",
    "Belgium",
    "Belize",
    "Benin",
    "Bermuda",
    "Bhutan",
    "Bolivia",
    "Bosnia and Herzegovina",
    "Botswana",
    "Bouvet Island",
    "Brazil",
    "British Indian Ocean Territory",
    "British Virgin Islands",
    "Brunei",
    "Bulgaria",
    "Burkina Faso",
    "Burma/Myanmar",
    "Burundi",
    "Cambodia",
    "Cameroon",
    "Canada",
    "Cape Verde",
    "Cayman Islands",
    "Central African Republic",
    "Chad",
    "Chile",
    "China",
    "Christmas Island",
    "Cocos (Keeling) Islands",
    "Colombia",
    "Comoros",
    "Congo",
    "Cook Islands",
    "Costa Rica",
    "Cote d'Ivoire/Ivory Coast",
    "Croatia",
    "Cuba",
    "Cyprus",
    "Czech",
    "Democratic Republic of the Congo",
    "Denmark",
    "Djibouti",
    "Dominica",
    "Dominican",
    "East Timor",
    "Ecuador",
    "Egypt",
    "El Salvador",
    "Equatorial Guinea",
    "Eritrea",
    "Estonia",
    "Ethiopia",
    "Europa Island",
    "Falkland Islands",
    "Faroe Islands",
    "Fiji",
    "Finland",
    "France",
    "French Guiana",
    "French Polynesia",
    "French Southern and Antarctic Lands",
    "Fyro Macedonia",
    "Gabon",
    "Gambia",
    "Gaza Strip",
    "Georgia",
    "Germany",
    "Ghana",
    "Gibraltar",
    "Glorioso Islands",
    "Greece",
    "Greenland",
    "Grenada",
    "Guadeloupe",
    "Guam",
    "Guatemala",
    "Guernsey",
    "Guinea",
    "Guinea-Bissau",
    "Guyana",
    "Haiti",
    "Holy See (Vatican City)",
    "Honduras",
    "Hong Kong",
    "Hungary",
    "Iceland",
    "India",
    "Indonesia",
    "Iran",
    "Iraq",
    "Ireland",
    "Isle of Man",
    "Israel",
    "Italy",
    "Jamaica",
    "Japan",
    "Jersey",
    "Jordan",
    "Juan de Nova Island",
    "Kazakhstan",
    "Kenya",
    "Kiribati",
    "Korea, South",
    "North Korea",
    "Kuwait",
    "Kyrgyzstan",
    "Laos",
    "Latvia",
    "Lebanon",
    "Lesotho",
    "Liberia",
    "Libya",
    "Liechtenstein",
    "Lithuania",
    "Luxembourg",
    "Macao",
    "Macedonia",
    "Madagascar",
    "Malawi",
    "Malaysia",
    "Maldives",
    "Mali",
    "Malta",
    "Man, Isle of",
    "Marshall Islands",
    "Martinique",
    "Mauritania",
    "Mauritius",
    "Mayotte",
    "Mexico",
    "Micronesia",
    "Midway Islands",
    "Moldova",
    "Monaco",
    "Mongolia",
    "Montenegro",
    "Montenegro(Karadag)",
    "Montserrat",
    "Morocco",
    "Mozambique",
    "Namibia",
    "Nauru",
    "Nepal",
    "Navassa Island",
    "Netherlands",
    "Netherlands Antilles",
    "New Caledonia",
    "New Zealand",
    "Nicaragua",
    "Niger",
    "Nigeria",
    "Niue",
    "Norfolk Island",
    "Northern Mariana Islands",
    "Norway",
    "Oman",
    "Pakistan",
    "Palau",
    "Panama",
    "Papua New Guinea",
    "Paraguay",
    "Peru",
    "Philippines",
    "Pitcairn Islands",
    "Poland",
    "Portugal",
    "Puerto Rico",
    "Qatar",
    "Reunion",
    "Romania",
    "Russia",
    "Rwanda",
    "Saint Helena",
    "Saint Kitts and Nevis",
    "Saint Lucia",
    "Saint Vincent and the Grenadines",
    "Samoa",
    "San Marino",
    "Sao Tome and Principe",
    "Saudi Arabia",
    "Senegal",
    "Serbia",
    "Seychelles",
    "Sierra Leone",
    "Singapore",
    "Slovakia",
    "Slovenia",
    "Solomon Islands",
    "Somalia",
    "South Africa",
    "South Sudan",
    "Spain",
    "Sri Lanka",
    "Sudan",
    "Suriname",
    "Svalbard",
    "Swaziland",
    "Sweden",
    "Switzerland",
    "Syria",
    "Taiwan",
    "Tajikistan",
    "Tanzania",
    "Thailand",
    "Timor-Leste",
    "Togo",
    "Tokelau",
    "Tonga",
    "Trinidad and Tobago",
    "Tromelin Island",
    "Tunisia",
    "Turkey",
    "Turkmenistan",
    "Turks and Caicos Islands",
    "Tuvalu",
    "Uganda",
    "Ukraine",
    "United Arab Emirates",
    "United Kingdom",
    "United States",
    "Uruguay",
    "US Virgin Islands",
    "Uzbekistan",
    "Vanuatu",
    "Vatican City",
    "Vietnam",
    "Venezuela",
    "Wake Island",
    "Wallis and Futuna",
    "Western Sahara",
    "Yemen",
    "Zambia",
    "Zimbabwe"
  ),
  countryarr_value = new Array(
    "AF",
    "AL",
    "DZ",
    "AS",
    "AD",
    "AO",
    "AI",
    "AG",
    "AR",
    "AM",
    "AW",
    "AU",
    "AT",
    "AZ",
    "BS",
    "BH",
    "BD",
    "BB",
    "BS",
    "BY",
    "BE",
    "BZ",
    "BJ",
    "BM",
    "BT",
    "BO",
    "BA",
    "BW",
    "BV",
    "BR",
    "IO",
    "VG",
    "BN",
    "BG",
    "BF",
    "MM",
    "BI",
    "KH",
    "CM",
    "CA",
    "CV",
    "KY",
    "CF",
    "TD",
    "CL",
    "CN",
    "CX",
    "CC",
    "CO",
    "KM",
    "CG",
    "CK",
    "CR",
    "CI",
    "HR",
    "CU",
    "CY",
    "CZ",
    "CD",
    "DK",
    "DJ",
    "DM",
    "DO",
    "TP",
    "EC",
    "EG",
    "SV",
    "GQ",
    "ER",
    "EE",
    "ET",
    "EU",
    "FK",
    "FO",
    "FJ",
    "FI",
    "FR",
    "GF",
    "PF",
    "FR",
    "ZD",
    "GA",
    "GM",
    "GZ",
    "GE",
    "DE",
    "GH",
    "RG",
    "GO",
    "GR",
    "GL",
    "GD",
    "GP",
    "GU",
    "GT",
    "GG",
    "GN",
    "GW",
    "GY",
    "HT",
    "VA",
    "HN",
    "HK",
    "HU",
    "IS",
    "IN",
    "ID",
    "IR",
    "IQ",
    "IE",
    "IM",
    "IL",
    "IT",
    "JM",
    "JP",
    "JE",
    "JO",
    "JO",
    "KZ",
    "KE",
    "KI",
    "KR",
    "KP",
    "KW",
    "KG",
    "LA",
    "LV",
    "LB",
    "LS",
    "LR",
    "LY",
    "LI",
    "LT",
    "LU",
    "MO",
    "MK",
    "MG",
    "MW",
    "MY",
    "MV",
    "ML",
    "MT",
    "IB",
    "MH",
    "MQ",
    "MR",
    "MU",
    "YT",
    "MX",
    "FM",
    "MW",
    "MD",
    "MC",
    "MN",
    "ME",
    "ME",
    "MS",
    "MA",
    "MZ",
    "NA",
    "NR",
    "NP",
    "VL",
    "NL",
    "AN",
    "NC",
    "NZ",
    "NI",
    "NE",
    "NG",
    "NU",
    "NFK",
    "MP",
    "NO",
    "OM",
    "PK",
    "PK",
    "PA",
    "PG",
    "PY",
    "PE",
    "PH",
    "PCN",
    "PL",
    "PT",
    "PR",
    "QA",
    "RE",
    "RO",
    "RU",
    "RW",
    "SH",
    "KN",
    "LC",
    "VC",
    "WS",
    "SM",
    "ST",
    "SA",
    "SN",
    "RS",
    "SC",
    "SL",
    "SG",
    "SK",
    "SI",
    "SB",
    "SO",
    "ZA",
    "SD",
    "ES",
    "LK",
    "SD",
    "SR",
    "SJ",
    "SZ",
    "SE",
    "CH",
    "SY",
    "TW",
    "TJ",
    "TZ",
    "TH",
    "TL",
    "TG",
    "TK",
    "TO",
    "TT",
    "TE",
    "TN",
    "TR",
    "TM",
    "TC",
    "TV",
    "UG",
    "UA",
    "AE",
    "GB",
    "US",
    "UY",
    "VI",
    "UZ",
    "VU",
    "VA",
    "VN",
    "VE",
    "WQ",
    "WF",
    "EH",
    "YE",
    "ZM",
    "ZW"
  );
function showcountrylist(a, n, i) {
  for (var e = 0; e < countryarr.length; ++e) {
    (Array.prototype.in_array = function (a) {
      for (var n = 0, i = this.length; n < i; n++) if (this[n] == a) return !0;
      return !1;
    }),
      addSelectOptions(
        document.forms[a][n],
        countryarr[e],
        countryarr_value[e],
        i
      );
  }
}
function addSelectOptions(a, n, i, e) {
  var r = document.createElement("option");
  (r.text = n),
    (r.value = i),
    i == e && (r.selected = "selected"),
    a.options.add(r);
}
/*################ country_list.min.js ends ###################*/

/*################ common-static-form.min.js starts ###################*/
var countryarr_isd_value = {
  AF: "93",
  AL: "335",
  DZ: "213",
  AS: "684",
  AD: "376",
  AO: "244",
  AI: "264",
  AQ: "672",
  AG: "268",
  AR: "54",
  AM: "374",
  AW: "297",
  AU: "61",
  AT: "43",
  AZ: "994",
  BS: "242",
  BH: "973",
  BD: "880",
  BB: "246",
  BY: "375",
  BE: "32",
  BZ: "501",
  BJ: "229",
  BM: "441",
  BT: "975",
  BO: "591",
  BA: "387",
  BW: "267",
  BV: "47",
  BR: "55",
  IO: "246",
  BN: "673",
  BG: "359",
  BF: "226",
  BI: "257",
  KH: "855",
  CM: "237",
  CA: "1",
  CV: "238",
  KY: "345",
  CF: "236",
  TD: "235",
  CL: "56",
  CN: "86",
  CX: "61",
  CC: "61",
  CO: "57",
  KM: "269",
  CG: "242",
  CK: "682",
  CR: "506",
  CI: "225",
  HR: "385",
  CU: "53",
  CY: "357",
  CZ: "420",
  DK: "45",
  DJ: "253",
  DM: "767",
  DO: "809",
  TP: "670",
  EC: "593",
  EG: "20",
  SV: "503",
  GQ: "240",
  ER: "291",
  EE: "372",
  ET: "251",
  FK: "500",
  FO: "298",
  FJ: "679",
  FI: "358",
  FR: "33",
  FX: "590",
  GF: "594",
  PF: "689",
  TF: "590",
  GA: "241",
  GM: "220",
  GE: "995",
  DE: "49",
  GH: "233",
  GI: "350",
  GR: "30",
  GL: "299",
  GD: "809",
  GP: "590",
  GU: "1",
  GT: "502",
  GN: "224",
  GW: "245",
  GY: "592",
  HT: "509",
  HM: "61",
  HN: "504",
  HK: "852",
  HU: "36",
  IS: "354",
  IN: "91",
  ID: "62",
  IR: "98",
  IQ: "964",
  IE: "353",
  IL: "972",
  IT: "39",
  JM: "876",
  JP: "81",
  JO: "962",
  KZ: "7",
  KE: "254",
  KI: "686",
  KP: "850",
  KR: "82",
  KW: "965",
  KG: "7",
  LA: "856",
  LV: "371",
  LB: "961",
  LS: "266",
  LR: "231",
  LY: "218",
  LI: "423",
  LT: "370",
  LU: "352",
  MO: "853",
  MK: "389",
  MG: "261",
  MW: "265",
  MY: "60",
  MV: "960",
  ML: "223",
  MT: "356",
  MH: "692",
  MQ: "596",
  MR: "222",
  MU: "230",
  YT: "269",
  MX: "52",
  FM: "691",
  MD: "373",
  MC: "377",
  MN: "976",
  MS: "664",
  MA: "212",
  MZ: "258",
  MM: "95",
  NA: "264",
  NR: "674",
  NP: "977",
  NL: "31",
  AN: "599",
  NC: "687",
  NZ: "64",
  NI: "505",
  NE: "227",
  NG: "234",
  NU: "683",
  NF: "672",
  MP: "670",
  NO: "47",
  OM: "968",
  PK: "92",
  PW: "680",
  PA: "507",
  PG: "675",
  PY: "595",
  PE: "51",
  PH: "63",
  PN: "872",
  PL: "48",
  PR: "787",
  QA: "974",
  RE: "262",
  RO: "40",
  RU: "7",
  RW: "250",
  KN: "869",
  LC: "758",
  VC: "784",
  WS: "685",
  SM: "378",
  ST: "239",
  SA: "966",
  SN: "221",
  SC: "248",
  SL: "232",
  SG: "65",
  SK: "421",
  SI: "386",
  SB: "677",
  SO: "252",
  ZA: "27",
  GS: "44",
  ES: "34",
  LK: "94",
  SH: "290",
  PM: "508",
  SD: "249",
  SR: "597",
  SJ: "47",
  SZ: "268",
  SE: "46",
  CH: "41",
  SY: "963",
  TW: "886",
  TJ: "7",
  TZ: "255",
  TH: "66",
  TG: "228",
  TK: "64",
  TO: "676",
  TT: "868",
  TN: "216",
  TR: "90",
  TM: "993",
  TC: "649",
  TV: "688",
  UG: "256",
  UA: "380",
  AE: "971",
  UK: "44",
  US: "1",
  UM: "1",
  UY: "598",
  UZ: "7",
  VU: "678",
  VA: "39",
  VE: "58",
  VN: "84",
  VG: "1",
  VI: "1",
  WF: "681",
  EH: "212",
  YE: "967",
  YU: "381",
  ZR: "243",
  ZM: "260",
  ZW: "263",
  PT: "351",
};
function static_inq_form_validate(e) {
  if ("" == e || "10001" == e) {
    if ("0" == chktrim(document.static_form.dynFrm_subject.value).length)
      return (
        alert("Please Enter Your Subject"),
        document.static_form.dynFrm_subject.focus(),
        !1
      );
    if (
      0 == chktrim(document.static_form.dynFrm_details_2.value).length ||
      chktrim(document.static_form.dynFrm_details_2.value).length < 20
    )
      return (
        alert(
          "Please Enter Your Requirement Details [ Minimum 20 Characters ]"
        ),
        document.static_form.dynFrm_details_2.focus(),
        !1
      );
    if (chktrim(document.static_form.dynFrm_details_2.value).length > 1e3)
      return (
        alert(
          "Please Enter Your Requirement Details [ Maximum 1000 Characters ]"
        ),
        document.static_form.dynFrm_details_2.focus(),
        !1
      );
    if (0 == chktrim(document.static_form.dynFrm_contact_person.value).length)
      return (
        alert("Please Enter Your Name"),
        document.static_form.dynFrm_contact_person.focus(),
        !1
      );
    if (document.static_form.comp_name_valid.checked)
      document
        .getElementById("dynFrm_company_name")
        .setAttribute("disabled", !0),
        (document.getElementById("company-name-star").className = "star dn"),
        (document.getElementById("company-name-star").style.display = "none");
    else if (
      0 == chktrim(document.static_form.dynFrm_company_name.value).length
    )
      return (
        alert("Please Enter Company Name"),
        document.static_form.dynFrm_company_name.focus(),
        !1
      );
    if (
      "" ==
      document.static_form.dynFrm_country.options[
        document.static_form.dynFrm_country.selectedIndex
      ].value
    )
      return (
        alert("Please Select Your Country."),
        document.static_form.dynFrm_country.focus(),
        !1
      );
    if (
      "IN^91" ==
        document.static_form.dynFrm_country.options[
          document.static_form.dynFrm_country.selectedIndex
        ].value &&
      "" ==
        document.static_form.dynFrm_state.options[
          document.static_form.dynFrm_state.selectedIndex
        ].value
    )
      return (
        alert("Please Select State."),
        document.static_form.dynFrm_state.focus(),
        !1
      );
    if (
      "N" != document.static_form.email_valid.value &&
      document.static_form.email_valid.checked
    )
      document.getElementById("dynFrm_email_id").setAttribute("disabled", !0),
        (document.getElementById("email-star").className = "star dn"),
        (document.getElementById("email-star").style.display = "none");
    else {
      var t = document.static_form.dynFrm_email_id.value;
      if ("" == chktrim(t))
        return (
          alert("Please enter email."),
          document.static_form.dynFrm_email_id.focus(),
          !1
        );
      var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
      if (!1 == r.test(t))
        return (
          alert("Please enter valid email."),
          document.static_form.dynFrm_email_id.focus(),
          !1
        );
    }
    if (0 == chktrim(document.static_form.dynFrm_phone.value).length)
      return (
        alert("Please Enter Mobile Number."),
        document.static_form.dynFrm_phone.focus(),
        !1
      );
    if (chktrim(document.static_form.dynFrm_phone.value).length > 0) {
      if (isNaN(document.static_form.dynFrm_phone.value))
        return (
          alert(
            "Please enter valid mobile number.Do not enter alphabet or special characters."
          ),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      if (
        (chktrim(document.static_form.dynFrm_phone.value).length < 10 ||
          chktrim(document.static_form.dynFrm_phone.value).length > 10) &&
        "IN^91" ==
          document.static_form.dynFrm_country.options[
            document.static_form.dynFrm_country.selectedIndex
          ].value
      )
        return (
          alert("Mobile Number Should be 10 digits."),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      if (
        chktrim(document.static_form.dynFrm_phone.value).length < 3 ||
        chktrim(document.static_form.dynFrm_phone.value).length > 15
      )
        return (
          alert("Mobile Number Should be 3 digits at least."),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
    }
    if (
      document.static_form.code &&
      0 == chktrim(document.static_form.code.value).length
    )
      return (
        alert("Please Enter Security Code Displayed on the Image."),
        document.static_form.code.focus(),
        !1
      );
  } else if ("10002" == e || "10003" == e) {
    if ("0" == chktrim(document.static_form.dynFrm_arrival_date.value).length)
      return (
        alert("Please add the travel date."),
        document.static_form.dynFrm_arrival_date.focus(),
        !1
      );
    if (
      void 0 !== document.static_form.dynFrm_departure_date &&
      "0" == chktrim(document.static_form.dynFrm_departure_date.value).length
    )
      return (
        alert("Please add the departure date."),
        document.static_form.dynFrm_departure_date.focus(),
        !1
      );
    if ("0" == chktrim(document.static_form.dynFrm_no_of_adults.value).length)
      return (
        alert("Please select the no. of persons."),
        document.static_form.dynFrm_no_of_adults.focus(),
        !1
      );
    if (
      "10003" == e &&
      "0" == chktrim(document.static_form.dynFrm_no_of_rooms.value).length
    )
      return (
        alert("Please select the no. of rooms."),
        document.static_form.dynFrm_no_of_rooms.focus(),
        !1
      );
    if (
      "0" ==
        chktrim(document.static_form.dynFrm_travel_plan_requirement.value)
          .length &&
      (void 0 === document.static_form.desc_valid ||
        (void 0 !== document.static_form.desc_valid &&
          "N" != document.static_form.desc_valid.value))
    )
      return (
        alert("Please enter description."),
        document.static_form.dynFrm_travel_plan_requirement.focus(),
        !1
      );
    if (
      document.static_form.code &&
      0 == chktrim(document.static_form.code.value).length
    )
      return (
        alert("Please Enter Security Code Displayed on the Image."),
        document.static_form.code.focus(),
        !1
      );
    if (0 == chktrim(document.static_form.dynFrm_your_name.value).length)
      return (
        alert("Please Enter Your Name"),
        document.static_form.dynFrm_your_name.focus(),
        !1
      );
    var t = document.static_form.dynFrm_your_e_mail.value;
    if ("" == chktrim(t))
      return (
        alert("Please enter email."),
        document.static_form.dynFrm_your_e_mail.focus(),
        !1
      );
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        alert("Please enter valid email."),
        document.static_form.dynFrm_your_e_mail.focus(),
        !1
      );
    if (
      "" ==
      document.static_form.dynFrm_country.options[
        document.static_form.dynFrm_country.selectedIndex
      ].value
    )
      return (
        alert("Please Select Your Country."),
        document.static_form.dynFrm_country.focus(),
        !1
      );
    if (
      "IN^+91" ==
        document.static_form.dynFrm_country.options[
          document.static_form.dynFrm_country.selectedIndex
        ].value &&
      "" ==
        document.static_form.dynFrm_state.options[
          document.static_form.dynFrm_state.selectedIndex
        ].value
    )
      return (
        alert("Please Select State."),
        document.static_form.dynFrm_state.focus(),
        !1
      );
    if (0 == chktrim(document.static_form.dynFrm_other_city.value).length)
      return (
        alert("Please enter City."),
        document.static_form.dynFrm_other_city.focus(),
        !1
      );
    if (0 == chktrim(document.static_form.dynFrm_phone_mobile.value).length)
      return (
        alert("Please Enter Mobile Number."),
        document.static_form.dynFrm_phone_mobile.focus(),
        !1
      );
    var n = /^[0-9\/,-]+$/;
    if (chktrim(document.static_form.dynFrm_phone_mobile.value).length > 0) {
      if (!n.test(document.static_form.dynFrm_phone_mobile.value))
        return (
          alert(
            "Please enter valid mobile number.Do not enter alphabet or special characters. Special Characters allowed only [-/,]"
          ),
          document.static_form.dynFrm_phone_mobile.focus(),
          !1
        );
      if (
        (chktrim(document.static_form.dynFrm_phone_mobile.value).length < 10 ||
          chktrim(document.static_form.dynFrm_phone_mobile.value).length >
            10) &&
        "IN^+91" ==
          document.static_form.dynFrm_country.options[
            document.static_form.dynFrm_country.selectedIndex
          ].value
      )
        return (
          alert("Mobile Number Should be 10 digits."),
          document.static_form.dynFrm_phone_mobile.focus(),
          !1
        );
      if (chktrim(document.static_form.dynFrm_phone_mobile.value).length < 3)
        return (
          alert("Mobile Number Should be 3 digits at least."),
          document.static_form.dynFrm_phone_mobile.focus(),
          !1
        );
    }
  } else if ("10004" == e || "10005" == e) {
    if ("0" == chktrim(document.static_form.dynFrm_inquiry_for.value).length)
      return (
        jQuery("#dynFrm_inquiry_for")
          .parent()
          .find("span.red")
          .text("Please select Enquiry for."),
        document.static_form.dynFrm_inquiry_for.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_inquiry_for").parent().find("span.red").text(""),
      "10099" == document.getElementById("dynFrm_inquiry_for").value ||
        "10335" == document.getElementById("dynFrm_inquiry_for").value ||
        "10102" == document.getElementById("dynFrm_inquiry_for").value ||
        "10101" == document.getElementById("dynFrm_inquiry_for").value ||
        "10322" == document.getElementById("dynFrm_inquiry_for").value)
    ) {
      if ("0" == chktrim(document.static_form.dynFrm_arrival_date.value).length)
        return (
          jQuery("#dynFrm_arrival_date")
            .parent()
            .find("span.red")
            .text("Please add the departure date."),
          document.static_form.dynFrm_arrival_date.focus(),
          !1
        );
      if (
        (jQuery("#dynFrm_arrival_date").parent().find("span.red").text(""),
        "10322" != document.getElementById("dynFrm_inquiry_for").value)
      ) {
        if (
          !0 == document.getElementById("dynFrm_tour_type").checked &&
          "0" ==
            chktrim(document.static_form.dynFrm_departure_date.value).length
        )
          return (
            jQuery("#dynFrm_departure_date")
              .parent()
              .find("span.red")
              .text("Please add the return date."),
            document.static_form.dynFrm_departure_date.focus(),
            !1
          );
        jQuery("#dynFrm_departure_date").parent().find("span.red").text("");
      } else {
        if (
          "0" ==
          chktrim(document.static_form.dynFrm_departure_date.value).length
        )
          return (
            jQuery("#dynFrm_departure_date")
              .parent()
              .find("span.red")
              .text("Please add the return date."),
            document.static_form.dynFrm_departure_date.focus(),
            !1
          );
        jQuery("#dynFrm_departure_date").parent().find("span.red").text("");
      }
      if (
        "0" ==
        chktrim(document.static_form.dynFrm_destination_from.value).length
      )
        return (
          jQuery("#dynFrm_destination_from")
            .parent()
            .find("span.red")
            .text("Please enter destination from."),
          document.static_form.dynFrm_destination_from.focus(),
          !1
        );
      if (
        (jQuery("#dynFrm_destination_from").parent().find("span.red").text(""),
        "0" == chktrim(document.static_form.dynFrm_destination_to.value).length)
      )
        return (
          jQuery("#dynFrm_destination_to")
            .parent()
            .find("span.red")
            .text("Please enter destination to."),
          document.static_form.dynFrm_destination_to.focus(),
          !1
        );
      if (
        (jQuery("#dynFrm_destination_to").parent().find("span.red").text(""),
        "10101" == document.getElementById("dynFrm_inquiry_for").value)
      ) {
        if (
          "0" == chktrim(document.static_form.dynFrm_car_no_adults.value).length
        )
          return (
            jQuery("#dynFrm_car_no_adults")
              .parent()
              .find("span.red")
              .text("Please select the no. of persons."),
            document.static_form.dynFrm_car_no_adults.focus(),
            !1
          );
        jQuery("#dynFrm_car_no_adults").parent().find("span.red").text("");
      }
      if (
        "10101" != document.getElementById("dynFrm_inquiry_for").value &&
        "10322" != document.getElementById("dynFrm_inquiry_for").value
      ) {
        if (
          "0" == chktrim(document.static_form.dynFrm_no_of_adults.value).length
        )
          return (
            jQuery("#dynFrm_no_of_adults")
              .parent()
              .find("span.red")
              .text("Please select the no. of tickets."),
            document.static_form.dynFrm_no_of_adults.focus(),
            !1
          );
        jQuery("#dynFrm_no_of_adults").parent().find("span.red").text("");
      }
    }
    if (
      "10100" == document.getElementById("dynFrm_inquiry_for").value ||
      "10324" == document.getElementById("dynFrm_inquiry_for").value
    ) {
      if ("10324" == document.getElementById("dynFrm_inquiry_for").value) {
        if (
          "" ==
          document.static_form.dynFrm_select_country.options[
            document.static_form.dynFrm_select_country.selectedIndex
          ].value
        )
          return (
            jQuery("#dynFrm_select_country")
              .parent()
              .find("span.red")
              .text("Please Select Country."),
            document.static_form.dynFrm_select_country.focus(),
            !1
          );
        if (
          (jQuery("#dynFrm_select_country").parent().find("span.red").text(""),
          "0" ==
            chktrim(document.static_form.dynFrm_city_to_travel.value).length)
        )
          return (
            jQuery("#dynFrm_city_to_travel")
              .parent()
              .find("span.red")
              .text("Please enter city to travel."),
            document.static_form.dynFrm_city_to_travel.focus(),
            !1
          );
        jQuery("#dynFrm_city_to_travel").parent().find("span.red").text("");
      }
      if ("10100" == document.getElementById("dynFrm_inquiry_for").value) {
        if (
          "0" ==
          chktrim(document.static_form.dynFrm_hotel_destination.value).length
        )
          return (
            jQuery("#dynFrm_hotel_destination")
              .parent()
              .find("span.red")
              .text("Please enter Hotel Destination."),
            document.static_form.dynFrm_hotel_destination.focus(),
            !1
          );
        jQuery("#dynFrm_hotel_destination").parent().find("span.red").text("");
      }
      if ("0" == chktrim(document.static_form.dynFrm_arrival_on.value).length)
        return (
          "10100" == document.getElementById("dynFrm_inquiry_for").value
            ? jQuery("#dynFrm_arrival_on")
                .parent()
                .find("span.red")
                .text("Please add the check in date.")
            : jQuery("#dynFrm_arrival_on")
                .parent()
                .find("span.red")
                .text("Please add the arrival on date."),
          document.static_form.dynFrm_arrival_on.focus(),
          !1
        );
      if (
        (jQuery("#dynFrm_arrival_on").parent().find("span.red").text(""),
        "10100" == document.getElementById("dynFrm_inquiry_for").value)
      ) {
        if (
          "0" == chktrim(document.static_form.dynFrm_departure_on.value).length
        )
          return (
            jQuery("#dynFrm_departure_on")
              .parent()
              .find("span.red")
              .text("Please add the check out date."),
            document.static_form.dynFrm_departure_on.focus(),
            !1
          );
        jQuery("#dynFrm_departure_on").parent().find("span.red").text("");
      }
      if ("10324" == document.getElementById("dynFrm_inquiry_for").value) {
        if ("0" == chktrim(document.static_form.dynFrm_duration.value).length)
          return (
            jQuery("#dynFrm_duration")
              .parent()
              .find("span.red")
              .text("Please enter the duration."),
            document.static_form.dynFrm_duration.focus(),
            !1
          );
        jQuery("#dynFrm_duration").parent().find("span.red").text("");
      }
      if ("0" == chktrim(document.static_form.dynFrm_no_adults.value).length)
        return (
          jQuery("#dynFrm_no_adults")
            .parent()
            .find("span.red")
            .text("Please select the no. of persons."),
          document.static_form.dynFrm_no_adults.focus(),
          !1
        );
      if (
        (jQuery("#dynFrm_no_adults").parent().find("span.red").text(""),
        "10100" == document.getElementById("dynFrm_inquiry_for").value)
      ) {
        if (
          "0" == chktrim(document.static_form.dynFrm_no_of_rooms.value).length
        )
          return (
            jQuery("#dynFrm_no_of_rooms")
              .parent()
              .find("span.red")
              .text("Please select the no. of rooms."),
            document.static_form.dynFrm_no_of_rooms.focus(),
            !1
          );
        jQuery("#dynFrm_no_of_rooms").parent().find("span.red").text("");
      }
      if (
        "10324" == document.getElementById("dynFrm_inquiry_for").value ||
        "10100" == document.getElementById("dynFrm_inquiry_for").value
      ) {
        if ("0" == chktrim(document.static_form.dynFrm_budget.value).length)
          return (
            jQuery("#dynFrm_budget")
              .parent()
              .find("span.red")
              .text("Please select budget."),
            document.static_form.dynFrm_budget.focus(),
            !1
          );
        jQuery("#dynFrm_budget").parent().find("span.red").text("");
      }
    }
    if (
      "10105" == document.getElementById("dynFrm_inquiry_for").value &&
      !0 != document.getElementById("dynFrm_service_type").checked
    ) {
      if (
        "" ==
        document.static_form.dynFrm_visa_for.options[
          document.static_form.dynFrm_visa_for.selectedIndex
        ].value
      )
        return (
          jQuery("#dynFrm_visa_for")
            .parent()
            .find("span.red")
            .text("Please Select Country."),
          document.static_form.dynFrm_visa_for.focus(),
          !1
        );
      if (
        (jQuery("#dynFrm_visa_for").parent().find("span.red").text(""),
        "" ==
          document.static_form.dynFrm_visa_type.options[
            document.static_form.dynFrm_visa_type.selectedIndex
          ].value)
      )
        return (
          jQuery("#dynFrm_visa_type")
            .parent()
            .find("span.red")
            .text("Please select visa type."),
          document.static_form.dynFrm_visa_type.focus(),
          !1
        );
      jQuery("#dynFrm_visa_type").parent().find("span.red").text("");
    }
    if (
      "0" ==
        chktrim(document.static_form.dynFrm_travel_plan_requirement.value)
          .length &&
      (void 0 === document.static_form.desc_valid ||
        (void 0 !== document.static_form.desc_valid &&
          "N" != document.static_form.desc_valid.value))
    )
      return (
        jQuery("#dynFrm_travel_plan_requirement")
          .parent()
          .find("span.red")
          .text("Please enter description."),
        document.static_form.dynFrm_travel_plan_requirement.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_travel_plan_requirement")
        .parent()
        .find("span.red")
        .text(""),
      document.static_form.code &&
        0 == chktrim(document.static_form.code.value).length)
    )
      return (
        jQuery("#code")
          .parent()
          .find("span.red")
          .text("Please Enter Security Code Displayed on the Image."),
        document.static_form.code.focus(),
        !1
      );
    if (
      (jQuery("#code").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_your_name.value).length)
    )
      return (
        jQuery("#dynFrm_your_name")
          .parent()
          .find("span.red")
          .text("Please Enter Your Name."),
        document.static_form.dynFrm_your_name.focus(),
        !1
      );
    jQuery("#dynFrm_your_name").parent().find("span.red").text("");
    var t = document.static_form.dynFrm_your_e_mail.value;
    if ("" == chktrim(t))
      return (
        jQuery("#dynFrm_your_e_mail")
          .parent()
          .find("span.red")
          .text("Please enter email."),
        document.static_form.dynFrm_your_e_mail.focus(),
        !1
      );
    jQuery("#dynFrm_your_e_mail").parent().find("span.red").text("");
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        jQuery("#dynFrm_your_e_mail")
          .parent()
          .find("span.red")
          .text("Please enter valid email."),
        document.static_form.dynFrm_your_e_mail.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_your_e_mail").parent().find("span.red").text(""),
      "" ==
        document.static_form.dynFrm_country.options[
          document.static_form.dynFrm_country.selectedIndex
        ].value)
    )
      return (
        jQuery("#dynFrm_country_10004")
          .parent()
          .find("span.red")
          .text("Please Select Your Country."),
        document.static_form.dynFrm_country.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_country_10004").parent().find("span.red").text(""),
      "IN^+91" ==
        document.static_form.dynFrm_country.options[
          document.static_form.dynFrm_country.selectedIndex
        ].value &&
        "" ==
          document.static_form.dynFrm_state.options[
            document.static_form.dynFrm_state.selectedIndex
          ].value)
    )
      return (
        jQuery("#dynFrm_state")
          .parent()
          .find("span.red")
          .text("Please Select State."),
        document.static_form.dynFrm_state.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_state").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_other_city.value).length)
    )
      return (
        jQuery("#dynFrm_other_city")
          .parent()
          .find("span.red")
          .text("Please enter City."),
        document.static_form.dynFrm_other_city.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_other_city").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_phone_mobile.value).length)
    )
      return (
        jQuery("#dynFrm_phone_mobile")
          .parent()
          .find("span.red")
          .text("Please Enter Mobile Number."),
        document.static_form.dynFrm_phone_mobile.focus(),
        !1
      );
    jQuery("#dynFrm_phone_mobile").parent().find("span.red").text("");
    var n = /^[0-9\/,-]+$/;
    if (chktrim(document.static_form.dynFrm_phone_mobile.value).length > 0) {
      if (!n.test(document.static_form.dynFrm_phone_mobile.value))
        return (
          jQuery("#dynFrm_phone_mobile")
            .parent()
            .find("span.red")
            .text(
              "Please enter valid mobile number.Do not enter alphabet or special characters. Special Characters allowed only [-/,]"
            ),
          document.static_form.dynFrm_phone_mobile.focus(),
          !1
        );
      if (
        (jQuery("#dynFrm_phone_mobile").parent().find("span.red").text(""),
        (chktrim(document.static_form.dynFrm_phone_mobile.value).length < 10 ||
          chktrim(document.static_form.dynFrm_phone_mobile.value).length >
            10) &&
          "IN^+91" ==
            document.static_form.dynFrm_country.options[
              document.static_form.dynFrm_country.selectedIndex
            ].value)
      )
        return (
          jQuery("#dynFrm_phone_mobile")
            .parent()
            .find("span.red")
            .text("Mobile Number Should be 10 digits."),
          document.static_form.dynFrm_phone_mobile.focus(),
          !1
        );
      if (chktrim(document.static_form.dynFrm_phone_mobile.value).length < 3)
        return (
          jQuery("#dynFrm_phone_mobile")
            .parent()
            .find("span.red")
            .text("Mobile Number Should be 3 digits at least."),
          document.static_form.dynFrm_phone_mobile.focus(),
          !1
        );
      jQuery("#dynFrm_phone_mobile").parent().find("span.red").text("");
    }
  } else if ("10006" == e) {
    if ("20001" == document.getElementById("dynFrm_inquiry_for").value) {
      if (
        "" ==
        document.static_form.dynFrm_event_type.options[
          document.static_form.dynFrm_event_type.selectedIndex
        ].value
      )
        return (
          jQuery("#dynFrm_event_type")
            .parent()
            .find("span.red")
            .text("Please Select Type Of Event."),
          document.static_form.dynFrm_event_type.focus(),
          !1
        );
      if (
        (jQuery("#dynFrm_event_type").parent().find("span.red").text(""),
        "0" == chktrim(document.static_form.dynFrm_event_location.value).length)
      )
        return (
          jQuery("#dynFrm_event_location")
            .parent()
            .find("span.red")
            .text("Please enter Event Location."),
          document.static_form.dynFrm_event_location.focus(),
          !1
        );
      if (
        (jQuery("#dynFrm_event_location").parent().find("span.red").text(""),
        "0" ==
          chktrim(document.static_form.dynFrm_event_from_date.value).length)
      )
        return (
          jQuery("#dynFrm_event_from_date")
            .parent()
            .find("span.red")
            .text("Please add the Event Date From."),
          document.static_form.dynFrm_event_from_date.focus(),
          !1
        );
      if (
        (jQuery("#dynFrm_event_from_date").parent().find("span.red").text(""),
        "0" == chktrim(document.static_form.dynFrm_event_to_date.value).length)
      )
        return (
          jQuery("#dynFrm_event_to_date")
            .parent()
            .find("span.red")
            .text("Please add the Event Date To."),
          document.static_form.dynFrm_event_to_date.focus(),
          !1
        );
      jQuery("#dynFrm_event_to_date").parent().find("span.red").text("");
    }
    if ("0" == chktrim(document.static_form.dynFrm_subject.value).length)
      return (
        jQuery("#dynFrm_subject")
          .parent()
          .find("span.red")
          .text("Please enter subject."),
        document.static_form.dynFrm_subject.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_subject").parent().find("span.red").text(""),
      "0" ==
        chktrim(document.static_form.dynFrm_travel_plan_requirement.value)
          .length &&
        (void 0 === document.static_form.desc_valid ||
          (void 0 !== document.static_form.desc_valid &&
            "N" != document.static_form.desc_valid.value)))
    )
      return (
        jQuery("#dynFrm_travel_plan_requirement")
          .parent()
          .find("span.red")
          .text("Please enter description."),
        document.static_form.dynFrm_travel_plan_requirement.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_travel_plan_requirement")
        .parent()
        .find("span.red")
        .text(""),
      document.static_form.code &&
        0 == chktrim(document.static_form.code.value).length)
    )
      return (
        jQuery("#code")
          .parent()
          .find("span.red")
          .text("Please Enter Security Code Displayed on the Image."),
        document.static_form.code.focus(),
        !1
      );
    if (
      (jQuery("#code").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_your_name.value).length)
    )
      return (
        jQuery("#dynFrm_your_name")
          .parent()
          .find("span.red")
          .text("Please enter Your Name."),
        document.static_form.dynFrm_your_name.focus(),
        !1
      );
    jQuery("#dynFrm_your_name").parent().find("span.red").text("");
    var t = document.static_form.dynFrm_your_e_mail.value;
    if ("" == chktrim(t))
      return (
        jQuery("#dynFrm_your_e_mail")
          .parent()
          .find("span.red")
          .text("Please enter email."),
        document.static_form.dynFrm_your_e_mail.focus(),
        !1
      );
    jQuery("#dynFrm_your_e_mail").parent().find("span.red").text("");
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        jQuery("#dynFrm_your_e_mail")
          .parent()
          .find("span.red")
          .text("Please enter valid email."),
        document.static_form.dynFrm_your_e_mail.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_your_e_mail").parent().find("span.red").text(""),
      "0" == chktrim(document.static_form.dynFrm_address.value).length)
    )
      return (
        jQuery("#dynFrm_address")
          .parent()
          .find("span.red")
          .text("Please enter address."),
        document.static_form.dynFrm_address.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_address").parent().find("span.red").text(""),
      "" ==
        document.static_form.dynFrm_country.options[
          document.static_form.dynFrm_country.selectedIndex
        ].value)
    )
      return (
        jQuery("#dynFrm_country_10006")
          .parent()
          .find("span.red")
          .text("Please Select Your Country."),
        document.static_form.dynFrm_country.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_country_10006").parent().find("span.red").text(""),
      "IN^+91" ==
        document.static_form.dynFrm_country.options[
          document.static_form.dynFrm_country.selectedIndex
        ].value &&
        "" ==
          document.static_form.dynFrm_state.options[
            document.static_form.dynFrm_state.selectedIndex
          ].value)
    )
      return (
        jQuery("#dynFrm_state")
          .parent()
          .find("span.red")
          .text("Please Select State."),
        document.static_form.dynFrm_state.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_state").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_other_city.value).length)
    )
      return (
        jQuery("#dynFrm_other_city")
          .parent()
          .find("span.red")
          .text("Please enter City."),
        document.static_form.dynFrm_other_city.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_other_city").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_phone_mobile.value).length)
    )
      return (
        jQuery("#dynFrm_phone_mobile")
          .parent()
          .find("span.red")
          .text("Please Enter Mobile Number."),
        document.static_form.dynFrm_phone_mobile.focus(),
        !1
      );
    jQuery("#dynFrm_phone_mobile").parent().find("span.red").text("");
    var n = /^[0-9\/,-]+$/;
    if (chktrim(document.static_form.dynFrm_phone_mobile.value).length > 0) {
      if (!n.test(document.static_form.dynFrm_phone_mobile.value))
        return (
          jQuery("#dynFrm_phone_mobile")
            .parent()
            .find("span.red")
            .text(
              "Please enter valid mobile number.Do not enter alphabet or special characters. Special Characters allowed only [-/,]."
            ),
          document.static_form.dynFrm_phone_mobile.focus(),
          !1
        );
      if (
        (jQuery("#dynFrm_phone_mobile").parent().find("span.red").text(""),
        (chktrim(document.static_form.dynFrm_phone_mobile.value).length < 10 ||
          chktrim(document.static_form.dynFrm_phone_mobile.value).length >
            10) &&
          "IN^+91" ==
            document.static_form.dynFrm_country.options[
              document.static_form.dynFrm_country.selectedIndex
            ].value)
      )
        return (
          jQuery("#dynFrm_phone_mobile")
            .parent()
            .find("span.red")
            .text("Mobile Number Should be 10 digits."),
          document.static_form.dynFrm_phone_mobile.focus(),
          !1
        );
      if (chktrim(document.static_form.dynFrm_phone_mobile.value).length < 3)
        return (
          jQuery("#dynFrm_phone_mobile")
            .parent()
            .find("span.red")
            .text("Mobile Number Should be 3 digits at least."),
          document.static_form.dynFrm_phone_mobile.focus(),
          !1
        );
      jQuery("#dynFrm_phone_mobile").parent().find("span.red").text("");
    }
  } else if (
    "10007" == e ||
    "10010" == e ||
    "10014" == e ||
    "10016" == e ||
    "10020" == e ||
    "10023" == e
  ) {
    if ("10010" == e || "10016" == e || "10023" == e) {
      if (
        "" ==
        document.static_form.dynFrm_mem_type.options[
          document.static_form.dynFrm_mem_type.selectedIndex
        ].value
      )
        return (
          jQuery("#dynFrm_mem_type")
            .parent()
            .find("span.red")
            .text("Please Select Enquiry For."),
          document.static_form.dynFrm_mem_type.focus(),
          !1
        );
      jQuery("#dynFrm_mem_type").parent().find("span.red").text("");
    }
    if ("10010" == e || "10016" == e || "10020" == e || "10023" == e) {
      if (0 == chktrim(document.static_form.dynFrm_your_name.value).length)
        return (
          jQuery("#dynFrm_your_name")
            .parent()
            .find("span.red")
            .text("Please Enter Your Name."),
          document.static_form.dynFrm_your_name.focus(),
          !1
        );
      jQuery("#dynFrm_your_name").parent().find("span.red").text("");
    } else {
      if (0 == chktrim(document.static_form.dynFrm_contact_person.value).length)
        return (
          jQuery("#dyn_contact_person")
            .parent()
            .find("span.red")
            .text("Please Enter Your Name."),
          document.static_form.dynFrm_contact_person.focus(),
          !1
        );
      jQuery("#dyn_contact_person").parent().find("span.red").text("");
    }
    if ("10010" == e || "10016" == e || "10023" == e) {
      if (
        "R" ==
          document.static_form.dynFrm_mem_type.options[
            document.static_form.dynFrm_mem_type.selectedIndex
          ].value &&
        "0" == chktrim(document.static_form.dynFrm_company_name.value).length
      )
        return (
          jQuery("#dynFrm_company_name")
            .parent()
            .find("span.red")
            .text("Please Enter Company Name."),
          document.static_form.dynFrm_company_name.focus(),
          !1
        );
      jQuery("#dynFrm_company_name").parent().find("span.red").text("");
    }
    if ("10007" != e && "10014" != e) {
      if (
        "" ==
        document.static_form.dynFrm_country.options[
          document.static_form.dynFrm_country.selectedIndex
        ].value
      )
        return (
          jQuery("#dyn_country")
            .parent()
            .find("span.red")
            .text("Please Select Your Country."),
          document.static_form.dynFrm_country.focus(),
          !1
        );
      jQuery("#dyn_country").parent().find("span.red").text("");
    }
    if ("10010" == e || "10016" == e || "10020" == e || "10023" == e) {
      if (
        "IN^91" ==
          document.static_form.dynFrm_country.options[
            document.static_form.dynFrm_country.selectedIndex
          ].value &&
        "" ==
          document.static_form.dynFrm_state.options[
            document.static_form.dynFrm_state.selectedIndex
          ].value
      )
        return (
          jQuery("#dynFrm_state")
            .parent()
            .find("span.red")
            .text("Please Select State."),
          document.static_form.dynFrm_state.focus(),
          !1
        );
      jQuery("#dynFrm_state").parent().find("span.red").text("");
    } else if ("10007" != e && "10014" != e) {
      if (
        "IN^+91" ==
          document.static_form.dynFrm_country.options[
            document.static_form.dynFrm_country.selectedIndex
          ].value &&
        "" ==
          document.static_form.dynFrm_state.options[
            document.static_form.dynFrm_state.selectedIndex
          ].value
      )
        return (
          jQuery("#dynFrm_state")
            .parent()
            .find("span.red")
            .text("Please Select State."),
          document.static_form.dynFrm_state.focus(),
          !1
        );
      jQuery("#dynFrm_state").parent().find("span.red").text("");
    }
    if ("10010" == e || "10023" == e) {
      if (0 == chktrim(document.static_form.dynFrm_city.value).length)
        return (
          jQuery("#dynFrm_city")
            .parent()
            .find("span.red")
            .text("Please Enter City."),
          document.static_form.dynFrm_city.focus(),
          !1
        );
      jQuery("#dynFrm_city").parent().find("span.red").text("");
    }
    var t = document.static_form.dynFrm_email_id.value;
    if ("" == chktrim(t))
      return (
        jQuery("#dyn_email_id")
          .parent()
          .find("span.red")
          .text("Please enter email."),
        document.static_form.dynFrm_email_id.focus(),
        !1
      );
    jQuery("#dyn_email_id").parent().find("span.red").text("");
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        jQuery("#dyn_email_id")
          .parent()
          .find("span.red")
          .text("Please enter valid email."),
        document.static_form.dynFrm_email_id.focus(),
        !1
      );
    if (
      (jQuery("#dyn_email_id").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_phone.value).length)
    )
      return (
        "10007" == e || "10014" == e
          ? jQuery("#phone_popup")
              .parents(".phonemsg")
              .find("span.red")
              .text("Please Enter Phone/Mobile Number.")
          : jQuery("#dyn_phone")
              .parent()
              .find("span.red")
              .text("Please Enter Phone/Mobile Number."),
        document.static_form.dynFrm_phone.focus(),
        !1
      );
    if (
      ("10007" == e || "10014" == e
        ? jQuery("#phone_popup").parents(".phonemsg").find("span.red").text("")
        : jQuery("#dyn_phone").parent().find("span.red").text(""),
      chktrim(document.static_form.dynFrm_phone.value).length > 0)
    ) {
      if (isNaN(document.static_form.dynFrm_phone.value))
        return (
          "10007" == e || "10014" == e
            ? jQuery("#phone_popup")
                .parents(".phonemsg")
                .find("span.red")
                .text(
                  "Please enter valid mobile number.Do not enter alphabet or special characters."
                )
            : jQuery("#dyn_phone")
                .parent()
                .find("span.red")
                .text(
                  "Please enter valid mobile number.Do not enter alphabet or special characters."
                ),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      if (
        ("10007" == e || "10014" == e
          ? jQuery("#phone_popup")
              .parents(".phonemsg")
              .find("span.red")
              .text("")
          : jQuery("#dyn_phone").parent().find("span.red").text(""),
        "10010" == e || "10016" == e || "10020" == e || "10023" == e)
      ) {
        if (chktrim(document.static_form.dynFrm_phone.value).length < 3)
          return (
            jQuery("#dynFrm_phone")
              .parent()
              .find("span.red")
              .text("Mobile Number Should be 3 digits at least."),
            document.static_form.dynFrm_phone.focus(),
            !1
          );
        if (
          (jQuery("#dyn_phone").parent().find("span.red").text(""),
          "IN^91" ==
            document.static_form.dynFrm_country.options[
              document.static_form.dynFrm_country.selectedIndex
            ].value &&
            (chktrim(document.static_form.dynFrm_phone.value).length < 10 ||
              chktrim(document.static_form.dynFrm_phone.value).length > 10))
        )
          return (
            jQuery("#dyn_phone")
              .parent()
              .find("span.red")
              .text("Please Enter Your 10 digits mobile number."),
            document.static_form.dynFrm_phone.focus(),
            !1
          );
        if (
          "IN^91" !=
            document.static_form.dynFrm_country.options[
              document.static_form.dynFrm_country.selectedIndex
            ].value &&
          (chktrim(document.static_form.dynFrm_phone.value).length < 3 ||
            chktrim(document.static_form.dynFrm_phone.value).length > 20)
        )
          return (
            jQuery("#dyn_phone")
              .parent()
              .find("span.red")
              .text("Please Enter Your 3 to 20 digits mobile number."),
            document.static_form.dynFrm_phone.focus(),
            !1
          );
        jQuery("#dyn_phone").parent().find("span.red").text("");
      } else if ("10007" == e || "10014" == e) {
        if (
          "IN^+91" == document.static_form.dynFrm_country.value &&
          (chktrim(document.static_form.dynFrm_phone.value).length < 10 ||
            chktrim(document.static_form.dynFrm_phone.value).length > 10)
        )
          return (
            jQuery("#phone_popup")
              .parents(".phonemsg")
              .find("span.red")
              .text("Please Enter Your 10 digits mobile number."),
            document.static_form.dynFrm_phone.focus(),
            !1
          );
        if (
          "IN^+91" != document.static_form.dynFrm_country.value &&
          (chktrim(document.static_form.dynFrm_phone.value).length < 3 ||
            chktrim(document.static_form.dynFrm_phone.value).length > 20)
        )
          return (
            jQuery("#phone_popup")
              .parents(".phonemsg")
              .find("span.red")
              .text("Please Enter Your 3 to 20 digits mobile number."),
            document.static_form.dynFrm_phone.focus(),
            !1
          );
        jQuery("#phone_popup").parents(".phonemsg").find("span.red").text("");
      }
    }
    if (0 == chktrim(document.static_form.dynFrm_details_2.value).length)
      return (
        jQuery("#dyn_details_2")
          .parent()
          .find("span.red")
          .text("Please Enter Your Requirement Details."),
        document.static_form.dynFrm_details_2.focus(),
        !1
      );
    if (
      (jQuery("#dyn_details_2").parent().find("span.red").text(""),
      document.static_form.code &&
        0 == chktrim(document.static_form.code.value).length)
    )
      return (
        jQuery("#code")
          .parent()
          .find("span.red")
          .text("Please Enter Security Code Displayed on the Image."),
        document.static_form.code.focus(),
        !1
      );
    if (
      (jQuery("#code").parent().find("span.red").text(""),
      void 0 !== document.static_form.term_cond &&
        !document.static_form.term_cond.checked)
    )
      return (
        jQuery("#term_cond")
          .parent()
          .find("span.red")
          .text("Please accept Terms & Conditions."),
        document.static_form.term_cond.focus(),
        !1
      );
    jQuery("#term_cond").parent().find("span.red").text("");
  } else if ("10008" == e) {
    if (
      "" ==
      document.static_form.dynFrm_property_category.options[
        document.static_form.dynFrm_property_category.selectedIndex
      ].value
    )
      return (
        jQuery("#dynFrm_property_category")
          .parent()
          .find("span.red")
          .text("Please Select Property Category."),
        document.static_form.dynFrm_property_category.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_property_category").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_budget.value).length)
    )
      return (
        jQuery("#dynFrm_budget")
          .parent()
          .find("span.red")
          .text("Please Enter Budget."),
        document.static_form.dynFrm_budget.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_budget").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_area.value).length)
    )
      return (
        jQuery("#dynFrm_area")
          .parent()
          .find("span.red")
          .text("Please Enter Area."),
        document.static_form.dynFrm_area.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_area").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_contact_person.value).length)
    )
      return (
        jQuery("#dyn_contact_person")
          .parent()
          .find("span.red")
          .text("Please Enter Your Name."),
        document.static_form.dynFrm_contact_person.focus(),
        !1
      );
    jQuery("#dyn_contact_person").parent().find("span.red").text("");
    var t = document.static_form.dynFrm_email_id.value;
    if ("" == chktrim(t))
      return (
        jQuery("#dyn_email_id")
          .parent()
          .find("span.red")
          .text("Please enter E-mail."),
        document.static_form.dynFrm_email_id.focus(),
        !1
      );
    jQuery("#dyn_email_id").parent().find("span.red").text("");
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        jQuery("#dyn_email_id")
          .parent()
          .find("span.red")
          .text("Please enter valid E-mail."),
        document.static_form.dynFrm_email_id.focus(),
        !1
      );
    if (
      (jQuery("#dyn_email_id").parent().find("span.red").text(""),
      "" ==
        document.static_form.dynFrm_country.options[
          document.static_form.dynFrm_country.selectedIndex
        ].value)
    )
      return (
        jQuery("#dyn_country")
          .parent()
          .find("span.red")
          .text("Please Select Your Country."),
        document.static_form.dynFrm_country.focus(),
        !1
      );
    if (
      (jQuery("#dyn_country").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_phone.value).length)
    )
      return (
        jQuery("#dyn_phone")
          .parent()
          .find("span.red")
          .text("Please Enter Phone/Mobile Number."),
        document.static_form.dynFrm_phone.focus(),
        !1
      );
    if (
      (jQuery("#dyn_phone").parent().find("span.red").text(""),
      chktrim(document.static_form.dynFrm_phone.value).length > 0)
    ) {
      if (isNaN(document.static_form.dynFrm_phone.value))
        return (
          jQuery("#dyn_phone")
            .parent()
            .find("span.red")
            .text(
              "Please enter valid phone/mobile number.Do not enter alphabet or special characters."
            ),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      if (
        (jQuery("#dyn_phone").parent().find("span.red").text(""),
        (chktrim(document.static_form.dynFrm_phone.value).length < 10 ||
          chktrim(document.static_form.dynFrm_phone.value).length > 10) &&
          "IN^+91" ==
            document.static_form.dynFrm_country.options[
              document.static_form.dynFrm_country.selectedIndex
            ].value)
      )
        return (
          jQuery("#dyn_phone")
            .parent()
            .find("span.red")
            .text("Mobile Number Should be 10 digits."),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      if (chktrim(document.static_form.dynFrm_phone.value).length < 3)
        return (
          jQuery("#dyn_phone")
            .parent()
            .find("span.red")
            .text("Mobile Number Should be 3 digits at least."),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      jQuery("#dyn_phone").parent().find("span.red").text("");
    }
    if (
      document.static_form.code &&
      0 == chktrim(document.static_form.code.value).length
    )
      return (
        jQuery("#code")
          .parent()
          .find("span.red")
          .text("Please Enter Security Code Displayed on the Image."),
        document.static_form.code.focus(),
        !1
      );
    jQuery("#code").parent().find("span.red").text("");
  } else if ("10009" == e) {
    if (0 == chktrim(document.static_form.dynFrm_your_name.value).length)
      return (
        jQuery("#dynFrm_your_name")
          .parent()
          .find("span.red")
          .text("Please Enter Your Name."),
        document.static_form.dynFrm_your_name.focus(),
        !1
      );
    jQuery("#dynFrm_your_name").parent().find("span.red").text("");
    var t = document.static_form.dynFrm_email_id.value;
    if ("" == chktrim(t))
      return (
        jQuery("#dyn_email_id")
          .parent()
          .find("span.red")
          .text("Please enter email."),
        document.static_form.dynFrm_email_id.focus(),
        !1
      );
    jQuery("#dyn_email_id").parent().find("span.red").text("");
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        jQuery("#dyn_email_id")
          .parent()
          .find("span.red")
          .text("Please enter valid email."),
        document.static_form.dynFrm_email_id.focus(),
        !1
      );
    if (
      (jQuery("#dyn_email_id").parent().find("span.red").text(""),
      "" ==
        document.static_form.dynFrm_country.options[
          document.static_form.dynFrm_country.selectedIndex
        ].value)
    )
      return (
        jQuery("#dyn_country")
          .parent()
          .find("span.red")
          .text("Please Select Your Country."),
        document.static_form.dynFrm_country.focus(),
        !1
      );
    if (
      (jQuery("#dyn_country").parent().find("span.red").text(""),
      "IN^91" ==
        document.static_form.dynFrm_country.options[
          document.static_form.dynFrm_country.selectedIndex
        ].value &&
        "" ==
          document.static_form.dynFrm_state.options[
            document.static_form.dynFrm_state.selectedIndex
          ].value)
    )
      return (
        jQuery("#dynFrm_state")
          .parent()
          .find("span.red")
          .text("Please Select State."),
        document.static_form.dynFrm_state.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_state").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_city.value).length)
    )
      return (
        jQuery("#dynFrm_city")
          .parent()
          .find("span.red")
          .text("Please Enter Your City."),
        document.static_form.dynFrm_city.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_city").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_mobile_phone.value).length)
    )
      return (
        jQuery("#dynFrm_mobile_phone")
          .parent()
          .find("span.red")
          .text("Please Enter Mobile Number."),
        document.static_form.dynFrm_mobile_phone.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_mobile_phone").parent().find("span.red").text(""),
      chktrim(document.static_form.dynFrm_mobile_phone.value).length > 0)
    ) {
      if (!/^[0-9\/,-]+$/.test(document.static_form.dynFrm_mobile_phone.value))
        return (
          jQuery("#dynFrm_mobile_phone")
            .parent()
            .find("span.red")
            .text(
              "Please enter valid mobile number.Do not enter alphabet or special characters. Special Characters allowed only [-/,]"
            ),
          (document.static_form.dynFrm_mobile_phone.value = ""),
          document.static_form.dynFrm_mobile_phone.focus(),
          !1
        );
      if (
        (jQuery("#dynFrm_mobile_phone").parent().find("span.red").text(""),
        (chktrim(document.static_form.dynFrm_mobile_phone.value).length < 10 ||
          chktrim(document.static_form.dynFrm_mobile_phone.value).length >
            10) &&
          "IN^91" ==
            document.static_form.dynFrm_country.options[
              document.static_form.dynFrm_country.selectedIndex
            ].value)
      )
        return (
          jQuery("#dynFrm_mobile_phone")
            .parent()
            .find("span.red")
            .text("Mobile Number Should be 10 digits."),
          document.static_form.dynFrm_mobile_phone.focus(),
          !1
        );
      if (chktrim(document.static_form.dynFrm_mobile_phone.value).length < 3)
        return (
          jQuery("#dynFrm_mobile_phone")
            .parent()
            .find("span.red")
            .text("Mobile Number Should be 3 digits at least."),
          document.static_form.dynFrm_mobile_phone.focus(),
          !1
        );
      jQuery("#dynFrm_mobile_phone").parent().find("span.red").text("");
    }
    if (
      0 == chktrim(document.static_form.dynFrm_education_details.value).length
    )
      return (
        jQuery("#dynFrm_education_details")
          .parent()
          .find("span.red")
          .text("Please Enter Your Education Details."),
        document.static_form.dynFrm_education_details.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_education_details").parent().find("span.red").text(""),
      "" ==
        document.static_form.dynFrm_exp_in_years.options[
          document.static_form.dynFrm_exp_in_years.selectedIndex
        ].value)
    )
      return (
        jQuery("#dynFrm_exp_in_years")
          .parent()
          .find("span.red")
          .text("Please Select Exp. In Years."),
        document.static_form.dynFrm_exp_in_years.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_exp_in_years").parent().find("span.red").text(""),
      "" ==
        document.static_form.dynFrm_exp_in_months.options[
          document.static_form.dynFrm_exp_in_months.selectedIndex
        ].value)
    )
      return (
        jQuery("#dynFrm_exp_in_months")
          .parent()
          .find("span.red")
          .text("Please Select Exp. In Months."),
        document.static_form.dynFrm_exp_in_months.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_exp_in_months").parent().find("span.red").text(""),
      "0" !=
        document.static_form.dynFrm_exp_in_years.options[
          document.static_form.dynFrm_exp_in_years.selectedIndex
        ].value)
    ) {
      if (
        "" ==
          document.static_form.dynFrm_salary_lac.options[
            document.static_form.dynFrm_salary_lac.selectedIndex
          ].value &&
        "" ==
          document.static_form.dynFrm_salary_mnth.options[
            document.static_form.dynFrm_salary_mnth.selectedIndex
          ].value
      )
        return (
          jQuery("#dynFrm_salary_lac")
            .parent()
            .find("span.red")
            .text("Please Select Salary."),
          document.static_form.dynFrm_salary_lac.focus(),
          !1
        );
      jQuery("#dynFrm_salary_lac").parent().find("span.red").text("");
    }
    if (0 == chktrim(document.static_form.dynFrm_key_skills.value).length)
      return (
        jQuery("#dynFrm_key_skills")
          .parent()
          .find("span.red")
          .text("Please Enter Your Key Skills."),
        document.static_form.dynFrm_key_skills.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_key_skills").parent().find("span.red").text(""),
      0 ==
        chktrim(document.static_form.dynFrm_paste_your_resume.value).length &&
        0 ==
          chktrim(document.static_form.dynFrm_attach_resume_file.value).length)
    )
      return (
        jQuery("#dynFrm_paste_your_resume")
          .parent()
          .find("span.red")
          .text("Please Paste or Attach Your Resume."),
        document.static_form.dynFrm_paste_your_resume.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_paste_your_resume").parent().find("span.red").text(""),
      document.static_form.code &&
        0 == chktrim(document.static_form.code.value).length)
    )
      return (
        jQuery("#code")
          .parent()
          .find("span.red")
          .text("Please Enter Security Code Displayed on the Image."),
        document.static_form.code.focus(),
        !1
      );
    if (
      (jQuery("#code").parent().find("span.red").text(""),
      void 0 !== document.static_form.term_cond &&
        !document.static_form.term_cond.checked)
    )
      return (
        jQuery("#term_cond")
          .parent()
          .find("span.red")
          .text("Please accept Terms & Conditions."),
        document.static_form.term_cond.focus(),
        !1
      );
    jQuery("#term_cond").parent().find("span.red").text("");
  } else if ("10011" == e) {
    if (0 == chktrim(document.static_form.dynFrm_your_name.value).length)
      return (
        alert("Please Enter Your Name"),
        document.static_form.dynFrm_your_name.focus(),
        !1
      );
    if (0 == chktrim(document.static_form.dynFrm_phone_mobile.value).length)
      return (
        alert("Please Enter Mobile Number."),
        document.static_form.dynFrm_phone_mobile.focus(),
        !1
      );
    var n = /^[0-9\/,-]+$/;
    if (chktrim(document.static_form.dynFrm_phone_mobile.value).length > 0) {
      if (!n.test(document.static_form.dynFrm_phone_mobile.value))
        return (
          alert(
            "Please enter valid mobile number.Do not enter alphabet or special characters. Special Characters allowed only [-/,]"
          ),
          document.static_form.dynFrm_phone_mobile.focus(),
          !1
        );
      if (
        (chktrim(document.static_form.dynFrm_phone_mobile.value).length < 10 ||
          chktrim(document.static_form.dynFrm_phone_mobile.value).length >
            10) &&
        "IN^+91" ==
          document.static_form.dynFrm_country.options[
            document.static_form.dynFrm_country.selectedIndex
          ].value
      )
        return (
          alert("Mobile Number Should be 10 digits."),
          document.static_form.dynFrm_phone_mobile.focus(),
          !1
        );
      if (chktrim(document.static_form.dynFrm_phone_mobile.value).length < 3)
        return (
          alert("Mobile Number Should be 3 digits at least."),
          document.static_form.dynFrm_phone_mobile.focus(),
          !1
        );
    }
    var t = document.static_form.dynFrm_your_e_mail.value;
    if ("" == chktrim(t))
      return (
        alert("Please enter email."),
        document.static_form.dynFrm_your_e_mail.focus(),
        !1
      );
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        alert("Please enter valid email."),
        document.static_form.dynFrm_your_e_mail.focus(),
        !1
      );
    if ("0" == chktrim(document.static_form.dynFrm_room_type.value).length)
      return (
        alert("Please select the room type."),
        document.static_form.dynFrm_room_type.focus(),
        !1
      );
    if ("0" == chktrim(document.static_form.dynFrm_arrival_date.value).length)
      return (
        alert("Please add the arrival date."),
        document.static_form.dynFrm_arrival_date.focus(),
        !1
      );
    if ("0" == chktrim(document.static_form.dynFrm_departure_date.value).length)
      return (
        alert("Please add the departure date."),
        document.static_form.dynFrm_departure_date.focus(),
        !1
      );
    if ("0" == chktrim(document.static_form.dynFrm_no_of_rooms.value).length)
      return (
        alert("Please select the no. of rooms."),
        document.static_form.dynFrm_no_of_rooms.focus(),
        !1
      );
    if ("0" == chktrim(document.static_form.dynFrm_no_of_adults.value).length)
      return (
        alert("Please select the no. of persons."),
        document.static_form.dynFrm_no_of_adults.focus(),
        !1
      );
  } else if ("10012" == e) {
    if (
      "" ==
      document.static_form.dynFrm_property_category.options[
        document.static_form.dynFrm_property_category.selectedIndex
      ].value
    )
      return (
        jQuery("#dynFrm_property_category")
          .parent()
          .find("span.red")
          .text("Please Select Property Category."),
        document.static_form.dynFrm_property_category.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_property_category").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_area.value).length)
    )
      return (
        jQuery("#dynFrm_area")
          .parent()
          .find("span.red")
          .text("Please Enter Area."),
        document.static_form.dynFrm_area.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_area").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_budget.value).length)
    )
      return (
        jQuery("#dynFrm_budget")
          .parent()
          .find("span.red")
          .text("Please Enter your selling Price."),
        document.static_form.dynFrm_budget.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_budget").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_details_2.value).length)
    )
      return (
        jQuery("#dyn_details_2")
          .parent()
          .find("span.red")
          .text("Please Enter Property Description."),
        document.static_form.dynFrm_details_2.focus(),
        !1
      );
    if (
      (jQuery("#dyn_details_2").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_contact_person.value).length)
    )
      return (
        jQuery("#dyn_contact_person")
          .parent()
          .find("span.red")
          .text("Please Enter Your Name."),
        document.static_form.dynFrm_contact_person.focus(),
        !1
      );
    jQuery("#dyn_contact_person").parent().find("span.red").text("");
    var t = document.static_form.dynFrm_email_id.value;
    if ("" == chktrim(t))
      return (
        jQuery("#dyn_email_id")
          .parent()
          .find("span.red")
          .text("Please enter E-mail."),
        document.static_form.dynFrm_email_id.focus(),
        !1
      );
    jQuery("#dyn_email_id").parent().find("span.red").text("");
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        jQuery("#dyn_email_id")
          .parent()
          .find("span.red")
          .text("Please enter valid E-mail."),
        document.static_form.dynFrm_email_id.focus(),
        !1
      );
    if (
      (jQuery("#dyn_email_id").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_address.value).length)
    )
      return (
        jQuery("#dynFrm_address")
          .parent()
          .find("span.red")
          .text("Please Enter Address."),
        document.static_form.dynFrm_address.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_address").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_city.value).length)
    )
      return (
        jQuery("#dynFrm_city")
          .parent()
          .find("span.red")
          .text("Please Enter City Name."),
        document.static_form.dynFrm_city.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_city").parent().find("span.red").text(""),
      "" ==
        document.static_form.dynFrm_country.options[
          document.static_form.dynFrm_country.selectedIndex
        ].value)
    )
      return (
        jQuery("#dyn_country")
          .parent()
          .find("span.red")
          .text("Please Select Your Country."),
        document.static_form.dynFrm_country.focus(),
        !1
      );
    if (
      (jQuery("#dyn_country").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_phone.value).length)
    )
      return (
        jQuery("#dyn_phone")
          .parent()
          .find("span.red")
          .text("Please Enter Phone/Mobile Number."),
        document.static_form.dynFrm_phone.focus(),
        !1
      );
    if (
      (jQuery("#dyn_phone").parent().find("span.red").text(""),
      chktrim(document.static_form.dynFrm_phone.value).length > 0)
    ) {
      if (isNaN(document.static_form.dynFrm_phone.value))
        return (
          jQuery("#dyn_phone")
            .parent()
            .find("span.red")
            .text(
              "Please enter valid phone/mobile number.Do not enter alphabet or special characters."
            ),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      if (
        (jQuery("#dyn_phone").parent().find("span.red").text(""),
        (chktrim(document.static_form.dynFrm_phone.value).length < 10 ||
          chktrim(document.static_form.dynFrm_phone.value).length > 10) &&
          "IN^+91" ==
            document.static_form.dynFrm_country.options[
              document.static_form.dynFrm_country.selectedIndex
            ].value)
      )
        return (
          jQuery("#dyn_phone")
            .parent()
            .find("span.red")
            .text("Mobile Number Should be 10 digits."),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      if (chktrim(document.static_form.dynFrm_phone.value).length < 3)
        return (
          jQuery("#dyn_phone")
            .parent()
            .find("span.red")
            .text("Mobile Number Should be 3 digits at least."),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      jQuery("#dyn_phone").parent().find("span.red").text("");
    }
    if (
      document.static_form.code &&
      0 == chktrim(document.static_form.code.value).length
    )
      return (
        jQuery("#code")
          .parent()
          .find("span.red")
          .text("Please Enter Security Code Displayed on the Image."),
        document.static_form.code.focus(),
        !1
      );
    jQuery("#code").parent().find("span.red").text("");
  } else if ("10013" == e || "10015" == e) {
    if (
      "0" == chktrim(document.static_form.dynFrm_destination_from.value).length
    )
      return (
        alert("Please enter destination from."),
        document.static_form.dynFrm_destination_from.focus(),
        !1
      );
    if ("0" == chktrim(document.static_form.dynFrm_destination_to.value).length)
      return (
        alert("Please enter destination to."),
        document.static_form.dynFrm_destination_to.focus(),
        !1
      );
    if ("0" == chktrim(document.static_form.dynFrm_arrival_date.value).length)
      return (
        alert("Please add the arrival date."),
        document.static_form.dynFrm_arrival_date.focus(),
        !1
      );
    if (
      "Round Trip" == document.getElementById("dynFrm_tour_type").value &&
      "0" == chktrim(document.static_form.dynFrm_departure_date.value).length
    )
      return (
        alert("Please add the return date."),
        document.static_form.dynFrm_departure_date.focus(),
        !1
      );
    if ("0" == chktrim(document.static_form.dynFrm_car_no_adults.value).length)
      return (
        alert("Please select the no. of persons."),
        document.static_form.dynFrm_car_no_adults.focus(),
        !1
      );
    if (0 == chktrim(document.static_form.dynFrm_your_name.value).length)
      return (
        alert("Please Enter Your Name"),
        document.static_form.dynFrm_your_name.focus(),
        !1
      );
    if (0 == chktrim(document.static_form.dynFrm_phone_mobile.value).length)
      return (
        alert("Please Enter Mobile Number."),
        document.static_form.dynFrm_phone_mobile.focus(),
        !1
      );
    var n = /^[0-9\/,-]+$/;
    if (chktrim(document.static_form.dynFrm_phone_mobile.value).length > 0) {
      if (!n.test(document.static_form.dynFrm_phone_mobile.value))
        return (
          alert(
            "Please enter valid mobile number.Do not enter alphabet or special characters. Special Characters allowed only [-/,]"
          ),
          document.static_form.dynFrm_phone_mobile.focus(),
          !1
        );
      if (
        (chktrim(document.static_form.dynFrm_phone_mobile.value).length < 10 ||
          chktrim(document.static_form.dynFrm_phone_mobile.value).length >
            10) &&
        "IN^+91" ==
          document.static_form.dynFrm_country.options[
            document.static_form.dynFrm_country.selectedIndex
          ].value
      )
        return (
          alert("Mobile Number Should be 10 digits."),
          document.static_form.dynFrm_phone_mobile.focus(),
          !1
        );
      if (chktrim(document.static_form.dynFrm_phone_mobile.value).length < 3)
        return (
          alert("Mobile Number Should be 3 digits at least."),
          document.static_form.dynFrm_phone_mobile.focus(),
          !1
        );
    }
    var t = document.static_form.dynFrm_your_e_mail.value;
    if ("" == chktrim(t))
      return (
        alert("Please enter email."),
        document.static_form.dynFrm_your_e_mail.focus(),
        !1
      );
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        alert("Please enter valid email."),
        document.static_form.dynFrm_your_e_mail.focus(),
        !1
      );
  } else if ("10017" == e) {
    if (0 == chktrim(document.static_form.dynFrm_contact_person.value).length)
      return (
        jQuery("#dynFrm_contact_person_10017")
          .parent()
          .find("span.red")
          .text("Please Enter Your Name."),
        document.static_form.dynFrm_contact_person.focus(),
        !1
      );
    jQuery("#dynFrm_contact_person_10017").parent().find("span.red").text("");
    var t = document.static_form.dynFrm_email_id.value;
    if ("" == chktrim(t))
      return (
        jQuery("#dynFrm_email_id_10017")
          .parent()
          .find("span.red")
          .text("Please enter email."),
        document.static_form.dynFrm_email_id.focus(),
        !1
      );
    jQuery("#dynFrm_email_id_10017").parent().find("span.red").text("");
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        jQuery("#dynFrm_email_id_10017")
          .parent()
          .find("span.red")
          .text("Please enter valid email."),
        document.static_form.dynFrm_email_id.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_email_id_10017").parent().find("span.red").text(""),
      "" ==
        document.static_form.dynFrm_country.options[
          document.static_form.dynFrm_country.selectedIndex
        ].value)
    )
      return (
        jQuery("#dynFrm_country_10017")
          .parent()
          .find("span.red")
          .text("Please Select Your Country."),
        document.static_form.dynFrm_country.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_country_10017").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_phone.value).length)
    )
      return (
        jQuery("#dynFrm_phone_10017")
          .parent()
          .find("span.red")
          .text("Please Enter Phone/Mobile Number."),
        document.static_form.dynFrm_phone.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_phone_10017").parent().find("span.red").text(""),
      chktrim(document.static_form.dynFrm_phone.value).length > 0)
    ) {
      if (isNaN(document.static_form.dynFrm_phone.value))
        return (
          jQuery("#dynFrm_phone_10017")
            .parent()
            .find("span.red")
            .text(
              "Please enter valid mobile number.Do not enter alphabet or special characters."
            ),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      if (
        (jQuery("#dynFrm_phone_10017").parent().find("span.red").text(""),
        "IN^+91" ==
          document.static_form.dynFrm_country.options[
            document.static_form.dynFrm_country.selectedIndex
          ].value &&
          (chktrim(document.static_form.dynFrm_phone.value).length < 10 ||
            chktrim(document.static_form.dynFrm_phone.value).length > 10))
      )
        return (
          jQuery("#dynFrm_phone_10017")
            .parent()
            .find("span.red")
            .text("Please Enter Your 10 digits mobile number."),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      if (
        "IN^+91" !=
          document.static_form.dynFrm_country.options[
            document.static_form.dynFrm_country.selectedIndex
          ].value &&
        (chktrim(document.static_form.dynFrm_phone.value).length < 3 ||
          chktrim(document.static_form.dynFrm_phone.value).length > 15)
      )
        return (
          jQuery("#dynFrm_phone_10017")
            .parent()
            .find("span.red")
            .text("Please Enter Your 3 to 15 digits mobile number."),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      jQuery("#dynFrm_phone_10017").parent().find("span.red").text("");
    }
    if (0 == chktrim(document.static_form.dynFrm_details_2.value).length)
      return (
        jQuery("#dynFrm_details_2_10017")
          .parent()
          .find("span.red")
          .text("Please Enter Your Requirement Details."),
        document.static_form.dynFrm_details_2.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_details_2_10017").parent().find("span.red").text(""),
      document.static_form.code &&
        0 == chktrim(document.static_form.code.value).length)
    ) {
      if (0 == chktrim(document.static_form.code.value).length)
        return (
          jQuery("#code_10017")
            .parent()
            .find("span.red")
            .text("Please Enter Security Code Displayed on the Image."),
          document.static_form.code.focus(),
          !1
        );
      jQuery("#dynFrm_details_2_10017").parent().find("span.red").text("");
    }
  } else if ("10018" == e) {
    if ("0" == chktrim(document.footer_form.dynFrm_subject.value).length)
      return (
        jQuery("#footer_subject")
          .parent()
          .find("span.dif")
          .text("Please Enter Name of Product / Service."),
        document.footer_form.dynFrm_subject.focus(),
        !1
      );
    if (
      (jQuery("#footer_subject").parent().find("span.dif").text(""),
      0 == chktrim(document.footer_form.dynFrm_details_2.value).length ||
        chktrim(document.footer_form.dynFrm_details_2.value).length < 20)
    )
      return (
        jQuery("#footer_details_2")
          .parent()
          .find("span.dif")
          .text(
            "Please Enter Your Requirement Details [ Minimum 20 Characters ]."
          ),
        document.footer_form.dynFrm_details_2.focus(),
        !1
      );
    if (
      (jQuery("#footer_details_2").parent().find("span.dif").text(""),
      chktrim(document.footer_form.dynFrm_details_2.value).length > 1e3)
    )
      return (
        jQuery("#footer_details_2")
          .parent()
          .find("span.dif")
          .text(
            "Please Enter Your Requirement Details [ Maximum 1000 Characters ]."
          ),
        document.footer_form.dynFrm_details_2.focus(),
        !1
      );
    if (
      (jQuery("#footer_details_2").parent().find("span.dif").text(""),
      0 == chktrim(document.footer_form.dynFrm_contact_person.value).length)
    )
      return (
        jQuery("#footer_contact_person")
          .parent()
          .find("span.dif")
          .text("Please Enter Your Name."),
        document.footer_form.dynFrm_contact_person.focus(),
        !1
      );
    jQuery("#footer_contact_person").parent().find("span.dif").text("");
    var t = document.footer_form.dynFrm_email_id.value;
    if ("" == chktrim(t))
      return (
        jQuery("#footer_email_id")
          .parent()
          .find("span.dif")
          .text("Please enter email."),
        document.footer_form.dynFrm_email_id.focus(),
        !1
      );
    jQuery("#footer_email_id").parent().find("span.dif").text("");
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        jQuery("#footer_email_id")
          .parent()
          .find("span.dif")
          .text("Please enter valid email."),
        document.footer_form.dynFrm_email_id.focus(),
        !1
      );
    if (
      (jQuery("#footer_email_id").parent().find("span.dif").text(""),
      "" ==
        document.footer_form.dynFrm_country.options[
          document.footer_form.dynFrm_country.selectedIndex
        ].value)
    )
      return (
        jQuery("#footer_country")
          .parent()
          .find("span.dif")
          .text("Please Select Your Country."),
        document.footer_form.dynFrm_country.focus(),
        !1
      );
    if (
      (jQuery("#footer_country").parent().find("span.dif").text(""),
      0 == chktrim(document.footer_form.dynFrm_phone.value).length)
    )
      return (
        jQuery("#footer_phone")
          .parents(".phonemsg")
          .find("span.dif")
          .text("Please Enter Phone/Mobile Number."),
        document.footer_form.dynFrm_phone.focus(),
        !1
      );
    if (
      (jQuery("#phone_popup").parents(".phonemsg").find("span.dif").text(""),
      chktrim(document.footer_form.dynFrm_phone.value).length > 0)
    ) {
      if (isNaN(document.footer_form.dynFrm_phone.value))
        return (
          jQuery("#footer_phone")
            .parents(".phonemsg")
            .find("span.dif")
            .text(
              "Please enter valid mobile number.Do not enter alphabet or special characters."
            ),
          document.footer_form.dynFrm_phone.focus(),
          !1
        );
      if (
        (jQuery("#phone_popup").parents(".phonemsg").find("span.dif").text(""),
        "IN^91" ==
          document.footer_form.dynFrm_country.options[
            document.footer_form.dynFrm_country.selectedIndex
          ].value &&
          (chktrim(document.footer_form.dynFrm_phone.value).length < 10 ||
            chktrim(document.footer_form.dynFrm_phone.value).length > 10))
      )
        return (
          jQuery("#footer_phone")
            .parents(".phonemsg")
            .find("span.dif")
            .text("Please Enter Your 10 digits mobile number."),
          document.footer_form.dynFrm_phone.focus(),
          !1
        );
      if (
        "IN^+91" !=
          document.footer_form.dynFrm_country.options[
            document.footer_form.dynFrm_country.selectedIndex
          ].value &&
        (chktrim(document.footer_form.dynFrm_phone.value).length < 3 ||
          chktrim(document.footer_form.dynFrm_phone.value).length > 15)
      )
        return (
          jQuery("#footer_phone")
            .parents(".phonemsg")
            .find("span.dif")
            .text("Please Enter Your 3 to 15 digits mobile number."),
          document.footer_form.dynFrm_phone.focus(),
          !1
        );
      jQuery("#phone_popup").parents(".phonemsg").find("span.dif").text("");
    }
  } else if ("10019" == e || "10026" == e) {
    if (0 == chktrim(document.static_form.dynFrm_contact_person.value).length)
      return (
        jQuery("#dynFrm_contact_person")
          .parent()
          .find("span.red")
          .text("Please Enter Your Name"),
        document.static_form.dynFrm_contact_person.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    jQuery("#dynFrm_contact_person").parent().find("span.red").text("");
    var t = document.static_form.dynFrm_email_id.value;
    if ("" == chktrim(t))
      return (
        jQuery("#dynFrm_email_id")
          .parent()
          .find("span.red")
          .text("Please enter email."),
        document.static_form.dynFrm_email_id.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    jQuery("#dynFrm_email_id").parent().find("span.red").text("");
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        jQuery("#dynFrm_email_id")
          .parent()
          .find("span.red")
          .text("Please enter valid email."),
        document.static_form.dynFrm_email_id.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    if (
      (jQuery("#dynFrm_email_id").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_phone.value).length)
    )
      return (
        jQuery("#phone_popup")
          .parents(".phonemsg")
          .find("span.red")
          .text("Please Enter Phone/Mobile Number."),
        document.static_form.dynFrm_phone.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    if (
      (jQuery("#phone_popup").parents(".phonemsg").find("span.red").text(""),
      chktrim(document.static_form.dynFrm_phone.value).length > 0)
    ) {
      if (isNaN(document.static_form.dynFrm_phone.value))
        return (
          jQuery("#phone_popup")
            .parents(".phonemsg")
            .find("span.red")
            .text(
              "Please enter valid mobile number.Do not enter alphabet or special characters."
            ),
          document.static_form.dynFrm_phone.focus(),
          jQuery('input[type="submit"]').prop("disabled", !1),
          !1
        );
      if (
        (jQuery("#phone_popup").parents(".phonemsg").find("span.red").text(""),
        "IN^91" == document.static_form.dynFrm_country.value &&
          (chktrim(document.static_form.dynFrm_phone.value).length < 10 ||
            chktrim(document.static_form.dynFrm_phone.value).length > 10))
      )
        return (
          jQuery("#phone_popup")
            .parents(".phonemsg")
            .find("span.red")
            .text("Please Enter Your 10 digits mobile number."),
          document.static_form.dynFrm_phone.focus(),
          jQuery('input[type="submit"]').prop("disabled", !1),
          !1
        );
      if (
        "IN^+91" != document.static_form.dynFrm_country.value &&
        (chktrim(document.static_form.dynFrm_phone.value).length < 3 ||
          chktrim(document.static_form.dynFrm_phone.value).length > 15)
      )
        return (
          jQuery("#phone_popup")
            .parents(".phonemsg")
            .find("span.red")
            .text("Please Enter Your 3 to 15 digits mobile number."),
          document.static_form.dynFrm_phone.focus(),
          jQuery('input[type="submit"]').prop("disabled", !1),
          !1
        );
      jQuery("#phone_popup").parents(".phonemsg").find("span.red").text("");
    }
    if (
      0 == chktrim(document.static_form.dynFrm_details_2.value).length ||
      chktrim(document.static_form.dynFrm_details_2.value).length < 20
    )
      return (
        jQuery("#dynFrm_details_2")
          .parent()
          .find("span.red")
          .text(
            "Please Enter Your Requirement Details [ Minimum 20 Characters ]"
          ),
        document.static_form.dynFrm_details_2.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    if (
      (jQuery("#dynFrm_details_2").parent().find("span.red").text(""),
      chktrim(document.static_form.dynFrm_details_2.value).length > 1e3)
    )
      return (
        jQuery("#dynFrm_details_2")
          .parent()
          .find("span.red")
          .text(
            "Please Enter Your Requirement Details [ Maximum 1000 Characters ]"
          ),
        document.static_form.dynFrm_details_2.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    jQuery("#dynFrm_details_2").parent().find("span.red").text("");
  } else if ("10021" == e) {
    if (void 0 !== document.email_form.dynFrm_subject) {
      if (0 == chktrim(document.email_form.dynFrm_subject.value).length)
        return (
          jQuery("#dynFrm_subject")
            .parent()
            .find("span.red")
            .text("Please Enter Product / Service Looking For"),
          document.email_form.dynFrm_subject.focus(),
          jQuery('input[type="submit"]').prop("disabled", !1),
          !1
        );
      jQuery("#dynFrm_subject").parent().find("span.red").text("");
    }
    if (
      0 == chktrim(document.email_form.dynFrm_details_2.value).length ||
      chktrim(document.email_form.dynFrm_details_2.value).length < 20
    )
      return (
        jQuery("#dynFrm_details_2")
          .parent()
          .find("span.red")
          .text(
            "Please Enter Your Requirement Details [ Minimum 20 Characters ]"
          ),
        document.email_form.dynFrm_details_2.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    if (
      (jQuery("#dynFrm_details_2").parent().find("span.red").text(""),
      chktrim(document.email_form.dynFrm_details_2.value).length > 1e3)
    )
      return (
        jQuery("#dynFrm_details_2")
          .parent()
          .find("span.red")
          .text(
            "Please Enter Your Requirement Details [ Maximum 1000 Characters ]"
          ),
        document.email_form.dynFrm_details_2.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    if (
      (jQuery("#dynFrm_details_2").parent().find("span.red").text(""),
      0 == chktrim(document.email_form.dynFrm_contact_person.value).length)
    )
      return (
        jQuery("#dynFrm_contact_person")
          .parent()
          .find("span.red")
          .text("Please Enter Your Name"),
        document.email_form.dynFrm_contact_person.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    jQuery("#dynFrm_contact_person").parent().find("span.red").text("");
    var t = document.email_form.dynFrm_email_id.value;
    if ("" == chktrim(t))
      return (
        jQuery("#dynFrm_email_id")
          .parent()
          .find("span.red")
          .text("Please enter email."),
        document.email_form.dynFrm_email_id.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    jQuery("#dynFrm_email_id").parent().find("span.red").text("");
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        jQuery("#dynFrm_email_id")
          .parent()
          .find("span.red")
          .text("Please enter valid email."),
        document.email_form.dynFrm_email_id.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    if (
      (jQuery("#dynFrm_email_id").parent().find("span.red").text(""),
      "" ==
        document.email_form.dynFrm_country.options[
          document.email_form.dynFrm_country.selectedIndex
        ].value)
    )
      return (
        jQuery("#dynFrm_country")
          .parent()
          .find("span.red")
          .text("Please Select Your Country."),
        document.email_form.dynFrm_country.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    if (
      (jQuery("#dynFrm_country").parent().find("span.red").text(""),
      0 == chktrim(document.email_form.dynFrm_phone.value).length)
    )
      return (
        jQuery("#dynFrm_phone")
          .parent()
          .find("span.red")
          .text("Please Enter Phone/Mobile Number."),
        document.email_form.dynFrm_phone.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    if (
      (jQuery("#dynFrm_phone").parent().find("span.red").text(""),
      chktrim(document.email_form.dynFrm_phone.value).length > 0)
    ) {
      if (isNaN(document.email_form.dynFrm_phone.value))
        return (
          jQuery("#dynFrm_phone")
            .parent()
            .find("span.red")
            .text(
              "Please enter valid mobile number.Do not enter alphabet or special characters."
            ),
          document.email_form.dynFrm_phone.focus(),
          jQuery('input[type="submit"]').prop("disabled", !1),
          !1
        );
      if (
        (jQuery("#dynFrm_phone").parent().find("span.red").text(""),
        "IN^91" ==
          document.email_form.dynFrm_country.options[
            document.email_form.dynFrm_country.selectedIndex
          ].value &&
          (chktrim(document.email_form.dynFrm_phone.value).length < 10 ||
            chktrim(document.email_form.dynFrm_phone.value).length > 10))
      )
        return (
          jQuery("#dynFrm_phone")
            .parent()
            .find("span.red")
            .text("Please Enter Your 10 digits mobile number."),
          document.email_form.dynFrm_phone.focus(),
          jQuery('input[type="submit"]').prop("disabled", !1),
          !1
        );
      if (
        "IN^+91" !=
          document.email_form.dynFrm_country.options[
            document.email_form.dynFrm_country.selectedIndex
          ].value &&
        (chktrim(document.email_form.dynFrm_phone.value).length < 3 ||
          chktrim(document.email_form.dynFrm_phone.value).length > 15)
      )
        return (
          jQuery("#dynFrm_phone")
            .parent()
            .find("span.red")
            .text("Please Enter Your 3 to 15 digits mobile number."),
          document.email_form.dynFrm_phone.focus(),
          jQuery('input[type="submit"]').prop("disabled", !1),
          !1
        );
      jQuery("#dynFrm_phone").parent().find("span.red").text("");
    }
  } else if ("10030" == e) {
    if (void 0 !== document.quote_form.dynFrm_subject) {
      if (0 == chktrim(document.quote_form.dynFrm_subject.value).length)
        return (
          jQuery("#dynFrm_subject")
            .parent()
            .find("span.red")
            .text("Please Enter Product / Service Looking For"),
          document.quote_form.dynFrm_subject.focus(),
          jQuery('input[type="submit"]').prop("disabled", !1),
          !1
        );
      jQuery("#dynFrm_subject").parent().find("span.red").text("");
    }
    if (
      0 == chktrim(document.quote_form.dynFrm_details_2.value).length ||
      chktrim(document.quote_form.dynFrm_details_2.value).length < 20
    )
      return (
        jQuery("#dynFrm_details_2")
          .parent()
          .find("span.red")
          .text(
            "Please Enter Your Requirement Details [ Minimum 20 Characters ]"
          ),
        document.quote_form.dynFrm_details_2.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    if (
      (jQuery("#dynFrm_details_2").parent().find("span.red").text(""),
      chktrim(document.quote_form.dynFrm_details_2.value).length > 1e3)
    )
      return (
        jQuery("#dynFrm_details_2")
          .parent()
          .find("span.red")
          .text(
            "Please Enter Your Requirement Details [ Maximum 1000 Characters ]"
          ),
        document.quote_form.dynFrm_details_2.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    if (
      (jQuery("#dynFrm_details_2").parent().find("span.red").text(""),
      0 == chktrim(document.quote_form.dynFrm_contact_person.value).length)
    )
      return (
        jQuery("#dynFrm_contact_person")
          .parent()
          .find("span.red")
          .text("Please Enter Your Name"),
        document.quote_form.dynFrm_contact_person.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    jQuery("#dynFrm_contact_person").parent().find("span.red").text("");
    var t = document.quote_form.dynFrm_email_id.value;
    if ("" == chktrim(t))
      return (
        jQuery("#dynFrm_email_id")
          .parent()
          .find("span.red")
          .text("Please enter email."),
        document.quote_form.dynFrm_email_id.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    jQuery("#dynFrm_email_id").parent().find("span.red").text("");
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        jQuery("#dynFrm_email_id")
          .parent()
          .find("span.red")
          .text("Please enter valid email."),
        document.quote_form.dynFrm_email_id.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    if (
      (jQuery("#dynFrm_email_id").parent().find("span.red").text(""),
      "" ==
        document.quote_form.dynFrm_country.options[
          document.quote_form.dynFrm_country.selectedIndex
        ].value)
    )
      return (
        jQuery("#dynFrm_country")
          .parent()
          .find("span.red")
          .text("Please Select Your Country."),
        document.quote_form.dynFrm_country.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    if (
      (jQuery("#dynFrm_country").parent().find("span.red").text(""),
      0 == chktrim(document.quote_form.dynFrm_phone.value).length)
    )
      return (
        jQuery("#dynFrm_phone")
          .parent()
          .find("span.red")
          .text("Please Enter Phone/Mobile Number."),
        document.quote_form.dynFrm_phone.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    if (
      (jQuery("#dynFrm_phone").parent().find("span.red").text(""),
      chktrim(document.quote_form.dynFrm_phone.value).length > 0)
    ) {
      if (isNaN(document.quote_form.dynFrm_phone.value))
        return (
          jQuery("#dynFrm_phone")
            .parent()
            .find("span.red")
            .text(
              "Please enter valid mobile number.Do not enter alphabet or special characters."
            ),
          document.quote_form.dynFrm_phone.focus(),
          jQuery('input[type="submit"]').prop("disabled", !1),
          !1
        );
      if (
        (jQuery("#dynFrm_phone").parent().find("span.red").text(""),
        "IN^91" ==
          document.quote_form.dynFrm_country.options[
            document.quote_form.dynFrm_country.selectedIndex
          ].value &&
          (chktrim(document.quote_form.dynFrm_phone.value).length < 10 ||
            chktrim(document.quote_form.dynFrm_phone.value).length > 10))
      )
        return (
          jQuery("#dynFrm_phone")
            .parent()
            .find("span.red")
            .text("Please Enter Your 10 digits mobile number."),
          document.quote_form.dynFrm_phone.focus(),
          jQuery('input[type="submit"]').prop("disabled", !1),
          !1
        );
      if (
        "IN^+91" !=
          document.quote_form.dynFrm_country.options[
            document.quote_form.dynFrm_country.selectedIndex
          ].value &&
        (chktrim(document.quote_form.dynFrm_phone.value).length < 3 ||
          chktrim(document.quote_form.dynFrm_phone.value).length > 15)
      )
        return (
          jQuery("#dynFrm_phone")
            .parent()
            .find("span.red")
            .text("Please Enter Your 3 to 15 digits mobile number."),
          document.quote_form.dynFrm_phone.focus(),
          jQuery('input[type="submit"]').prop("disabled", !1),
          !1
        );
      jQuery("#dynFrm_phone").parent().find("span.red").text("");
    }
  } else if ("10022" == e) {
    if (
      0 == chktrim(document.sms_form.dynFrm_details_2.value).length ||
      chktrim(document.sms_form.dynFrm_details_2.value).length < 20
    )
      return (
        jQuery("#dynFrm_details_2")
          .parent()
          .find("span.red")
          .text(
            "Please Enter Your Requirement Details [ Minimum 20 Characters ]"
          ),
        document.sms_form.dynFrm_details_2.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    if (
      (jQuery("#dynFrm_details_2").parent().find("span.red").text(""),
      chktrim(document.sms_form.dynFrm_details_2.value).length > 1e3)
    )
      return (
        jQuery("#dynFrm_details_2")
          .parent()
          .find("span.red")
          .text(
            "Please Enter Your Requirement Details [ Maximum 1000 Characters ]"
          ),
        document.sms_form.dynFrm_details_2.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    if (
      (jQuery("#dynFrm_details_2").parent().find("span.red").text(""),
      0 == chktrim(document.sms_form.dynFrm_contact_person.value).length)
    )
      return (
        jQuery("#dynFrm_contact_person")
          .parent()
          .find("span.red")
          .text("Please Enter Your Name"),
        document.sms_form.dynFrm_contact_person.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    jQuery("#dynFrm_contact_person").parent().find("span.red").text("");
    var t = document.sms_form.dynFrm_email_id.value;
    if ("" == chktrim(t))
      return (
        jQuery("#dynFrm_email_id")
          .parent()
          .find("span.red")
          .text("Please enter email."),
        document.sms_form.dynFrm_email_id.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    jQuery("#dynFrm_email_id").parent().find("span.red").text("");
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        jQuery("#dynFrm_email_id")
          .parent()
          .find("span.red")
          .text("Please enter valid email."),
        document.sms_form.dynFrm_email_id.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    if (
      (jQuery("#dynFrm_email_id").parent().find("span.red").text(""),
      "" ==
        document.sms_form.dynFrm_country.options[
          document.sms_form.dynFrm_country.selectedIndex
        ].value)
    )
      return (
        jQuery("#dynFrm_country")
          .parent()
          .find("span.red")
          .text("Please Select Your Country."),
        document.sms_form.dynFrm_country.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    if (
      (jQuery("#dynFrm_country").parent().find("span.red").text(""),
      0 == chktrim(document.sms_form.dynFrm_phone.value).length)
    )
      return (
        jQuery("#dynFrm_phone")
          .parent()
          .find("span.red")
          .text("Please Enter Phone/Mobile Number."),
        document.sms_form.dynFrm_phone.focus(),
        jQuery('input[type="submit"]').prop("disabled", !1),
        !1
      );
    if (
      (jQuery("#dynFrm_phone").parent().find("span.red").text(""),
      chktrim(document.sms_form.dynFrm_phone.value).length > 0)
    ) {
      if (isNaN(document.sms_form.dynFrm_phone.value))
        return (
          jQuery("#dynFrm_phone")
            .parent()
            .find("span.red")
            .text(
              "Please enter valid mobile number.Do not enter alphabet or special characters."
            ),
          document.sms_form.dynFrm_phone.focus(),
          jQuery('input[type="submit"]').prop("disabled", !1),
          !1
        );
      if (
        (jQuery("#dynFrm_phone").parent().find("span.red").text(""),
        "IN^91" ==
          document.sms_form.dynFrm_country.options[
            document.sms_form.dynFrm_country.selectedIndex
          ].value &&
          (chktrim(document.sms_form.dynFrm_phone.value).length < 10 ||
            chktrim(document.sms_form.dynFrm_phone.value).length > 10))
      )
        return (
          jQuery("#dynFrm_phone")
            .parent()
            .find("span.red")
            .text("Please Enter Your 10 digits mobile number."),
          document.sms_form.dynFrm_phone.focus(),
          jQuery('input[type="submit"]').prop("disabled", !1),
          !1
        );
      if (
        "IN^+91" !=
          document.sms_form.dynFrm_country.options[
            document.sms_form.dynFrm_country.selectedIndex
          ].value &&
        (chktrim(document.sms_form.dynFrm_phone.value).length < 3 ||
          chktrim(document.sms_form.dynFrm_phone.value).length > 15)
      )
        return (
          jQuery("#dynFrm_phone")
            .parent()
            .find("span.red")
            .text("Please Enter Your 3 to 15 digits mobile number."),
          document.sms_form.dynFrm_phone.focus(),
          jQuery('input[type="submit"]').prop("disabled", !1),
          !1
        );
      jQuery("#dynFrm_phone").parent().find("span.red").text("");
    }
  } else if ("10024" == e || "10027" == e) {
    if (0 == chktrim(document.products_form.dynFrm_contact_person.value).length)
      return (
        jQuery("#detail_contact_person")
          .parent()
          .find("span.red")
          .text("Please Enter Your Name"),
        document.products_form.dynFrm_contact_person.focus(),
        !1
      );
    jQuery("#detail_contact_person").parent().find("span.red").text("");
    var t = document.products_form.dynFrm_email_id.value;
    if ("" == chktrim(t))
      return (
        jQuery("#detail_email_id")
          .parent()
          .find("span.red")
          .text("Please enter email."),
        document.products_form.dynFrm_email_id.focus(),
        !1
      );
    jQuery("#detail_email_id").parent().find("span.red").text("");
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        jQuery("#detail_email_id")
          .parent()
          .find("span.red")
          .text("Please enter valid email."),
        document.products_form.dynFrm_email_id.focus(),
        !1
      );
    if (
      (jQuery("#detail_email_id").parent().find("span.red").text(""),
      0 == chktrim(document.products_form.dynFrm_phone.value).length)
    )
      return (
        jQuery("#phone_popup")
          .parents(".phonemsg")
          .find("span.red")
          .text("Please Enter Phone/Mobile Number."),
        document.products_form.dynFrm_phone.focus(),
        !1
      );
    if (
      (jQuery("#phone_popup").parent().find("span.red").text(""),
      chktrim(document.products_form.dynFrm_phone.value).length > 0)
    ) {
      if (isNaN(document.products_form.dynFrm_phone.value))
        return (
          jQuery("#phone_popup")
            .parents(".phonemsg")
            .find("span.red")
            .text(
              "Please enter valid mobile number.Do not enter alphabet or special characters."
            ),
          document.products_form.dynFrm_phone.focus(),
          !1
        );
      if (
        (jQuery("#phone_popup").parents(".phonemsg").find("span.red").text(""),
        "IN^91" == document.products_form.dynFrm_country.value &&
          (chktrim(document.products_form.dynFrm_phone.value).length < 10 ||
            chktrim(document.products_form.dynFrm_phone.value).length > 10))
      )
        return (
          jQuery("#phone_popup")
            .parents(".phonemsg")
            .find("span.red")
            .text("Please Enter Your 10 digits mobile number."),
          document.products_form.dynFrm_phone.focus(),
          !1
        );
      if (
        "IN^+91" != document.products_form.dynFrm_country.value &&
        (chktrim(document.products_form.dynFrm_phone.value).length < 3 ||
          chktrim(document.products_form.dynFrm_phone.value).length > 15)
      )
        return (
          jQuery("#phone_popup")
            .parents(".phonemsg")
            .find("span.red")
            .text("Please Enter Your 3 to 15 digits mobile number."),
          document.products_form.dynFrm_phone.focus(),
          !1
        );
      jQuery("#phone_popup").parents(".phonemsg").find("span.red").text("");
    }
    if (
      0 == chktrim(document.products_form.dynFrm_details_2.value).length ||
      chktrim(document.products_form.dynFrm_details_2.value).length < 20
    )
      return (
        jQuery("#detail_details_2")
          .parent()
          .find("span.red")
          .text(
            "Please Enter Your Requirement Details [ Minimum 20 Characters ]"
          ),
        document.products_form.dynFrm_details_2.focus(),
        !1
      );
    if (
      (jQuery("#detail_details_2").parent().find("span.red").text(""),
      chktrim(document.products_form.dynFrm_details_2.value).length > 1e3)
    )
      return (
        jQuery("#detail_details_2")
          .parent()
          .find("span.red")
          .text(
            "Please Enter Your Requirement Details [ Maximum 1000 Characters ]"
          ),
        document.products_form.dynFrm_details_2.focus(),
        !1
      );
    jQuery("#detail_details_2").parent().find("span.red").text("");
  } else if ("10025" == e) {
    if (0 == chktrim(document.static_form.dynFrm_contact_person.value).length)
      return (
        jQuery("#dynFrm_contact_person_10025")
          .parent()
          .find("span.red")
          .text("Please Enter Your Name."),
        document.static_form.dynFrm_contact_person.focus(),
        !1
      );
    jQuery("#dynFrm_contact_person_10025").parent().find("span.red").text("");
    var t = document.static_form.dynFrm_email_id.value;
    if ("" == chktrim(t))
      return (
        jQuery("#dynFrm_email_id_10025")
          .parent()
          .find("span.red")
          .text("Please enter email."),
        document.static_form.dynFrm_email_id.focus(),
        !1
      );
    jQuery("#dynFrm_email_id_10025").parent().find("span.red").text("");
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        jQuery("#dynFrm_email_id_10025")
          .parent()
          .find("span.red")
          .text("Please enter valid email."),
        document.static_form.dynFrm_email_id.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_email_id_10025").parent().find("span.red").text(""),
      "" ==
        document.static_form.dynFrm_country.options[
          document.static_form.dynFrm_country.selectedIndex
        ].value)
    )
      return (
        jQuery("#dynFrm_country_10025")
          .parent()
          .find("span.red")
          .text("Please Select Your Country."),
        document.static_form.dynFrm_country.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_country_10025").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_phone.value).length)
    )
      return (
        jQuery("#dynFrm_phone_10025")
          .parent()
          .find("span.red")
          .text("Please Enter Phone/Mobile Number."),
        document.static_form.dynFrm_phone.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_phone_10025").parent().find("span.red").text(""),
      chktrim(document.static_form.dynFrm_phone.value).length > 0)
    ) {
      if (isNaN(document.static_form.dynFrm_phone.value))
        return (
          jQuery("#dynFrm_phone_10025")
            .parent()
            .find("span.red")
            .text(
              "Please enter valid mobile number.Do not enter alphabet or special characters."
            ),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      if (
        (jQuery("#dynFrm_phone_10025").parent().find("span.red").text(""),
        "IN^+91" ==
          document.static_form.dynFrm_country.options[
            document.static_form.dynFrm_country.selectedIndex
          ].value &&
          (chktrim(document.static_form.dynFrm_phone.value).length < 10 ||
            chktrim(document.static_form.dynFrm_phone.value).length > 10))
      )
        return (
          jQuery("#dynFrm_phone_10025")
            .parent()
            .find("span.red")
            .text("Please Enter Your 10 digits mobile number."),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      if (
        "IN^+91" !=
          document.static_form.dynFrm_country.options[
            document.static_form.dynFrm_country.selectedIndex
          ].value &&
        (chktrim(document.static_form.dynFrm_phone.value).length < 3 ||
          chktrim(document.static_form.dynFrm_phone.value).length > 15)
      )
        return (
          jQuery("#dynFrm_phone_10025")
            .parent()
            .find("span.red")
            .text("Please Enter Your 3 to 15 digits mobile number."),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      jQuery("#dynFrm_phone_10025").parent().find("span.red").text("");
    }
    if (0 == chktrim(document.static_form.dynFrm_details_2.value).length)
      return (
        jQuery("#dynFrm_details_2_10025")
          .parent()
          .find("span.red")
          .text("Please Enter Your Requirement Details."),
        document.static_form.dynFrm_details_2.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_details_2_10025").parent().find("span.red").text(""),
      document.static_form.code &&
        0 == chktrim(document.static_form.code.value).length)
    ) {
      if (0 == chktrim(document.static_form.code.value).length)
        return (
          jQuery("#code_10025")
            .parent()
            .find("span.red")
            .text("Please Enter Security Code Displayed on the Image."),
          document.static_form.code.focus(),
          !1
        );
      jQuery("#dynFrm_details_2_10025").parent().find("span.red").text("");
    }
  } else if ("10028" == e) {
    if (0 == chktrim(document.static_form.dynFrm_contact_person.value).length)
      return (
        jQuery("#dynFrm_contact_person_10028")
          .parent()
          .find("span.red")
          .text("Please Enter Your Name."),
        document.static_form.dynFrm_contact_person.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_contact_person_10028")
        .parent()
        .find("span.red")
        .text(""),
      0 == chktrim(document.static_form.dynFrm_details_2.value).length)
    )
      return (
        jQuery("#dynFrm_details_2_10028")
          .parent()
          .find("span.red")
          .text("Please Enter Tour Description."),
        document.static_form.dynFrm_details_2.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_details_2_10028").parent().find("span.red").text(""),
      "0" == chktrim(document.static_form.dynFrm_arrival_date.value).length)
    )
      return (
        jQuery("#dynFrm_arrival_date_10028")
          .parent()
          .find("span.red")
          .text("Please Enter Departure Date."),
        document.static_form.dynFrm_arrival_date.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_arrival_date_10028").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_duration.value).length)
    )
      return (
        jQuery("#dynFrm_duration_10028")
          .parent()
          .find("span.red")
          .text("Please Enter Number of Days."),
        document.static_form.dynFrm_duration.focus(),
        !1
      );
    jQuery("#dynFrm_duration_10028").parent().find("span.red").text("");
    var t = document.static_form.dynFrm_email_id.value;
    if ("" == chktrim(t))
      return (
        jQuery("#dynFrm_email_id_10028")
          .parent()
          .find("span.red")
          .text("Please enter Email id."),
        document.static_form.dynFrm_email_id.focus(),
        !1
      );
    jQuery("#dynFrm_email_id_10028").parent().find("span.red").text("");
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        jQuery("#dynFrm_email_id_10028")
          .parent()
          .find("span.red")
          .text("Please enter valid email."),
        document.static_form.dynFrm_email_id.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_email_id_10028").parent().find("span.red").text(""),
      0 == chktrim(document.static_form.dynFrm_phone.value).length)
    )
      return (
        jQuery("#dynFrm_phone_10028")
          .parent()
          .find("span.red")
          .text("Please Enter Phone/Mobile Number."),
        document.static_form.dynFrm_phone.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_phone_10028").parent().find("span.red").text(""),
      chktrim(document.static_form.dynFrm_phone.value).length > 0)
    ) {
      if (isNaN(document.static_form.dynFrm_phone.value))
        return (
          jQuery("#dynFrm_phone_10028")
            .parent()
            .find("span.red")
            .text(
              "Please enter valid mobile number.Do not enter alphabet or special characters."
            ),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      if (
        (jQuery("#dynFrm_phone_10028").parent().find("span.red").text(""),
        "IN^+91" ==
          document.static_form.dynFrm_country.options[
            document.static_form.dynFrm_country.selectedIndex
          ].value &&
          (chktrim(document.static_form.dynFrm_phone.value).length < 10 ||
            chktrim(document.static_form.dynFrm_phone.value).length > 10))
      )
        return (
          jQuery("#dynFrm_phone_10028")
            .parent()
            .find("span.red")
            .text("Please Enter Your 10 digits mobile number."),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      if (
        "IN^+91" !=
          document.static_form.dynFrm_country.options[
            document.static_form.dynFrm_country.selectedIndex
          ].value &&
        (chktrim(document.static_form.dynFrm_phone.value).length < 3 ||
          chktrim(document.static_form.dynFrm_phone.value).length > 15)
      )
        return (
          jQuery("#dynFrm_phone_10028")
            .parent()
            .find("span.red")
            .text("Please Enter Your 3 to 15 digits mobile number."),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      jQuery("#dynFrm_phone_10028").parent().find("span.red").text("");
    }
  } else if ("10029" == e) {
    if (0 == chktrim(document.package_form.dynFrm_contact_person.value).length)
      return (
        jQuery("#dynFrm_contact_person_10029")
          .parent()
          .find("span.red")
          .text("Please Enter Your Name."),
        document.package_form.dynFrm_contact_person.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_contact_person_10029")
        .parent()
        .find("span.red")
        .text(""),
      0 == chktrim(document.package_form.dynFrm_details_2.value).length)
    )
      return (
        jQuery("#dynFrm_details_2_10029")
          .parent()
          .find("span.red")
          .text("Please Enter Tour Description."),
        document.package_form.dynFrm_details_2.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_details_2_10029").parent().find("span.red").text(""),
      "0" == chktrim(document.package_form.dynFrm_arrival_date.value).length)
    )
      return (
        jQuery("#dynFrm_arrival_date_10029")
          .parent()
          .find("span.red")
          .text("Enter Departure Date."),
        document.package_form.dynFrm_arrival_date.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_arrival_date_10029").parent().find("span.red").text(""),
      0 == chktrim(document.package_form.dynFrm_duration.value).length)
    )
      return (
        jQuery("#dynFrm_duration_10029")
          .parent()
          .find("span.red")
          .text("Enter Number of Days."),
        document.package_form.dynFrm_duration.focus(),
        !1
      );
    jQuery("#dynFrm_duration_10029").parent().find("span.red").text("");
    var t = document.package_form.dynFrm_email_id.value;
    if ("" == chktrim(t))
      return (
        jQuery("#dynFrm_email_id_10029")
          .parent()
          .find("span.red")
          .text("Please enter Email id."),
        document.package_form.dynFrm_email_id.focus(),
        !1
      );
    jQuery("#dynFrm_email_id_10029").parent().find("span.red").text("");
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        jQuery("#dynFrm_email_id_10029")
          .parent()
          .find("span.red")
          .text("Please enter valid email."),
        document.package_form.dynFrm_email_id.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_email_id_10029").parent().find("span.red").text(""),
      0 == chktrim(document.package_form.dynFrm_phone.value).length)
    )
      return (
        jQuery("#dynFrm_phone_10029")
          .parent()
          .find("span.red")
          .text("Please Enter Phone/Mobile Number."),
        document.package_form.dynFrm_phone.focus(),
        !1
      );
    if (
      (jQuery("#dynFrm_phone_10029").parent().find("span.red").text(""),
      chktrim(document.package_form.dynFrm_phone.value).length > 0)
    ) {
      if (isNaN(document.package_form.dynFrm_phone.value))
        return (
          jQuery("#dynFrm_phone_10029")
            .parent()
            .find("span.red")
            .text(
              "Please enter valid mobile number.Do not enter alphabet or special characters."
            ),
          document.package_form.dynFrm_phone.focus(),
          !1
        );
      if (
        (jQuery("#dynFrm_phone_10029").parent().find("span.red").text(""),
        "IN^+91" ==
          document.package_form.dynFrm_country.options[
            document.package_form.dynFrm_country.selectedIndex
          ].value &&
          (chktrim(document.package_form.dynFrm_phone.value).length < 10 ||
            chktrim(document.package_form.dynFrm_phone.value).length > 10))
      )
        return (
          jQuery("#dynFrm_phone_10029")
            .parent()
            .find("span.red")
            .text("Please Enter Your 10 digits mobile number."),
          document.package_form.dynFrm_phone.focus(),
          !1
        );
      if (
        "IN^+91" !=
          document.package_form.dynFrm_country.options[
            document.package_form.dynFrm_country.selectedIndex
          ].value &&
        (chktrim(document.package_form.dynFrm_phone.value).length < 3 ||
          chktrim(document.package_form.dynFrm_phone.value).length > 15)
      )
        return (
          jQuery("#dynFrm_phone_10029")
            .parent()
            .find("span.red")
            .text("Please Enter Your 3 to 15 digits mobile number."),
          document.package_form.dynFrm_phone.focus(),
          !1
        );
      jQuery("#dynFrm_phone_10029").parent().find("span.red").text("");
    }
  } else if (
    "10031" == e ||
    "10032" == e ||
    "10033" == e ||
    "10034" == e ||
    "10035" == e
  ) {
    if (0 == chktrim(document.static_form.dynFrm_contact_person.value).length)
      return (
        jQuery("#detail_contact_person")
          .parent()
          .find("span.red")
          .text("Please Enter Your Name"),
        document.static_form.dynFrm_contact_person.focus(),
        !1
      );
    jQuery("#detail_contact_person").parent().find("span.red").text("");
    var t = document.static_form.dynFrm_email_id.value;
    if ("" == chktrim(t))
      return (
        jQuery("#detail_email_id")
          .parent()
          .find("span.red")
          .text("Please enter email."),
        document.static_form.dynFrm_email_id.focus(),
        !1
      );
    jQuery("#detail_email_id").parent().find("span.red").text("");
    var r = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!1 == r.test(t))
      return (
        jQuery("#detail_email_id")
          .parent()
          .find("span.red")
          .text("Please enter valid email."),
        document.static_form.dynFrm_email_id.focus(),
        !1
      );
    if (
      (jQuery("#detail_email_id").parent().find("span.red").text(""),
      "10034" == e || "10035" == e)
    ) {
      if (
        "" ==
        document.static_form.dynFrm_country.options[
          document.static_form.dynFrm_country.selectedIndex
        ].value
      )
        return (
          jQuery("#detail_country")
            .parent()
            .find("span.red")
            .text("Please Select Your Country."),
          document.static_form.dynFrm_country.focus(),
          !1
        );
      jQuery("#detail_country").parent().find("span.red").text("");
    } else {
      if (
        "" ==
        document.static_form.dynFrm_country.options[
          document.static_form.dynFrm_country.selectedIndex
        ].value
      )
        return (
          jQuery("#dynFrm_country")
            .parent()
            .find("span.red")
            .text("Please Select Your Country."),
          document.static_form.dynFrm_country.focus(),
          !1
        );
      jQuery("#dynFrm_country").parent().find("span.red").text("");
    }
    if ("10032" != e && "10034" != e && "10035" != e) {
      if (
        ("IN^91" ==
          document.static_form.dynFrm_country.options[
            document.static_form.dynFrm_country.selectedIndex
          ].value ||
          "IN^+91" ==
            document.static_form.dynFrm_country.options[
              document.static_form.dynFrm_country.selectedIndex
            ].value) &&
        "" ==
          document.static_form.dynFrm_state.options[
            document.static_form.dynFrm_state.selectedIndex
          ].value
      )
        return (
          jQuery("#dynFrm_state")
            .parent()
            .find("span.red")
            .text("Please Select State."),
          document.static_form.dynFrm_state.focus(),
          !1
        );
      jQuery("#dynFrm_state").parent().find("span.red").text("");
    }
    if (0 == chktrim(document.static_form.dynFrm_phone.value).length)
      return (
        jQuery("#detail_phone")
          .parent()
          .find("span.red")
          .text("Please Enter Phone/Mobile Number."),
        document.static_form.dynFrm_phone.focus(),
        !1
      );
    if (
      (jQuery("#detail_phone").parent().find("span.red").text(""),
      chktrim(document.static_form.dynFrm_phone.value).length > 0)
    ) {
      if (isNaN(document.static_form.dynFrm_phone.value))
        return (
          jQuery("#detail_phone")
            .parent()
            .find("span.red")
            .text(
              "Please enter valid mobile number.Do not enter alphabet or special characters."
            ),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      if (
        (jQuery("#detail_phone").parent().find("span.red").text(""),
        ("IN^91" == document.static_form.dynFrm_country.value ||
          "IN^+91" == document.static_form.dynFrm_country.value) &&
          (chktrim(document.static_form.dynFrm_phone.value).length < 10 ||
            chktrim(document.static_form.dynFrm_phone.value).length > 10))
      )
        return (
          jQuery("#detail_phone")
            .parent()
            .find("span.red")
            .text("Please Enter Your 10 digits mobile number."),
          document.static_form.dynFrm_phone.focus(),
          !1
        );
      if (
        "IN^91" != document.static_form.dynFrm_country.value &&
        "IN^+91" != document.static_form.dynFrm_country.value &&
        (chktrim(document.static_form.dynFrm_phone.value).length < 3 ||
          chktrim(document.static_form.dynFrm_phone.value).length > 15)
      )
        return (
          jQuery("#detail_phone")
            .parent()
            .find("span.red")
            .text("Please Enter Your 3 to 15 digits mobile number."),
          document.products_form.dynFrm_phone.focus(),
          !1
        );
      jQuery("#detail_phone").parent().find("span.red").text("");
    }
    if (
      0 == chktrim(document.static_form.dynFrm_details_2.value).length ||
      chktrim(document.static_form.dynFrm_details_2.value).length < 20
    )
      return (
        jQuery("#detail_details_2")
          .parent()
          .find("span.red")
          .text(
            "Please Enter Your Requirement Details [ Minimum 20 Characters ]"
          ),
        document.static_form.dynFrm_details_2.focus(),
        !1
      );
    if (
      (jQuery("#detail_details_2").parent().find("span.red").text(""),
      chktrim(document.static_form.dynFrm_details_2.value).length > 1e3)
    )
      return (
        jQuery("#detail_details_2")
          .parent()
          .find("span.red")
          .text(
            "Please Enter Your Requirement Details [ Maximum 1000 Characters ]"
          ),
        document.static_form.dynFrm_details_2.focus(),
        !1
      );
    jQuery("#detail_details_2").parent().find("span.red").text("");
  }
}
function project_inqform_validate() {
  if (0 == chktrim(document.proj_form.your_name.value).length)
    return (
      jQuery("#proj_your_name")
        .parent()
        .find("span.small")
        .text("Please Enter Your Name."),
      document.proj_form.your_name.focus(),
      !1
    );
  if (
    (jQuery("#proj_your_name").parent().find("span.small").text(""),
    0 == chktrim(document.proj_form.mobile.value).length)
  )
    return (
      jQuery("#proj_mobile")
        .parent()
        .find("span.small")
        .text("Please Enter Phone/Mobile Number."),
      document.proj_form.mobile.focus(),
      !1
    );
  if (
    (jQuery("#proj_mobile").parent().find("span.small").text(""),
    chktrim(document.proj_form.mobile.value).length > 0)
  ) {
    if (isNaN(document.proj_form.mobile.value))
      return (
        jQuery("#proj_mobile")
          .parent()
          .find("span.small")
          .text(
            "Please enter valid mobile number.Do not enter alphabet or special characters."
          ),
        document.proj_form.mobile.focus(),
        !1
      );
    if (
      (jQuery("#proj_mobile").parent().find("span.small").text(""),
      ("IN" == document.proj_form.country.value ||
        "IN" == document.proj_form.country.value) &&
        (chktrim(document.proj_form.mobile.value).length < 10 ||
          chktrim(document.proj_form.mobile.value).length > 10))
    )
      return (
        jQuery("#proj_mobile")
          .parent()
          .find("span.small")
          .text("Please Enter Your 10 digits mobile number."),
        document.proj_form.mobile.focus(),
        !1
      );
    if (
      "IN" != document.proj_form.country.value &&
      "IN" != document.proj_form.country.value &&
      (chktrim(document.proj_form.mobile.value).length < 3 ||
        chktrim(document.proj_form.mobile.value).length > 15)
    )
      return (
        jQuery("#proj_mobile")
          .parent()
          .find("span.small")
          .text("Please Enter Your 3 to 15 digits mobile number."),
        document.products_form.mobile.focus(),
        !1
      );
    jQuery("#proj_mobile").parent().find("span.small").text("");
  }
  var e = document.proj_form.email_id.value;
  return "" == chktrim(e)
    ? (jQuery("#proj_email_id")
        .parent()
        .find("span.small")
        .text("Please enter email."),
      document.proj_form.email_id.focus(),
      !1)
    : (jQuery("#proj_email_id").parent().find("span.small").text(""),
      !1 ==
        /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(
          e
        ))
    ? (jQuery("#proj_email_id")
        .parent()
        .find("span.small")
        .text("Please enter valid email."),
      document.proj_form.email_id.focus(),
      !1)
    : (jQuery("#proj_email_id").parent().find("span.small").text(""),
      0 == chktrim(document.proj_form.desc.value).length)
    ? (jQuery("#proj_desc")
        .parent()
        .find("span.small")
        .text("Please Enter Your Requirement"),
      document.proj_form.desc.focus(),
      !1)
    : (jQuery("#proj_desc").parent().find("span.small").text(""),
      document.proj_form.code &&
        0 == chktrim(document.proj_form.code.value).length)
    ? (jQuery("#proj_code")
        .parent()
        .find("span.small")
        .text("Please Enter Security Code Displayed on the Image."),
      document.proj_form.code.focus(),
      !1)
    : void jQuery("#proj_code").parent().find("span.small").text("");
}
/*################ common-static-form.min.js ends ###################*/

/*################ swfobject-new.js starts ###################*/
/*	SWFObject v2.2 <http://code.google.com/p/swfobject/> 
	is released under the MIT License <http://www.opensource.org/licenses/mit-license.php> 
*/
var swfobject = (function () {
  var D = "undefined",
    r = "object",
    S = "Shockwave Flash",
    W = "ShockwaveFlash.ShockwaveFlash",
    q = "application/x-shockwave-flash",
    R = "SWFObjectExprInst",
    x = "onreadystatechange",
    O = window,
    j = document,
    t = navigator,
    T = false,
    U = [h],
    o = [],
    N = [],
    I = [],
    l,
    Q,
    E,
    B,
    J = false,
    a = false,
    n,
    G,
    m = true,
    M = (function () {
      var aa =
          typeof j.getElementById != D &&
          typeof j.getElementsByTagName != D &&
          typeof j.createElement != D,
        ah = t.userAgent.toLowerCase(),
        Y = t.platform.toLowerCase(),
        ae = Y ? /win/.test(Y) : /win/.test(ah),
        ac = Y ? /mac/.test(Y) : /mac/.test(ah),
        af = /webkit/.test(ah)
          ? parseFloat(ah.replace(/^.*webkit\/(\d+(\.\d+)?).*$/, "$1"))
          : false,
        X = !+"\v1",
        ag = [0, 0, 0],
        ab = null;
      if (typeof t.plugins != D && typeof t.plugins[S] == r) {
        ab = t.plugins[S].description;
        if (
          ab &&
          !(
            typeof t.mimeTypes != D &&
            t.mimeTypes[q] &&
            !t.mimeTypes[q].enabledPlugin
          )
        ) {
          T = true;
          X = false;
          ab = ab.replace(/^.*\s+(\S+\s+\S+$)/, "$1");
          ag[0] = parseInt(ab.replace(/^(.*)\..*$/, "$1"), 10);
          ag[1] = parseInt(ab.replace(/^.*\.(.*)\s.*$/, "$1"), 10);
          ag[2] = /[a-zA-Z]/.test(ab)
            ? parseInt(ab.replace(/^.*[a-zA-Z]+(.*)$/, "$1"), 10)
            : 0;
        }
      } else {
        if (typeof O.ActiveXObject != D) {
          try {
            var ad = new ActiveXObject(W);
            if (ad) {
              ab = ad.GetVariable("$version");
              if (ab) {
                X = true;
                ab = ab.split(" ")[1].split(",");
                ag = [
                  parseInt(ab[0], 10),
                  parseInt(ab[1], 10),
                  parseInt(ab[2], 10),
                ];
              }
            }
          } catch (Z) {}
        }
      }
      return { w3: aa, pv: ag, wk: af, ie: X, win: ae, mac: ac };
    })(),
    k = (function () {
      if (!M.w3) {
        return;
      }
      if (
        (typeof j.readyState != D && j.readyState == "complete") ||
        (typeof j.readyState == D &&
          (j.getElementsByTagName("body")[0] || j.body))
      ) {
        f();
      }
      if (!J) {
        if (typeof j.addEventListener != D) {
          j.addEventListener("DOMContentLoaded", f, false);
        }
        if (M.ie && M.win) {
          j.attachEvent(x, function () {
            if (j.readyState == "complete") {
              j.detachEvent(x, arguments.callee);
              f();
            }
          });
          if (O == top) {
            (function () {
              if (J) {
                return;
              }
              try {
                j.documentElement.doScroll("left");
              } catch (X) {
                setTimeout(arguments.callee, 0);
                return;
              }
              f();
            })();
          }
        }
        if (M.wk) {
          (function () {
            if (J) {
              return;
            }
            if (!/loaded|complete/.test(j.readyState)) {
              setTimeout(arguments.callee, 0);
              return;
            }
            f();
          })();
        }
        s(f);
      }
    })();
  function f() {
    if (J) {
      return;
    }
    try {
      var Z = j.getElementsByTagName("body")[0].appendChild(C("span"));
      Z.parentNode.removeChild(Z);
    } catch (aa) {
      return;
    }
    J = true;
    var X = U.length;
    for (var Y = 0; Y < X; Y++) {
      U[Y]();
    }
  }
  function K(X) {
    if (J) {
      X();
    } else {
      U[U.length] = X;
    }
  }
  function s(Y) {
    if (typeof O.addEventListener != D) {
      O.addEventListener("load", Y, false);
    } else {
      if (typeof j.addEventListener != D) {
        j.addEventListener("load", Y, false);
      } else {
        if (typeof O.attachEvent != D) {
          i(O, "onload", Y);
        } else {
          if (typeof O.onload == "function") {
            var X = O.onload;
            O.onload = function () {
              X();
              Y();
            };
          } else {
            O.onload = Y;
          }
        }
      }
    }
  }
  function h() {
    if (T) {
      V();
    } else {
      H();
    }
  }
  function V() {
    var X = j.getElementsByTagName("body")[0];
    var aa = C(r);
    aa.setAttribute("type", q);
    var Z = X.appendChild(aa);
    if (Z) {
      var Y = 0;
      (function () {
        if (typeof Z.GetVariable != D) {
          var ab = Z.GetVariable("$version");
          if (ab) {
            ab = ab.split(" ")[1].split(",");
            M.pv = [
              parseInt(ab[0], 10),
              parseInt(ab[1], 10),
              parseInt(ab[2], 10),
            ];
          }
        } else {
          if (Y < 10) {
            Y++;
            setTimeout(arguments.callee, 10);
            return;
          }
        }
        X.removeChild(aa);
        Z = null;
        H();
      })();
    } else {
      H();
    }
  }
  function H() {
    var ag = o.length;
    if (ag > 0) {
      for (var af = 0; af < ag; af++) {
        var Y = o[af].id;
        var ab = o[af].callbackFn;
        var aa = { success: false, id: Y };
        if (M.pv[0] > 0) {
          var ae = c(Y);
          if (ae) {
            if (F(o[af].swfVersion) && !(M.wk && M.wk < 312)) {
              w(Y, true);
              if (ab) {
                aa.success = true;
                aa.ref = z(Y);
                ab(aa);
              }
            } else {
              if (o[af].expressInstall && A()) {
                var ai = {};
                ai.data = o[af].expressInstall;
                ai.width = ae.getAttribute("width") || "0";
                ai.height = ae.getAttribute("height") || "0";
                if (ae.getAttribute("class")) {
                  ai.styleclass = ae.getAttribute("class");
                }
                if (ae.getAttribute("align")) {
                  ai.align = ae.getAttribute("align");
                }
                var ah = {};
                var X = ae.getElementsByTagName("param");
                var ac = X.length;
                for (var ad = 0; ad < ac; ad++) {
                  if (X[ad].getAttribute("name").toLowerCase() != "movie") {
                    ah[X[ad].getAttribute("name")] =
                      X[ad].getAttribute("value");
                  }
                }
                P(ai, ah, Y, ab);
              } else {
                p(ae);
                if (ab) {
                  ab(aa);
                }
              }
            }
          }
        } else {
          w(Y, true);
          if (ab) {
            var Z = z(Y);
            if (Z && typeof Z.SetVariable != D) {
              aa.success = true;
              aa.ref = Z;
            }
            ab(aa);
          }
        }
      }
    }
  }
  function z(aa) {
    var X = null;
    var Y = c(aa);
    if (Y && Y.nodeName == "OBJECT") {
      if (typeof Y.SetVariable != D) {
        X = Y;
      } else {
        var Z = Y.getElementsByTagName(r)[0];
        if (Z) {
          X = Z;
        }
      }
    }
    return X;
  }
  function A() {
    return !a && F("6.0.65") && (M.win || M.mac) && !(M.wk && M.wk < 312);
  }
  function P(aa, ab, X, Z) {
    a = true;
    E = Z || null;
    B = { success: false, id: X };
    var ae = c(X);
    if (ae) {
      if (ae.nodeName == "OBJECT") {
        l = g(ae);
        Q = null;
      } else {
        l = ae;
        Q = X;
      }
      aa.id = R;
      if (
        typeof aa.width == D ||
        (!/%$/.test(aa.width) && parseInt(aa.width, 10) < 310)
      ) {
        aa.width = "310";
      }
      if (
        typeof aa.height == D ||
        (!/%$/.test(aa.height) && parseInt(aa.height, 10) < 137)
      ) {
        aa.height = "137";
      }
      j.title = j.title.slice(0, 47) + " - Flash Player Installation";
      var ad = M.ie && M.win ? "ActiveX" : "PlugIn",
        ac =
          "MMredirectURL=" +
          O.location.toString().replace(/&/g, "%26") +
          "&MMplayerType=" +
          ad +
          "&MMdoctitle=" +
          j.title;
      if (typeof ab.flashvars != D) {
        ab.flashvars += "&" + ac;
      } else {
        ab.flashvars = ac;
      }
      if (M.ie && M.win && ae.readyState != 4) {
        var Y = C("div");
        X += "SWFObjectNew";
        Y.setAttribute("id", X);
        ae.parentNode.insertBefore(Y, ae);
        ae.style.display = "none";
        (function () {
          if (ae.readyState == 4) {
            ae.parentNode.removeChild(ae);
          } else {
            setTimeout(arguments.callee, 10);
          }
        })();
      }
      u(aa, ab, X);
    }
  }
  function p(Y) {
    if (M.ie && M.win && Y.readyState != 4) {
      var X = C("div");
      Y.parentNode.insertBefore(X, Y);
      X.parentNode.replaceChild(g(Y), X);
      Y.style.display = "none";
      (function () {
        if (Y.readyState == 4) {
          Y.parentNode.removeChild(Y);
        } else {
          setTimeout(arguments.callee, 10);
        }
      })();
    } else {
      Y.parentNode.replaceChild(g(Y), Y);
    }
  }
  function g(ab) {
    var aa = C("div");
    if (M.win && M.ie) {
      aa.innerHTML = ab.innerHTML;
    } else {
      var Y = ab.getElementsByTagName(r)[0];
      if (Y) {
        var ad = Y.childNodes;
        if (ad) {
          var X = ad.length;
          for (var Z = 0; Z < X; Z++) {
            if (
              !(ad[Z].nodeType == 1 && ad[Z].nodeName == "PARAM") &&
              !(ad[Z].nodeType == 8)
            ) {
              aa.appendChild(ad[Z].cloneNode(true));
            }
          }
        }
      }
    }
    return aa;
  }
  function u(ai, ag, Y) {
    var X,
      aa = c(Y);
    if (M.wk && M.wk < 312) {
      return X;
    }
    if (aa) {
      if (typeof ai.id == D) {
        ai.id = Y;
      }
      if (M.ie && M.win) {
        var ah = "";
        for (var ae in ai) {
          if (ai[ae] != Object.prototype[ae]) {
            if (ae.toLowerCase() == "data") {
              ag.movie = ai[ae];
            } else {
              if (ae.toLowerCase() == "styleclass") {
                ah += ' class="' + ai[ae] + '"';
              } else {
                if (ae.toLowerCase() != "classid") {
                  ah += " " + ae + '="' + ai[ae] + '"';
                }
              }
            }
          }
        }
        var af = "";
        for (var ad in ag) {
          if (ag[ad] != Object.prototype[ad]) {
            af += '<param name="' + ad + '" value="' + ag[ad] + '" />';
          }
        }
        aa.outerHTML =
          '<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"' +
          ah +
          ">" +
          af +
          "</object>";
        N[N.length] = ai.id;
        X = c(ai.id);
      } else {
        var Z = C(r);
        Z.setAttribute("type", q);
        for (var ac in ai) {
          if (ai[ac] != Object.prototype[ac]) {
            if (ac.toLowerCase() == "styleclass") {
              Z.setAttribute("class", ai[ac]);
            } else {
              if (ac.toLowerCase() != "classid") {
                Z.setAttribute(ac, ai[ac]);
              }
            }
          }
        }
        for (var ab in ag) {
          if (ag[ab] != Object.prototype[ab] && ab.toLowerCase() != "movie") {
            e(Z, ab, ag[ab]);
          }
        }
        aa.parentNode.replaceChild(Z, aa);
        X = Z;
      }
    }
    return X;
  }
  function e(Z, X, Y) {
    var aa = C("param");
    aa.setAttribute("name", X);
    aa.setAttribute("value", Y);
    Z.appendChild(aa);
  }
  function y(Y) {
    var X = c(Y);
    if (X && X.nodeName == "OBJECT") {
      if (M.ie && M.win) {
        X.style.display = "none";
        (function () {
          if (X.readyState == 4) {
            b(Y);
          } else {
            setTimeout(arguments.callee, 10);
          }
        })();
      } else {
        X.parentNode.removeChild(X);
      }
    }
  }
  function b(Z) {
    var Y = c(Z);
    if (Y) {
      for (var X in Y) {
        if (typeof Y[X] == "function") {
          Y[X] = null;
        }
      }
      Y.parentNode.removeChild(Y);
    }
  }
  function c(Z) {
    var X = null;
    try {
      X = j.getElementById(Z);
    } catch (Y) {}
    return X;
  }
  function C(X) {
    return j.createElement(X);
  }
  function i(Z, X, Y) {
    Z.attachEvent(X, Y);
    I[I.length] = [Z, X, Y];
  }
  function F(Z) {
    var Y = M.pv,
      X = Z.split(".");
    X[0] = parseInt(X[0], 10);
    X[1] = parseInt(X[1], 10) || 0;
    X[2] = parseInt(X[2], 10) || 0;
    return Y[0] > X[0] ||
      (Y[0] == X[0] && Y[1] > X[1]) ||
      (Y[0] == X[0] && Y[1] == X[1] && Y[2] >= X[2])
      ? true
      : false;
  }
  function v(ac, Y, ad, ab) {
    if (M.ie && M.mac) {
      return;
    }
    var aa = j.getElementsByTagName("head")[0];
    if (!aa) {
      return;
    }
    var X = ad && typeof ad == "string" ? ad : "screen";
    if (ab) {
      n = null;
      G = null;
    }
    if (!n || G != X) {
      var Z = C("style");
      Z.setAttribute("type", "text/css");
      Z.setAttribute("media", X);
      n = aa.appendChild(Z);
      if (
        M.ie &&
        M.win &&
        typeof j.styleSheets != D &&
        j.styleSheets.length > 0
      ) {
        n = j.styleSheets[j.styleSheets.length - 1];
      }
      G = X;
    }
    if (M.ie && M.win) {
      if (n && typeof n.addRule == r) {
        n.addRule(ac, Y);
      }
    } else {
      if (n && typeof j.createTextNode != D) {
        n.appendChild(j.createTextNode(ac + " {" + Y + "}"));
      }
    }
  }
  function w(Z, X) {
    if (!m) {
      return;
    }
    var Y = X ? "visible" : "hidden";
    if (J && c(Z)) {
      c(Z).style.visibility = Y;
    } else {
      v("#" + Z, "visibility:" + Y);
    }
  }
  function L(Y) {
    var Z = /[\\\"<>\.;]/;
    var X = Z.exec(Y) != null;
    return X && typeof encodeURIComponent != D ? encodeURIComponent(Y) : Y;
  }
  var d = (function () {
    if (M.ie && M.win) {
      window.attachEvent("onunload", function () {
        var ac = I.length;
        for (var ab = 0; ab < ac; ab++) {
          I[ab][0].detachEvent(I[ab][1], I[ab][2]);
        }
        var Z = N.length;
        for (var aa = 0; aa < Z; aa++) {
          y(N[aa]);
        }
        for (var Y in M) {
          M[Y] = null;
        }
        M = null;
        for (var X in swfobject) {
          swfobject[X] = null;
        }
        swfobject = null;
      });
    }
  })();
  return {
    registerObject: function (ab, X, aa, Z) {
      if (M.w3 && ab && X) {
        var Y = {};
        Y.id = ab;
        Y.swfVersion = X;
        Y.expressInstall = aa;
        Y.callbackFn = Z;
        o[o.length] = Y;
        w(ab, false);
      } else {
        if (Z) {
          Z({ success: false, id: ab });
        }
      }
    },
    getObjectById: function (X) {
      if (M.w3) {
        return z(X);
      }
    },
    embedSWF: function (ab, ah, ae, ag, Y, aa, Z, ad, af, ac) {
      var X = { success: false, id: ah };
      if (M.w3 && !(M.wk && M.wk < 312) && ab && ah && ae && ag && Y) {
        w(ah, false);
        K(function () {
          ae += "";
          ag += "";
          var aj = {};
          if (af && typeof af === r) {
            for (var al in af) {
              aj[al] = af[al];
            }
          }
          aj.data = ab;
          aj.width = ae;
          aj.height = ag;
          var am = {};
          if (ad && typeof ad === r) {
            for (var ak in ad) {
              am[ak] = ad[ak];
            }
          }
          if (Z && typeof Z === r) {
            for (var ai in Z) {
              if (typeof am.flashvars != D) {
                am.flashvars += "&" + ai + "=" + Z[ai];
              } else {
                am.flashvars = ai + "=" + Z[ai];
              }
            }
          }
          if (F(Y)) {
            var an = u(aj, am, ah);
            if (aj.id == ah) {
              w(ah, true);
            }
            X.success = true;
            X.ref = an;
          } else {
            if (aa && A()) {
              aj.data = aa;
              P(aj, am, ah, ac);
              return;
            } else {
              w(ah, true);
            }
          }
          if (ac) {
            ac(X);
          }
        });
      } else {
        if (ac) {
          ac(X);
        }
      }
    },
    switchOffAutoHideShow: function () {
      m = false;
    },
    ua: M,
    getFlashPlayerVersion: function () {
      return { major: M.pv[0], minor: M.pv[1], release: M.pv[2] };
    },
    hasFlashPlayerVersion: F,
    createSWF: function (Z, Y, X) {
      if (M.w3) {
        return u(Z, Y, X);
      } else {
        return undefined;
      }
    },
    showExpressInstall: function (Z, aa, X, Y) {
      if (M.w3 && A()) {
        P(Z, aa, X, Y);
      }
    },
    removeSWF: function (X) {
      if (M.w3) {
        y(X);
      }
    },
    createCSS: function (aa, Z, Y, X) {
      if (M.w3) {
        v(aa, Z, Y, X);
      }
    },
    addDomLoadEvent: K,
    addLoadEvent: s,
    getQueryParamValue: function (aa) {
      var Z = j.location.search || j.location.hash;
      if (Z) {
        if (/\?/.test(Z)) {
          Z = Z.split("?")[1];
        }
        if (aa == null) {
          return L(Z);
        }
        var Y = Z.split("&");
        for (var X = 0; X < Y.length; X++) {
          if (Y[X].substring(0, Y[X].indexOf("=")) == aa) {
            return L(Y[X].substring(Y[X].indexOf("=") + 1));
          }
        }
      }
      return "";
    },
    expressInstallCallback: function () {
      if (a) {
        var X = c(R);
        if (X && l) {
          X.parentNode.replaceChild(l, X);
          if (Q) {
            w(Q, true);
            if (M.ie && M.win) {
              l.style.display = "block";
            }
          }
          if (E) {
            E(B);
          }
        }
        a = false;
      }
    },
  };
})();
/*################ swfobject-new.js ends ###################*/

/*################ jquery-date-picker/jquery-ui.min.js starts ###################*/
/*! jQuery UI - v1.8.24 - 2012-09-28

* https://github.com/jquery/jquery-ui

* Includes: jquery.ui.core.js, jquery.ui.widget.js, jquery.ui.mouse.js, jquery.ui.draggable.js, jquery.ui.droppable.js, jquery.ui.resizable.js, jquery.ui.selectable.js, jquery.ui.sortable.js, jquery.effects.core.js, jquery.effects.blind.js, jquery.effects.bounce.js, jquery.effects.clip.js, jquery.effects.drop.js, jquery.effects.explode.js, jquery.effects.fade.js, jquery.effects.fold.js, jquery.effects.highlight.js, jquery.effects.pulsate.js, jquery.effects.scale.js, jquery.effects.shake.js, jquery.effects.slide.js, jquery.effects.transfer.js, jquery.ui.accordion.js, jquery.ui.autocomplete.js, jquery.ui.button.js, jquery.ui.datepicker.js, jquery.ui.dialog.js, jquery.ui.position.js, jquery.ui.progressbar.js, jquery.ui.slider.js, jquery.ui.tabs.js

* Copyright (c) 2012 AUTHORS.txt; Licensed MIT, GPL */

(function (a, b) {
  function c(b, c) {
    var e = b.nodeName.toLowerCase();
    if ("area" === e) {
      var f = b.parentNode,
        g = f.name,
        h;
      return !b.href || !g || f.nodeName.toLowerCase() !== "map"
        ? !1
        : ((h = a("img[usemap=#" + g + "]")[0]), !!h && d(h));
    }
    return (
      (/input|select|textarea|button|object/.test(e)
        ? !b.disabled
        : "a" == e
        ? b.href || c
        : c) && d(b)
    );
  }
  function d(b) {
    return !a(b)
      .parents()
      .andSelf()
      .filter(function () {
        return (
          a.curCSS(this, "visibility") === "hidden" ||
          a.expr.filters.hidden(this)
        );
      }).length;
  }
  a.ui = a.ui || {};
  if (a.ui.version) return;
  a.extend(a.ui, {
    version: "1.8.24",
    keyCode: {
      ALT: 18,
      BACKSPACE: 8,
      CAPS_LOCK: 20,
      COMMA: 188,
      COMMAND: 91,
      COMMAND_LEFT: 91,
      COMMAND_RIGHT: 93,
      CONTROL: 17,
      DELETE: 46,
      DOWN: 40,
      END: 35,
      ENTER: 13,
      ESCAPE: 27,
      HOME: 36,
      INSERT: 45,
      LEFT: 37,
      MENU: 93,
      NUMPAD_ADD: 107,
      NUMPAD_DECIMAL: 110,
      NUMPAD_DIVIDE: 111,
      NUMPAD_ENTER: 108,
      NUMPAD_MULTIPLY: 106,
      NUMPAD_SUBTRACT: 109,
      PAGE_DOWN: 34,
      PAGE_UP: 33,
      PERIOD: 190,
      RIGHT: 39,
      SHIFT: 16,
      SPACE: 32,
      TAB: 9,
      UP: 38,
      WINDOWS: 91,
    },
  }),
    a.fn.extend({
      propAttr: a.fn.prop || a.fn.attr,
      _focus: a.fn.focus,
      focus: function (b, c) {
        return typeof b == "number"
          ? this.each(function () {
              var d = this;
              setTimeout(function () {
                a(d).focus(), c && c.call(d);
              }, b);
            })
          : this._focus.apply(this, arguments);
      },
      scrollParent: function () {
        var b;
        return (
          (a.browser.msie && /(static|relative)/.test(this.css("position"))) ||
          /absolute/.test(this.css("position"))
            ? (b = this.parents()
                .filter(function () {
                  return (
                    /(relative|absolute|fixed)/.test(
                      a.curCSS(this, "position", 1)
                    ) &&
                    /(auto|scroll)/.test(
                      a.curCSS(this, "overflow", 1) +
                        a.curCSS(this, "overflow-y", 1) +
                        a.curCSS(this, "overflow-x", 1)
                    )
                  );
                })
                .eq(0))
            : (b = this.parents()
                .filter(function () {
                  return /(auto|scroll)/.test(
                    a.curCSS(this, "overflow", 1) +
                      a.curCSS(this, "overflow-y", 1) +
                      a.curCSS(this, "overflow-x", 1)
                  );
                })
                .eq(0)),
          /fixed/.test(this.css("position")) || !b.length ? a(document) : b
        );
      },
      zIndex: function (c) {
        if (c !== b) return this.css("zIndex", c);
        if (this.length) {
          var d = a(this[0]),
            e,
            f;
          while (d.length && d[0] !== document) {
            e = d.css("position");
            if (e === "absolute" || e === "relative" || e === "fixed") {
              f = parseInt(d.css("zIndex"), 10);
              if (!isNaN(f) && f !== 0) return f;
            }
            d = d.parent();
          }
        }
        return 0;
      },
      disableSelection: function () {
        return this.bind(
          (a.support.selectstart ? "selectstart" : "mousedown") +
            ".ui-disableSelection",
          function (a) {
            a.preventDefault();
          }
        );
      },
      enableSelection: function () {
        return this.unbind(".ui-disableSelection");
      },
    }),
    a("<a>").outerWidth(1).jquery ||
      a.each(["Width", "Height"], function (c, d) {
        function h(b, c, d, f) {
          return (
            a.each(e, function () {
              (c -= parseFloat(a.curCSS(b, "padding" + this, !0)) || 0),
                d &&
                  (c -=
                    parseFloat(a.curCSS(b, "border" + this + "Width", !0)) ||
                    0),
                f && (c -= parseFloat(a.curCSS(b, "margin" + this, !0)) || 0);
            }),
            c
          );
        }
        var e = d === "Width" ? ["Left", "Right"] : ["Top", "Bottom"],
          f = d.toLowerCase(),
          g = {
            innerWidth: a.fn.innerWidth,
            innerHeight: a.fn.innerHeight,
            outerWidth: a.fn.outerWidth,
            outerHeight: a.fn.outerHeight,
          };
        (a.fn["inner" + d] = function (c) {
          return c === b
            ? g["inner" + d].call(this)
            : this.each(function () {
                a(this).css(f, h(this, c) + "px");
              });
        }),
          (a.fn["outer" + d] = function (b, c) {
            return typeof b != "number"
              ? g["outer" + d].call(this, b)
              : this.each(function () {
                  a(this).css(f, h(this, b, !0, c) + "px");
                });
          });
      }),
    a.extend(a.expr[":"], {
      data: a.expr.createPseudo
        ? a.expr.createPseudo(function (b) {
            return function (c) {
              return !!a.data(c, b);
            };
          })
        : function (b, c, d) {
            return !!a.data(b, d[3]);
          },
      focusable: function (b) {
        return c(b, !isNaN(a.attr(b, "tabindex")));
      },
      tabbable: function (b) {
        var d = a.attr(b, "tabindex"),
          e = isNaN(d);
        return (e || d >= 0) && c(b, !e);
      },
    }),
    a(function () {
      var b = document.body,
        c = b.appendChild((c = document.createElement("div")));
      c.offsetHeight,
        a.extend(c.style, {
          minHeight: "100px",
          height: "auto",
          padding: 0,
          borderWidth: 0,
        }),
        (a.support.minHeight = c.offsetHeight === 100),
        (a.support.selectstart = "onselectstart" in c),
        (b.removeChild(c).style.display = "none");
    }),
    a.curCSS || (a.curCSS = a.css),
    a.extend(a.ui, {
      plugin: {
        add: function (b, c, d) {
          var e = a.ui[b].prototype;
          for (var f in d)
            (e.plugins[f] = e.plugins[f] || []), e.plugins[f].push([c, d[f]]);
        },
        call: function (a, b, c) {
          var d = a.plugins[b];
          if (!d || !a.element[0].parentNode) return;
          for (var e = 0; e < d.length; e++)
            a.options[d[e][0]] && d[e][1].apply(a.element, c);
        },
      },
      contains: function (a, b) {
        return document.compareDocumentPosition
          ? a.compareDocumentPosition(b) & 16
          : a !== b && a.contains(b);
      },
      hasScroll: function (b, c) {
        if (a(b).css("overflow") === "hidden") return !1;
        var d = c && c === "left" ? "scrollLeft" : "scrollTop",
          e = !1;
        return b[d] > 0 ? !0 : ((b[d] = 1), (e = b[d] > 0), (b[d] = 0), e);
      },
      isOverAxis: function (a, b, c) {
        return a > b && a < b + c;
      },
      isOver: function (b, c, d, e, f, g) {
        return a.ui.isOverAxis(b, d, f) && a.ui.isOverAxis(c, e, g);
      },
    });
})(jQuery),
  (function (a, b) {
    if (a.cleanData) {
      var c = a.cleanData;
      a.cleanData = function (b) {
        for (var d = 0, e; (e = b[d]) != null; d++)
          try {
            a(e).triggerHandler("remove");
          } catch (f) {}
        c(b);
      };
    } else {
      var d = a.fn.remove;
      a.fn.remove = function (b, c) {
        return this.each(function () {
          return (
            c ||
              ((!b || a.filter(b, [this]).length) &&
                a("*", this)
                  .add([this])
                  .each(function () {
                    try {
                      a(this).triggerHandler("remove");
                    } catch (b) {}
                  })),
            d.call(a(this), b, c)
          );
        });
      };
    }
    (a.widget = function (b, c, d) {
      var e = b.split(".")[0],
        f;
      (b = b.split(".")[1]),
        (f = e + "-" + b),
        d || ((d = c), (c = a.Widget)),
        (a.expr[":"][f] = function (c) {
          return !!a.data(c, b);
        }),
        (a[e] = a[e] || {}),
        (a[e][b] = function (a, b) {
          arguments.length && this._createWidget(a, b);
        });
      var g = new c();
      (g.options = a.extend(!0, {}, g.options)),
        (a[e][b].prototype = a.extend(
          !0,
          g,
          {
            namespace: e,
            widgetName: b,
            widgetEventPrefix: a[e][b].prototype.widgetEventPrefix || b,
            widgetBaseClass: f,
          },
          d
        )),
        a.widget.bridge(b, a[e][b]);
    }),
      (a.widget.bridge = function (c, d) {
        a.fn[c] = function (e) {
          var f = typeof e == "string",
            g = Array.prototype.slice.call(arguments, 1),
            h = this;
          return (
            (e = !f && g.length ? a.extend.apply(null, [!0, e].concat(g)) : e),
            f && e.charAt(0) === "_"
              ? h
              : (f
                  ? this.each(function () {
                      var d = a.data(this, c),
                        f = d && a.isFunction(d[e]) ? d[e].apply(d, g) : d;
                      if (f !== d && f !== b) return (h = f), !1;
                    })
                  : this.each(function () {
                      var b = a.data(this, c);
                      b
                        ? b.option(e || {})._init()
                        : a.data(this, c, new d(e, this));
                    }),
                h)
          );
        };
      }),
      (a.Widget = function (a, b) {
        arguments.length && this._createWidget(a, b);
      }),
      (a.Widget.prototype = {
        widgetName: "widget",
        widgetEventPrefix: "",
        options: { disabled: !1 },
        _createWidget: function (b, c) {
          a.data(c, this.widgetName, this),
            (this.element = a(c)),
            (this.options = a.extend(
              !0,
              {},
              this.options,
              this._getCreateOptions(),
              b
            ));
          var d = this;
          this.element.bind("remove." + this.widgetName, function () {
            d.destroy();
          }),
            this._create(),
            this._trigger("create"),
            this._init();
        },
        _getCreateOptions: function () {
          return a.metadata && a.metadata.get(this.element[0])[this.widgetName];
        },
        _create: function () {},
        _init: function () {},
        destroy: function () {
          this.element
            .unbind("." + this.widgetName)
            .removeData(this.widgetName),
            this.widget()
              .unbind("." + this.widgetName)
              .removeAttr("aria-disabled")
              .removeClass(
                this.widgetBaseClass + "-disabled " + "ui-state-disabled"
              );
        },
        widget: function () {
          return this.element;
        },
        option: function (c, d) {
          var e = c;
          if (arguments.length === 0) return a.extend({}, this.options);
          if (typeof c == "string") {
            if (d === b) return this.options[c];
            (e = {}), (e[c] = d);
          }
          return this._setOptions(e), this;
        },
        _setOptions: function (b) {
          var c = this;
          return (
            a.each(b, function (a, b) {
              c._setOption(a, b);
            }),
            this
          );
        },
        _setOption: function (a, b) {
          return (
            (this.options[a] = b),
            a === "disabled" &&
              this.widget()
                [b ? "addClass" : "removeClass"](
                  this.widgetBaseClass + "-disabled" + " " + "ui-state-disabled"
                )
                .attr("aria-disabled", b),
            this
          );
        },
        enable: function () {
          return this._setOption("disabled", !1);
        },
        disable: function () {
          return this._setOption("disabled", !0);
        },
        _trigger: function (b, c, d) {
          var e,
            f,
            g = this.options[b];
          (d = d || {}),
            (c = a.Event(c)),
            (c.type = (
              b === this.widgetEventPrefix ? b : this.widgetEventPrefix + b
            ).toLowerCase()),
            (c.target = this.element[0]),
            (f = c.originalEvent);
          if (f) for (e in f) e in c || (c[e] = f[e]);
          return (
            this.element.trigger(c, d),
            !(
              (a.isFunction(g) && g.call(this.element[0], c, d) === !1) ||
              c.isDefaultPrevented()
            )
          );
        },
      });
  })(jQuery),
  (function (a, b) {
    var c = !1;
    a(document).mouseup(function (a) {
      c = !1;
    }),
      a.widget("ui.mouse", {
        options: { cancel: ":input,option", distance: 1, delay: 0 },
        _mouseInit: function () {
          var b = this;
          this.element
            .bind("mousedown." + this.widgetName, function (a) {
              return b._mouseDown(a);
            })
            .bind("click." + this.widgetName, function (c) {
              if (!0 === a.data(c.target, b.widgetName + ".preventClickEvent"))
                return (
                  a.removeData(c.target, b.widgetName + ".preventClickEvent"),
                  c.stopImmediatePropagation(),
                  !1
                );
            }),
            (this.started = !1);
        },
        _mouseDestroy: function () {
          this.element.unbind("." + this.widgetName),
            this._mouseMoveDelegate &&
              a(document)
                .unbind("mousemove." + this.widgetName, this._mouseMoveDelegate)
                .unbind("mouseup." + this.widgetName, this._mouseUpDelegate);
        },
        _mouseDown: function (b) {
          if (c) return;
          this._mouseStarted && this._mouseUp(b), (this._mouseDownEvent = b);
          var d = this,
            e = b.which == 1,
            f =
              typeof this.options.cancel == "string" && b.target.nodeName
                ? a(b.target).closest(this.options.cancel).length
                : !1;
          if (!e || f || !this._mouseCapture(b)) return !0;
          (this.mouseDelayMet = !this.options.delay),
            this.mouseDelayMet ||
              (this._mouseDelayTimer = setTimeout(function () {
                d.mouseDelayMet = !0;
              }, this.options.delay));
          if (this._mouseDistanceMet(b) && this._mouseDelayMet(b)) {
            this._mouseStarted = this._mouseStart(b) !== !1;
            if (!this._mouseStarted) return b.preventDefault(), !0;
          }
          return (
            !0 === a.data(b.target, this.widgetName + ".preventClickEvent") &&
              a.removeData(b.target, this.widgetName + ".preventClickEvent"),
            (this._mouseMoveDelegate = function (a) {
              return d._mouseMove(a);
            }),
            (this._mouseUpDelegate = function (a) {
              return d._mouseUp(a);
            }),
            a(document)
              .bind("mousemove." + this.widgetName, this._mouseMoveDelegate)
              .bind("mouseup." + this.widgetName, this._mouseUpDelegate),
            b.preventDefault(),
            (c = !0),
            !0
          );
        },
        _mouseMove: function (b) {
          return !a.browser.msie || document.documentMode >= 9 || !!b.button
            ? this._mouseStarted
              ? (this._mouseDrag(b), b.preventDefault())
              : (this._mouseDistanceMet(b) &&
                  this._mouseDelayMet(b) &&
                  ((this._mouseStarted =
                    this._mouseStart(this._mouseDownEvent, b) !== !1),
                  this._mouseStarted ? this._mouseDrag(b) : this._mouseUp(b)),
                !this._mouseStarted)
            : this._mouseUp(b);
        },
        _mouseUp: function (b) {
          return (
            a(document)
              .unbind("mousemove." + this.widgetName, this._mouseMoveDelegate)
              .unbind("mouseup." + this.widgetName, this._mouseUpDelegate),
            this._mouseStarted &&
              ((this._mouseStarted = !1),
              b.target == this._mouseDownEvent.target &&
                a.data(b.target, this.widgetName + ".preventClickEvent", !0),
              this._mouseStop(b)),
            !1
          );
        },
        _mouseDistanceMet: function (a) {
          return (
            Math.max(
              Math.abs(this._mouseDownEvent.pageX - a.pageX),
              Math.abs(this._mouseDownEvent.pageY - a.pageY)
            ) >= this.options.distance
          );
        },
        _mouseDelayMet: function (a) {
          return this.mouseDelayMet;
        },
        _mouseStart: function (a) {},
        _mouseDrag: function (a) {},
        _mouseStop: function (a) {},
        _mouseCapture: function (a) {
          return !0;
        },
      });
  })(jQuery),
  (function (a, b) {
    a.widget("ui.draggable", a.ui.mouse, {
      widgetEventPrefix: "drag",
      options: {
        addClasses: !0,
        appendTo: "parent",
        axis: !1,
        connectToSortable: !1,
        containment: !1,
        cursor: "auto",
        cursorAt: !1,
        grid: !1,
        handle: !1,
        helper: "original",
        iframeFix: !1,
        opacity: !1,
        refreshPositions: !1,
        revert: !1,
        revertDuration: 500,
        scope: "default",
        scroll: !0,
        scrollSensitivity: 20,
        scrollSpeed: 20,
        snap: !1,
        snapMode: "both",
        snapTolerance: 20,
        stack: !1,
        zIndex: !1,
      },
      _create: function () {
        this.options.helper == "original" &&
          !/^(?:r|a|f)/.test(this.element.css("position")) &&
          (this.element[0].style.position = "relative"),
          this.options.addClasses && this.element.addClass("ui-draggable"),
          this.options.disabled &&
            this.element.addClass("ui-draggable-disabled"),
          this._mouseInit();
      },
      destroy: function () {
        if (!this.element.data("draggable")) return;
        return (
          this.element
            .removeData("draggable")
            .unbind(".draggable")
            .removeClass(
              "ui-draggable ui-draggable-dragging ui-draggable-disabled"
            ),
          this._mouseDestroy(),
          this
        );
      },
      _mouseCapture: function (b) {
        var c = this.options;
        return this.helper ||
          c.disabled ||
          a(b.target).is(".ui-resizable-handle")
          ? !1
          : ((this.handle = this._getHandle(b)),
            this.handle
              ? (c.iframeFix &&
                  a(c.iframeFix === !0 ? "iframe" : c.iframeFix).each(
                    function () {
                      a(
                        '<div class="ui-draggable-iframeFix" style="background: #fff;"></div>'
                      )
                        .css({
                          width: this.offsetWidth + "px",
                          height: this.offsetHeight + "px",
                          position: "absolute",
                          opacity: "0.001",
                          zIndex: 1e3,
                        })
                        .css(a(this).offset())
                        .appendTo("body");
                    }
                  ),
                !0)
              : !1);
      },
      _mouseStart: function (b) {
        var c = this.options;
        return (
          (this.helper = this._createHelper(b)),
          this.helper.addClass("ui-draggable-dragging"),
          this._cacheHelperProportions(),
          a.ui.ddmanager && (a.ui.ddmanager.current = this),
          this._cacheMargins(),
          (this.cssPosition = this.helper.css("position")),
          (this.scrollParent = this.helper.scrollParent()),
          (this.offset = this.positionAbs = this.element.offset()),
          (this.offset = {
            top: this.offset.top - this.margins.top,
            left: this.offset.left - this.margins.left,
          }),
          a.extend(this.offset, {
            click: {
              left: b.pageX - this.offset.left,
              top: b.pageY - this.offset.top,
            },
            parent: this._getParentOffset(),
            relative: this._getRelativeOffset(),
          }),
          (this.originalPosition = this.position = this._generatePosition(b)),
          (this.originalPageX = b.pageX),
          (this.originalPageY = b.pageY),
          c.cursorAt && this._adjustOffsetFromHelper(c.cursorAt),
          c.containment && this._setContainment(),
          this._trigger("start", b) === !1
            ? (this._clear(), !1)
            : (this._cacheHelperProportions(),
              a.ui.ddmanager &&
                !c.dropBehaviour &&
                a.ui.ddmanager.prepareOffsets(this, b),
              this._mouseDrag(b, !0),
              a.ui.ddmanager && a.ui.ddmanager.dragStart(this, b),
              !0)
        );
      },
      _mouseDrag: function (b, c) {
        (this.position = this._generatePosition(b)),
          (this.positionAbs = this._convertPositionTo("absolute"));
        if (!c) {
          var d = this._uiHash();
          if (this._trigger("drag", b, d) === !1) return this._mouseUp({}), !1;
          this.position = d.position;
        }
        if (!this.options.axis || this.options.axis != "y")
          this.helper[0].style.left = this.position.left + "px";
        if (!this.options.axis || this.options.axis != "x")
          this.helper[0].style.top = this.position.top + "px";
        return a.ui.ddmanager && a.ui.ddmanager.drag(this, b), !1;
      },
      _mouseStop: function (b) {
        var c = !1;
        a.ui.ddmanager &&
          !this.options.dropBehaviour &&
          (c = a.ui.ddmanager.drop(this, b)),
          this.dropped && ((c = this.dropped), (this.dropped = !1));
        var d = this.element[0],
          e = !1;
        while (d && (d = d.parentNode)) d == document && (e = !0);
        if (!e && this.options.helper === "original") return !1;
        if (
          (this.options.revert == "invalid" && !c) ||
          (this.options.revert == "valid" && c) ||
          this.options.revert === !0 ||
          (a.isFunction(this.options.revert) &&
            this.options.revert.call(this.element, c))
        ) {
          var f = this;
          a(this.helper).animate(
            this.originalPosition,
            parseInt(this.options.revertDuration, 10),
            function () {
              f._trigger("stop", b) !== !1 && f._clear();
            }
          );
        } else this._trigger("stop", b) !== !1 && this._clear();
        return !1;
      },
      _mouseUp: function (b) {
        return (
          a("div.ui-draggable-iframeFix").each(function () {
            this.parentNode.removeChild(this);
          }),
          a.ui.ddmanager && a.ui.ddmanager.dragStop(this, b),
          a.ui.mouse.prototype._mouseUp.call(this, b)
        );
      },
      cancel: function () {
        return (
          this.helper.is(".ui-draggable-dragging")
            ? this._mouseUp({})
            : this._clear(),
          this
        );
      },
      _getHandle: function (b) {
        var c =
          !this.options.handle || !a(this.options.handle, this.element).length
            ? !0
            : !1;
        return (
          a(this.options.handle, this.element)
            .find("*")
            .andSelf()
            .each(function () {
              this == b.target && (c = !0);
            }),
          c
        );
      },
      _createHelper: function (b) {
        var c = this.options,
          d = a.isFunction(c.helper)
            ? a(c.helper.apply(this.element[0], [b]))
            : c.helper == "clone"
            ? this.element.clone().removeAttr("id")
            : this.element;
        return (
          d.parents("body").length ||
            d.appendTo(
              c.appendTo == "parent" ? this.element[0].parentNode : c.appendTo
            ),
          d[0] != this.element[0] &&
            !/(fixed|absolute)/.test(d.css("position")) &&
            d.css("position", "absolute"),
          d
        );
      },
      _adjustOffsetFromHelper: function (b) {
        typeof b == "string" && (b = b.split(" ")),
          a.isArray(b) && (b = { left: +b[0], top: +b[1] || 0 }),
          "left" in b && (this.offset.click.left = b.left + this.margins.left),
          "right" in b &&
            (this.offset.click.left =
              this.helperProportions.width - b.right + this.margins.left),
          "top" in b && (this.offset.click.top = b.top + this.margins.top),
          "bottom" in b &&
            (this.offset.click.top =
              this.helperProportions.height - b.bottom + this.margins.top);
      },
      _getParentOffset: function () {
        this.offsetParent = this.helper.offsetParent();
        var b = this.offsetParent.offset();
        this.cssPosition == "absolute" &&
          this.scrollParent[0] != document &&
          a.ui.contains(this.scrollParent[0], this.offsetParent[0]) &&
          ((b.left += this.scrollParent.scrollLeft()),
          (b.top += this.scrollParent.scrollTop()));
        if (
          this.offsetParent[0] == document.body ||
          (this.offsetParent[0].tagName &&
            this.offsetParent[0].tagName.toLowerCase() == "html" &&
            a.browser.msie)
        )
          b = { top: 0, left: 0 };
        return {
          top:
            b.top +
            (parseInt(this.offsetParent.css("borderTopWidth"), 10) || 0),
          left:
            b.left +
            (parseInt(this.offsetParent.css("borderLeftWidth"), 10) || 0),
        };
      },
      _getRelativeOffset: function () {
        if (this.cssPosition == "relative") {
          var a = this.element.position();
          return {
            top:
              a.top -
              (parseInt(this.helper.css("top"), 10) || 0) +
              this.scrollParent.scrollTop(),
            left:
              a.left -
              (parseInt(this.helper.css("left"), 10) || 0) +
              this.scrollParent.scrollLeft(),
          };
        }
        return { top: 0, left: 0 };
      },
      _cacheMargins: function () {
        this.margins = {
          left: parseInt(this.element.css("marginLeft"), 10) || 0,
          top: parseInt(this.element.css("marginTop"), 10) || 0,
          right: parseInt(this.element.css("marginRight"), 10) || 0,
          bottom: parseInt(this.element.css("marginBottom"), 10) || 0,
        };
      },
      _cacheHelperProportions: function () {
        this.helperProportions = {
          width: this.helper.outerWidth(),
          height: this.helper.outerHeight(),
        };
      },
      _setContainment: function () {
        var b = this.options;
        b.containment == "parent" &&
          (b.containment = this.helper[0].parentNode);
        if (b.containment == "document" || b.containment == "window")
          this.containment = [
            b.containment == "document"
              ? 0
              : a(window).scrollLeft() -
                this.offset.relative.left -
                this.offset.parent.left,
            b.containment == "document"
              ? 0
              : a(window).scrollTop() -
                this.offset.relative.top -
                this.offset.parent.top,
            (b.containment == "document" ? 0 : a(window).scrollLeft()) +
              a(b.containment == "document" ? document : window).width() -
              this.helperProportions.width -
              this.margins.left,
            (b.containment == "document" ? 0 : a(window).scrollTop()) +
              (a(b.containment == "document" ? document : window).height() ||
                document.body.parentNode.scrollHeight) -
              this.helperProportions.height -
              this.margins.top,
          ];
        if (
          !/^(document|window|parent)$/.test(b.containment) &&
          b.containment.constructor != Array
        ) {
          var c = a(b.containment),
            d = c[0];
          if (!d) return;
          var e = c.offset(),
            f = a(d).css("overflow") != "hidden";
          (this.containment = [
            (parseInt(a(d).css("borderLeftWidth"), 10) || 0) +
              (parseInt(a(d).css("paddingLeft"), 10) || 0),
            (parseInt(a(d).css("borderTopWidth"), 10) || 0) +
              (parseInt(a(d).css("paddingTop"), 10) || 0),
            (f ? Math.max(d.scrollWidth, d.offsetWidth) : d.offsetWidth) -
              (parseInt(a(d).css("borderLeftWidth"), 10) || 0) -
              (parseInt(a(d).css("paddingRight"), 10) || 0) -
              this.helperProportions.width -
              this.margins.left -
              this.margins.right,
            (f ? Math.max(d.scrollHeight, d.offsetHeight) : d.offsetHeight) -
              (parseInt(a(d).css("borderTopWidth"), 10) || 0) -
              (parseInt(a(d).css("paddingBottom"), 10) || 0) -
              this.helperProportions.height -
              this.margins.top -
              this.margins.bottom,
          ]),
            (this.relative_container = c);
        } else
          b.containment.constructor == Array &&
            (this.containment = b.containment);
      },
      _convertPositionTo: function (b, c) {
        c || (c = this.position);
        var d = b == "absolute" ? 1 : -1,
          e = this.options,
          f =
            this.cssPosition == "absolute" &&
            (this.scrollParent[0] == document ||
              !a.ui.contains(this.scrollParent[0], this.offsetParent[0]))
              ? this.offsetParent
              : this.scrollParent,
          g = /(html|body)/i.test(f[0].tagName);
        return {
          top:
            c.top +
            this.offset.relative.top * d +
            this.offset.parent.top * d -
            (a.browser.safari &&
            a.browser.version < 526 &&
            this.cssPosition == "fixed"
              ? 0
              : (this.cssPosition == "fixed"
                  ? -this.scrollParent.scrollTop()
                  : g
                  ? 0
                  : f.scrollTop()) * d),
          left:
            c.left +
            this.offset.relative.left * d +
            this.offset.parent.left * d -
            (a.browser.safari &&
            a.browser.version < 526 &&
            this.cssPosition == "fixed"
              ? 0
              : (this.cssPosition == "fixed"
                  ? -this.scrollParent.scrollLeft()
                  : g
                  ? 0
                  : f.scrollLeft()) * d),
        };
      },
      _generatePosition: function (b) {
        var c = this.options,
          d =
            this.cssPosition == "absolute" &&
            (this.scrollParent[0] == document ||
              !a.ui.contains(this.scrollParent[0], this.offsetParent[0]))
              ? this.offsetParent
              : this.scrollParent,
          e = /(html|body)/i.test(d[0].tagName),
          f = b.pageX,
          g = b.pageY;
        if (this.originalPosition) {
          var h;
          if (this.containment) {
            if (this.relative_container) {
              var i = this.relative_container.offset();
              h = [
                this.containment[0] + i.left,
                this.containment[1] + i.top,
                this.containment[2] + i.left,
                this.containment[3] + i.top,
              ];
            } else h = this.containment;
            b.pageX - this.offset.click.left < h[0] &&
              (f = h[0] + this.offset.click.left),
              b.pageY - this.offset.click.top < h[1] &&
                (g = h[1] + this.offset.click.top),
              b.pageX - this.offset.click.left > h[2] &&
                (f = h[2] + this.offset.click.left),
              b.pageY - this.offset.click.top > h[3] &&
                (g = h[3] + this.offset.click.top);
          }
          if (c.grid) {
            var j = c.grid[1]
              ? this.originalPageY +
                Math.round((g - this.originalPageY) / c.grid[1]) * c.grid[1]
              : this.originalPageY;
            g = h
              ? j - this.offset.click.top < h[1] ||
                j - this.offset.click.top > h[3]
                ? j - this.offset.click.top < h[1]
                  ? j + c.grid[1]
                  : j - c.grid[1]
                : j
              : j;
            var k = c.grid[0]
              ? this.originalPageX +
                Math.round((f - this.originalPageX) / c.grid[0]) * c.grid[0]
              : this.originalPageX;
            f = h
              ? k - this.offset.click.left < h[0] ||
                k - this.offset.click.left > h[2]
                ? k - this.offset.click.left < h[0]
                  ? k + c.grid[0]
                  : k - c.grid[0]
                : k
              : k;
          }
        }
        return {
          top:
            g -
            this.offset.click.top -
            this.offset.relative.top -
            this.offset.parent.top +
            (a.browser.safari &&
            a.browser.version < 526 &&
            this.cssPosition == "fixed"
              ? 0
              : this.cssPosition == "fixed"
              ? -this.scrollParent.scrollTop()
              : e
              ? 0
              : d.scrollTop()),
          left:
            f -
            this.offset.click.left -
            this.offset.relative.left -
            this.offset.parent.left +
            (a.browser.safari &&
            a.browser.version < 526 &&
            this.cssPosition == "fixed"
              ? 0
              : this.cssPosition == "fixed"
              ? -this.scrollParent.scrollLeft()
              : e
              ? 0
              : d.scrollLeft()),
        };
      },
      _clear: function () {
        this.helper.removeClass("ui-draggable-dragging"),
          this.helper[0] != this.element[0] &&
            !this.cancelHelperRemoval &&
            this.helper.remove(),
          (this.helper = null),
          (this.cancelHelperRemoval = !1);
      },
      _trigger: function (b, c, d) {
        return (
          (d = d || this._uiHash()),
          a.ui.plugin.call(this, b, [c, d]),
          b == "drag" &&
            (this.positionAbs = this._convertPositionTo("absolute")),
          a.Widget.prototype._trigger.call(this, b, c, d)
        );
      },
      plugins: {},
      _uiHash: function (a) {
        return {
          helper: this.helper,
          position: this.position,
          originalPosition: this.originalPosition,
          offset: this.positionAbs,
        };
      },
    }),
      a.extend(a.ui.draggable, { version: "1.8.24" }),
      a.ui.plugin.add("draggable", "connectToSortable", {
        start: function (b, c) {
          var d = a(this).data("draggable"),
            e = d.options,
            f = a.extend({}, c, { item: d.element });
          (d.sortables = []),
            a(e.connectToSortable).each(function () {
              var c = a.data(this, "sortable");
              c &&
                !c.options.disabled &&
                (d.sortables.push({
                  instance: c,
                  shouldRevert: c.options.revert,
                }),
                c.refreshPositions(),
                c._trigger("activate", b, f));
            });
        },
        stop: function (b, c) {
          var d = a(this).data("draggable"),
            e = a.extend({}, c, { item: d.element });
          a.each(d.sortables, function () {
            this.instance.isOver
              ? ((this.instance.isOver = 0),
                (d.cancelHelperRemoval = !0),
                (this.instance.cancelHelperRemoval = !1),
                this.shouldRevert && (this.instance.options.revert = !0),
                this.instance._mouseStop(b),
                (this.instance.options.helper = this.instance.options._helper),
                d.options.helper == "original" &&
                  this.instance.currentItem.css({ top: "auto", left: "auto" }))
              : ((this.instance.cancelHelperRemoval = !1),
                this.instance._trigger("deactivate", b, e));
          });
        },
        drag: function (b, c) {
          var d = a(this).data("draggable"),
            e = this,
            f = function (b) {
              var c = this.offset.click.top,
                d = this.offset.click.left,
                e = this.positionAbs.top,
                f = this.positionAbs.left,
                g = b.height,
                h = b.width,
                i = b.top,
                j = b.left;
              return a.ui.isOver(e + c, f + d, i, j, g, h);
            };
          a.each(d.sortables, function (f) {
            (this.instance.positionAbs = d.positionAbs),
              (this.instance.helperProportions = d.helperProportions),
              (this.instance.offset.click = d.offset.click),
              this.instance._intersectsWith(this.instance.containerCache)
                ? (this.instance.isOver ||
                    ((this.instance.isOver = 1),
                    (this.instance.currentItem = a(e)
                      .clone()
                      .removeAttr("id")
                      .appendTo(this.instance.element)
                      .data("sortable-item", !0)),
                    (this.instance.options._helper =
                      this.instance.options.helper),
                    (this.instance.options.helper = function () {
                      return c.helper[0];
                    }),
                    (b.target = this.instance.currentItem[0]),
                    this.instance._mouseCapture(b, !0),
                    this.instance._mouseStart(b, !0, !0),
                    (this.instance.offset.click.top = d.offset.click.top),
                    (this.instance.offset.click.left = d.offset.click.left),
                    (this.instance.offset.parent.left -=
                      d.offset.parent.left - this.instance.offset.parent.left),
                    (this.instance.offset.parent.top -=
                      d.offset.parent.top - this.instance.offset.parent.top),
                    d._trigger("toSortable", b),
                    (d.dropped = this.instance.element),
                    (d.currentItem = d.element),
                    (this.instance.fromOutside = d)),
                  this.instance.currentItem && this.instance._mouseDrag(b))
                : this.instance.isOver &&
                  ((this.instance.isOver = 0),
                  (this.instance.cancelHelperRemoval = !0),
                  (this.instance.options.revert = !1),
                  this.instance._trigger(
                    "out",
                    b,
                    this.instance._uiHash(this.instance)
                  ),
                  this.instance._mouseStop(b, !0),
                  (this.instance.options.helper =
                    this.instance.options._helper),
                  this.instance.currentItem.remove(),
                  this.instance.placeholder &&
                    this.instance.placeholder.remove(),
                  d._trigger("fromSortable", b),
                  (d.dropped = !1));
          });
        },
      }),
      a.ui.plugin.add("draggable", "cursor", {
        start: function (b, c) {
          var d = a("body"),
            e = a(this).data("draggable").options;
          d.css("cursor") && (e._cursor = d.css("cursor")),
            d.css("cursor", e.cursor);
        },
        stop: function (b, c) {
          var d = a(this).data("draggable").options;
          d._cursor && a("body").css("cursor", d._cursor);
        },
      }),
      a.ui.plugin.add("draggable", "opacity", {
        start: function (b, c) {
          var d = a(c.helper),
            e = a(this).data("draggable").options;
          d.css("opacity") && (e._opacity = d.css("opacity")),
            d.css("opacity", e.opacity);
        },
        stop: function (b, c) {
          var d = a(this).data("draggable").options;
          d._opacity && a(c.helper).css("opacity", d._opacity);
        },
      }),
      a.ui.plugin.add("draggable", "scroll", {
        start: function (b, c) {
          var d = a(this).data("draggable");
          d.scrollParent[0] != document &&
            d.scrollParent[0].tagName != "HTML" &&
            (d.overflowOffset = d.scrollParent.offset());
        },
        drag: function (b, c) {
          var d = a(this).data("draggable"),
            e = d.options,
            f = !1;
          if (
            d.scrollParent[0] != document &&
            d.scrollParent[0].tagName != "HTML"
          ) {
            if (!e.axis || e.axis != "x")
              d.overflowOffset.top + d.scrollParent[0].offsetHeight - b.pageY <
              e.scrollSensitivity
                ? (d.scrollParent[0].scrollTop = f =
                    d.scrollParent[0].scrollTop + e.scrollSpeed)
                : b.pageY - d.overflowOffset.top < e.scrollSensitivity &&
                  (d.scrollParent[0].scrollTop = f =
                    d.scrollParent[0].scrollTop - e.scrollSpeed);
            if (!e.axis || e.axis != "y")
              d.overflowOffset.left + d.scrollParent[0].offsetWidth - b.pageX <
              e.scrollSensitivity
                ? (d.scrollParent[0].scrollLeft = f =
                    d.scrollParent[0].scrollLeft + e.scrollSpeed)
                : b.pageX - d.overflowOffset.left < e.scrollSensitivity &&
                  (d.scrollParent[0].scrollLeft = f =
                    d.scrollParent[0].scrollLeft - e.scrollSpeed);
          } else {
            if (!e.axis || e.axis != "x")
              b.pageY - a(document).scrollTop() < e.scrollSensitivity
                ? (f = a(document).scrollTop(
                    a(document).scrollTop() - e.scrollSpeed
                  ))
                : a(window).height() - (b.pageY - a(document).scrollTop()) <
                    e.scrollSensitivity &&
                  (f = a(document).scrollTop(
                    a(document).scrollTop() + e.scrollSpeed
                  ));
            if (!e.axis || e.axis != "y")
              b.pageX - a(document).scrollLeft() < e.scrollSensitivity
                ? (f = a(document).scrollLeft(
                    a(document).scrollLeft() - e.scrollSpeed
                  ))
                : a(window).width() - (b.pageX - a(document).scrollLeft()) <
                    e.scrollSensitivity &&
                  (f = a(document).scrollLeft(
                    a(document).scrollLeft() + e.scrollSpeed
                  ));
          }
          f !== !1 &&
            a.ui.ddmanager &&
            !e.dropBehaviour &&
            a.ui.ddmanager.prepareOffsets(d, b);
        },
      }),
      a.ui.plugin.add("draggable", "snap", {
        start: function (b, c) {
          var d = a(this).data("draggable"),
            e = d.options;
          (d.snapElements = []),
            a(
              e.snap.constructor != String
                ? e.snap.items || ":data(draggable)"
                : e.snap
            ).each(function () {
              var b = a(this),
                c = b.offset();
              this != d.element[0] &&
                d.snapElements.push({
                  item: this,
                  width: b.outerWidth(),
                  height: b.outerHeight(),
                  top: c.top,
                  left: c.left,
                });
            });
        },
        drag: function (b, c) {
          var d = a(this).data("draggable"),
            e = d.options,
            f = e.snapTolerance,
            g = c.offset.left,
            h = g + d.helperProportions.width,
            i = c.offset.top,
            j = i + d.helperProportions.height;
          for (var k = d.snapElements.length - 1; k >= 0; k--) {
            var l = d.snapElements[k].left,
              m = l + d.snapElements[k].width,
              n = d.snapElements[k].top,
              o = n + d.snapElements[k].height;
            if (
              !(
                (l - f < g && g < m + f && n - f < i && i < o + f) ||
                (l - f < g && g < m + f && n - f < j && j < o + f) ||
                (l - f < h && h < m + f && n - f < i && i < o + f) ||
                (l - f < h && h < m + f && n - f < j && j < o + f)
              )
            ) {
              d.snapElements[k].snapping &&
                d.options.snap.release &&
                d.options.snap.release.call(
                  d.element,
                  b,
                  a.extend(d._uiHash(), { snapItem: d.snapElements[k].item })
                ),
                (d.snapElements[k].snapping = !1);
              continue;
            }
            if (e.snapMode != "inner") {
              var p = Math.abs(n - j) <= f,
                q = Math.abs(o - i) <= f,
                r = Math.abs(l - h) <= f,
                s = Math.abs(m - g) <= f;
              p &&
                (c.position.top =
                  d._convertPositionTo("relative", {
                    top: n - d.helperProportions.height,
                    left: 0,
                  }).top - d.margins.top),
                q &&
                  (c.position.top =
                    d._convertPositionTo("relative", { top: o, left: 0 }).top -
                    d.margins.top),
                r &&
                  (c.position.left =
                    d._convertPositionTo("relative", {
                      top: 0,
                      left: l - d.helperProportions.width,
                    }).left - d.margins.left),
                s &&
                  (c.position.left =
                    d._convertPositionTo("relative", { top: 0, left: m }).left -
                    d.margins.left);
            }
            var t = p || q || r || s;
            if (e.snapMode != "outer") {
              var p = Math.abs(n - i) <= f,
                q = Math.abs(o - j) <= f,
                r = Math.abs(l - g) <= f,
                s = Math.abs(m - h) <= f;
              p &&
                (c.position.top =
                  d._convertPositionTo("relative", { top: n, left: 0 }).top -
                  d.margins.top),
                q &&
                  (c.position.top =
                    d._convertPositionTo("relative", {
                      top: o - d.helperProportions.height,
                      left: 0,
                    }).top - d.margins.top),
                r &&
                  (c.position.left =
                    d._convertPositionTo("relative", { top: 0, left: l }).left -
                    d.margins.left),
                s &&
                  (c.position.left =
                    d._convertPositionTo("relative", {
                      top: 0,
                      left: m - d.helperProportions.width,
                    }).left - d.margins.left);
            }
            !d.snapElements[k].snapping &&
              (p || q || r || s || t) &&
              d.options.snap.snap &&
              d.options.snap.snap.call(
                d.element,
                b,
                a.extend(d._uiHash(), { snapItem: d.snapElements[k].item })
              ),
              (d.snapElements[k].snapping = p || q || r || s || t);
          }
        },
      }),
      a.ui.plugin.add("draggable", "stack", {
        start: function (b, c) {
          var d = a(this).data("draggable").options,
            e = a.makeArray(a(d.stack)).sort(function (b, c) {
              return (
                (parseInt(a(b).css("zIndex"), 10) || 0) -
                (parseInt(a(c).css("zIndex"), 10) || 0)
              );
            });
          if (!e.length) return;
          var f = parseInt(e[0].style.zIndex) || 0;
          a(e).each(function (a) {
            this.style.zIndex = f + a;
          }),
            (this[0].style.zIndex = f + e.length);
        },
      }),
      a.ui.plugin.add("draggable", "zIndex", {
        start: function (b, c) {
          var d = a(c.helper),
            e = a(this).data("draggable").options;
          d.css("zIndex") && (e._zIndex = d.css("zIndex")),
            d.css("zIndex", e.zIndex);
        },
        stop: function (b, c) {
          var d = a(this).data("draggable").options;
          d._zIndex && a(c.helper).css("zIndex", d._zIndex);
        },
      });
  })(jQuery),
  (function (a, b) {
    a.widget("ui.droppable", {
      widgetEventPrefix: "drop",
      options: {
        accept: "*",
        activeClass: !1,
        addClasses: !0,
        greedy: !1,
        hoverClass: !1,
        scope: "default",
        tolerance: "intersect",
      },
      _create: function () {
        var b = this.options,
          c = b.accept;
        (this.isover = 0),
          (this.isout = 1),
          (this.accept = a.isFunction(c)
            ? c
            : function (a) {
                return a.is(c);
              }),
          (this.proportions = {
            width: this.element[0].offsetWidth,
            height: this.element[0].offsetHeight,
          }),
          (a.ui.ddmanager.droppables[b.scope] =
            a.ui.ddmanager.droppables[b.scope] || []),
          a.ui.ddmanager.droppables[b.scope].push(this),
          b.addClasses && this.element.addClass("ui-droppable");
      },
      destroy: function () {
        var b = a.ui.ddmanager.droppables[this.options.scope];
        for (var c = 0; c < b.length; c++) b[c] == this && b.splice(c, 1);
        return (
          this.element
            .removeClass("ui-droppable ui-droppable-disabled")
            .removeData("droppable")
            .unbind(".droppable"),
          this
        );
      },
      _setOption: function (b, c) {
        b == "accept" &&
          (this.accept = a.isFunction(c)
            ? c
            : function (a) {
                return a.is(c);
              }),
          a.Widget.prototype._setOption.apply(this, arguments);
      },
      _activate: function (b) {
        var c = a.ui.ddmanager.current;
        this.options.activeClass &&
          this.element.addClass(this.options.activeClass),
          c && this._trigger("activate", b, this.ui(c));
      },
      _deactivate: function (b) {
        var c = a.ui.ddmanager.current;
        this.options.activeClass &&
          this.element.removeClass(this.options.activeClass),
          c && this._trigger("deactivate", b, this.ui(c));
      },
      _over: function (b) {
        var c = a.ui.ddmanager.current;
        if (!c || (c.currentItem || c.element)[0] == this.element[0]) return;
        this.accept.call(this.element[0], c.currentItem || c.element) &&
          (this.options.hoverClass &&
            this.element.addClass(this.options.hoverClass),
          this._trigger("over", b, this.ui(c)));
      },
      _out: function (b) {
        var c = a.ui.ddmanager.current;
        if (!c || (c.currentItem || c.element)[0] == this.element[0]) return;
        this.accept.call(this.element[0], c.currentItem || c.element) &&
          (this.options.hoverClass &&
            this.element.removeClass(this.options.hoverClass),
          this._trigger("out", b, this.ui(c)));
      },
      _drop: function (b, c) {
        var d = c || a.ui.ddmanager.current;
        if (!d || (d.currentItem || d.element)[0] == this.element[0]) return !1;
        var e = !1;
        return (
          this.element
            .find(":data(droppable)")
            .not(".ui-draggable-dragging")
            .each(function () {
              var b = a.data(this, "droppable");
              if (
                b.options.greedy &&
                !b.options.disabled &&
                b.options.scope == d.options.scope &&
                b.accept.call(b.element[0], d.currentItem || d.element) &&
                a.ui.intersect(
                  d,
                  a.extend(b, { offset: b.element.offset() }),
                  b.options.tolerance
                )
              )
                return (e = !0), !1;
            }),
          e
            ? !1
            : this.accept.call(this.element[0], d.currentItem || d.element)
            ? (this.options.activeClass &&
                this.element.removeClass(this.options.activeClass),
              this.options.hoverClass &&
                this.element.removeClass(this.options.hoverClass),
              this._trigger("drop", b, this.ui(d)),
              this.element)
            : !1
        );
      },
      ui: function (a) {
        return {
          draggable: a.currentItem || a.element,
          helper: a.helper,
          position: a.position,
          offset: a.positionAbs,
        };
      },
    }),
      a.extend(a.ui.droppable, { version: "1.8.24" }),
      (a.ui.intersect = function (b, c, d) {
        if (!c.offset) return !1;
        var e = (b.positionAbs || b.position.absolute).left,
          f = e + b.helperProportions.width,
          g = (b.positionAbs || b.position.absolute).top,
          h = g + b.helperProportions.height,
          i = c.offset.left,
          j = i + c.proportions.width,
          k = c.offset.top,
          l = k + c.proportions.height;
        switch (d) {
          case "fit":
            return i <= e && f <= j && k <= g && h <= l;
          case "intersect":
            return (
              i < e + b.helperProportions.width / 2 &&
              f - b.helperProportions.width / 2 < j &&
              k < g + b.helperProportions.height / 2 &&
              h - b.helperProportions.height / 2 < l
            );
          case "pointer":
            var m =
                (b.positionAbs || b.position.absolute).left +
                (b.clickOffset || b.offset.click).left,
              n =
                (b.positionAbs || b.position.absolute).top +
                (b.clickOffset || b.offset.click).top,
              o = a.ui.isOver(
                n,
                m,
                k,
                i,
                c.proportions.height,
                c.proportions.width
              );
            return o;
          case "touch":
            return (
              ((g >= k && g <= l) || (h >= k && h <= l) || (g < k && h > l)) &&
              ((e >= i && e <= j) || (f >= i && f <= j) || (e < i && f > j))
            );
          default:
            return !1;
        }
      }),
      (a.ui.ddmanager = {
        current: null,
        droppables: { default: [] },
        prepareOffsets: function (b, c) {
          var d = a.ui.ddmanager.droppables[b.options.scope] || [],
            e = c ? c.type : null,
            f = (b.currentItem || b.element).find(":data(droppable)").andSelf();
          g: for (var h = 0; h < d.length; h++) {
            if (
              d[h].options.disabled ||
              (b &&
                !d[h].accept.call(d[h].element[0], b.currentItem || b.element))
            )
              continue;
            for (var i = 0; i < f.length; i++)
              if (f[i] == d[h].element[0]) {
                d[h].proportions.height = 0;
                continue g;
              }
            d[h].visible = d[h].element.css("display") != "none";
            if (!d[h].visible) continue;
            e == "mousedown" && d[h]._activate.call(d[h], c),
              (d[h].offset = d[h].element.offset()),
              (d[h].proportions = {
                width: d[h].element[0].offsetWidth,
                height: d[h].element[0].offsetHeight,
              });
          }
        },
        drop: function (b, c) {
          var d = !1;
          return (
            a.each(
              a.ui.ddmanager.droppables[b.options.scope] || [],
              function () {
                if (!this.options) return;
                !this.options.disabled &&
                  this.visible &&
                  a.ui.intersect(b, this, this.options.tolerance) &&
                  (d = this._drop.call(this, c) || d),
                  !this.options.disabled &&
                    this.visible &&
                    this.accept.call(
                      this.element[0],
                      b.currentItem || b.element
                    ) &&
                    ((this.isout = 1),
                    (this.isover = 0),
                    this._deactivate.call(this, c));
              }
            ),
            d
          );
        },
        dragStart: function (b, c) {
          b.element
            .parents(":not(body,html)")
            .bind("scroll.droppable", function () {
              b.options.refreshPositions || a.ui.ddmanager.prepareOffsets(b, c);
            });
        },
        drag: function (b, c) {
          b.options.refreshPositions && a.ui.ddmanager.prepareOffsets(b, c),
            a.each(
              a.ui.ddmanager.droppables[b.options.scope] || [],
              function () {
                if (this.options.disabled || this.greedyChild || !this.visible)
                  return;
                var d = a.ui.intersect(b, this, this.options.tolerance),
                  e =
                    !d && this.isover == 1
                      ? "isout"
                      : d && this.isover == 0
                      ? "isover"
                      : null;
                if (!e) return;
                var f;
                if (this.options.greedy) {
                  var g = this.options.scope,
                    h = this.element
                      .parents(":data(droppable)")
                      .filter(function () {
                        return a.data(this, "droppable").options.scope === g;
                      });
                  h.length &&
                    ((f = a.data(h[0], "droppable")),
                    (f.greedyChild = e == "isover" ? 1 : 0));
                }
                f &&
                  e == "isover" &&
                  ((f.isover = 0), (f.isout = 1), f._out.call(f, c)),
                  (this[e] = 1),
                  (this[e == "isout" ? "isover" : "isout"] = 0),
                  this[e == "isover" ? "_over" : "_out"].call(this, c),
                  f &&
                    e == "isout" &&
                    ((f.isout = 0), (f.isover = 1), f._over.call(f, c));
              }
            );
        },
        dragStop: function (b, c) {
          b.element.parents(":not(body,html)").unbind("scroll.droppable"),
            b.options.refreshPositions || a.ui.ddmanager.prepareOffsets(b, c);
        },
      });
  })(jQuery),
  (function (a, b) {
    a.widget("ui.resizable", a.ui.mouse, {
      widgetEventPrefix: "resize",
      options: {
        alsoResize: !1,
        animate: !1,
        animateDuration: "slow",
        animateEasing: "swing",
        aspectRatio: !1,
        autoHide: !1,
        containment: !1,
        ghost: !1,
        grid: !1,
        handles: "e,s,se",
        helper: !1,
        maxHeight: null,
        maxWidth: null,
        minHeight: 10,
        minWidth: 10,
        zIndex: 1e3,
      },
      _create: function () {
        var b = this,
          c = this.options;
        this.element.addClass("ui-resizable"),
          a.extend(this, {
            _aspectRatio: !!c.aspectRatio,
            aspectRatio: c.aspectRatio,
            originalElement: this.element,
            _proportionallyResizeElements: [],
            _helper:
              c.helper || c.ghost || c.animate
                ? c.helper || "ui-resizable-helper"
                : null,
          }),
          this.element[0].nodeName.match(
            /canvas|textarea|input|select|button|img/i
          ) &&
            (this.element.wrap(
              a('<div class="ui-wrapper" style="overflow: hidden;"></div>').css(
                {
                  position: this.element.css("position"),
                  width: this.element.outerWidth(),
                  height: this.element.outerHeight(),
                  top: this.element.css("top"),
                  left: this.element.css("left"),
                }
              )
            ),
            (this.element = this.element
              .parent()
              .data("resizable", this.element.data("resizable"))),
            (this.elementIsWrapper = !0),
            this.element.css({
              marginLeft: this.originalElement.css("marginLeft"),
              marginTop: this.originalElement.css("marginTop"),
              marginRight: this.originalElement.css("marginRight"),
              marginBottom: this.originalElement.css("marginBottom"),
            }),
            this.originalElement.css({
              marginLeft: 0,
              marginTop: 0,
              marginRight: 0,
              marginBottom: 0,
            }),
            (this.originalResizeStyle = this.originalElement.css("resize")),
            this.originalElement.css("resize", "none"),
            this._proportionallyResizeElements.push(
              this.originalElement.css({
                position: "static",
                zoom: 1,
                display: "block",
              })
            ),
            this.originalElement.css({
              margin: this.originalElement.css("margin"),
            }),
            this._proportionallyResize()),
          (this.handles =
            c.handles ||
            (a(".ui-resizable-handle", this.element).length
              ? {
                  n: ".ui-resizable-n",
                  e: ".ui-resizable-e",
                  s: ".ui-resizable-s",
                  w: ".ui-resizable-w",
                  se: ".ui-resizable-se",
                  sw: ".ui-resizable-sw",
                  ne: ".ui-resizable-ne",
                  nw: ".ui-resizable-nw",
                }
              : "e,s,se"));
        if (this.handles.constructor == String) {
          this.handles == "all" && (this.handles = "n,e,s,w,se,sw,ne,nw");
          var d = this.handles.split(",");
          this.handles = {};
          for (var e = 0; e < d.length; e++) {
            var f = a.trim(d[e]),
              g = "ui-resizable-" + f,
              h = a('<div class="ui-resizable-handle ' + g + '"></div>');
            h.css({ zIndex: c.zIndex }),
              "se" == f && h.addClass("ui-icon ui-icon-gripsmall-diagonal-se"),
              (this.handles[f] = ".ui-resizable-" + f),
              this.element.append(h);
          }
        }
        (this._renderAxis = function (b) {
          b = b || this.element;
          for (var c in this.handles) {
            this.handles[c].constructor == String &&
              (this.handles[c] = a(this.handles[c], this.element).show());
            if (
              this.elementIsWrapper &&
              this.originalElement[0].nodeName.match(
                /textarea|input|select|button/i
              )
            ) {
              var d = a(this.handles[c], this.element),
                e = 0;
              e = /sw|ne|nw|se|n|s/.test(c) ? d.outerHeight() : d.outerWidth();
              var f = [
                "padding",
                /ne|nw|n/.test(c)
                  ? "Top"
                  : /se|sw|s/.test(c)
                  ? "Bottom"
                  : /^e$/.test(c)
                  ? "Right"
                  : "Left",
              ].join("");
              b.css(f, e), this._proportionallyResize();
            }
            if (!a(this.handles[c]).length) continue;
          }
        }),
          this._renderAxis(this.element),
          (this._handles = a(
            ".ui-resizable-handle",
            this.element
          ).disableSelection()),
          this._handles.mouseover(function () {
            if (!b.resizing) {
              if (this.className)
                var a = this.className.match(
                  /ui-resizable-(se|sw|ne|nw|n|e|s|w)/i
                );
              b.axis = a && a[1] ? a[1] : "se";
            }
          }),
          c.autoHide &&
            (this._handles.hide(),
            a(this.element)
              .addClass("ui-resizable-autohide")
              .hover(
                function () {
                  if (c.disabled) return;
                  a(this).removeClass("ui-resizable-autohide"),
                    b._handles.show();
                },
                function () {
                  if (c.disabled) return;
                  b.resizing ||
                    (a(this).addClass("ui-resizable-autohide"),
                    b._handles.hide());
                }
              )),
          this._mouseInit();
      },
      destroy: function () {
        this._mouseDestroy();
        var b = function (b) {
          a(b)
            .removeClass(
              "ui-resizable ui-resizable-disabled ui-resizable-resizing"
            )
            .removeData("resizable")
            .unbind(".resizable")
            .find(".ui-resizable-handle")
            .remove();
        };
        if (this.elementIsWrapper) {
          b(this.element);
          var c = this.element;
          c.after(
            this.originalElement.css({
              position: c.css("position"),
              width: c.outerWidth(),
              height: c.outerHeight(),
              top: c.css("top"),
              left: c.css("left"),
            })
          ).remove();
        }
        return (
          this.originalElement.css("resize", this.originalResizeStyle),
          b(this.originalElement),
          this
        );
      },
      _mouseCapture: function (b) {
        var c = !1;
        for (var d in this.handles)
          a(this.handles[d])[0] == b.target && (c = !0);
        return !this.options.disabled && c;
      },
      _mouseStart: function (b) {
        var d = this.options,
          e = this.element.position(),
          f = this.element;
        (this.resizing = !0),
          (this.documentScroll = {
            top: a(document).scrollTop(),
            left: a(document).scrollLeft(),
          }),
          (f.is(".ui-draggable") || /absolute/.test(f.css("position"))) &&
            f.css({ position: "absolute", top: e.top, left: e.left }),
          this._renderProxy();
        var g = c(this.helper.css("left")),
          h = c(this.helper.css("top"));
        d.containment &&
          ((g += a(d.containment).scrollLeft() || 0),
          (h += a(d.containment).scrollTop() || 0)),
          (this.offset = this.helper.offset()),
          (this.position = { left: g, top: h }),
          (this.size = this._helper
            ? { width: f.outerWidth(), height: f.outerHeight() }
            : { width: f.width(), height: f.height() }),
          (this.originalSize = this._helper
            ? { width: f.outerWidth(), height: f.outerHeight() }
            : { width: f.width(), height: f.height() }),
          (this.originalPosition = { left: g, top: h }),
          (this.sizeDiff = {
            width: f.outerWidth() - f.width(),
            height: f.outerHeight() - f.height(),
          }),
          (this.originalMousePosition = { left: b.pageX, top: b.pageY }),
          (this.aspectRatio =
            typeof d.aspectRatio == "number"
              ? d.aspectRatio
              : this.originalSize.width / this.originalSize.height || 1);
        var i = a(".ui-resizable-" + this.axis).css("cursor");
        return (
          a("body").css("cursor", i == "auto" ? this.axis + "-resize" : i),
          f.addClass("ui-resizable-resizing"),
          this._propagate("start", b),
          !0
        );
      },
      _mouseDrag: function (b) {
        var c = this.helper,
          d = this.options,
          e = {},
          f = this,
          g = this.originalMousePosition,
          h = this.axis,
          i = b.pageX - g.left || 0,
          j = b.pageY - g.top || 0,
          k = this._change[h];
        if (!k) return !1;
        var l = k.apply(this, [b, i, j]),
          m = a.browser.msie && a.browser.version < 7,
          n = this.sizeDiff;
        this._updateVirtualBoundaries(b.shiftKey);
        if (this._aspectRatio || b.shiftKey) l = this._updateRatio(l, b);
        return (
          (l = this._respectSize(l, b)),
          this._propagate("resize", b),
          c.css({
            top: this.position.top + "px",
            left: this.position.left + "px",
            width: this.size.width + "px",
            height: this.size.height + "px",
          }),
          !this._helper &&
            this._proportionallyResizeElements.length &&
            this._proportionallyResize(),
          this._updateCache(l),
          this._trigger("resize", b, this.ui()),
          !1
        );
      },
      _mouseStop: function (b) {
        this.resizing = !1;
        var c = this.options,
          d = this;
        if (this._helper) {
          var e = this._proportionallyResizeElements,
            f = e.length && /textarea/i.test(e[0].nodeName),
            g = f && a.ui.hasScroll(e[0], "left") ? 0 : d.sizeDiff.height,
            h = f ? 0 : d.sizeDiff.width,
            i = { width: d.helper.width() - h, height: d.helper.height() - g },
            j =
              parseInt(d.element.css("left"), 10) +
                (d.position.left - d.originalPosition.left) || null,
            k =
              parseInt(d.element.css("top"), 10) +
                (d.position.top - d.originalPosition.top) || null;
          c.animate || this.element.css(a.extend(i, { top: k, left: j })),
            d.helper.height(d.size.height),
            d.helper.width(d.size.width),
            this._helper && !c.animate && this._proportionallyResize();
        }
        return (
          a("body").css("cursor", "auto"),
          this.element.removeClass("ui-resizable-resizing"),
          this._propagate("stop", b),
          this._helper && this.helper.remove(),
          !1
        );
      },
      _updateVirtualBoundaries: function (a) {
        var b = this.options,
          c,
          e,
          f,
          g,
          h;
        h = {
          minWidth: d(b.minWidth) ? b.minWidth : 0,
          maxWidth: d(b.maxWidth) ? b.maxWidth : Infinity,
          minHeight: d(b.minHeight) ? b.minHeight : 0,
          maxHeight: d(b.maxHeight) ? b.maxHeight : Infinity,
        };
        if (this._aspectRatio || a)
          (c = h.minHeight * this.aspectRatio),
            (f = h.minWidth / this.aspectRatio),
            (e = h.maxHeight * this.aspectRatio),
            (g = h.maxWidth / this.aspectRatio),
            c > h.minWidth && (h.minWidth = c),
            f > h.minHeight && (h.minHeight = f),
            e < h.maxWidth && (h.maxWidth = e),
            g < h.maxHeight && (h.maxHeight = g);
        this._vBoundaries = h;
      },
      _updateCache: function (a) {
        var b = this.options;
        (this.offset = this.helper.offset()),
          d(a.left) && (this.position.left = a.left),
          d(a.top) && (this.position.top = a.top),
          d(a.height) && (this.size.height = a.height),
          d(a.width) && (this.size.width = a.width);
      },
      _updateRatio: function (a, b) {
        var c = this.options,
          e = this.position,
          f = this.size,
          g = this.axis;
        return (
          d(a.height)
            ? (a.width = a.height * this.aspectRatio)
            : d(a.width) && (a.height = a.width / this.aspectRatio),
          g == "sw" &&
            ((a.left = e.left + (f.width - a.width)), (a.top = null)),
          g == "nw" &&
            ((a.top = e.top + (f.height - a.height)),
            (a.left = e.left + (f.width - a.width))),
          a
        );
      },
      _respectSize: function (a, b) {
        var c = this.helper,
          e = this._vBoundaries,
          f = this._aspectRatio || b.shiftKey,
          g = this.axis,
          h = d(a.width) && e.maxWidth && e.maxWidth < a.width,
          i = d(a.height) && e.maxHeight && e.maxHeight < a.height,
          j = d(a.width) && e.minWidth && e.minWidth > a.width,
          k = d(a.height) && e.minHeight && e.minHeight > a.height;
        j && (a.width = e.minWidth),
          k && (a.height = e.minHeight),
          h && (a.width = e.maxWidth),
          i && (a.height = e.maxHeight);
        var l = this.originalPosition.left + this.originalSize.width,
          m = this.position.top + this.size.height,
          n = /sw|nw|w/.test(g),
          o = /nw|ne|n/.test(g);
        j && n && (a.left = l - e.minWidth),
          h && n && (a.left = l - e.maxWidth),
          k && o && (a.top = m - e.minHeight),
          i && o && (a.top = m - e.maxHeight);
        var p = !a.width && !a.height;
        return (
          p && !a.left && a.top
            ? (a.top = null)
            : p && !a.top && a.left && (a.left = null),
          a
        );
      },
      _proportionallyResize: function () {
        var b = this.options;
        if (!this._proportionallyResizeElements.length) return;
        var c = this.helper || this.element;
        for (var d = 0; d < this._proportionallyResizeElements.length; d++) {
          var e = this._proportionallyResizeElements[d];
          if (!this.borderDif) {
            var f = [
                e.css("borderTopWidth"),
                e.css("borderRightWidth"),
                e.css("borderBottomWidth"),
                e.css("borderLeftWidth"),
              ],
              g = [
                e.css("paddingTop"),
                e.css("paddingRight"),
                e.css("paddingBottom"),
                e.css("paddingLeft"),
              ];
            this.borderDif = a.map(f, function (a, b) {
              var c = parseInt(a, 10) || 0,
                d = parseInt(g[b], 10) || 0;
              return c + d;
            });
          }
          if (
            !a.browser.msie ||
            (!a(c).is(":hidden") && !a(c).parents(":hidden").length)
          )
            e.css({
              height: c.height() - this.borderDif[0] - this.borderDif[2] || 0,
              width: c.width() - this.borderDif[1] - this.borderDif[3] || 0,
            });
          else continue;
        }
      },
      _renderProxy: function () {
        var b = this.element,
          c = this.options;
        this.elementOffset = b.offset();
        if (this._helper) {
          this.helper =
            this.helper || a('<div style="overflow:hidden;"></div>');
          var d = a.browser.msie && a.browser.version < 7,
            e = d ? 1 : 0,
            f = d ? 2 : -1;
          this.helper
            .addClass(this._helper)
            .css({
              width: this.element.outerWidth() + f,
              height: this.element.outerHeight() + f,
              position: "absolute",
              left: this.elementOffset.left - e + "px",
              top: this.elementOffset.top - e + "px",
              zIndex: ++c.zIndex,
            }),
            this.helper.appendTo("body").disableSelection();
        } else this.helper = this.element;
      },
      _change: {
        e: function (a, b, c) {
          return { width: this.originalSize.width + b };
        },
        w: function (a, b, c) {
          var d = this.options,
            e = this.originalSize,
            f = this.originalPosition;
          return { left: f.left + b, width: e.width - b };
        },
        n: function (a, b, c) {
          var d = this.options,
            e = this.originalSize,
            f = this.originalPosition;
          return { top: f.top + c, height: e.height - c };
        },
        s: function (a, b, c) {
          return { height: this.originalSize.height + c };
        },
        se: function (b, c, d) {
          return a.extend(
            this._change.s.apply(this, arguments),
            this._change.e.apply(this, [b, c, d])
          );
        },
        sw: function (b, c, d) {
          return a.extend(
            this._change.s.apply(this, arguments),
            this._change.w.apply(this, [b, c, d])
          );
        },
        ne: function (b, c, d) {
          return a.extend(
            this._change.n.apply(this, arguments),
            this._change.e.apply(this, [b, c, d])
          );
        },
        nw: function (b, c, d) {
          return a.extend(
            this._change.n.apply(this, arguments),
            this._change.w.apply(this, [b, c, d])
          );
        },
      },
      _propagate: function (b, c) {
        a.ui.plugin.call(this, b, [c, this.ui()]),
          b != "resize" && this._trigger(b, c, this.ui());
      },
      plugins: {},
      ui: function () {
        return {
          originalElement: this.originalElement,
          element: this.element,
          helper: this.helper,
          position: this.position,
          size: this.size,
          originalSize: this.originalSize,
          originalPosition: this.originalPosition,
        };
      },
    }),
      a.extend(a.ui.resizable, { version: "1.8.24" }),
      a.ui.plugin.add("resizable", "alsoResize", {
        start: function (b, c) {
          var d = a(this).data("resizable"),
            e = d.options,
            f = function (b) {
              a(b).each(function () {
                var b = a(this);
                b.data("resizable-alsoresize", {
                  width: parseInt(b.width(), 10),
                  height: parseInt(b.height(), 10),
                  left: parseInt(b.css("left"), 10),
                  top: parseInt(b.css("top"), 10),
                });
              });
            };
          typeof e.alsoResize == "object" && !e.alsoResize.parentNode
            ? e.alsoResize.length
              ? ((e.alsoResize = e.alsoResize[0]), f(e.alsoResize))
              : a.each(e.alsoResize, function (a) {
                  f(a);
                })
            : f(e.alsoResize);
        },
        resize: function (b, c) {
          var d = a(this).data("resizable"),
            e = d.options,
            f = d.originalSize,
            g = d.originalPosition,
            h = {
              height: d.size.height - f.height || 0,
              width: d.size.width - f.width || 0,
              top: d.position.top - g.top || 0,
              left: d.position.left - g.left || 0,
            },
            i = function (b, d) {
              a(b).each(function () {
                var b = a(this),
                  e = a(this).data("resizable-alsoresize"),
                  f = {},
                  g =
                    d && d.length
                      ? d
                      : b.parents(c.originalElement[0]).length
                      ? ["width", "height"]
                      : ["width", "height", "top", "left"];
                a.each(g, function (a, b) {
                  var c = (e[b] || 0) + (h[b] || 0);
                  c && c >= 0 && (f[b] = c || null);
                }),
                  b.css(f);
              });
            };
          typeof e.alsoResize == "object" && !e.alsoResize.nodeType
            ? a.each(e.alsoResize, function (a, b) {
                i(a, b);
              })
            : i(e.alsoResize);
        },
        stop: function (b, c) {
          a(this).removeData("resizable-alsoresize");
        },
      }),
      a.ui.plugin.add("resizable", "animate", {
        stop: function (b, c) {
          var d = a(this).data("resizable"),
            e = d.options,
            f = d._proportionallyResizeElements,
            g = f.length && /textarea/i.test(f[0].nodeName),
            h = g && a.ui.hasScroll(f[0], "left") ? 0 : d.sizeDiff.height,
            i = g ? 0 : d.sizeDiff.width,
            j = { width: d.size.width - i, height: d.size.height - h },
            k =
              parseInt(d.element.css("left"), 10) +
                (d.position.left - d.originalPosition.left) || null,
            l =
              parseInt(d.element.css("top"), 10) +
                (d.position.top - d.originalPosition.top) || null;
          d.element.animate(a.extend(j, l && k ? { top: l, left: k } : {}), {
            duration: e.animateDuration,
            easing: e.animateEasing,
            step: function () {
              var c = {
                width: parseInt(d.element.css("width"), 10),
                height: parseInt(d.element.css("height"), 10),
                top: parseInt(d.element.css("top"), 10),
                left: parseInt(d.element.css("left"), 10),
              };
              f &&
                f.length &&
                a(f[0]).css({ width: c.width, height: c.height }),
                d._updateCache(c),
                d._propagate("resize", b);
            },
          });
        },
      }),
      a.ui.plugin.add("resizable", "containment", {
        start: function (b, d) {
          var e = a(this).data("resizable"),
            f = e.options,
            g = e.element,
            h = f.containment,
            i =
              h instanceof a
                ? h.get(0)
                : /parent/.test(h)
                ? g.parent().get(0)
                : h;
          if (!i) return;
          e.containerElement = a(i);
          if (/document/.test(h) || h == document)
            (e.containerOffset = { left: 0, top: 0 }),
              (e.containerPosition = { left: 0, top: 0 }),
              (e.parentData = {
                element: a(document),
                left: 0,
                top: 0,
                width: a(document).width(),
                height:
                  a(document).height() || document.body.parentNode.scrollHeight,
              });
          else {
            var j = a(i),
              k = [];
            a(["Top", "Right", "Left", "Bottom"]).each(function (a, b) {
              k[a] = c(j.css("padding" + b));
            }),
              (e.containerOffset = j.offset()),
              (e.containerPosition = j.position()),
              (e.containerSize = {
                height: j.innerHeight() - k[3],
                width: j.innerWidth() - k[1],
              });
            var l = e.containerOffset,
              m = e.containerSize.height,
              n = e.containerSize.width,
              o = a.ui.hasScroll(i, "left") ? i.scrollWidth : n,
              p = a.ui.hasScroll(i) ? i.scrollHeight : m;
            e.parentData = {
              element: i,
              left: l.left,
              top: l.top,
              width: o,
              height: p,
            };
          }
        },
        resize: function (b, c) {
          var d = a(this).data("resizable"),
            e = d.options,
            f = d.containerSize,
            g = d.containerOffset,
            h = d.size,
            i = d.position,
            j = d._aspectRatio || b.shiftKey,
            k = { top: 0, left: 0 },
            l = d.containerElement;
          l[0] != document && /static/.test(l.css("position")) && (k = g),
            i.left < (d._helper ? g.left : 0) &&
              ((d.size.width =
                d.size.width +
                (d._helper
                  ? d.position.left - g.left
                  : d.position.left - k.left)),
              j && (d.size.height = d.size.width / d.aspectRatio),
              (d.position.left = e.helper ? g.left : 0)),
            i.top < (d._helper ? g.top : 0) &&
              ((d.size.height =
                d.size.height +
                (d._helper ? d.position.top - g.top : d.position.top)),
              j && (d.size.width = d.size.height * d.aspectRatio),
              (d.position.top = d._helper ? g.top : 0)),
            (d.offset.left = d.parentData.left + d.position.left),
            (d.offset.top = d.parentData.top + d.position.top);
          var m = Math.abs(
              (d._helper ? d.offset.left - k.left : d.offset.left - k.left) +
                d.sizeDiff.width
            ),
            n = Math.abs(
              (d._helper ? d.offset.top - k.top : d.offset.top - g.top) +
                d.sizeDiff.height
            ),
            o = d.containerElement.get(0) == d.element.parent().get(0),
            p = /relative|absolute/.test(d.containerElement.css("position"));
          o && p && (m -= d.parentData.left),
            m + d.size.width >= d.parentData.width &&
              ((d.size.width = d.parentData.width - m),
              j && (d.size.height = d.size.width / d.aspectRatio)),
            n + d.size.height >= d.parentData.height &&
              ((d.size.height = d.parentData.height - n),
              j && (d.size.width = d.size.height * d.aspectRatio));
        },
        stop: function (b, c) {
          var d = a(this).data("resizable"),
            e = d.options,
            f = d.position,
            g = d.containerOffset,
            h = d.containerPosition,
            i = d.containerElement,
            j = a(d.helper),
            k = j.offset(),
            l = j.outerWidth() - d.sizeDiff.width,
            m = j.outerHeight() - d.sizeDiff.height;
          d._helper &&
            !e.animate &&
            /relative/.test(i.css("position")) &&
            a(this).css({
              left: k.left - h.left - g.left,
              width: l,
              height: m,
            }),
            d._helper &&
              !e.animate &&
              /static/.test(i.css("position")) &&
              a(this).css({
                left: k.left - h.left - g.left,
                width: l,
                height: m,
              });
        },
      }),
      a.ui.plugin.add("resizable", "ghost", {
        start: function (b, c) {
          var d = a(this).data("resizable"),
            e = d.options,
            f = d.size;
          (d.ghost = d.originalElement.clone()),
            d.ghost
              .css({
                opacity: 0.25,
                display: "block",
                position: "relative",
                height: f.height,
                width: f.width,
                margin: 0,
                left: 0,
                top: 0,
              })
              .addClass("ui-resizable-ghost")
              .addClass(typeof e.ghost == "string" ? e.ghost : ""),
            d.ghost.appendTo(d.helper);
        },
        resize: function (b, c) {
          var d = a(this).data("resizable"),
            e = d.options;
          d.ghost &&
            d.ghost.css({
              position: "relative",
              height: d.size.height,
              width: d.size.width,
            });
        },
        stop: function (b, c) {
          var d = a(this).data("resizable"),
            e = d.options;
          d.ghost && d.helper && d.helper.get(0).removeChild(d.ghost.get(0));
        },
      }),
      a.ui.plugin.add("resizable", "grid", {
        resize: function (b, c) {
          var d = a(this).data("resizable"),
            e = d.options,
            f = d.size,
            g = d.originalSize,
            h = d.originalPosition,
            i = d.axis,
            j = e._aspectRatio || b.shiftKey;
          e.grid = typeof e.grid == "number" ? [e.grid, e.grid] : e.grid;
          var k =
              Math.round((f.width - g.width) / (e.grid[0] || 1)) *
              (e.grid[0] || 1),
            l =
              Math.round((f.height - g.height) / (e.grid[1] || 1)) *
              (e.grid[1] || 1);
          /^(se|s|e)$/.test(i)
            ? ((d.size.width = g.width + k), (d.size.height = g.height + l))
            : /^(ne)$/.test(i)
            ? ((d.size.width = g.width + k),
              (d.size.height = g.height + l),
              (d.position.top = h.top - l))
            : /^(sw)$/.test(i)
            ? ((d.size.width = g.width + k),
              (d.size.height = g.height + l),
              (d.position.left = h.left - k))
            : ((d.size.width = g.width + k),
              (d.size.height = g.height + l),
              (d.position.top = h.top - l),
              (d.position.left = h.left - k));
        },
      });
    var c = function (a) {
        return parseInt(a, 10) || 0;
      },
      d = function (a) {
        return !isNaN(parseInt(a, 10));
      };
  })(jQuery),
  (function (a, b) {
    a.widget("ui.selectable", a.ui.mouse, {
      options: {
        appendTo: "body",
        autoRefresh: !0,
        distance: 0,
        filter: "*",
        tolerance: "touch",
      },
      _create: function () {
        var b = this;
        this.element.addClass("ui-selectable"), (this.dragged = !1);
        var c;
        (this.refresh = function () {
          (c = a(b.options.filter, b.element[0])),
            c.addClass("ui-selectee"),
            c.each(function () {
              var b = a(this),
                c = b.offset();
              a.data(this, "selectable-item", {
                element: this,
                $element: b,
                left: c.left,
                top: c.top,
                right: c.left + b.outerWidth(),
                bottom: c.top + b.outerHeight(),
                startselected: !1,
                selected: b.hasClass("ui-selected"),
                selecting: b.hasClass("ui-selecting"),
                unselecting: b.hasClass("ui-unselecting"),
              });
            });
        }),
          this.refresh(),
          (this.selectees = c.addClass("ui-selectee")),
          this._mouseInit(),
          (this.helper = a("<div class='ui-selectable-helper'></div>"));
      },
      destroy: function () {
        return (
          this.selectees
            .removeClass("ui-selectee")
            .removeData("selectable-item"),
          this.element
            .removeClass("ui-selectable ui-selectable-disabled")
            .removeData("selectable")
            .unbind(".selectable"),
          this._mouseDestroy(),
          this
        );
      },
      _mouseStart: function (b) {
        var c = this;
        this.opos = [b.pageX, b.pageY];
        if (this.options.disabled) return;
        var d = this.options;
        (this.selectees = a(d.filter, this.element[0])),
          this._trigger("start", b),
          a(d.appendTo).append(this.helper),
          this.helper.css({
            left: b.clientX,
            top: b.clientY,
            width: 0,
            height: 0,
          }),
          d.autoRefresh && this.refresh(),
          this.selectees.filter(".ui-selected").each(function () {
            var d = a.data(this, "selectable-item");
            (d.startselected = !0),
              !b.metaKey &&
                !b.ctrlKey &&
                (d.$element.removeClass("ui-selected"),
                (d.selected = !1),
                d.$element.addClass("ui-unselecting"),
                (d.unselecting = !0),
                c._trigger("unselecting", b, { unselecting: d.element }));
          }),
          a(b.target)
            .parents()
            .andSelf()
            .each(function () {
              var d = a.data(this, "selectable-item");
              if (d) {
                var e =
                  (!b.metaKey && !b.ctrlKey) ||
                  !d.$element.hasClass("ui-selected");
                return (
                  d.$element
                    .removeClass(e ? "ui-unselecting" : "ui-selected")
                    .addClass(e ? "ui-selecting" : "ui-unselecting"),
                  (d.unselecting = !e),
                  (d.selecting = e),
                  (d.selected = e),
                  e
                    ? c._trigger("selecting", b, { selecting: d.element })
                    : c._trigger("unselecting", b, { unselecting: d.element }),
                  !1
                );
              }
            });
      },
      _mouseDrag: function (b) {
        var c = this;
        this.dragged = !0;
        if (this.options.disabled) return;
        var d = this.options,
          e = this.opos[0],
          f = this.opos[1],
          g = b.pageX,
          h = b.pageY;
        if (e > g) {
          var i = g;
          (g = e), (e = i);
        }
        if (f > h) {
          var i = h;
          (h = f), (f = i);
        }
        return (
          this.helper.css({ left: e, top: f, width: g - e, height: h - f }),
          this.selectees.each(function () {
            var i = a.data(this, "selectable-item");
            if (!i || i.element == c.element[0]) return;
            var j = !1;
            d.tolerance == "touch"
              ? (j = !(i.left > g || i.right < e || i.top > h || i.bottom < f))
              : d.tolerance == "fit" &&
                (j = i.left > e && i.right < g && i.top > f && i.bottom < h),
              j
                ? (i.selected &&
                    (i.$element.removeClass("ui-selected"), (i.selected = !1)),
                  i.unselecting &&
                    (i.$element.removeClass("ui-unselecting"),
                    (i.unselecting = !1)),
                  i.selecting ||
                    (i.$element.addClass("ui-selecting"),
                    (i.selecting = !0),
                    c._trigger("selecting", b, { selecting: i.element })))
                : (i.selecting &&
                    ((b.metaKey || b.ctrlKey) && i.startselected
                      ? (i.$element.removeClass("ui-selecting"),
                        (i.selecting = !1),
                        i.$element.addClass("ui-selected"),
                        (i.selected = !0))
                      : (i.$element.removeClass("ui-selecting"),
                        (i.selecting = !1),
                        i.startselected &&
                          (i.$element.addClass("ui-unselecting"),
                          (i.unselecting = !0)),
                        c._trigger("unselecting", b, {
                          unselecting: i.element,
                        }))),
                  i.selected &&
                    !b.metaKey &&
                    !b.ctrlKey &&
                    !i.startselected &&
                    (i.$element.removeClass("ui-selected"),
                    (i.selected = !1),
                    i.$element.addClass("ui-unselecting"),
                    (i.unselecting = !0),
                    c._trigger("unselecting", b, { unselecting: i.element })));
          }),
          !1
        );
      },
      _mouseStop: function (b) {
        var c = this;
        this.dragged = !1;
        var d = this.options;
        return (
          a(".ui-unselecting", this.element[0]).each(function () {
            var d = a.data(this, "selectable-item");
            d.$element.removeClass("ui-unselecting"),
              (d.unselecting = !1),
              (d.startselected = !1),
              c._trigger("unselected", b, { unselected: d.element });
          }),
          a(".ui-selecting", this.element[0]).each(function () {
            var d = a.data(this, "selectable-item");
            d.$element.removeClass("ui-selecting").addClass("ui-selected"),
              (d.selecting = !1),
              (d.selected = !0),
              (d.startselected = !0),
              c._trigger("selected", b, { selected: d.element });
          }),
          this._trigger("stop", b),
          this.helper.remove(),
          !1
        );
      },
    }),
      a.extend(a.ui.selectable, { version: "1.8.24" });
  })(jQuery),
  (function (a, b) {
    a.widget("ui.sortable", a.ui.mouse, {
      widgetEventPrefix: "sort",
      ready: !1,
      options: {
        appendTo: "parent",
        axis: !1,
        connectWith: !1,
        containment: !1,
        cursor: "auto",
        cursorAt: !1,
        dropOnEmpty: !0,
        forcePlaceholderSize: !1,
        forceHelperSize: !1,
        grid: !1,
        handle: !1,
        helper: "original",
        items: "> *",
        opacity: !1,
        placeholder: !1,
        revert: !1,
        scroll: !0,
        scrollSensitivity: 20,
        scrollSpeed: 20,
        scope: "default",
        tolerance: "intersect",
        zIndex: 1e3,
      },
      _create: function () {
        var a = this.options;
        (this.containerCache = {}),
          this.element.addClass("ui-sortable"),
          this.refresh(),
          (this.floating = this.items.length
            ? a.axis === "x" ||
              /left|right/.test(this.items[0].item.css("float")) ||
              /inline|table-cell/.test(this.items[0].item.css("display"))
            : !1),
          (this.offset = this.element.offset()),
          this._mouseInit(),
          (this.ready = !0);
      },
      destroy: function () {
        a.Widget.prototype.destroy.call(this),
          this.element.removeClass("ui-sortable ui-sortable-disabled"),
          this._mouseDestroy();
        for (var b = this.items.length - 1; b >= 0; b--)
          this.items[b].item.removeData(this.widgetName + "-item");
        return this;
      },
      _setOption: function (b, c) {
        b === "disabled"
          ? ((this.options[b] = c),
            this.widget()[c ? "addClass" : "removeClass"](
              "ui-sortable-disabled"
            ))
          : a.Widget.prototype._setOption.apply(this, arguments);
      },
      _mouseCapture: function (b, c) {
        var d = this;
        if (this.reverting) return !1;
        if (this.options.disabled || this.options.type == "static") return !1;
        this._refreshItems(b);
        var e = null,
          f = this,
          g = a(b.target)
            .parents()
            .each(function () {
              if (a.data(this, d.widgetName + "-item") == f)
                return (e = a(this)), !1;
            });
        a.data(b.target, d.widgetName + "-item") == f && (e = a(b.target));
        if (!e) return !1;
        if (this.options.handle && !c) {
          var h = !1;
          a(this.options.handle, e)
            .find("*")
            .andSelf()
            .each(function () {
              this == b.target && (h = !0);
            });
          if (!h) return !1;
        }
        return (this.currentItem = e), this._removeCurrentsFromItems(), !0;
      },
      _mouseStart: function (b, c, d) {
        var e = this.options,
          f = this;
        (this.currentContainer = this),
          this.refreshPositions(),
          (this.helper = this._createHelper(b)),
          this._cacheHelperProportions(),
          this._cacheMargins(),
          (this.scrollParent = this.helper.scrollParent()),
          (this.offset = this.currentItem.offset()),
          (this.offset = {
            top: this.offset.top - this.margins.top,
            left: this.offset.left - this.margins.left,
          }),
          a.extend(this.offset, {
            click: {
              left: b.pageX - this.offset.left,
              top: b.pageY - this.offset.top,
            },
            parent: this._getParentOffset(),
            relative: this._getRelativeOffset(),
          }),
          this.helper.css("position", "absolute"),
          (this.cssPosition = this.helper.css("position")),
          (this.originalPosition = this._generatePosition(b)),
          (this.originalPageX = b.pageX),
          (this.originalPageY = b.pageY),
          e.cursorAt && this._adjustOffsetFromHelper(e.cursorAt),
          (this.domPosition = {
            prev: this.currentItem.prev()[0],
            parent: this.currentItem.parent()[0],
          }),
          this.helper[0] != this.currentItem[0] && this.currentItem.hide(),
          this._createPlaceholder(),
          e.containment && this._setContainment(),
          e.cursor &&
            (a("body").css("cursor") &&
              (this._storedCursor = a("body").css("cursor")),
            a("body").css("cursor", e.cursor)),
          e.opacity &&
            (this.helper.css("opacity") &&
              (this._storedOpacity = this.helper.css("opacity")),
            this.helper.css("opacity", e.opacity)),
          e.zIndex &&
            (this.helper.css("zIndex") &&
              (this._storedZIndex = this.helper.css("zIndex")),
            this.helper.css("zIndex", e.zIndex)),
          this.scrollParent[0] != document &&
            this.scrollParent[0].tagName != "HTML" &&
            (this.overflowOffset = this.scrollParent.offset()),
          this._trigger("start", b, this._uiHash()),
          this._preserveHelperProportions || this._cacheHelperProportions();
        if (!d)
          for (var g = this.containers.length - 1; g >= 0; g--)
            this.containers[g]._trigger("activate", b, f._uiHash(this));
        return (
          a.ui.ddmanager && (a.ui.ddmanager.current = this),
          a.ui.ddmanager &&
            !e.dropBehaviour &&
            a.ui.ddmanager.prepareOffsets(this, b),
          (this.dragging = !0),
          this.helper.addClass("ui-sortable-helper"),
          this._mouseDrag(b),
          !0
        );
      },
      _mouseDrag: function (b) {
        (this.position = this._generatePosition(b)),
          (this.positionAbs = this._convertPositionTo("absolute")),
          this.lastPositionAbs || (this.lastPositionAbs = this.positionAbs);
        if (this.options.scroll) {
          var c = this.options,
            d = !1;
          this.scrollParent[0] != document &&
          this.scrollParent[0].tagName != "HTML"
            ? (this.overflowOffset.top +
                this.scrollParent[0].offsetHeight -
                b.pageY <
              c.scrollSensitivity
                ? (this.scrollParent[0].scrollTop = d =
                    this.scrollParent[0].scrollTop + c.scrollSpeed)
                : b.pageY - this.overflowOffset.top < c.scrollSensitivity &&
                  (this.scrollParent[0].scrollTop = d =
                    this.scrollParent[0].scrollTop - c.scrollSpeed),
              this.overflowOffset.left +
                this.scrollParent[0].offsetWidth -
                b.pageX <
              c.scrollSensitivity
                ? (this.scrollParent[0].scrollLeft = d =
                    this.scrollParent[0].scrollLeft + c.scrollSpeed)
                : b.pageX - this.overflowOffset.left < c.scrollSensitivity &&
                  (this.scrollParent[0].scrollLeft = d =
                    this.scrollParent[0].scrollLeft - c.scrollSpeed))
            : (b.pageY - a(document).scrollTop() < c.scrollSensitivity
                ? (d = a(document).scrollTop(
                    a(document).scrollTop() - c.scrollSpeed
                  ))
                : a(window).height() - (b.pageY - a(document).scrollTop()) <
                    c.scrollSensitivity &&
                  (d = a(document).scrollTop(
                    a(document).scrollTop() + c.scrollSpeed
                  )),
              b.pageX - a(document).scrollLeft() < c.scrollSensitivity
                ? (d = a(document).scrollLeft(
                    a(document).scrollLeft() - c.scrollSpeed
                  ))
                : a(window).width() - (b.pageX - a(document).scrollLeft()) <
                    c.scrollSensitivity &&
                  (d = a(document).scrollLeft(
                    a(document).scrollLeft() + c.scrollSpeed
                  ))),
            d !== !1 &&
              a.ui.ddmanager &&
              !c.dropBehaviour &&
              a.ui.ddmanager.prepareOffsets(this, b);
        }
        this.positionAbs = this._convertPositionTo("absolute");
        if (!this.options.axis || this.options.axis != "y")
          this.helper[0].style.left = this.position.left + "px";
        if (!this.options.axis || this.options.axis != "x")
          this.helper[0].style.top = this.position.top + "px";
        for (var e = this.items.length - 1; e >= 0; e--) {
          var f = this.items[e],
            g = f.item[0],
            h = this._intersectsWithPointer(f);
          if (!h) continue;
          if (f.instance !== this.currentContainer) continue;
          if (
            g != this.currentItem[0] &&
            this.placeholder[h == 1 ? "next" : "prev"]()[0] != g &&
            !a.ui.contains(this.placeholder[0], g) &&
            (this.options.type == "semi-dynamic"
              ? !a.ui.contains(this.element[0], g)
              : !0)
          ) {
            this.direction = h == 1 ? "down" : "up";
            if (
              this.options.tolerance == "pointer" ||
              this._intersectsWithSides(f)
            )
              this._rearrange(b, f);
            else break;
            this._trigger("change", b, this._uiHash());
            break;
          }
        }
        return (
          this._contactContainers(b),
          a.ui.ddmanager && a.ui.ddmanager.drag(this, b),
          this._trigger("sort", b, this._uiHash()),
          (this.lastPositionAbs = this.positionAbs),
          !1
        );
      },
      _mouseStop: function (b, c) {
        if (!b) return;
        a.ui.ddmanager &&
          !this.options.dropBehaviour &&
          a.ui.ddmanager.drop(this, b);
        if (this.options.revert) {
          var d = this,
            e = d.placeholder.offset();
          (d.reverting = !0),
            a(this.helper).animate(
              {
                left:
                  e.left -
                  this.offset.parent.left -
                  d.margins.left +
                  (this.offsetParent[0] == document.body
                    ? 0
                    : this.offsetParent[0].scrollLeft),
                top:
                  e.top -
                  this.offset.parent.top -
                  d.margins.top +
                  (this.offsetParent[0] == document.body
                    ? 0
                    : this.offsetParent[0].scrollTop),
              },
              parseInt(this.options.revert, 10) || 500,
              function () {
                d._clear(b);
              }
            );
        } else this._clear(b, c);
        return !1;
      },
      cancel: function () {
        var b = this;
        if (this.dragging) {
          this._mouseUp({ target: null }),
            this.options.helper == "original"
              ? this.currentItem
                  .css(this._storedCSS)
                  .removeClass("ui-sortable-helper")
              : this.currentItem.show();
          for (var c = this.containers.length - 1; c >= 0; c--)
            this.containers[c]._trigger("deactivate", null, b._uiHash(this)),
              this.containers[c].containerCache.over &&
                (this.containers[c]._trigger("out", null, b._uiHash(this)),
                (this.containers[c].containerCache.over = 0));
        }
        return (
          this.placeholder &&
            (this.placeholder[0].parentNode &&
              this.placeholder[0].parentNode.removeChild(this.placeholder[0]),
            this.options.helper != "original" &&
              this.helper &&
              this.helper[0].parentNode &&
              this.helper.remove(),
            a.extend(this, {
              helper: null,
              dragging: !1,
              reverting: !1,
              _noFinalSort: null,
            }),
            this.domPosition.prev
              ? a(this.domPosition.prev).after(this.currentItem)
              : a(this.domPosition.parent).prepend(this.currentItem)),
          this
        );
      },
      serialize: function (b) {
        var c = this._getItemsAsjQuery(b && b.connected),
          d = [];
        return (
          (b = b || {}),
          a(c).each(function () {
            var c = (a(b.item || this).attr(b.attribute || "id") || "").match(
              b.expression || /(.+)[-=_](.+)/
            );
            c &&
              d.push(
                (b.key || c[1] + "[]") +
                  "=" +
                  (b.key && b.expression ? c[1] : c[2])
              );
          }),
          !d.length && b.key && d.push(b.key + "="),
          d.join("&")
        );
      },
      toArray: function (b) {
        var c = this._getItemsAsjQuery(b && b.connected),
          d = [];
        return (
          (b = b || {}),
          c.each(function () {
            d.push(a(b.item || this).attr(b.attribute || "id") || "");
          }),
          d
        );
      },
      _intersectsWith: function (a) {
        var b = this.positionAbs.left,
          c = b + this.helperProportions.width,
          d = this.positionAbs.top,
          e = d + this.helperProportions.height,
          f = a.left,
          g = f + a.width,
          h = a.top,
          i = h + a.height,
          j = this.offset.click.top,
          k = this.offset.click.left,
          l = d + j > h && d + j < i && b + k > f && b + k < g;
        return this.options.tolerance == "pointer" ||
          this.options.forcePointerForContainers ||
          (this.options.tolerance != "pointer" &&
            this.helperProportions[this.floating ? "width" : "height"] >
              a[this.floating ? "width" : "height"])
          ? l
          : f < b + this.helperProportions.width / 2 &&
              c - this.helperProportions.width / 2 < g &&
              h < d + this.helperProportions.height / 2 &&
              e - this.helperProportions.height / 2 < i;
      },
      _intersectsWithPointer: function (b) {
        var c =
            this.options.axis === "x" ||
            a.ui.isOverAxis(
              this.positionAbs.top + this.offset.click.top,
              b.top,
              b.height
            ),
          d =
            this.options.axis === "y" ||
            a.ui.isOverAxis(
              this.positionAbs.left + this.offset.click.left,
              b.left,
              b.width
            ),
          e = c && d,
          f = this._getDragVerticalDirection(),
          g = this._getDragHorizontalDirection();
        return e
          ? this.floating
            ? (g && g == "right") || f == "down"
              ? 2
              : 1
            : f && (f == "down" ? 2 : 1)
          : !1;
      },
      _intersectsWithSides: function (b) {
        var c = a.ui.isOverAxis(
            this.positionAbs.top + this.offset.click.top,
            b.top + b.height / 2,
            b.height
          ),
          d = a.ui.isOverAxis(
            this.positionAbs.left + this.offset.click.left,
            b.left + b.width / 2,
            b.width
          ),
          e = this._getDragVerticalDirection(),
          f = this._getDragHorizontalDirection();
        return this.floating && f
          ? (f == "right" && d) || (f == "left" && !d)
          : e && ((e == "down" && c) || (e == "up" && !c));
      },
      _getDragVerticalDirection: function () {
        var a = this.positionAbs.top - this.lastPositionAbs.top;
        return a != 0 && (a > 0 ? "down" : "up");
      },
      _getDragHorizontalDirection: function () {
        var a = this.positionAbs.left - this.lastPositionAbs.left;
        return a != 0 && (a > 0 ? "right" : "left");
      },
      refresh: function (a) {
        return this._refreshItems(a), this.refreshPositions(), this;
      },
      _connectWith: function () {
        var a = this.options;
        return a.connectWith.constructor == String
          ? [a.connectWith]
          : a.connectWith;
      },
      _getItemsAsjQuery: function (b) {
        var c = this,
          d = [],
          e = [],
          f = this._connectWith();
        if (f && b)
          for (var g = f.length - 1; g >= 0; g--) {
            var h = a(f[g]);
            for (var i = h.length - 1; i >= 0; i--) {
              var j = a.data(h[i], this.widgetName);
              j &&
                j != this &&
                !j.options.disabled &&
                e.push([
                  a.isFunction(j.options.items)
                    ? j.options.items.call(j.element)
                    : a(j.options.items, j.element)
                        .not(".ui-sortable-helper")
                        .not(".ui-sortable-placeholder"),
                  j,
                ]);
            }
          }
        e.push([
          a.isFunction(this.options.items)
            ? this.options.items.call(this.element, null, {
                options: this.options,
                item: this.currentItem,
              })
            : a(this.options.items, this.element)
                .not(".ui-sortable-helper")
                .not(".ui-sortable-placeholder"),
          this,
        ]);
        for (var g = e.length - 1; g >= 0; g--)
          e[g][0].each(function () {
            d.push(this);
          });
        return a(d);
      },
      _removeCurrentsFromItems: function () {
        var a = this.currentItem.find(":data(" + this.widgetName + "-item)");
        for (var b = 0; b < this.items.length; b++)
          for (var c = 0; c < a.length; c++)
            a[c] == this.items[b].item[0] && this.items.splice(b, 1);
      },
      _refreshItems: function (b) {
        (this.items = []), (this.containers = [this]);
        var c = this.items,
          d = this,
          e = [
            [
              a.isFunction(this.options.items)
                ? this.options.items.call(this.element[0], b, {
                    item: this.currentItem,
                  })
                : a(this.options.items, this.element),
              this,
            ],
          ],
          f = this._connectWith();
        if (f && this.ready)
          for (var g = f.length - 1; g >= 0; g--) {
            var h = a(f[g]);
            for (var i = h.length - 1; i >= 0; i--) {
              var j = a.data(h[i], this.widgetName);
              j &&
                j != this &&
                !j.options.disabled &&
                (e.push([
                  a.isFunction(j.options.items)
                    ? j.options.items.call(j.element[0], b, {
                        item: this.currentItem,
                      })
                    : a(j.options.items, j.element),
                  j,
                ]),
                this.containers.push(j));
            }
          }
        for (var g = e.length - 1; g >= 0; g--) {
          var k = e[g][1],
            l = e[g][0];
          for (var i = 0, m = l.length; i < m; i++) {
            var n = a(l[i]);
            n.data(this.widgetName + "-item", k),
              c.push({
                item: n,
                instance: k,
                width: 0,
                height: 0,
                left: 0,
                top: 0,
              });
          }
        }
      },
      refreshPositions: function (b) {
        this.offsetParent &&
          this.helper &&
          (this.offset.parent = this._getParentOffset());
        for (var c = this.items.length - 1; c >= 0; c--) {
          var d = this.items[c];
          if (
            d.instance != this.currentContainer &&
            this.currentContainer &&
            d.item[0] != this.currentItem[0]
          )
            continue;
          var e = this.options.toleranceElement
            ? a(this.options.toleranceElement, d.item)
            : d.item;
          b || ((d.width = e.outerWidth()), (d.height = e.outerHeight()));
          var f = e.offset();
          (d.left = f.left), (d.top = f.top);
        }
        if (this.options.custom && this.options.custom.refreshContainers)
          this.options.custom.refreshContainers.call(this);
        else
          for (var c = this.containers.length - 1; c >= 0; c--) {
            var f = this.containers[c].element.offset();
            (this.containers[c].containerCache.left = f.left),
              (this.containers[c].containerCache.top = f.top),
              (this.containers[c].containerCache.width =
                this.containers[c].element.outerWidth()),
              (this.containers[c].containerCache.height =
                this.containers[c].element.outerHeight());
          }
        return this;
      },
      _createPlaceholder: function (b) {
        var c = b || this,
          d = c.options;
        if (!d.placeholder || d.placeholder.constructor == String) {
          var e = d.placeholder;
          d.placeholder = {
            element: function () {
              var b = a(document.createElement(c.currentItem[0].nodeName))
                .addClass(
                  e || c.currentItem[0].className + " ui-sortable-placeholder"
                )
                .removeClass("ui-sortable-helper")[0];
              return e || (b.style.visibility = "hidden"), b;
            },
            update: function (a, b) {
              if (e && !d.forcePlaceholderSize) return;
              b.height() ||
                b.height(
                  c.currentItem.innerHeight() -
                    parseInt(c.currentItem.css("paddingTop") || 0, 10) -
                    parseInt(c.currentItem.css("paddingBottom") || 0, 10)
                ),
                b.width() ||
                  b.width(
                    c.currentItem.innerWidth() -
                      parseInt(c.currentItem.css("paddingLeft") || 0, 10) -
                      parseInt(c.currentItem.css("paddingRight") || 0, 10)
                  );
            },
          };
        }
        (c.placeholder = a(
          d.placeholder.element.call(c.element, c.currentItem)
        )),
          c.currentItem.after(c.placeholder),
          d.placeholder.update(c, c.placeholder);
      },
      _contactContainers: function (b) {
        var c = null,
          d = null;
        for (var e = this.containers.length - 1; e >= 0; e--) {
          if (a.ui.contains(this.currentItem[0], this.containers[e].element[0]))
            continue;
          if (this._intersectsWith(this.containers[e].containerCache)) {
            if (c && a.ui.contains(this.containers[e].element[0], c.element[0]))
              continue;
            (c = this.containers[e]), (d = e);
          } else
            this.containers[e].containerCache.over &&
              (this.containers[e]._trigger("out", b, this._uiHash(this)),
              (this.containers[e].containerCache.over = 0));
        }
        if (!c) return;
        if (this.containers.length === 1)
          this.containers[d]._trigger("over", b, this._uiHash(this)),
            (this.containers[d].containerCache.over = 1);
        else if (this.currentContainer != this.containers[d]) {
          var f = 1e4,
            g = null,
            h = this.positionAbs[this.containers[d].floating ? "left" : "top"];
          for (var i = this.items.length - 1; i >= 0; i--) {
            if (
              !a.ui.contains(
                this.containers[d].element[0],
                this.items[i].item[0]
              )
            )
              continue;
            var j = this.containers[d].floating
              ? this.items[i].item.offset().left
              : this.items[i].item.offset().top;
            Math.abs(j - h) < f &&
              ((f = Math.abs(j - h)),
              (g = this.items[i]),
              (this.direction = j - h > 0 ? "down" : "up"));
          }
          if (!g && !this.options.dropOnEmpty) return;
          (this.currentContainer = this.containers[d]),
            g
              ? this._rearrange(b, g, null, !0)
              : this._rearrange(b, null, this.containers[d].element, !0),
            this._trigger("change", b, this._uiHash()),
            this.containers[d]._trigger("change", b, this._uiHash(this)),
            this.options.placeholder.update(
              this.currentContainer,
              this.placeholder
            ),
            this.containers[d]._trigger("over", b, this._uiHash(this)),
            (this.containers[d].containerCache.over = 1);
        }
      },
      _createHelper: function (b) {
        var c = this.options,
          d = a.isFunction(c.helper)
            ? a(c.helper.apply(this.element[0], [b, this.currentItem]))
            : c.helper == "clone"
            ? this.currentItem.clone()
            : this.currentItem;
        return (
          d.parents("body").length ||
            a(
              c.appendTo != "parent"
                ? c.appendTo
                : this.currentItem[0].parentNode
            )[0].appendChild(d[0]),
          d[0] == this.currentItem[0] &&
            (this._storedCSS = {
              width: this.currentItem[0].style.width,
              height: this.currentItem[0].style.height,
              position: this.currentItem.css("position"),
              top: this.currentItem.css("top"),
              left: this.currentItem.css("left"),
            }),
          (d[0].style.width == "" || c.forceHelperSize) &&
            d.width(this.currentItem.width()),
          (d[0].style.height == "" || c.forceHelperSize) &&
            d.height(this.currentItem.height()),
          d
        );
      },
      _adjustOffsetFromHelper: function (b) {
        typeof b == "string" && (b = b.split(" ")),
          a.isArray(b) && (b = { left: +b[0], top: +b[1] || 0 }),
          "left" in b && (this.offset.click.left = b.left + this.margins.left),
          "right" in b &&
            (this.offset.click.left =
              this.helperProportions.width - b.right + this.margins.left),
          "top" in b && (this.offset.click.top = b.top + this.margins.top),
          "bottom" in b &&
            (this.offset.click.top =
              this.helperProportions.height - b.bottom + this.margins.top);
      },
      _getParentOffset: function () {
        this.offsetParent = this.helper.offsetParent();
        var b = this.offsetParent.offset();
        this.cssPosition == "absolute" &&
          this.scrollParent[0] != document &&
          a.ui.contains(this.scrollParent[0], this.offsetParent[0]) &&
          ((b.left += this.scrollParent.scrollLeft()),
          (b.top += this.scrollParent.scrollTop()));
        if (
          this.offsetParent[0] == document.body ||
          (this.offsetParent[0].tagName &&
            this.offsetParent[0].tagName.toLowerCase() == "html" &&
            a.browser.msie)
        )
          b = { top: 0, left: 0 };
        return {
          top:
            b.top +
            (parseInt(this.offsetParent.css("borderTopWidth"), 10) || 0),
          left:
            b.left +
            (parseInt(this.offsetParent.css("borderLeftWidth"), 10) || 0),
        };
      },
      _getRelativeOffset: function () {
        if (this.cssPosition == "relative") {
          var a = this.currentItem.position();
          return {
            top:
              a.top -
              (parseInt(this.helper.css("top"), 10) || 0) +
              this.scrollParent.scrollTop(),
            left:
              a.left -
              (parseInt(this.helper.css("left"), 10) || 0) +
              this.scrollParent.scrollLeft(),
          };
        }
        return { top: 0, left: 0 };
      },
      _cacheMargins: function () {
        this.margins = {
          left: parseInt(this.currentItem.css("marginLeft"), 10) || 0,
          top: parseInt(this.currentItem.css("marginTop"), 10) || 0,
        };
      },
      _cacheHelperProportions: function () {
        this.helperProportions = {
          width: this.helper.outerWidth(),
          height: this.helper.outerHeight(),
        };
      },
      _setContainment: function () {
        var b = this.options;
        b.containment == "parent" &&
          (b.containment = this.helper[0].parentNode);
        if (b.containment == "document" || b.containment == "window")
          this.containment = [
            0 - this.offset.relative.left - this.offset.parent.left,
            0 - this.offset.relative.top - this.offset.parent.top,
            a(b.containment == "document" ? document : window).width() -
              this.helperProportions.width -
              this.margins.left,
            (a(b.containment == "document" ? document : window).height() ||
              document.body.parentNode.scrollHeight) -
              this.helperProportions.height -
              this.margins.top,
          ];
        if (!/^(document|window|parent)$/.test(b.containment)) {
          var c = a(b.containment)[0],
            d = a(b.containment).offset(),
            e = a(c).css("overflow") != "hidden";
          this.containment = [
            d.left +
              (parseInt(a(c).css("borderLeftWidth"), 10) || 0) +
              (parseInt(a(c).css("paddingLeft"), 10) || 0) -
              this.margins.left,
            d.top +
              (parseInt(a(c).css("borderTopWidth"), 10) || 0) +
              (parseInt(a(c).css("paddingTop"), 10) || 0) -
              this.margins.top,
            d.left +
              (e ? Math.max(c.scrollWidth, c.offsetWidth) : c.offsetWidth) -
              (parseInt(a(c).css("borderLeftWidth"), 10) || 0) -
              (parseInt(a(c).css("paddingRight"), 10) || 0) -
              this.helperProportions.width -
              this.margins.left,
            d.top +
              (e ? Math.max(c.scrollHeight, c.offsetHeight) : c.offsetHeight) -
              (parseInt(a(c).css("borderTopWidth"), 10) || 0) -
              (parseInt(a(c).css("paddingBottom"), 10) || 0) -
              this.helperProportions.height -
              this.margins.top,
          ];
        }
      },
      _convertPositionTo: function (b, c) {
        c || (c = this.position);
        var d = b == "absolute" ? 1 : -1,
          e = this.options,
          f =
            this.cssPosition == "absolute" &&
            (this.scrollParent[0] == document ||
              !a.ui.contains(this.scrollParent[0], this.offsetParent[0]))
              ? this.offsetParent
              : this.scrollParent,
          g = /(html|body)/i.test(f[0].tagName);
        return {
          top:
            c.top +
            this.offset.relative.top * d +
            this.offset.parent.top * d -
            (a.browser.safari && this.cssPosition == "fixed"
              ? 0
              : (this.cssPosition == "fixed"
                  ? -this.scrollParent.scrollTop()
                  : g
                  ? 0
                  : f.scrollTop()) * d),
          left:
            c.left +
            this.offset.relative.left * d +
            this.offset.parent.left * d -
            (a.browser.safari && this.cssPosition == "fixed"
              ? 0
              : (this.cssPosition == "fixed"
                  ? -this.scrollParent.scrollLeft()
                  : g
                  ? 0
                  : f.scrollLeft()) * d),
        };
      },
      _generatePosition: function (b) {
        var c = this.options,
          d =
            this.cssPosition == "absolute" &&
            (this.scrollParent[0] == document ||
              !a.ui.contains(this.scrollParent[0], this.offsetParent[0]))
              ? this.offsetParent
              : this.scrollParent,
          e = /(html|body)/i.test(d[0].tagName);
        this.cssPosition == "relative" &&
          (this.scrollParent[0] == document ||
            this.scrollParent[0] == this.offsetParent[0]) &&
          (this.offset.relative = this._getRelativeOffset());
        var f = b.pageX,
          g = b.pageY;
        if (this.originalPosition) {
          this.containment &&
            (b.pageX - this.offset.click.left < this.containment[0] &&
              (f = this.containment[0] + this.offset.click.left),
            b.pageY - this.offset.click.top < this.containment[1] &&
              (g = this.containment[1] + this.offset.click.top),
            b.pageX - this.offset.click.left > this.containment[2] &&
              (f = this.containment[2] + this.offset.click.left),
            b.pageY - this.offset.click.top > this.containment[3] &&
              (g = this.containment[3] + this.offset.click.top));
          if (c.grid) {
            var h =
              this.originalPageY +
              Math.round((g - this.originalPageY) / c.grid[1]) * c.grid[1];
            g = this.containment
              ? h - this.offset.click.top < this.containment[1] ||
                h - this.offset.click.top > this.containment[3]
                ? h - this.offset.click.top < this.containment[1]
                  ? h + c.grid[1]
                  : h - c.grid[1]
                : h
              : h;
            var i =
              this.originalPageX +
              Math.round((f - this.originalPageX) / c.grid[0]) * c.grid[0];
            f = this.containment
              ? i - this.offset.click.left < this.containment[0] ||
                i - this.offset.click.left > this.containment[2]
                ? i - this.offset.click.left < this.containment[0]
                  ? i + c.grid[0]
                  : i - c.grid[0]
                : i
              : i;
          }
        }
        return {
          top:
            g -
            this.offset.click.top -
            this.offset.relative.top -
            this.offset.parent.top +
            (a.browser.safari && this.cssPosition == "fixed"
              ? 0
              : this.cssPosition == "fixed"
              ? -this.scrollParent.scrollTop()
              : e
              ? 0
              : d.scrollTop()),
          left:
            f -
            this.offset.click.left -
            this.offset.relative.left -
            this.offset.parent.left +
            (a.browser.safari && this.cssPosition == "fixed"
              ? 0
              : this.cssPosition == "fixed"
              ? -this.scrollParent.scrollLeft()
              : e
              ? 0
              : d.scrollLeft()),
        };
      },
      _rearrange: function (a, b, c, d) {
        c
          ? c[0].appendChild(this.placeholder[0])
          : b.item[0].parentNode.insertBefore(
              this.placeholder[0],
              this.direction == "down" ? b.item[0] : b.item[0].nextSibling
            ),
          (this.counter = this.counter ? ++this.counter : 1);
        var e = this,
          f = this.counter;
        window.setTimeout(function () {
          f == e.counter && e.refreshPositions(!d);
        }, 0);
      },
      _clear: function (b, c) {
        this.reverting = !1;
        var d = [],
          e = this;
        !this._noFinalSort &&
          this.currentItem.parent().length &&
          this.placeholder.before(this.currentItem),
          (this._noFinalSort = null);
        if (this.helper[0] == this.currentItem[0]) {
          for (var f in this._storedCSS)
            if (this._storedCSS[f] == "auto" || this._storedCSS[f] == "static")
              this._storedCSS[f] = "";
          this.currentItem
            .css(this._storedCSS)
            .removeClass("ui-sortable-helper");
        } else this.currentItem.show();
        this.fromOutside &&
          !c &&
          d.push(function (a) {
            this._trigger("receive", a, this._uiHash(this.fromOutside));
          }),
          (this.fromOutside ||
            this.domPosition.prev !=
              this.currentItem.prev().not(".ui-sortable-helper")[0] ||
            this.domPosition.parent != this.currentItem.parent()[0]) &&
            !c &&
            d.push(function (a) {
              this._trigger("update", a, this._uiHash());
            }),
          this !== this.currentContainer &&
            (c ||
              (d.push(function (a) {
                this._trigger("remove", a, this._uiHash());
              }),
              d.push(
                function (a) {
                  return function (b) {
                    a._trigger("receive", b, this._uiHash(this));
                  };
                }.call(this, this.currentContainer)
              ),
              d.push(
                function (a) {
                  return function (b) {
                    a._trigger("update", b, this._uiHash(this));
                  };
                }.call(this, this.currentContainer)
              )));
        for (var f = this.containers.length - 1; f >= 0; f--)
          c ||
            d.push(
              function (a) {
                return function (b) {
                  a._trigger("deactivate", b, this._uiHash(this));
                };
              }.call(this, this.containers[f])
            ),
            this.containers[f].containerCache.over &&
              (d.push(
                function (a) {
                  return function (b) {
                    a._trigger("out", b, this._uiHash(this));
                  };
                }.call(this, this.containers[f])
              ),
              (this.containers[f].containerCache.over = 0));
        this._storedCursor && a("body").css("cursor", this._storedCursor),
          this._storedOpacity &&
            this.helper.css("opacity", this._storedOpacity),
          this._storedZIndex &&
            this.helper.css(
              "zIndex",
              this._storedZIndex == "auto" ? "" : this._storedZIndex
            ),
          (this.dragging = !1);
        if (this.cancelHelperRemoval) {
          if (!c) {
            this._trigger("beforeStop", b, this._uiHash());
            for (var f = 0; f < d.length; f++) d[f].call(this, b);
            this._trigger("stop", b, this._uiHash());
          }
          return (this.fromOutside = !1), !1;
        }
        c || this._trigger("beforeStop", b, this._uiHash()),
          this.placeholder[0].parentNode.removeChild(this.placeholder[0]),
          this.helper[0] != this.currentItem[0] && this.helper.remove(),
          (this.helper = null);
        if (!c) {
          for (var f = 0; f < d.length; f++) d[f].call(this, b);
          this._trigger("stop", b, this._uiHash());
        }
        return (this.fromOutside = !1), !0;
      },
      _trigger: function () {
        a.Widget.prototype._trigger.apply(this, arguments) === !1 &&
          this.cancel();
      },
      _uiHash: function (b) {
        var c = b || this;
        return {
          helper: c.helper,
          placeholder: c.placeholder || a([]),
          position: c.position,
          originalPosition: c.originalPosition,
          offset: c.positionAbs,
          item: c.currentItem,
          sender: b ? b.element : null,
        };
      },
    }),
      a.extend(a.ui.sortable, { version: "1.8.24" });
  })(jQuery),
  jQuery.effects ||
    (function (a, b) {
      function c(b) {
        var c;
        return b && b.constructor == Array && b.length == 3
          ? b
          : (c =
              /rgb\(\s*([0-9]{1,3})\s*,\s*([0-9]{1,3})\s*,\s*([0-9]{1,3})\s*\)/.exec(
                b
              ))
          ? [parseInt(c[1], 10), parseInt(c[2], 10), parseInt(c[3], 10)]
          : (c =
              /rgb\(\s*([0-9]+(?:\.[0-9]+)?)\%\s*,\s*([0-9]+(?:\.[0-9]+)?)\%\s*,\s*([0-9]+(?:\.[0-9]+)?)\%\s*\)/.exec(
                b
              ))
          ? [
              parseFloat(c[1]) * 2.55,
              parseFloat(c[2]) * 2.55,
              parseFloat(c[3]) * 2.55,
            ]
          : (c = /#([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})/.exec(b))
          ? [parseInt(c[1], 16), parseInt(c[2], 16), parseInt(c[3], 16)]
          : (c = /#([a-fA-F0-9])([a-fA-F0-9])([a-fA-F0-9])/.exec(b))
          ? [
              parseInt(c[1] + c[1], 16),
              parseInt(c[2] + c[2], 16),
              parseInt(c[3] + c[3], 16),
            ]
          : (c = /rgba\(0, 0, 0, 0\)/.exec(b))
          ? e.transparent
          : e[a.trim(b).toLowerCase()];
      }
      function d(b, d) {
        var e;
        do {
          e = (a.curCSS || a.css)(b, d);
          if ((e != "" && e != "transparent") || a.nodeName(b, "body")) break;
          d = "backgroundColor";
        } while ((b = b.parentNode));
        return c(e);
      }
      function h() {
        var a = document.defaultView
            ? document.defaultView.getComputedStyle(this, null)
            : this.currentStyle,
          b = {},
          c,
          d;
        if (a && a.length && a[0] && a[a[0]]) {
          var e = a.length;
          while (e--)
            (c = a[e]),
              typeof a[c] == "string" &&
                ((d = c.replace(/\-(\w)/g, function (a, b) {
                  return b.toUpperCase();
                })),
                (b[d] = a[c]));
        } else for (c in a) typeof a[c] == "string" && (b[c] = a[c]);
        return b;
      }
      function i(b) {
        var c, d;
        for (c in b)
          (d = b[c]),
            (d == null ||
              a.isFunction(d) ||
              c in g ||
              /scrollbar/.test(c) ||
              (!/color/i.test(c) && isNaN(parseFloat(d)))) &&
              delete b[c];
        return b;
      }
      function j(a, b) {
        var c = { _: 0 },
          d;
        for (d in b) a[d] != b[d] && (c[d] = b[d]);
        return c;
      }
      function k(b, c, d, e) {
        typeof b == "object" && ((e = c), (d = null), (c = b), (b = c.effect)),
          a.isFunction(c) && ((e = c), (d = null), (c = {}));
        if (typeof c == "number" || a.fx.speeds[c]) (e = d), (d = c), (c = {});
        return (
          a.isFunction(d) && ((e = d), (d = null)),
          (c = c || {}),
          (d = d || c.duration),
          (d = a.fx.off
            ? 0
            : typeof d == "number"
            ? d
            : d in a.fx.speeds
            ? a.fx.speeds[d]
            : a.fx.speeds._default),
          (e = e || c.complete),
          [b, c, d, e]
        );
      }
      function l(b) {
        return !b || typeof b == "number" || a.fx.speeds[b]
          ? !0
          : typeof b == "string" && !a.effects[b]
          ? !0
          : !1;
      }
      (a.effects = {}),
        a.each(
          [
            "backgroundColor",
            "borderBottomColor",
            "borderLeftColor",
            "borderRightColor",
            "borderTopColor",
            "borderColor",
            "color",
            "outlineColor",
          ],
          function (b, e) {
            a.fx.step[e] = function (a) {
              a.colorInit ||
                ((a.start = d(a.elem, e)),
                (a.end = c(a.end)),
                (a.colorInit = !0)),
                (a.elem.style[e] =
                  "rgb(" +
                  Math.max(
                    Math.min(
                      parseInt(
                        a.pos * (a.end[0] - a.start[0]) + a.start[0],
                        10
                      ),
                      255
                    ),
                    0
                  ) +
                  "," +
                  Math.max(
                    Math.min(
                      parseInt(
                        a.pos * (a.end[1] - a.start[1]) + a.start[1],
                        10
                      ),
                      255
                    ),
                    0
                  ) +
                  "," +
                  Math.max(
                    Math.min(
                      parseInt(
                        a.pos * (a.end[2] - a.start[2]) + a.start[2],
                        10
                      ),
                      255
                    ),
                    0
                  ) +
                  ")");
            };
          }
        );
      var e = {
          aqua: [0, 255, 255],
          azure: [240, 255, 255],
          beige: [245, 245, 220],
          black: [0, 0, 0],
          blue: [0, 0, 255],
          brown: [165, 42, 42],
          cyan: [0, 255, 255],
          darkblue: [0, 0, 139],
          darkcyan: [0, 139, 139],
          darkgrey: [169, 169, 169],
          darkgreen: [0, 100, 0],
          darkkhaki: [189, 183, 107],
          darkmagenta: [139, 0, 139],
          darkolivegreen: [85, 107, 47],
          darkorange: [255, 140, 0],
          darkorchid: [153, 50, 204],
          darkred: [139, 0, 0],
          darksalmon: [233, 150, 122],
          darkviolet: [148, 0, 211],
          fuchsia: [255, 0, 255],
          gold: [255, 215, 0],
          green: [0, 128, 0],
          indigo: [75, 0, 130],
          khaki: [240, 230, 140],
          lightblue: [173, 216, 230],
          lightcyan: [224, 255, 255],
          lightgreen: [144, 238, 144],
          lightgrey: [211, 211, 211],
          lightpink: [255, 182, 193],
          lightyellow: [255, 255, 224],
          lime: [0, 255, 0],
          magenta: [255, 0, 255],
          maroon: [128, 0, 0],
          navy: [0, 0, 128],
          olive: [128, 128, 0],
          orange: [255, 165, 0],
          pink: [255, 192, 203],
          purple: [128, 0, 128],
          violet: [128, 0, 128],
          red: [255, 0, 0],
          silver: [192, 192, 192],
          white: [255, 255, 255],
          yellow: [255, 255, 0],
          transparent: [255, 255, 255],
        },
        f = ["add", "remove", "toggle"],
        g = {
          border: 1,
          borderBottom: 1,
          borderColor: 1,
          borderLeft: 1,
          borderRight: 1,
          borderTop: 1,
          borderWidth: 1,
          margin: 1,
          padding: 1,
        };
      (a.effects.animateClass = function (b, c, d, e) {
        return (
          a.isFunction(d) && ((e = d), (d = null)),
          this.queue(function () {
            var g = a(this),
              k = g.attr("style") || " ",
              l = i(h.call(this)),
              m,
              n = g.attr("class") || "";
            a.each(f, function (a, c) {
              b[c] && g[c + "Class"](b[c]);
            }),
              (m = i(h.call(this))),
              g.attr("class", n),
              g.animate(j(l, m), {
                queue: !1,
                duration: c,
                easing: d,
                complete: function () {
                  a.each(f, function (a, c) {
                    b[c] && g[c + "Class"](b[c]);
                  }),
                    typeof g.attr("style") == "object"
                      ? ((g.attr("style").cssText = ""),
                        (g.attr("style").cssText = k))
                      : g.attr("style", k),
                    e && e.apply(this, arguments),
                    a.dequeue(this);
                },
              });
          })
        );
      }),
        a.fn.extend({
          _addClass: a.fn.addClass,
          addClass: function (b, c, d, e) {
            return c
              ? a.effects.animateClass.apply(this, [{ add: b }, c, d, e])
              : this._addClass(b);
          },
          _removeClass: a.fn.removeClass,
          removeClass: function (b, c, d, e) {
            return c
              ? a.effects.animateClass.apply(this, [{ remove: b }, c, d, e])
              : this._removeClass(b);
          },
          _toggleClass: a.fn.toggleClass,
          toggleClass: function (c, d, e, f, g) {
            return typeof d == "boolean" || d === b
              ? e
                ? a.effects.animateClass.apply(this, [
                    d ? { add: c } : { remove: c },
                    e,
                    f,
                    g,
                  ])
                : this._toggleClass(c, d)
              : a.effects.animateClass.apply(this, [{ toggle: c }, d, e, f]);
          },
          switchClass: function (b, c, d, e, f) {
            return a.effects.animateClass.apply(this, [
              { add: c, remove: b },
              d,
              e,
              f,
            ]);
          },
        }),
        a.extend(a.effects, {
          version: "1.8.24",
          save: function (a, b) {
            for (var c = 0; c < b.length; c++)
              b[c] !== null && a.data("ec.storage." + b[c], a[0].style[b[c]]);
          },
          restore: function (a, b) {
            for (var c = 0; c < b.length; c++)
              b[c] !== null && a.css(b[c], a.data("ec.storage." + b[c]));
          },
          setMode: function (a, b) {
            return b == "toggle" && (b = a.is(":hidden") ? "show" : "hide"), b;
          },
          getBaseline: function (a, b) {
            var c, d;
            switch (a[0]) {
              case "top":
                c = 0;
                break;
              case "middle":
                c = 0.5;
                break;
              case "bottom":
                c = 1;
                break;
              default:
                c = a[0] / b.height;
            }
            switch (a[1]) {
              case "left":
                d = 0;
                break;
              case "center":
                d = 0.5;
                break;
              case "right":
                d = 1;
                break;
              default:
                d = a[1] / b.width;
            }
            return { x: d, y: c };
          },
          createWrapper: function (b) {
            if (b.parent().is(".ui-effects-wrapper")) return b.parent();
            var c = {
                width: b.outerWidth(!0),
                height: b.outerHeight(!0),
                float: b.css("float"),
              },
              d = a("<div></div>")
                .addClass("ui-effects-wrapper")
                .css({
                  fontSize: "100%",
                  background: "transparent",
                  border: "none",
                  margin: 0,
                  padding: 0,
                }),
              e = document.activeElement;
            try {
              e.id;
            } catch (f) {
              e = document.body;
            }
            return (
              b.wrap(d),
              (b[0] === e || a.contains(b[0], e)) && a(e).focus(),
              (d = b.parent()),
              b.css("position") == "static"
                ? (d.css({ position: "relative" }),
                  b.css({ position: "relative" }))
                : (a.extend(c, {
                    position: b.css("position"),
                    zIndex: b.css("z-index"),
                  }),
                  a.each(["top", "left", "bottom", "right"], function (a, d) {
                    (c[d] = b.css(d)),
                      isNaN(parseInt(c[d], 10)) && (c[d] = "auto");
                  }),
                  b.css({
                    position: "relative",
                    top: 0,
                    left: 0,
                    right: "auto",
                    bottom: "auto",
                  })),
              d.css(c).show()
            );
          },
          removeWrapper: function (b) {
            var c,
              d = document.activeElement;
            return b.parent().is(".ui-effects-wrapper")
              ? ((c = b.parent().replaceWith(b)),
                (b[0] === d || a.contains(b[0], d)) && a(d).focus(),
                c)
              : b;
          },
          setTransition: function (b, c, d, e) {
            return (
              (e = e || {}),
              a.each(c, function (a, c) {
                var f = b.cssUnit(c);
                f[0] > 0 && (e[c] = f[0] * d + f[1]);
              }),
              e
            );
          },
        }),
        a.fn.extend({
          effect: function (b, c, d, e) {
            var f = k.apply(this, arguments),
              g = { options: f[1], duration: f[2], callback: f[3] },
              h = g.options.mode,
              i = a.effects[b];
            return a.fx.off || !i
              ? h
                ? this[h](g.duration, g.callback)
                : this.each(function () {
                    g.callback && g.callback.call(this);
                  })
              : i.call(this, g);
          },
          _show: a.fn.show,
          show: function (a) {
            if (l(a)) return this._show.apply(this, arguments);
            var b = k.apply(this, arguments);
            return (b[1].mode = "show"), this.effect.apply(this, b);
          },
          _hide: a.fn.hide,
          hide: function (a) {
            if (l(a)) return this._hide.apply(this, arguments);
            var b = k.apply(this, arguments);
            return (b[1].mode = "hide"), this.effect.apply(this, b);
          },
          __toggle: a.fn.toggle,
          toggle: function (b) {
            if (l(b) || typeof b == "boolean" || a.isFunction(b))
              return this.__toggle.apply(this, arguments);
            var c = k.apply(this, arguments);
            return (c[1].mode = "toggle"), this.effect.apply(this, c);
          },
          cssUnit: function (b) {
            var c = this.css(b),
              d = [];
            return (
              a.each(["em", "px", "%", "pt"], function (a, b) {
                c.indexOf(b) > 0 && (d = [parseFloat(c), b]);
              }),
              d
            );
          },
        });
      var m = {};
      a.each(["Quad", "Cubic", "Quart", "Quint", "Expo"], function (a, b) {
        m[b] = function (b) {
          return Math.pow(b, a + 2);
        };
      }),
        a.extend(m, {
          Sine: function (a) {
            return 1 - Math.cos((a * Math.PI) / 2);
          },
          Circ: function (a) {
            return 1 - Math.sqrt(1 - a * a);
          },
          Elastic: function (a) {
            return a === 0 || a === 1
              ? a
              : -Math.pow(2, 8 * (a - 1)) *
                  Math.sin((((a - 1) * 80 - 7.5) * Math.PI) / 15);
          },
          Back: function (a) {
            return a * a * (3 * a - 2);
          },
          Bounce: function (a) {
            var b,
              c = 4;
            while (a < ((b = Math.pow(2, --c)) - 1) / 11);
            return (
              1 / Math.pow(4, 3 - c) -
              7.5625 * Math.pow((b * 3 - 2) / 22 - a, 2)
            );
          },
        }),
        a.each(m, function (b, c) {
          (a.easing["easeIn" + b] = c),
            (a.easing["easeOut" + b] = function (a) {
              return 1 - c(1 - a);
            }),
            (a.easing["easeInOut" + b] = function (a) {
              return a < 0.5 ? c(a * 2) / 2 : c(a * -2 + 2) / -2 + 1;
            });
        });
    })(jQuery),
  (function (a, b) {
    a.effects.blind = function (b) {
      return this.queue(function () {
        var c = a(this),
          d = ["position", "top", "bottom", "left", "right"],
          e = a.effects.setMode(c, b.options.mode || "hide"),
          f = b.options.direction || "vertical";
        a.effects.save(c, d), c.show();
        var g = a.effects.createWrapper(c).css({ overflow: "hidden" }),
          h = f == "vertical" ? "height" : "width",
          i = f == "vertical" ? g.height() : g.width();
        e == "show" && g.css(h, 0);
        var j = {};
        (j[h] = e == "show" ? i : 0),
          g.animate(j, b.duration, b.options.easing, function () {
            e == "hide" && c.hide(),
              a.effects.restore(c, d),
              a.effects.removeWrapper(c),
              b.callback && b.callback.apply(c[0], arguments),
              c.dequeue();
          });
      });
    };
  })(jQuery),
  (function (a, b) {
    a.effects.bounce = function (b) {
      return this.queue(function () {
        var c = a(this),
          d = ["position", "top", "bottom", "left", "right"],
          e = a.effects.setMode(c, b.options.mode || "effect"),
          f = b.options.direction || "up",
          g = b.options.distance || 20,
          h = b.options.times || 5,
          i = b.duration || 250;
        /show|hide/.test(e) && d.push("opacity"),
          a.effects.save(c, d),
          c.show(),
          a.effects.createWrapper(c);
        var j = f == "up" || f == "down" ? "top" : "left",
          k = f == "up" || f == "left" ? "pos" : "neg",
          g =
            b.options.distance ||
            (j == "top" ? c.outerHeight(!0) / 3 : c.outerWidth(!0) / 3);
        e == "show" && c.css("opacity", 0).css(j, k == "pos" ? -g : g),
          e == "hide" && (g = g / (h * 2)),
          e != "hide" && h--;
        if (e == "show") {
          var l = { opacity: 1 };
          (l[j] = (k == "pos" ? "+=" : "-=") + g),
            c.animate(l, i / 2, b.options.easing),
            (g = g / 2),
            h--;
        }
        for (var m = 0; m < h; m++) {
          var n = {},
            p = {};
          (n[j] = (k == "pos" ? "-=" : "+=") + g),
            (p[j] = (k == "pos" ? "+=" : "-=") + g),
            c
              .animate(n, i / 2, b.options.easing)
              .animate(p, i / 2, b.options.easing),
            (g = e == "hide" ? g * 2 : g / 2);
        }
        if (e == "hide") {
          var l = { opacity: 0 };
          (l[j] = (k == "pos" ? "-=" : "+=") + g),
            c.animate(l, i / 2, b.options.easing, function () {
              c.hide(),
                a.effects.restore(c, d),
                a.effects.removeWrapper(c),
                b.callback && b.callback.apply(this, arguments);
            });
        } else {
          var n = {},
            p = {};
          (n[j] = (k == "pos" ? "-=" : "+=") + g),
            (p[j] = (k == "pos" ? "+=" : "-=") + g),
            c
              .animate(n, i / 2, b.options.easing)
              .animate(p, i / 2, b.options.easing, function () {
                a.effects.restore(c, d),
                  a.effects.removeWrapper(c),
                  b.callback && b.callback.apply(this, arguments);
              });
        }
        c.queue("fx", function () {
          c.dequeue();
        }),
          c.dequeue();
      });
    };
  })(jQuery),
  (function (a, b) {
    a.effects.clip = function (b) {
      return this.queue(function () {
        var c = a(this),
          d = ["position", "top", "bottom", "left", "right", "height", "width"],
          e = a.effects.setMode(c, b.options.mode || "hide"),
          f = b.options.direction || "vertical";
        a.effects.save(c, d), c.show();
        var g = a.effects.createWrapper(c).css({ overflow: "hidden" }),
          h = c[0].tagName == "IMG" ? g : c,
          i = {
            size: f == "vertical" ? "height" : "width",
            position: f == "vertical" ? "top" : "left",
          },
          j = f == "vertical" ? h.height() : h.width();
        e == "show" && (h.css(i.size, 0), h.css(i.position, j / 2));
        var k = {};
        (k[i.size] = e == "show" ? j : 0),
          (k[i.position] = e == "show" ? 0 : j / 2),
          h.animate(k, {
            queue: !1,
            duration: b.duration,
            easing: b.options.easing,
            complete: function () {
              e == "hide" && c.hide(),
                a.effects.restore(c, d),
                a.effects.removeWrapper(c),
                b.callback && b.callback.apply(c[0], arguments),
                c.dequeue();
            },
          });
      });
    };
  })(jQuery),
  (function (a, b) {
    a.effects.drop = function (b) {
      return this.queue(function () {
        var c = a(this),
          d = ["position", "top", "bottom", "left", "right", "opacity"],
          e = a.effects.setMode(c, b.options.mode || "hide"),
          f = b.options.direction || "left";
        a.effects.save(c, d), c.show(), a.effects.createWrapper(c);
        var g = f == "up" || f == "down" ? "top" : "left",
          h = f == "up" || f == "left" ? "pos" : "neg",
          i =
            b.options.distance ||
            (g == "top" ? c.outerHeight(!0) / 2 : c.outerWidth(!0) / 2);
        e == "show" && c.css("opacity", 0).css(g, h == "pos" ? -i : i);
        var j = { opacity: e == "show" ? 1 : 0 };
        (j[g] =
          (e == "show"
            ? h == "pos"
              ? "+="
              : "-="
            : h == "pos"
            ? "-="
            : "+=") + i),
          c.animate(j, {
            queue: !1,
            duration: b.duration,
            easing: b.options.easing,
            complete: function () {
              e == "hide" && c.hide(),
                a.effects.restore(c, d),
                a.effects.removeWrapper(c),
                b.callback && b.callback.apply(this, arguments),
                c.dequeue();
            },
          });
      });
    };
  })(jQuery),
  (function (a, b) {
    a.effects.explode = function (b) {
      return this.queue(function () {
        var c = b.options.pieces ? Math.round(Math.sqrt(b.options.pieces)) : 3,
          d = b.options.pieces ? Math.round(Math.sqrt(b.options.pieces)) : 3;
        b.options.mode =
          b.options.mode == "toggle"
            ? a(this).is(":visible")
              ? "hide"
              : "show"
            : b.options.mode;
        var e = a(this).show().css("visibility", "hidden"),
          f = e.offset();
        (f.top -= parseInt(e.css("marginTop"), 10) || 0),
          (f.left -= parseInt(e.css("marginLeft"), 10) || 0);
        var g = e.outerWidth(!0),
          h = e.outerHeight(!0);
        for (var i = 0; i < c; i++)
          for (var j = 0; j < d; j++)
            e.clone()
              .appendTo("body")
              .wrap("<div></div>")
              .css({
                position: "absolute",
                visibility: "visible",
                left: -j * (g / d),
                top: -i * (h / c),
              })
              .parent()
              .addClass("ui-effects-explode")
              .css({
                position: "absolute",
                overflow: "hidden",
                width: g / d,
                height: h / c,
                left:
                  f.left +
                  j * (g / d) +
                  (b.options.mode == "show"
                    ? (j - Math.floor(d / 2)) * (g / d)
                    : 0),
                top:
                  f.top +
                  i * (h / c) +
                  (b.options.mode == "show"
                    ? (i - Math.floor(c / 2)) * (h / c)
                    : 0),
                opacity: b.options.mode == "show" ? 0 : 1,
              })
              .animate(
                {
                  left:
                    f.left +
                    j * (g / d) +
                    (b.options.mode == "show"
                      ? 0
                      : (j - Math.floor(d / 2)) * (g / d)),
                  top:
                    f.top +
                    i * (h / c) +
                    (b.options.mode == "show"
                      ? 0
                      : (i - Math.floor(c / 2)) * (h / c)),
                  opacity: b.options.mode == "show" ? 1 : 0,
                },
                b.duration || 500
              );
        setTimeout(function () {
          b.options.mode == "show"
            ? e.css({ visibility: "visible" })
            : e.css({ visibility: "visible" }).hide(),
            b.callback && b.callback.apply(e[0]),
            e.dequeue(),
            a("div.ui-effects-explode").remove();
        }, b.duration || 500);
      });
    };
  })(jQuery),
  (function (a, b) {
    a.effects.fade = function (b) {
      return this.queue(function () {
        var c = a(this),
          d = a.effects.setMode(c, b.options.mode || "hide");
        c.animate(
          { opacity: d },
          {
            queue: !1,
            duration: b.duration,
            easing: b.options.easing,
            complete: function () {
              b.callback && b.callback.apply(this, arguments), c.dequeue();
            },
          }
        );
      });
    };
  })(jQuery),
  (function (a, b) {
    a.effects.fold = function (b) {
      return this.queue(function () {
        var c = a(this),
          d = ["position", "top", "bottom", "left", "right"],
          e = a.effects.setMode(c, b.options.mode || "hide"),
          f = b.options.size || 15,
          g = !!b.options.horizFirst,
          h = b.duration ? b.duration / 2 : a.fx.speeds._default / 2;
        a.effects.save(c, d), c.show();
        var i = a.effects.createWrapper(c).css({ overflow: "hidden" }),
          j = (e == "show") != g,
          k = j ? ["width", "height"] : ["height", "width"],
          l = j ? [i.width(), i.height()] : [i.height(), i.width()],
          m = /([0-9]+)%/.exec(f);
        m && (f = (parseInt(m[1], 10) / 100) * l[e == "hide" ? 0 : 1]),
          e == "show" &&
            i.css(g ? { height: 0, width: f } : { height: f, width: 0 });
        var n = {},
          p = {};
        (n[k[0]] = e == "show" ? l[0] : f),
          (p[k[1]] = e == "show" ? l[1] : 0),
          i
            .animate(n, h, b.options.easing)
            .animate(p, h, b.options.easing, function () {
              e == "hide" && c.hide(),
                a.effects.restore(c, d),
                a.effects.removeWrapper(c),
                b.callback && b.callback.apply(c[0], arguments),
                c.dequeue();
            });
      });
    };
  })(jQuery),
  (function (a, b) {
    a.effects.highlight = function (b) {
      return this.queue(function () {
        var c = a(this),
          d = ["backgroundImage", "backgroundColor", "opacity"],
          e = a.effects.setMode(c, b.options.mode || "show"),
          f = { backgroundColor: c.css("backgroundColor") };
        e == "hide" && (f.opacity = 0),
          a.effects.save(c, d),
          c
            .show()
            .css({
              backgroundImage: "none",
              backgroundColor: b.options.color || "#ffff99",
            })
            .animate(f, {
              queue: !1,
              duration: b.duration,
              easing: b.options.easing,
              complete: function () {
                e == "hide" && c.hide(),
                  a.effects.restore(c, d),
                  e == "show" &&
                    !a.support.opacity &&
                    this.style.removeAttribute("filter"),
                  b.callback && b.callback.apply(this, arguments),
                  c.dequeue();
              },
            });
      });
    };
  })(jQuery),
  (function (a, b) {
    a.effects.pulsate = function (b) {
      return this.queue(function () {
        var c = a(this),
          d = a.effects.setMode(c, b.options.mode || "show"),
          e = (b.options.times || 5) * 2 - 1,
          f = b.duration ? b.duration / 2 : a.fx.speeds._default / 2,
          g = c.is(":visible"),
          h = 0;
        g || (c.css("opacity", 0).show(), (h = 1)),
          ((d == "hide" && g) || (d == "show" && !g)) && e--;
        for (var i = 0; i < e; i++)
          c.animate({ opacity: h }, f, b.options.easing), (h = (h + 1) % 2);
        c.animate({ opacity: h }, f, b.options.easing, function () {
          h == 0 && c.hide(), b.callback && b.callback.apply(this, arguments);
        }),
          c
            .queue("fx", function () {
              c.dequeue();
            })
            .dequeue();
      });
    };
  })(jQuery),
  (function (a, b) {
    (a.effects.puff = function (b) {
      return this.queue(function () {
        var c = a(this),
          d = a.effects.setMode(c, b.options.mode || "hide"),
          e = parseInt(b.options.percent, 10) || 150,
          f = e / 100,
          g = { height: c.height(), width: c.width() };
        a.extend(b.options, {
          fade: !0,
          mode: d,
          percent: d == "hide" ? e : 100,
          from: d == "hide" ? g : { height: g.height * f, width: g.width * f },
        }),
          c.effect("scale", b.options, b.duration, b.callback),
          c.dequeue();
      });
    }),
      (a.effects.scale = function (b) {
        return this.queue(function () {
          var c = a(this),
            d = a.extend(!0, {}, b.options),
            e = a.effects.setMode(c, b.options.mode || "effect"),
            f =
              parseInt(b.options.percent, 10) ||
              (parseInt(b.options.percent, 10) == 0
                ? 0
                : e == "hide"
                ? 0
                : 100),
            g = b.options.direction || "both",
            h = b.options.origin;
          e != "effect" &&
            ((d.origin = h || ["middle", "center"]), (d.restore = !0));
          var i = { height: c.height(), width: c.width() };
          c.from =
            b.options.from || (e == "show" ? { height: 0, width: 0 } : i);
          var j = {
            y: g != "horizontal" ? f / 100 : 1,
            x: g != "vertical" ? f / 100 : 1,
          };
          (c.to = { height: i.height * j.y, width: i.width * j.x }),
            b.options.fade &&
              (e == "show" && ((c.from.opacity = 0), (c.to.opacity = 1)),
              e == "hide" && ((c.from.opacity = 1), (c.to.opacity = 0))),
            (d.from = c.from),
            (d.to = c.to),
            (d.mode = e),
            c.effect("size", d, b.duration, b.callback),
            c.dequeue();
        });
      }),
      (a.effects.size = function (b) {
        return this.queue(function () {
          var c = a(this),
            d = [
              "position",
              "top",
              "bottom",
              "left",
              "right",
              "width",
              "height",
              "overflow",
              "opacity",
            ],
            e = [
              "position",
              "top",
              "bottom",
              "left",
              "right",
              "overflow",
              "opacity",
            ],
            f = ["width", "height", "overflow"],
            g = ["fontSize"],
            h = [
              "borderTopWidth",
              "borderBottomWidth",
              "paddingTop",
              "paddingBottom",
            ],
            i = [
              "borderLeftWidth",
              "borderRightWidth",
              "paddingLeft",
              "paddingRight",
            ],
            j = a.effects.setMode(c, b.options.mode || "effect"),
            k = b.options.restore || !1,
            l = b.options.scale || "both",
            m = b.options.origin,
            n = { height: c.height(), width: c.width() };
          (c.from = b.options.from || n), (c.to = b.options.to || n);
          if (m) {
            var p = a.effects.getBaseline(m, n);
            (c.from.top = (n.height - c.from.height) * p.y),
              (c.from.left = (n.width - c.from.width) * p.x),
              (c.to.top = (n.height - c.to.height) * p.y),
              (c.to.left = (n.width - c.to.width) * p.x);
          }
          var q = {
            from: { y: c.from.height / n.height, x: c.from.width / n.width },
            to: { y: c.to.height / n.height, x: c.to.width / n.width },
          };
          if (l == "box" || l == "both")
            q.from.y != q.to.y &&
              ((d = d.concat(h)),
              (c.from = a.effects.setTransition(c, h, q.from.y, c.from)),
              (c.to = a.effects.setTransition(c, h, q.to.y, c.to))),
              q.from.x != q.to.x &&
                ((d = d.concat(i)),
                (c.from = a.effects.setTransition(c, i, q.from.x, c.from)),
                (c.to = a.effects.setTransition(c, i, q.to.x, c.to)));
          (l == "content" || l == "both") &&
            q.from.y != q.to.y &&
            ((d = d.concat(g)),
            (c.from = a.effects.setTransition(c, g, q.from.y, c.from)),
            (c.to = a.effects.setTransition(c, g, q.to.y, c.to))),
            a.effects.save(c, k ? d : e),
            c.show(),
            a.effects.createWrapper(c),
            c.css("overflow", "hidden").css(c.from);
          if (l == "content" || l == "both")
            (h = h.concat(["marginTop", "marginBottom"]).concat(g)),
              (i = i.concat(["marginLeft", "marginRight"])),
              (f = d.concat(h).concat(i)),
              c.find("*[width]").each(function () {
                var c = a(this);
                k && a.effects.save(c, f);
                var d = { height: c.height(), width: c.width() };
                (c.from = {
                  height: d.height * q.from.y,
                  width: d.width * q.from.x,
                }),
                  (c.to = {
                    height: d.height * q.to.y,
                    width: d.width * q.to.x,
                  }),
                  q.from.y != q.to.y &&
                    ((c.from = a.effects.setTransition(c, h, q.from.y, c.from)),
                    (c.to = a.effects.setTransition(c, h, q.to.y, c.to))),
                  q.from.x != q.to.x &&
                    ((c.from = a.effects.setTransition(c, i, q.from.x, c.from)),
                    (c.to = a.effects.setTransition(c, i, q.to.x, c.to))),
                  c.css(c.from),
                  c.animate(c.to, b.duration, b.options.easing, function () {
                    k && a.effects.restore(c, f);
                  });
              });
          c.animate(c.to, {
            queue: !1,
            duration: b.duration,
            easing: b.options.easing,
            complete: function () {
              c.to.opacity === 0 && c.css("opacity", c.from.opacity),
                j == "hide" && c.hide(),
                a.effects.restore(c, k ? d : e),
                a.effects.removeWrapper(c),
                b.callback && b.callback.apply(this, arguments),
                c.dequeue();
            },
          });
        });
      });
  })(jQuery),
  (function (a, b) {
    a.effects.shake = function (b) {
      return this.queue(function () {
        var c = a(this),
          d = ["position", "top", "bottom", "left", "right"],
          e = a.effects.setMode(c, b.options.mode || "effect"),
          f = b.options.direction || "left",
          g = b.options.distance || 20,
          h = b.options.times || 3,
          i = b.duration || b.options.duration || 140;
        a.effects.save(c, d), c.show(), a.effects.createWrapper(c);
        var j = f == "up" || f == "down" ? "top" : "left",
          k = f == "up" || f == "left" ? "pos" : "neg",
          l = {},
          m = {},
          n = {};
        (l[j] = (k == "pos" ? "-=" : "+=") + g),
          (m[j] = (k == "pos" ? "+=" : "-=") + g * 2),
          (n[j] = (k == "pos" ? "-=" : "+=") + g * 2),
          c.animate(l, i, b.options.easing);
        for (var p = 1; p < h; p++)
          c.animate(m, i, b.options.easing).animate(n, i, b.options.easing);
        c
          .animate(m, i, b.options.easing)
          .animate(l, i / 2, b.options.easing, function () {
            a.effects.restore(c, d),
              a.effects.removeWrapper(c),
              b.callback && b.callback.apply(this, arguments);
          }),
          c.queue("fx", function () {
            c.dequeue();
          }),
          c.dequeue();
      });
    };
  })(jQuery),
  (function (a, b) {
    a.effects.slide = function (b) {
      return this.queue(function () {
        var c = a(this),
          d = ["position", "top", "bottom", "left", "right"],
          e = a.effects.setMode(c, b.options.mode || "show"),
          f = b.options.direction || "left";
        a.effects.save(c, d),
          c.show(),
          a.effects.createWrapper(c).css({ overflow: "hidden" });
        var g = f == "up" || f == "down" ? "top" : "left",
          h = f == "up" || f == "left" ? "pos" : "neg",
          i =
            b.options.distance ||
            (g == "top" ? c.outerHeight(!0) : c.outerWidth(!0));
        e == "show" && c.css(g, h == "pos" ? (isNaN(i) ? "-" + i : -i) : i);
        var j = {};
        (j[g] =
          (e == "show"
            ? h == "pos"
              ? "+="
              : "-="
            : h == "pos"
            ? "-="
            : "+=") + i),
          c.animate(j, {
            queue: !1,
            duration: b.duration,
            easing: b.options.easing,
            complete: function () {
              e == "hide" && c.hide(),
                a.effects.restore(c, d),
                a.effects.removeWrapper(c),
                b.callback && b.callback.apply(this, arguments),
                c.dequeue();
            },
          });
      });
    };
  })(jQuery),
  (function (a, b) {
    a.effects.transfer = function (b) {
      return this.queue(function () {
        var c = a(this),
          d = a(b.options.to),
          e = d.offset(),
          f = {
            top: e.top,
            left: e.left,
            height: d.innerHeight(),
            width: d.innerWidth(),
          },
          g = c.offset(),
          h = a('<div class="ui-effects-transfer"></div>')
            .appendTo(document.body)
            .addClass(b.options.className)
            .css({
              top: g.top,
              left: g.left,
              height: c.innerHeight(),
              width: c.innerWidth(),
              position: "absolute",
            })
            .animate(f, b.duration, b.options.easing, function () {
              h.remove(),
                b.callback && b.callback.apply(c[0], arguments),
                c.dequeue();
            });
      });
    };
  })(jQuery),
  (function (a, b) {
    a.widget("ui.accordion", {
      options: {
        active: 0,
        animated: "slide",
        clearStyle: !1,
        collapsible: !1,
        event: "click",
        fillSpace: !1,
        header: "> li > :first-child,> :not(li):even",
        icons: {
          header: "ui-icon-triangle-1-e",
          headerSelected: "ui-icon-triangle-1-s",
        },
        navigation: !1,
        navigationFilter: function () {
          return this.href.toLowerCase() === location.href.toLowerCase();
        },
      },
      _create: function () {
        var b = this,
          c = b.options;
        (b.running = 0),
          b.element
            .addClass("ui-accordion ui-widget ui-helper-reset")
            .children("li")
            .addClass("ui-accordion-li-fix"),
          (b.headers = b.element
            .find(c.header)
            .addClass(
              "ui-accordion-header ui-helper-reset ui-state-default ui-corner-all"
            )
            .bind("mouseenter.accordion", function () {
              if (c.disabled) return;
              a(this).addClass("ui-state-hover");
            })
            .bind("mouseleave.accordion", function () {
              if (c.disabled) return;
              a(this).removeClass("ui-state-hover");
            })
            .bind("focus.accordion", function () {
              if (c.disabled) return;
              a(this).addClass("ui-state-focus");
            })
            .bind("blur.accordion", function () {
              if (c.disabled) return;
              a(this).removeClass("ui-state-focus");
            })),
          b.headers
            .next()
            .addClass(
              "ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom"
            );
        if (c.navigation) {
          var d = b.element.find("a").filter(c.navigationFilter).eq(0);
          if (d.length) {
            var e = d.closest(".ui-accordion-header");
            e.length
              ? (b.active = e)
              : (b.active = d.closest(".ui-accordion-content").prev());
          }
        }
        (b.active = b
          ._findActive(b.active || c.active)
          .addClass("ui-state-default ui-state-active")
          .toggleClass("ui-corner-all")
          .toggleClass("ui-corner-top")),
          b.active.next().addClass("ui-accordion-content-active"),
          b._createIcons(),
          b.resize(),
          b.element.attr("role", "tablist"),
          b.headers
            .attr("role", "tab")
            .bind("keydown.accordion", function (a) {
              return b._keydown(a);
            })
            .next()
            .attr("role", "tabpanel"),
          b.headers
            .not(b.active || "")
            .attr({
              "aria-expanded": "false",
              "aria-selected": "false",
              tabIndex: -1,
            })
            .next()
            .hide(),
          b.active.length
            ? b.active.attr({
                "aria-expanded": "true",
                "aria-selected": "true",
                tabIndex: 0,
              })
            : b.headers.eq(0).attr("tabIndex", 0),
          a.browser.safari || b.headers.find("a").attr("tabIndex", -1),
          c.event &&
            b.headers.bind(
              c.event.split(" ").join(".accordion ") + ".accordion",
              function (a) {
                b._clickHandler.call(b, a, this), a.preventDefault();
              }
            );
      },
      _createIcons: function () {
        var b = this.options;
        b.icons &&
          (a("<span></span>")
            .addClass("ui-icon " + b.icons.header)
            .prependTo(this.headers),
          this.active
            .children(".ui-icon")
            .toggleClass(b.icons.header)
            .toggleClass(b.icons.headerSelected),
          this.element.addClass("ui-accordion-icons"));
      },
      _destroyIcons: function () {
        this.headers.children(".ui-icon").remove(),
          this.element.removeClass("ui-accordion-icons");
      },
      destroy: function () {
        var b = this.options;
        this.element
          .removeClass("ui-accordion ui-widget ui-helper-reset")
          .removeAttr("role"),
          this.headers
            .unbind(".accordion")
            .removeClass(
              "ui-accordion-header ui-accordion-disabled ui-helper-reset ui-state-default ui-corner-all ui-state-active ui-state-disabled ui-corner-top"
            )
            .removeAttr("role")
            .removeAttr("aria-expanded")
            .removeAttr("aria-selected")
            .removeAttr("tabIndex"),
          this.headers.find("a").removeAttr("tabIndex"),
          this._destroyIcons();
        var c = this.headers
          .next()
          .css("display", "")
          .removeAttr("role")
          .removeClass(
            "ui-helper-reset ui-widget-content ui-corner-bottom ui-accordion-content ui-accordion-content-active ui-accordion-disabled ui-state-disabled"
          );
        return (
          (b.autoHeight || b.fillHeight) && c.css("height", ""),
          a.Widget.prototype.destroy.call(this)
        );
      },
      _setOption: function (b, c) {
        a.Widget.prototype._setOption.apply(this, arguments),
          b == "active" && this.activate(c),
          b == "icons" && (this._destroyIcons(), c && this._createIcons()),
          b == "disabled" &&
            this.headers
              .add(this.headers.next())
              [c ? "addClass" : "removeClass"](
                "ui-accordion-disabled ui-state-disabled"
              );
      },
      _keydown: function (b) {
        if (this.options.disabled || b.altKey || b.ctrlKey) return;
        var c = a.ui.keyCode,
          d = this.headers.length,
          e = this.headers.index(b.target),
          f = !1;
        switch (b.keyCode) {
          case c.RIGHT:
          case c.DOWN:
            f = this.headers[(e + 1) % d];
            break;
          case c.LEFT:
          case c.UP:
            f = this.headers[(e - 1 + d) % d];
            break;
          case c.SPACE:
          case c.ENTER:
            this._clickHandler({ target: b.target }, b.target),
              b.preventDefault();
        }
        return f
          ? (a(b.target).attr("tabIndex", -1),
            a(f).attr("tabIndex", 0),
            f.focus(),
            !1)
          : !0;
      },
      resize: function () {
        var b = this.options,
          c;
        if (b.fillSpace) {
          if (a.browser.msie) {
            var d = this.element.parent().css("overflow");
            this.element.parent().css("overflow", "hidden");
          }
          (c = this.element.parent().height()),
            a.browser.msie && this.element.parent().css("overflow", d),
            this.headers.each(function () {
              c -= a(this).outerHeight(!0);
            }),
            this.headers
              .next()
              .each(function () {
                a(this).height(
                  Math.max(0, c - a(this).innerHeight() + a(this).height())
                );
              })
              .css("overflow", "auto");
        } else
          b.autoHeight &&
            ((c = 0),
            this.headers
              .next()
              .each(function () {
                c = Math.max(c, a(this).height("").height());
              })
              .height(c));
        return this;
      },
      activate: function (a) {
        this.options.active = a;
        var b = this._findActive(a)[0];
        return this._clickHandler({ target: b }, b), this;
      },
      _findActive: function (b) {
        return b
          ? typeof b == "number"
            ? this.headers.filter(":eq(" + b + ")")
            : this.headers.not(this.headers.not(b))
          : b === !1
          ? a([])
          : this.headers.filter(":eq(0)");
      },
      _clickHandler: function (b, c) {
        var d = this.options;
        if (d.disabled) return;
        if (!b.target) {
          if (!d.collapsible) return;
          this.active
            .removeClass("ui-state-active ui-corner-top")
            .addClass("ui-state-default ui-corner-all")
            .children(".ui-icon")
            .removeClass(d.icons.headerSelected)
            .addClass(d.icons.header),
            this.active.next().addClass("ui-accordion-content-active");
          var e = this.active.next(),
            f = {
              options: d,
              newHeader: a([]),
              oldHeader: d.active,
              newContent: a([]),
              oldContent: e,
            },
            g = (this.active = a([]));
          this._toggle(g, e, f);
          return;
        }
        var h = a(b.currentTarget || c),
          i = h[0] === this.active[0];
        d.active = d.collapsible && i ? !1 : this.headers.index(h);
        if (this.running || (!d.collapsible && i)) return;
        var j = this.active,
          g = h.next(),
          e = this.active.next(),
          f = {
            options: d,
            newHeader: i && d.collapsible ? a([]) : h,
            oldHeader: this.active,
            newContent: i && d.collapsible ? a([]) : g,
            oldContent: e,
          },
          k = this.headers.index(this.active[0]) > this.headers.index(h[0]);
        (this.active = i ? a([]) : h),
          this._toggle(g, e, f, i, k),
          j
            .removeClass("ui-state-active ui-corner-top")
            .addClass("ui-state-default ui-corner-all")
            .children(".ui-icon")
            .removeClass(d.icons.headerSelected)
            .addClass(d.icons.header),
          i ||
            (h
              .removeClass("ui-state-default ui-corner-all")
              .addClass("ui-state-active ui-corner-top")
              .children(".ui-icon")
              .removeClass(d.icons.header)
              .addClass(d.icons.headerSelected),
            h.next().addClass("ui-accordion-content-active"));
        return;
      },
      _toggle: function (b, c, d, e, f) {
        var g = this,
          h = g.options;
        (g.toShow = b), (g.toHide = c), (g.data = d);
        var i = function () {
          if (!g) return;
          return g._completed.apply(g, arguments);
        };
        g._trigger("changestart", null, g.data),
          (g.running = c.size() === 0 ? b.size() : c.size());
        if (h.animated) {
          var j = {};
          h.collapsible && e
            ? (j = {
                toShow: a([]),
                toHide: c,
                complete: i,
                down: f,
                autoHeight: h.autoHeight || h.fillSpace,
              })
            : (j = {
                toShow: b,
                toHide: c,
                complete: i,
                down: f,
                autoHeight: h.autoHeight || h.fillSpace,
              }),
            h.proxied || (h.proxied = h.animated),
            h.proxiedDuration || (h.proxiedDuration = h.duration),
            (h.animated = a.isFunction(h.proxied) ? h.proxied(j) : h.proxied),
            (h.duration = a.isFunction(h.proxiedDuration)
              ? h.proxiedDuration(j)
              : h.proxiedDuration);
          var k = a.ui.accordion.animations,
            l = h.duration,
            m = h.animated;
          m && !k[m] && !a.easing[m] && (m = "slide"),
            k[m] ||
              (k[m] = function (a) {
                this.slide(a, { easing: m, duration: l || 700 });
              }),
            k[m](j);
        } else h.collapsible && e ? b.toggle() : (c.hide(), b.show()), i(!0);
        c
          .prev()
          .attr({
            "aria-expanded": "false",
            "aria-selected": "false",
            tabIndex: -1,
          })
          .blur(),
          b
            .prev()
            .attr({
              "aria-expanded": "true",
              "aria-selected": "true",
              tabIndex: 0,
            })
            .focus();
      },
      _completed: function (a) {
        this.running = a ? 0 : --this.running;
        if (this.running) return;
        this.options.clearStyle &&
          this.toShow.add(this.toHide).css({ height: "", overflow: "" }),
          this.toHide.removeClass("ui-accordion-content-active"),
          this.toHide.length &&
            (this.toHide.parent()[0].className =
              this.toHide.parent()[0].className),
          this._trigger("change", null, this.data);
      },
    }),
      a.extend(a.ui.accordion, {
        version: "1.8.24",
        animations: {
          slide: function (b, c) {
            b = a.extend({ easing: "swing", duration: 300 }, b, c);
            if (!b.toHide.size()) {
              b.toShow.animate(
                { height: "show", paddingTop: "show", paddingBottom: "show" },
                b
              );
              return;
            }
            if (!b.toShow.size()) {
              b.toHide.animate(
                { height: "hide", paddingTop: "hide", paddingBottom: "hide" },
                b
              );
              return;
            }
            var d = b.toShow.css("overflow"),
              e = 0,
              f = {},
              g = {},
              h = ["height", "paddingTop", "paddingBottom"],
              i,
              j = b.toShow;
            (i = j[0].style.width),
              j.width(
                j.parent().width() -
                  parseFloat(j.css("paddingLeft")) -
                  parseFloat(j.css("paddingRight")) -
                  (parseFloat(j.css("borderLeftWidth")) || 0) -
                  (parseFloat(j.css("borderRightWidth")) || 0)
              ),
              a.each(h, function (c, d) {
                g[d] = "hide";
                var e = ("" + a.css(b.toShow[0], d)).match(/^([\d+-.]+)(.*)$/);
                f[d] = { value: e[1], unit: e[2] || "px" };
              }),
              b.toShow.css({ height: 0, overflow: "hidden" }).show(),
              b.toHide
                .filter(":hidden")
                .each(b.complete)
                .end()
                .filter(":visible")
                .animate(g, {
                  step: function (a, c) {
                    c.prop == "height" &&
                      (e =
                        c.end - c.start === 0
                          ? 0
                          : (c.now - c.start) / (c.end - c.start)),
                      (b.toShow[0].style[c.prop] =
                        e * f[c.prop].value + f[c.prop].unit);
                  },
                  duration: b.duration,
                  easing: b.easing,
                  complete: function () {
                    b.autoHeight || b.toShow.css("height", ""),
                      b.toShow.css({ width: i, overflow: d }),
                      b.complete();
                  },
                });
          },
          bounceslide: function (a) {
            this.slide(a, {
              easing: a.down ? "easeOutBounce" : "swing",
              duration: a.down ? 1e3 : 200,
            });
          },
        },
      });
  })(jQuery),
  (function (a, b) {
    var c = 0;
    a.widget("ui.autocomplete", {
      options: {
        appendTo: "body",
        autoFocus: !1,
        delay: 300,
        minLength: 1,
        position: { my: "left top", at: "left bottom", collision: "none" },
        source: null,
      },
      pending: 0,
      _create: function () {
        var b = this,
          c = this.element[0].ownerDocument,
          d;
        (this.isMultiLine = this.element.is("textarea")),
          this.element
            .addClass("ui-autocomplete-input")
            .attr("autocomplete", "off")
            .attr({
              role: "textbox",
              "aria-autocomplete": "list",
              "aria-haspopup": "true",
            })
            .bind("keydown.autocomplete", function (c) {
              if (b.options.disabled || b.element.propAttr("readOnly")) return;
              d = !1;
              var e = a.ui.keyCode;
              switch (c.keyCode) {
                case e.PAGE_UP:
                  b._move("previousPage", c);
                  break;
                case e.PAGE_DOWN:
                  b._move("nextPage", c);
                  break;
                case e.UP:
                  b._keyEvent("previous", c);
                  break;
                case e.DOWN:
                  b._keyEvent("next", c);
                  break;
                case e.ENTER:
                case e.NUMPAD_ENTER:
                  b.menu.active && ((d = !0), c.preventDefault());
                case e.TAB:
                  if (!b.menu.active) return;
                  b.menu.select(c);
                  break;
                case e.ESCAPE:
                  b.element.val(b.term), b.close(c);
                  break;
                default:
                  clearTimeout(b.searching),
                    (b.searching = setTimeout(function () {
                      b.term != b.element.val() &&
                        ((b.selectedItem = null), b.search(null, c));
                    }, b.options.delay));
              }
            })
            .bind("keypress.autocomplete", function (a) {
              d && ((d = !1), a.preventDefault());
            })
            .bind("focus.autocomplete", function () {
              if (b.options.disabled) return;
              (b.selectedItem = null), (b.previous = b.element.val());
            })
            .bind("blur.autocomplete", function (a) {
              if (b.options.disabled) return;
              clearTimeout(b.searching),
                (b.closing = setTimeout(function () {
                  b.close(a), b._change(a);
                }, 150));
            }),
          this._initSource(),
          (this.menu = a("<ul></ul>")
            .addClass("ui-autocomplete")
            .appendTo(a(this.options.appendTo || "body", c)[0])
            .mousedown(function (c) {
              var d = b.menu.element[0];
              a(c.target).closest(".ui-menu-item").length ||
                setTimeout(function () {
                  a(document).one("mousedown", function (c) {
                    c.target !== b.element[0] &&
                      c.target !== d &&
                      !a.ui.contains(d, c.target) &&
                      b.close();
                  });
                }, 1),
                setTimeout(function () {
                  clearTimeout(b.closing);
                }, 13);
            })
            .menu({
              focus: function (a, c) {
                var d = c.item.data("item.autocomplete");
                !1 !== b._trigger("focus", a, { item: d }) &&
                  /^key/.test(a.originalEvent.type) &&
                  b.element.val(d.value);
              },
              selected: function (a, d) {
                var e = d.item.data("item.autocomplete"),
                  f = b.previous;
                b.element[0] !== c.activeElement &&
                  (b.element.focus(),
                  (b.previous = f),
                  setTimeout(function () {
                    (b.previous = f), (b.selectedItem = e);
                  }, 1)),
                  !1 !== b._trigger("select", a, { item: e }) &&
                    b.element.val(e.value),
                  (b.term = b.element.val()),
                  b.close(a),
                  (b.selectedItem = e);
              },
              blur: function (a, c) {
                b.menu.element.is(":visible") &&
                  b.element.val() !== b.term &&
                  b.element.val(b.term);
              },
            })
            .zIndex(this.element.zIndex() + 1)
            .css({ top: 0, left: 0 })
            .hide()
            .data("menu")),
          a.fn.bgiframe && this.menu.element.bgiframe(),
          (b.beforeunloadHandler = function () {
            b.element.removeAttr("autocomplete");
          }),
          a(window).bind("beforeunload", b.beforeunloadHandler);
      },
      destroy: function () {
        this.element
          .removeClass("ui-autocomplete-input")
          .removeAttr("autocomplete")
          .removeAttr("role")
          .removeAttr("aria-autocomplete")
          .removeAttr("aria-haspopup"),
          this.menu.element.remove(),
          a(window).unbind("beforeunload", this.beforeunloadHandler),
          a.Widget.prototype.destroy.call(this);
      },
      _setOption: function (b, c) {
        a.Widget.prototype._setOption.apply(this, arguments),
          b === "source" && this._initSource(),
          b === "appendTo" &&
            this.menu.element.appendTo(
              a(c || "body", this.element[0].ownerDocument)[0]
            ),
          b === "disabled" && c && this.xhr && this.xhr.abort();
      },
      _initSource: function () {
        var b = this,
          c,
          d;
        a.isArray(this.options.source)
          ? ((c = this.options.source),
            (this.source = function (b, d) {
              d(a.ui.autocomplete.filter(c, b.term));
            }))
          : typeof this.options.source == "string"
          ? ((d = this.options.source),
            (this.source = function (c, e) {
              b.xhr && b.xhr.abort(),
                (b.xhr = a.ajax({
                  url: d,
                  data: c,
                  dataType: "json",
                  success: function (a, b) {
                    e(a);
                  },
                  error: function () {
                    e([]);
                  },
                }));
            }))
          : (this.source = this.options.source);
      },
      search: function (a, b) {
        (a = a != null ? a : this.element.val()),
          (this.term = this.element.val());
        if (a.length < this.options.minLength) return this.close(b);
        clearTimeout(this.closing);
        if (this._trigger("search", b) === !1) return;
        return this._search(a);
      },
      _search: function (a) {
        this.pending++,
          this.element.addClass("ui-autocomplete-loading"),
          this.source({ term: a }, this._response());
      },
      _response: function () {
        var a = this,
          b = ++c;
        return function (d) {
          b === c && a.__response(d),
            a.pending--,
            a.pending || a.element.removeClass("ui-autocomplete-loading");
        };
      },
      __response: function (a) {
        !this.options.disabled && a && a.length
          ? ((a = this._normalize(a)), this._suggest(a), this._trigger("open"))
          : this.close();
      },
      close: function (a) {
        clearTimeout(this.closing),
          this.menu.element.is(":visible") &&
            (this.menu.element.hide(),
            this.menu.deactivate(),
            this._trigger("close", a));
      },
      _change: function (a) {
        this.previous !== this.element.val() &&
          this._trigger("change", a, { item: this.selectedItem });
      },
      _normalize: function (b) {
        return b.length && b[0].label && b[0].value
          ? b
          : a.map(b, function (b) {
              return typeof b == "string"
                ? { label: b, value: b }
                : a.extend(
                    { label: b.label || b.value, value: b.value || b.label },
                    b
                  );
            });
      },
      _suggest: function (b) {
        var c = this.menu.element.empty().zIndex(this.element.zIndex() + 1);
        this._renderMenu(c, b),
          this.menu.deactivate(),
          this.menu.refresh(),
          c.show(),
          this._resizeMenu(),
          c.position(a.extend({ of: this.element }, this.options.position)),
          this.options.autoFocus && this.menu.next(new a.Event("mouseover"));
      },
      _resizeMenu: function () {
        var a = this.menu.element;
        a.outerWidth(
          Math.max(a.width("").outerWidth() + 1, this.element.outerWidth())
        );
      },
      _renderMenu: function (b, c) {
        var d = this;
        a.each(c, function (a, c) {
          d._renderItem(b, c);
        });
      },
      _renderItem: function (b, c) {
        return a("<li></li>")
          .data("item.autocomplete", c)
          .append(a("<a></a>").text(c.label))
          .appendTo(b);
      },
      _move: function (a, b) {
        if (!this.menu.element.is(":visible")) {
          this.search(null, b);
          return;
        }
        if (
          (this.menu.first() && /^previous/.test(a)) ||
          (this.menu.last() && /^next/.test(a))
        ) {
          this.element.val(this.term), this.menu.deactivate();
          return;
        }
        this.menu[a](b);
      },
      widget: function () {
        return this.menu.element;
      },
      _keyEvent: function (a, b) {
        if (!this.isMultiLine || this.menu.element.is(":visible"))
          this._move(a, b), b.preventDefault();
      },
    }),
      a.extend(a.ui.autocomplete, {
        escapeRegex: function (a) {
          return a.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
        },
        filter: function (b, c) {
          var d = new RegExp(a.ui.autocomplete.escapeRegex(c), "i");
          return a.grep(b, function (a) {
            return d.test(a.label || a.value || a);
          });
        },
      });
  })(jQuery),
  (function (a) {
    a.widget("ui.menu", {
      _create: function () {
        var b = this;
        this.element
          .addClass("ui-menu ui-widget ui-widget-content ui-corner-all")
          .attr({
            role: "listbox",
            "aria-activedescendant": "ui-active-menuitem",
          })
          .click(function (c) {
            if (!a(c.target).closest(".ui-menu-item a").length) return;
            c.preventDefault(), b.select(c);
          }),
          this.refresh();
      },
      refresh: function () {
        var b = this,
          c = this.element
            .children("li:not(.ui-menu-item):has(a)")
            .addClass("ui-menu-item")
            .attr("role", "menuitem");
        c.children("a")
          .addClass("ui-corner-all")
          .attr("tabindex", -1)
          .mouseenter(function (c) {
            b.activate(c, a(this).parent());
          })
          .mouseleave(function () {
            b.deactivate();
          });
      },
      activate: function (a, b) {
        this.deactivate();
        if (this.hasScroll()) {
          var c = b.offset().top - this.element.offset().top,
            d = this.element.scrollTop(),
            e = this.element.height();
          c < 0
            ? this.element.scrollTop(d + c)
            : c >= e && this.element.scrollTop(d + c - e + b.height());
        }
        (this.active = b
          .eq(0)
          .children("a")
          .addClass("ui-state-hover")
          .attr("id", "ui-active-menuitem")
          .end()),
          this._trigger("focus", a, { item: b });
      },
      deactivate: function () {
        if (!this.active) return;
        this.active
          .children("a")
          .removeClass("ui-state-hover")
          .removeAttr("id"),
          this._trigger("blur"),
          (this.active = null);
      },
      next: function (a) {
        this.move("next", ".ui-menu-item:first", a);
      },
      previous: function (a) {
        this.move("prev", ".ui-menu-item:last", a);
      },
      first: function () {
        return this.active && !this.active.prevAll(".ui-menu-item").length;
      },
      last: function () {
        return this.active && !this.active.nextAll(".ui-menu-item").length;
      },
      move: function (a, b, c) {
        if (!this.active) {
          this.activate(c, this.element.children(b));
          return;
        }
        var d = this.active[a + "All"](".ui-menu-item").eq(0);
        d.length
          ? this.activate(c, d)
          : this.activate(c, this.element.children(b));
      },
      nextPage: function (b) {
        if (this.hasScroll()) {
          if (!this.active || this.last()) {
            this.activate(b, this.element.children(".ui-menu-item:first"));
            return;
          }
          var c = this.active.offset().top,
            d = this.element.height(),
            e = this.element.children(".ui-menu-item").filter(function () {
              var b = a(this).offset().top - c - d + a(this).height();
              return b < 10 && b > -10;
            });
          e.length || (e = this.element.children(".ui-menu-item:last")),
            this.activate(b, e);
        } else
          this.activate(
            b,
            this.element
              .children(".ui-menu-item")
              .filter(!this.active || this.last() ? ":first" : ":last")
          );
      },
      previousPage: function (b) {
        if (this.hasScroll()) {
          if (!this.active || this.first()) {
            this.activate(b, this.element.children(".ui-menu-item:last"));
            return;
          }
          var c = this.active.offset().top,
            d = this.element.height(),
            e = this.element.children(".ui-menu-item").filter(function () {
              var b = a(this).offset().top - c + d - a(this).height();
              return b < 10 && b > -10;
            });
          e.length || (e = this.element.children(".ui-menu-item:first")),
            this.activate(b, e);
        } else
          this.activate(
            b,
            this.element
              .children(".ui-menu-item")
              .filter(!this.active || this.first() ? ":last" : ":first")
          );
      },
      hasScroll: function () {
        return (
          this.element.height() <
          this.element[a.fn.prop ? "prop" : "attr"]("scrollHeight")
        );
      },
      select: function (a) {
        this._trigger("selected", a, { item: this.active });
      },
    });
  })(jQuery),
  (function (a, b) {
    var c,
      d,
      e,
      f,
      g = "ui-button ui-widget ui-state-default ui-corner-all",
      h = "ui-state-hover ui-state-active ",
      i =
        "ui-button-icons-only ui-button-icon-only ui-button-text-icons ui-button-text-icon-primary ui-button-text-icon-secondary ui-button-text-only",
      j = function () {
        var b = a(this).find(":ui-button");
        setTimeout(function () {
          b.button("refresh");
        }, 1);
      },
      k = function (b) {
        var c = b.name,
          d = b.form,
          e = a([]);
        return (
          c &&
            (d
              ? (e = a(d).find("[name='" + c + "']"))
              : (e = a("[name='" + c + "']", b.ownerDocument).filter(
                  function () {
                    return !this.form;
                  }
                ))),
          e
        );
      };
    a.widget("ui.button", {
      options: {
        disabled: null,
        text: !0,
        label: null,
        icons: { primary: null, secondary: null },
      },
      _create: function () {
        this.element
          .closest("form")
          .unbind("reset.button")
          .bind("reset.button", j),
          typeof this.options.disabled != "boolean"
            ? (this.options.disabled = !!this.element.propAttr("disabled"))
            : this.element.propAttr("disabled", this.options.disabled),
          this._determineButtonType(),
          (this.hasTitle = !!this.buttonElement.attr("title"));
        var b = this,
          h = this.options,
          i = this.type === "checkbox" || this.type === "radio",
          l = "ui-state-hover" + (i ? "" : " ui-state-active"),
          m = "ui-state-focus";
        h.label === null && (h.label = this.buttonElement.html()),
          this.buttonElement
            .addClass(g)
            .attr("role", "button")
            .bind("mouseenter.button", function () {
              if (h.disabled) return;
              a(this).addClass("ui-state-hover"),
                this === c && a(this).addClass("ui-state-active");
            })
            .bind("mouseleave.button", function () {
              if (h.disabled) return;
              a(this).removeClass(l);
            })
            .bind("click.button", function (a) {
              h.disabled && (a.preventDefault(), a.stopImmediatePropagation());
            }),
          this.element
            .bind("focus.button", function () {
              b.buttonElement.addClass(m);
            })
            .bind("blur.button", function () {
              b.buttonElement.removeClass(m);
            }),
          i &&
            (this.element.bind("change.button", function () {
              if (f) return;
              b.refresh();
            }),
            this.buttonElement
              .bind("mousedown.button", function (a) {
                if (h.disabled) return;
                (f = !1), (d = a.pageX), (e = a.pageY);
              })
              .bind("mouseup.button", function (a) {
                if (h.disabled) return;
                if (d !== a.pageX || e !== a.pageY) f = !0;
              })),
          this.type === "checkbox"
            ? this.buttonElement.bind("click.button", function () {
                if (h.disabled || f) return !1;
                a(this).toggleClass("ui-state-active"),
                  b.buttonElement.attr("aria-pressed", b.element[0].checked);
              })
            : this.type === "radio"
            ? this.buttonElement.bind("click.button", function () {
                if (h.disabled || f) return !1;
                a(this).addClass("ui-state-active"),
                  b.buttonElement.attr("aria-pressed", "true");
                var c = b.element[0];
                k(c)
                  .not(c)
                  .map(function () {
                    return a(this).button("widget")[0];
                  })
                  .removeClass("ui-state-active")
                  .attr("aria-pressed", "false");
              })
            : (this.buttonElement
                .bind("mousedown.button", function () {
                  if (h.disabled) return !1;
                  a(this).addClass("ui-state-active"),
                    (c = this),
                    a(document).one("mouseup", function () {
                      c = null;
                    });
                })
                .bind("mouseup.button", function () {
                  if (h.disabled) return !1;
                  a(this).removeClass("ui-state-active");
                })
                .bind("keydown.button", function (b) {
                  if (h.disabled) return !1;
                  (b.keyCode == a.ui.keyCode.SPACE ||
                    b.keyCode == a.ui.keyCode.ENTER) &&
                    a(this).addClass("ui-state-active");
                })
                .bind("keyup.button", function () {
                  a(this).removeClass("ui-state-active");
                }),
              this.buttonElement.is("a") &&
                this.buttonElement.keyup(function (b) {
                  b.keyCode === a.ui.keyCode.SPACE && a(this).click();
                })),
          this._setOption("disabled", h.disabled),
          this._resetButton();
      },
      _determineButtonType: function () {
        this.element.is(":checkbox")
          ? (this.type = "checkbox")
          : this.element.is(":radio")
          ? (this.type = "radio")
          : this.element.is("input")
          ? (this.type = "input")
          : (this.type = "button");
        if (this.type === "checkbox" || this.type === "radio") {
          var a = this.element.parents().filter(":last"),
            b = "label[for='" + this.element.attr("id") + "']";
          (this.buttonElement = a.find(b)),
            this.buttonElement.length ||
              ((a = a.length ? a.siblings() : this.element.siblings()),
              (this.buttonElement = a.filter(b)),
              this.buttonElement.length || (this.buttonElement = a.find(b))),
            this.element.addClass("ui-helper-hidden-accessible");
          var c = this.element.is(":checked");
          c && this.buttonElement.addClass("ui-state-active"),
            this.buttonElement.attr("aria-pressed", c);
        } else this.buttonElement = this.element;
      },
      widget: function () {
        return this.buttonElement;
      },
      destroy: function () {
        this.element.removeClass("ui-helper-hidden-accessible"),
          this.buttonElement
            .removeClass(g + " " + h + " " + i)
            .removeAttr("role")
            .removeAttr("aria-pressed")
            .html(this.buttonElement.find(".ui-button-text").html()),
          this.hasTitle || this.buttonElement.removeAttr("title"),
          a.Widget.prototype.destroy.call(this);
      },
      _setOption: function (b, c) {
        a.Widget.prototype._setOption.apply(this, arguments);
        if (b === "disabled") {
          c
            ? this.element.propAttr("disabled", !0)
            : this.element.propAttr("disabled", !1);
          return;
        }
        this._resetButton();
      },
      refresh: function () {
        var b = this.element.is(":disabled");
        b !== this.options.disabled && this._setOption("disabled", b),
          this.type === "radio"
            ? k(this.element[0]).each(function () {
                a(this).is(":checked")
                  ? a(this)
                      .button("widget")
                      .addClass("ui-state-active")
                      .attr("aria-pressed", "true")
                  : a(this)
                      .button("widget")
                      .removeClass("ui-state-active")
                      .attr("aria-pressed", "false");
              })
            : this.type === "checkbox" &&
              (this.element.is(":checked")
                ? this.buttonElement
                    .addClass("ui-state-active")
                    .attr("aria-pressed", "true")
                : this.buttonElement
                    .removeClass("ui-state-active")
                    .attr("aria-pressed", "false"));
      },
      _resetButton: function () {
        if (this.type === "input") {
          this.options.label && this.element.val(this.options.label);
          return;
        }
        var b = this.buttonElement.removeClass(i),
          c = a("<span></span>", this.element[0].ownerDocument)
            .addClass("ui-button-text")
            .html(this.options.label)
            .appendTo(b.empty())
            .text(),
          d = this.options.icons,
          e = d.primary && d.secondary,
          f = [];
        d.primary || d.secondary
          ? (this.options.text &&
              f.push(
                "ui-button-text-icon" +
                  (e ? "s" : d.primary ? "-primary" : "-secondary")
              ),
            d.primary &&
              b.prepend(
                "<span class='ui-button-icon-primary ui-icon " +
                  d.primary +
                  "'></span>"
              ),
            d.secondary &&
              b.append(
                "<span class='ui-button-icon-secondary ui-icon " +
                  d.secondary +
                  "'></span>"
              ),
            this.options.text ||
              (f.push(e ? "ui-button-icons-only" : "ui-button-icon-only"),
              this.hasTitle || b.attr("title", c)))
          : f.push("ui-button-text-only"),
          b.addClass(f.join(" "));
      },
    }),
      a.widget("ui.buttonset", {
        options: {
          items:
            ":button, :submit, :reset, :checkbox, :radio, a, :data(button)",
        },
        _create: function () {
          this.element.addClass("ui-buttonset");
        },
        _init: function () {
          this.refresh();
        },
        _setOption: function (b, c) {
          b === "disabled" && this.buttons.button("option", b, c),
            a.Widget.prototype._setOption.apply(this, arguments);
        },
        refresh: function () {
          var b = this.element.css("direction") === "rtl";
          this.buttons = this.element
            .find(this.options.items)
            .filter(":ui-button")
            .button("refresh")
            .end()
            .not(":ui-button")
            .button()
            .end()
            .map(function () {
              return a(this).button("widget")[0];
            })
            .removeClass("ui-corner-all ui-corner-left ui-corner-right")
            .filter(":first")
            .addClass(b ? "ui-corner-right" : "ui-corner-left")
            .end()
            .filter(":last")
            .addClass(b ? "ui-corner-left" : "ui-corner-right")
            .end()
            .end();
        },
        destroy: function () {
          this.element.removeClass("ui-buttonset"),
            this.buttons
              .map(function () {
                return a(this).button("widget")[0];
              })
              .removeClass("ui-corner-left ui-corner-right")
              .end()
              .button("destroy"),
            a.Widget.prototype.destroy.call(this);
        },
      });
  })(jQuery),
  (function ($, undefined) {
    function Datepicker() {
      (this.debug = !1),
        (this._curInst = null),
        (this._keyEvent = !1),
        (this._disabledInputs = []),
        (this._datepickerShowing = !1),
        (this._inDialog = !1),
        (this._mainDivId = "ui-datepicker-div"),
        (this._inlineClass = "ui-datepicker-inline"),
        (this._appendClass = "ui-datepicker-append"),
        (this._triggerClass = "ui-datepicker-trigger"),
        (this._dialogClass = "ui-datepicker-dialog"),
        (this._disableClass = "ui-datepicker-disabled"),
        (this._unselectableClass = "ui-datepicker-unselectable"),
        (this._currentClass = "ui-datepicker-current-day"),
        (this._dayOverClass = "ui-datepicker-days-cell-over"),
        (this.regional = []),
        (this.regional[""] = {
          closeText: "Done",
          prevText: "Prev",
          nextText: "Next",
          currentText: "Today",
          monthNames: [
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December",
          ],
          monthNamesShort: [
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sep",
            "Oct",
            "Nov",
            "Dec",
          ],
          dayNames: [
            "Sunday",
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday",
          ],
          dayNamesShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
          dayNamesMin: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
          weekHeader: "Wk",
          dateFormat: "mm/dd/yy",
          firstDay: 0,
          isRTL: !1,
          showMonthAfterYear: !1,
          yearSuffix: "",
        }),
        (this._defaults = {
          showOn: "focus",
          showAnim: "fadeIn",
          showOptions: {},
          defaultDate: null,
          appendText: "",
          buttonText: "...",
          buttonImage: "",
          buttonImageOnly: !1,
          hideIfNoPrevNext: !1,
          navigationAsDateFormat: !1,
          gotoCurrent: !1,
          changeMonth: !1,
          changeYear: !1,
          yearRange: "c-10:c+10",
          showOtherMonths: !1,
          selectOtherMonths: !1,
          showWeek: !1,
          calculateWeek: this.iso8601Week,
          shortYearCutoff: "+10",
          minDate: null,
          maxDate: null,
          duration: "fast",
          beforeShowDay: null,
          beforeShow: null,
          onSelect: null,
          onChangeMonthYear: null,
          onClose: null,
          numberOfMonths: 1,
          showCurrentAtPos: 0,
          stepMonths: 1,
          stepBigMonths: 12,
          altField: "",
          altFormat: "",
          constrainInput: !0,
          showButtonPanel: !1,
          autoSize: !1,
          disabled: !1,
        }),
        $.extend(this._defaults, this.regional[""]),
        (this.dpDiv = bindHover(
          $(
            '<div id="' +
              this._mainDivId +
              '" class="ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all"></div>'
          )
        ));
    }
    function bindHover(a) {
      var b =
        "button, .ui-datepicker-prev, .ui-datepicker-next, .ui-datepicker-calendar td a";
      return a
        .bind("mouseout", function (a) {
          var c = $(a.target).closest(b);
          if (!c.length) return;
          c.removeClass(
            "ui-state-hover ui-datepicker-prev-hover ui-datepicker-next-hover"
          );
        })
        .bind("mouseover", function (c) {
          var d = $(c.target).closest(b);
          if (
            $.datepicker._isDisabledDatepicker(
              instActive.inline ? a.parent()[0] : instActive.input[0]
            ) ||
            !d.length
          )
            return;
          d
            .parents(".ui-datepicker-calendar")
            .find("a")
            .removeClass("ui-state-hover"),
            d.addClass("ui-state-hover"),
            d.hasClass("ui-datepicker-prev") &&
              d.addClass("ui-datepicker-prev-hover"),
            d.hasClass("ui-datepicker-next") &&
              d.addClass("ui-datepicker-next-hover");
        });
    }
    function extendRemove(a, b) {
      $.extend(a, b);
      for (var c in b) if (b[c] == null || b[c] == undefined) a[c] = b[c];
      return a;
    }
    function isArray(a) {
      return (
        a &&
        (($.browser.safari && typeof a == "object" && a.length) ||
          (a.constructor && a.constructor.toString().match(/\Array\(\)/)))
      );
    }
    $.extend($.ui, { datepicker: { version: "1.8.24" } });
    var PROP_NAME = "datepicker",
      dpuuid = new Date().getTime(),
      instActive;
    $.extend(Datepicker.prototype, {
      markerClassName: "hasDatepicker",
      maxRows: 4,
      log: function () {
        this.debug && console.log.apply("", arguments);
      },
      _widgetDatepicker: function () {
        return this.dpDiv;
      },
      setDefaults: function (a) {
        return extendRemove(this._defaults, a || {}), this;
      },
      _attachDatepicker: function (target, settings) {
        var inlineSettings = null;
        for (var attrName in this._defaults) {
          var attrValue = target.getAttribute("date:" + attrName);
          if (attrValue) {
            inlineSettings = inlineSettings || {};
            try {
              inlineSettings[attrName] = eval(attrValue);
            } catch (err) {
              inlineSettings[attrName] = attrValue;
            }
          }
        }
        var nodeName = target.nodeName.toLowerCase(),
          inline = nodeName == "div" || nodeName == "span";
        target.id || ((this.uuid += 1), (target.id = "dp" + this.uuid));
        var inst = this._newInst($(target), inline);
        (inst.settings = $.extend({}, settings || {}, inlineSettings || {})),
          nodeName == "input"
            ? this._connectDatepicker(target, inst)
            : inline && this._inlineDatepicker(target, inst);
      },
      _newInst: function (a, b) {
        var c = a[0].id.replace(/([^A-Za-z0-9_-])/g, "\\\\$1");
        return {
          id: c,
          input: a,
          selectedDay: 0,
          selectedMonth: 0,
          selectedYear: 0,
          drawMonth: 0,
          drawYear: 0,
          inline: b,
          dpDiv: b
            ? bindHover(
                $(
                  '<div class="' +
                    this._inlineClass +
                    ' ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all"></div>'
                )
              )
            : this.dpDiv,
        };
      },
      _connectDatepicker: function (a, b) {
        var c = $(a);
        (b.append = $([])), (b.trigger = $([]));
        if (c.hasClass(this.markerClassName)) return;
        this._attachments(c, b),
          c
            .addClass(this.markerClassName)
            .keydown(this._doKeyDown)
            .keypress(this._doKeyPress)
            .keyup(this._doKeyUp)
            .bind("setData.datepicker", function (a, c, d) {
              b.settings[c] = d;
            })
            .bind("getData.datepicker", function (a, c) {
              return this._get(b, c);
            }),
          this._autoSize(b),
          $.data(a, PROP_NAME, b),
          b.settings.disabled && this._disableDatepicker(a);
      },
      _attachments: function (a, b) {
        var c = this._get(b, "appendText"),
          d = this._get(b, "isRTL");
        b.append && b.append.remove(),
          c &&
            ((b.append = $(
              '<span class="' + this._appendClass + '">' + c + "</span>"
            )),
            a[d ? "before" : "after"](b.append)),
          a.unbind("focus", this._showDatepicker),
          b.trigger && b.trigger.remove();
        var e = this._get(b, "showOn");
        (e == "focus" || e == "both") && a.focus(this._showDatepicker);
        if (e == "button" || e == "both") {
          var f = this._get(b, "buttonText"),
            g = this._get(b, "buttonImage");
          (b.trigger = $(
            this._get(b, "buttonImageOnly")
              ? $("<img/>")
                  .addClass(this._triggerClass)
                  .attr({ src: g, alt: f, title: f })
              : $('<button type="button"></button>')
                  .addClass(this._triggerClass)
                  .html(
                    g == "" ? f : $("<img/>").attr({ src: g, alt: f, title: f })
                  )
          )),
            a[d ? "before" : "after"](b.trigger),
            b.trigger.click(function () {
              return (
                $.datepicker._datepickerShowing &&
                $.datepicker._lastInput == a[0]
                  ? $.datepicker._hideDatepicker()
                  : $.datepicker._datepickerShowing &&
                    $.datepicker._lastInput != a[0]
                  ? ($.datepicker._hideDatepicker(),
                    $.datepicker._showDatepicker(a[0]))
                  : $.datepicker._showDatepicker(a[0]),
                !1
              );
            });
        }
      },
      _autoSize: function (a) {
        if (this._get(a, "autoSize") && !a.inline) {
          var b = new Date(2009, 11, 20),
            c = this._get(a, "dateFormat");
          if (c.match(/[DM]/)) {
            var d = function (a) {
              var b = 0,
                c = 0;
              for (var d = 0; d < a.length; d++)
                a[d].length > b && ((b = a[d].length), (c = d));
              return c;
            };
            b.setMonth(
              d(this._get(a, c.match(/MM/) ? "monthNames" : "monthNamesShort"))
            ),
              b.setDate(
                d(this._get(a, c.match(/DD/) ? "dayNames" : "dayNamesShort")) +
                  20 -
                  b.getDay()
              );
          }
          a.input.attr("size", this._formatDate(a, b).length);
        }
      },
      _inlineDatepicker: function (a, b) {
        var c = $(a);
        if (c.hasClass(this.markerClassName)) return;
        c
          .addClass(this.markerClassName)
          .append(b.dpDiv)
          .bind("setData.datepicker", function (a, c, d) {
            b.settings[c] = d;
          })
          .bind("getData.datepicker", function (a, c) {
            return this._get(b, c);
          }),
          $.data(a, PROP_NAME, b),
          this._setDate(b, this._getDefaultDate(b), !0),
          this._updateDatepicker(b),
          this._updateAlternate(b),
          b.settings.disabled && this._disableDatepicker(a),
          b.dpDiv.css("display", "block");
      },
      _dialogDatepicker: function (a, b, c, d, e) {
        var f = this._dialogInst;
        if (!f) {
          this.uuid += 1;
          var g = "dp" + this.uuid;
          (this._dialogInput = $(
            '<input type="text" id="' +
              g +
              '" style="position: absolute; top: -100px; width: 0px;"/>'
          )),
            this._dialogInput.keydown(this._doKeyDown),
            $("body").append(this._dialogInput),
            (f = this._dialogInst = this._newInst(this._dialogInput, !1)),
            (f.settings = {}),
            $.data(this._dialogInput[0], PROP_NAME, f);
        }
        extendRemove(f.settings, d || {}),
          (b = b && b.constructor == Date ? this._formatDate(f, b) : b),
          this._dialogInput.val(b),
          (this._pos = e ? (e.length ? e : [e.pageX, e.pageY]) : null);
        if (!this._pos) {
          var h = document.documentElement.clientWidth,
            i = document.documentElement.clientHeight,
            j = document.documentElement.scrollLeft || document.body.scrollLeft,
            k = document.documentElement.scrollTop || document.body.scrollTop;
          this._pos = [h / 2 - 100 + j, i / 2 - 150 + k];
        }
        return (
          this._dialogInput
            .css("left", this._pos[0] + 20 + "px")
            .css("top", this._pos[1] + "px"),
          (f.settings.onSelect = c),
          (this._inDialog = !0),
          this.dpDiv.addClass(this._dialogClass),
          this._showDatepicker(this._dialogInput[0]),
          $.blockUI && $.blockUI(this.dpDiv),
          $.data(this._dialogInput[0], PROP_NAME, f),
          this
        );
      },
      _destroyDatepicker: function (a) {
        var b = $(a),
          c = $.data(a, PROP_NAME);
        if (!b.hasClass(this.markerClassName)) return;
        var d = a.nodeName.toLowerCase();
        $.removeData(a, PROP_NAME),
          d == "input"
            ? (c.append.remove(),
              c.trigger.remove(),
              b
                .removeClass(this.markerClassName)
                .unbind("focus", this._showDatepicker)
                .unbind("keydown", this._doKeyDown)
                .unbind("keypress", this._doKeyPress)
                .unbind("keyup", this._doKeyUp))
            : (d == "div" || d == "span") &&
              b.removeClass(this.markerClassName).empty();
      },
      _enableDatepicker: function (a) {
        var b = $(a),
          c = $.data(a, PROP_NAME);
        if (!b.hasClass(this.markerClassName)) return;
        var d = a.nodeName.toLowerCase();
        if (d == "input")
          (a.disabled = !1),
            c.trigger
              .filter("button")
              .each(function () {
                this.disabled = !1;
              })
              .end()
              .filter("img")
              .css({ opacity: "1.0", cursor: "" });
        else if (d == "div" || d == "span") {
          var e = b.children("." + this._inlineClass);
          e.children().removeClass("ui-state-disabled"),
            e
              .find("select.ui-datepicker-month, select.ui-datepicker-year")
              .removeAttr("disabled");
        }
        this._disabledInputs = $.map(this._disabledInputs, function (b) {
          return b == a ? null : b;
        });
      },
      _disableDatepicker: function (a) {
        var b = $(a),
          c = $.data(a, PROP_NAME);
        if (!b.hasClass(this.markerClassName)) return;
        var d = a.nodeName.toLowerCase();
        if (d == "input")
          (a.disabled = !0),
            c.trigger
              .filter("button")
              .each(function () {
                this.disabled = !0;
              })
              .end()
              .filter("img")
              .css({ opacity: "0.5", cursor: "default" });
        else if (d == "div" || d == "span") {
          var e = b.children("." + this._inlineClass);
          e.children().addClass("ui-state-disabled"),
            e
              .find("select.ui-datepicker-month, select.ui-datepicker-year")
              .attr("disabled", "disabled");
        }
        (this._disabledInputs = $.map(this._disabledInputs, function (b) {
          return b == a ? null : b;
        })),
          (this._disabledInputs[this._disabledInputs.length] = a);
      },
      _isDisabledDatepicker: function (a) {
        if (!a) return !1;
        for (var b = 0; b < this._disabledInputs.length; b++)
          if (this._disabledInputs[b] == a) return !0;
        return !1;
      },
      _getInst: function (a) {
        try {
          return $.data(a, PROP_NAME);
        } catch (b) {
          throw "Missing instance data for this datepicker";
        }
      },
      _optionDatepicker: function (a, b, c) {
        var d = this._getInst(a);
        if (arguments.length == 2 && typeof b == "string")
          return b == "defaults"
            ? $.extend({}, $.datepicker._defaults)
            : d
            ? b == "all"
              ? $.extend({}, d.settings)
              : this._get(d, b)
            : null;
        var e = b || {};
        typeof b == "string" && ((e = {}), (e[b] = c));
        if (d) {
          this._curInst == d && this._hideDatepicker();
          var f = this._getDateDatepicker(a, !0),
            g = this._getMinMaxDate(d, "min"),
            h = this._getMinMaxDate(d, "max");
          extendRemove(d.settings, e),
            g !== null &&
              e.dateFormat !== undefined &&
              e.minDate === undefined &&
              (d.settings.minDate = this._formatDate(d, g)),
            h !== null &&
              e.dateFormat !== undefined &&
              e.maxDate === undefined &&
              (d.settings.maxDate = this._formatDate(d, h)),
            this._attachments($(a), d),
            this._autoSize(d),
            this._setDate(d, f),
            this._updateAlternate(d),
            this._updateDatepicker(d);
        }
      },
      _changeDatepicker: function (a, b, c) {
        this._optionDatepicker(a, b, c);
      },
      _refreshDatepicker: function (a) {
        var b = this._getInst(a);
        b && this._updateDatepicker(b);
      },
      _setDateDatepicker: function (a, b) {
        var c = this._getInst(a);
        c &&
          (this._setDate(c, b),
          this._updateDatepicker(c),
          this._updateAlternate(c));
      },
      _getDateDatepicker: function (a, b) {
        var c = this._getInst(a);
        return (
          c && !c.inline && this._setDateFromField(c, b),
          c ? this._getDate(c) : null
        );
      },
      _doKeyDown: function (a) {
        var b = $.datepicker._getInst(a.target),
          c = !0,
          d = b.dpDiv.is(".ui-datepicker-rtl");
        b._keyEvent = !0;
        if ($.datepicker._datepickerShowing)
          switch (a.keyCode) {
            case 9:
              $.datepicker._hideDatepicker(), (c = !1);
              break;
            case 13:
              var e = $(
                "td." +
                  $.datepicker._dayOverClass +
                  ":not(." +
                  $.datepicker._currentClass +
                  ")",
                b.dpDiv
              );
              e[0] &&
                $.datepicker._selectDay(
                  a.target,
                  b.selectedMonth,
                  b.selectedYear,
                  e[0]
                );
              var f = $.datepicker._get(b, "onSelect");
              if (f) {
                var g = $.datepicker._formatDate(b);
                f.apply(b.input ? b.input[0] : null, [g, b]);
              } else $.datepicker._hideDatepicker();
              return !1;
            case 27:
              $.datepicker._hideDatepicker();
              break;
            case 33:
              $.datepicker._adjustDate(
                a.target,
                a.ctrlKey
                  ? -$.datepicker._get(b, "stepBigMonths")
                  : -$.datepicker._get(b, "stepMonths"),
                "M"
              );
              break;
            case 34:
              $.datepicker._adjustDate(
                a.target,
                a.ctrlKey
                  ? +$.datepicker._get(b, "stepBigMonths")
                  : +$.datepicker._get(b, "stepMonths"),
                "M"
              );
              break;
            case 35:
              (a.ctrlKey || a.metaKey) && $.datepicker._clearDate(a.target),
                (c = a.ctrlKey || a.metaKey);
              break;
            case 36:
              (a.ctrlKey || a.metaKey) && $.datepicker._gotoToday(a.target),
                (c = a.ctrlKey || a.metaKey);
              break;
            case 37:
              (a.ctrlKey || a.metaKey) &&
                $.datepicker._adjustDate(a.target, d ? 1 : -1, "D"),
                (c = a.ctrlKey || a.metaKey),
                a.originalEvent.altKey &&
                  $.datepicker._adjustDate(
                    a.target,
                    a.ctrlKey
                      ? -$.datepicker._get(b, "stepBigMonths")
                      : -$.datepicker._get(b, "stepMonths"),
                    "M"
                  );
              break;
            case 38:
              (a.ctrlKey || a.metaKey) &&
                $.datepicker._adjustDate(a.target, -7, "D"),
                (c = a.ctrlKey || a.metaKey);
              break;
            case 39:
              (a.ctrlKey || a.metaKey) &&
                $.datepicker._adjustDate(a.target, d ? -1 : 1, "D"),
                (c = a.ctrlKey || a.metaKey),
                a.originalEvent.altKey &&
                  $.datepicker._adjustDate(
                    a.target,
                    a.ctrlKey
                      ? +$.datepicker._get(b, "stepBigMonths")
                      : +$.datepicker._get(b, "stepMonths"),
                    "M"
                  );
              break;
            case 40:
              (a.ctrlKey || a.metaKey) &&
                $.datepicker._adjustDate(a.target, 7, "D"),
                (c = a.ctrlKey || a.metaKey);
              break;
            default:
              c = !1;
          }
        else
          a.keyCode == 36 && a.ctrlKey
            ? $.datepicker._showDatepicker(this)
            : (c = !1);
        c && (a.preventDefault(), a.stopPropagation());
      },
      _doKeyPress: function (a) {
        var b = $.datepicker._getInst(a.target);
        if ($.datepicker._get(b, "constrainInput")) {
          var c = $.datepicker._possibleChars(
              $.datepicker._get(b, "dateFormat")
            ),
            d = String.fromCharCode(
              a.charCode == undefined ? a.keyCode : a.charCode
            );
          return a.ctrlKey || a.metaKey || d < " " || !c || c.indexOf(d) > -1;
        }
      },
      _doKeyUp: function (a) {
        var b = $.datepicker._getInst(a.target);
        if (b.input.val() != b.lastVal)
          try {
            var c = $.datepicker.parseDate(
              $.datepicker._get(b, "dateFormat"),
              b.input ? b.input.val() : null,
              $.datepicker._getFormatConfig(b)
            );
            c &&
              ($.datepicker._setDateFromField(b),
              $.datepicker._updateAlternate(b),
              $.datepicker._updateDatepicker(b));
          } catch (d) {
            $.datepicker.log(d);
          }
        return !0;
      },
      _showDatepicker: function (a) {
        (a = a.target || a),
          a.nodeName.toLowerCase() != "input" &&
            (a = $("input", a.parentNode)[0]);
        if (
          $.datepicker._isDisabledDatepicker(a) ||
          $.datepicker._lastInput == a
        )
          return;
        var b = $.datepicker._getInst(a);
        $.datepicker._curInst &&
          $.datepicker._curInst != b &&
          ($.datepicker._curInst.dpDiv.stop(!0, !0),
          b &&
            $.datepicker._datepickerShowing &&
            $.datepicker._hideDatepicker($.datepicker._curInst.input[0]));
        var c = $.datepicker._get(b, "beforeShow"),
          d = c ? c.apply(a, [a, b]) : {};
        if (d === !1) return;
        extendRemove(b.settings, d),
          (b.lastVal = null),
          ($.datepicker._lastInput = a),
          $.datepicker._setDateFromField(b),
          $.datepicker._inDialog && (a.value = ""),
          $.datepicker._pos ||
            (($.datepicker._pos = $.datepicker._findPos(a)),
            ($.datepicker._pos[1] += a.offsetHeight));
        var e = !1;
        $(a)
          .parents()
          .each(function () {
            return (e |= $(this).css("position") == "fixed"), !e;
          }),
          e &&
            $.browser.opera &&
            (($.datepicker._pos[0] -= document.documentElement.scrollLeft),
            ($.datepicker._pos[1] -= document.documentElement.scrollTop));
        var f = { left: $.datepicker._pos[0], top: $.datepicker._pos[1] };
        ($.datepicker._pos = null),
          b.dpDiv.empty(),
          b.dpDiv.css({
            position: "absolute",
            display: "block",
            top: "-1000px",
          }),
          $.datepicker._updateDatepicker(b),
          (f = $.datepicker._checkOffset(b, f, e)),
          b.dpDiv.css({
            position:
              $.datepicker._inDialog && $.blockUI
                ? "static"
                : e
                ? "fixed"
                : "absolute",
            display: "none",
            left: f.left + "px",
            top: f.top + "px",
          });
        if (!b.inline) {
          var g = $.datepicker._get(b, "showAnim"),
            h = $.datepicker._get(b, "duration"),
            i = function () {
              var a = b.dpDiv.find("iframe.ui-datepicker-cover");
              if (!!a.length) {
                var c = $.datepicker._getBorders(b.dpDiv);
                a.css({
                  left: -c[0],
                  top: -c[1],
                  width: b.dpDiv.outerWidth(),
                  height: b.dpDiv.outerHeight(),
                });
              }
            };
          b.dpDiv.zIndex($(a).zIndex() + 1),
            ($.datepicker._datepickerShowing = !0),
            $.effects && $.effects[g]
              ? b.dpDiv.show(g, $.datepicker._get(b, "showOptions"), h, i)
              : b.dpDiv[g || "show"](g ? h : null, i),
            (!g || !h) && i(),
            b.input.is(":visible") &&
              !b.input.is(":disabled") &&
              b.input.focus(),
            ($.datepicker._curInst = b);
        }
      },
      _updateDatepicker: function (a) {
        var b = this;
        b.maxRows = 4;
        var c = $.datepicker._getBorders(a.dpDiv);
        (instActive = a),
          a.dpDiv.empty().append(this._generateHTML(a)),
          this._attachHandlers(a);
        var d = a.dpDiv.find("iframe.ui-datepicker-cover");
        !d.length ||
          d.css({
            left: -c[0],
            top: -c[1],
            width: a.dpDiv.outerWidth(),
            height: a.dpDiv.outerHeight(),
          }),
          a.dpDiv.find("." + this._dayOverClass + " a").mouseover();
        var e = this._getNumberOfMonths(a),
          f = e[1],
          g = 17;
        a.dpDiv
          .removeClass(
            "ui-datepicker-multi-2 ui-datepicker-multi-3 ui-datepicker-multi-4"
          )
          .width(""),
          f > 1 &&
            a.dpDiv
              .addClass("ui-datepicker-multi-" + f)
              .css("width", g * f + "em"),
          a.dpDiv[(e[0] != 1 || e[1] != 1 ? "add" : "remove") + "Class"](
            "ui-datepicker-multi"
          ),
          a.dpDiv[(this._get(a, "isRTL") ? "add" : "remove") + "Class"](
            "ui-datepicker-rtl"
          ),
          a == $.datepicker._curInst &&
            $.datepicker._datepickerShowing &&
            a.input &&
            a.input.is(":visible") &&
            !a.input.is(":disabled") &&
            a.input[0] != document.activeElement &&
            a.input.focus();
        if (a.yearshtml) {
          var h = a.yearshtml;
          setTimeout(function () {
            h === a.yearshtml &&
              a.yearshtml &&
              a.dpDiv
                .find("select.ui-datepicker-year:first")
                .replaceWith(a.yearshtml),
              (h = a.yearshtml = null);
          }, 0);
        }
      },
      _getBorders: function (a) {
        var b = function (a) {
          return { thin: 1, medium: 2, thick: 3 }[a] || a;
        };
        return [
          parseFloat(b(a.css("border-left-width"))),
          parseFloat(b(a.css("border-top-width"))),
        ];
      },
      _checkOffset: function (a, b, c) {
        var d = a.dpDiv.outerWidth(),
          e = a.dpDiv.outerHeight(),
          f = a.input ? a.input.outerWidth() : 0,
          g = a.input ? a.input.outerHeight() : 0,
          h =
            document.documentElement.clientWidth +
            (c ? 0 : $(document).scrollLeft()),
          i =
            document.documentElement.clientHeight +
            (c ? 0 : $(document).scrollTop());
        return (
          (b.left -= this._get(a, "isRTL") ? d - f : 0),
          (b.left -=
            c && b.left == a.input.offset().left
              ? $(document).scrollLeft()
              : 0),
          (b.top -=
            c && b.top == a.input.offset().top + g
              ? $(document).scrollTop()
              : 0),
          (b.left -= Math.min(
            b.left,
            b.left + d > h && h > d ? Math.abs(b.left + d - h) : 0
          )),
          (b.top -= Math.min(
            b.top,
            b.top + e > i && i > e ? Math.abs(e + g) : 0
          )),
          b
        );
      },
      _findPos: function (a) {
        var b = this._getInst(a),
          c = this._get(b, "isRTL");
        while (
          a &&
          (a.type == "hidden" || a.nodeType != 1 || $.expr.filters.hidden(a))
        )
          a = a[c ? "previousSibling" : "nextSibling"];
        var d = $(a).offset();
        return [d.left, d.top];
      },
      _hideDatepicker: function (a) {
        var b = this._curInst;
        if (!b || (a && b != $.data(a, PROP_NAME))) return;
        if (this._datepickerShowing) {
          var c = this._get(b, "showAnim"),
            d = this._get(b, "duration"),
            e = function () {
              $.datepicker._tidyDialog(b);
            };
          $.effects && $.effects[c]
            ? b.dpDiv.hide(c, $.datepicker._get(b, "showOptions"), d, e)
            : b.dpDiv[
                c == "slideDown"
                  ? "slideUp"
                  : c == "fadeIn"
                  ? "fadeOut"
                  : "hide"
              ](c ? d : null, e),
            c || e(),
            (this._datepickerShowing = !1);
          var f = this._get(b, "onClose");
          f &&
            f.apply(b.input ? b.input[0] : null, [
              b.input ? b.input.val() : "",
              b,
            ]),
            (this._lastInput = null),
            this._inDialog &&
              (this._dialogInput.css({
                position: "absolute",
                left: "0",
                top: "-100px",
              }),
              $.blockUI && ($.unblockUI(), $("body").append(this.dpDiv))),
            (this._inDialog = !1);
        }
      },
      _tidyDialog: function (a) {
        a.dpDiv
          .removeClass(this._dialogClass)
          .unbind(".ui-datepicker-calendar");
      },
      _checkExternalClick: function (a) {
        if (!$.datepicker._curInst) return;
        var b = $(a.target),
          c = $.datepicker._getInst(b[0]);
        ((b[0].id != $.datepicker._mainDivId &&
          b.parents("#" + $.datepicker._mainDivId).length == 0 &&
          !b.hasClass($.datepicker.markerClassName) &&
          !b.closest("." + $.datepicker._triggerClass).length &&
          $.datepicker._datepickerShowing &&
          (!$.datepicker._inDialog || !$.blockUI)) ||
          (b.hasClass($.datepicker.markerClassName) &&
            $.datepicker._curInst != c)) &&
          $.datepicker._hideDatepicker();
      },
      _adjustDate: function (a, b, c) {
        var d = $(a),
          e = this._getInst(d[0]);
        if (this._isDisabledDatepicker(d[0])) return;
        this._adjustInstDate(
          e,
          b + (c == "M" ? this._get(e, "showCurrentAtPos") : 0),
          c
        ),
          this._updateDatepicker(e);
      },
      _gotoToday: function (a) {
        var b = $(a),
          c = this._getInst(b[0]);
        if (this._get(c, "gotoCurrent") && c.currentDay)
          (c.selectedDay = c.currentDay),
            (c.drawMonth = c.selectedMonth = c.currentMonth),
            (c.drawYear = c.selectedYear = c.currentYear);
        else {
          var d = new Date();
          (c.selectedDay = d.getDate()),
            (c.drawMonth = c.selectedMonth = d.getMonth()),
            (c.drawYear = c.selectedYear = d.getFullYear());
        }
        this._notifyChange(c), this._adjustDate(b);
      },
      _selectMonthYear: function (a, b, c) {
        var d = $(a),
          e = this._getInst(d[0]);
        (e["selected" + (c == "M" ? "Month" : "Year")] = e[
          "draw" + (c == "M" ? "Month" : "Year")
        ] =
          parseInt(b.options[b.selectedIndex].value, 10)),
          this._notifyChange(e),
          this._adjustDate(d);
      },
      _selectDay: function (a, b, c, d) {
        var e = $(a);
        if (
          $(d).hasClass(this._unselectableClass) ||
          this._isDisabledDatepicker(e[0])
        )
          return;
        var f = this._getInst(e[0]);
        (f.selectedDay = f.currentDay = $("a", d).html()),
          (f.selectedMonth = f.currentMonth = b),
          (f.selectedYear = f.currentYear = c),
          this._selectDate(
            a,
            this._formatDate(f, f.currentDay, f.currentMonth, f.currentYear)
          );
      },
      _clearDate: function (a) {
        var b = $(a),
          c = this._getInst(b[0]);
        this._selectDate(b, "");
      },
      _selectDate: function (a, b) {
        var c = $(a),
          d = this._getInst(c[0]);
        (b = b != null ? b : this._formatDate(d)),
          d.input && d.input.val(b),
          this._updateAlternate(d);
        var e = this._get(d, "onSelect");
        e
          ? e.apply(d.input ? d.input[0] : null, [b, d])
          : d.input && d.input.trigger("change"),
          d.inline
            ? this._updateDatepicker(d)
            : (this._hideDatepicker(),
              (this._lastInput = d.input[0]),
              typeof d.input[0] != "object" && d.input.focus(),
              (this._lastInput = null));
      },
      _updateAlternate: function (a) {
        var b = this._get(a, "altField");
        if (b) {
          var c = this._get(a, "altFormat") || this._get(a, "dateFormat"),
            d = this._getDate(a),
            e = this.formatDate(c, d, this._getFormatConfig(a));
          $(b).each(function () {
            $(this).val(e);
          });
        }
      },
      noWeekends: function (a) {
        var b = a.getDay();
        return [b > 0 && b < 6, ""];
      },
      iso8601Week: function (a) {
        var b = new Date(a.getTime());
        b.setDate(b.getDate() + 4 - (b.getDay() || 7));
        var c = b.getTime();
        return (
          b.setMonth(0),
          b.setDate(1),
          Math.floor(Math.round((c - b) / 864e5) / 7) + 1
        );
      },
      parseDate: function (a, b, c) {
        if (a == null || b == null) throw "Invalid arguments";
        b = typeof b == "object" ? b.toString() : b + "";
        if (b == "") return null;
        var d =
          (c ? c.shortYearCutoff : null) || this._defaults.shortYearCutoff;
        d =
          typeof d != "string"
            ? d
            : (new Date().getFullYear() % 100) + parseInt(d, 10);
        var e = (c ? c.dayNamesShort : null) || this._defaults.dayNamesShort,
          f = (c ? c.dayNames : null) || this._defaults.dayNames,
          g = (c ? c.monthNamesShort : null) || this._defaults.monthNamesShort,
          h = (c ? c.monthNames : null) || this._defaults.monthNames,
          i = -1,
          j = -1,
          k = -1,
          l = -1,
          m = !1,
          n = function (b) {
            var c = s + 1 < a.length && a.charAt(s + 1) == b;
            return c && s++, c;
          },
          o = function (a) {
            var c = n(a),
              d =
                a == "@"
                  ? 14
                  : a == "!"
                  ? 20
                  : a == "y" && c
                  ? 4
                  : a == "o"
                  ? 3
                  : 2,
              e = new RegExp("^\\d{1," + d + "}"),
              f = b.substring(r).match(e);
            if (!f) throw "Missing number at position " + r;
            return (r += f[0].length), parseInt(f[0], 10);
          },
          p = function (a, c, d) {
            var e = $.map(n(a) ? d : c, function (a, b) {
                return [[b, a]];
              }).sort(function (a, b) {
                return -(a[1].length - b[1].length);
              }),
              f = -1;
            $.each(e, function (a, c) {
              var d = c[1];
              if (b.substr(r, d.length).toLowerCase() == d.toLowerCase())
                return (f = c[0]), (r += d.length), !1;
            });
            if (f != -1) return f + 1;
            throw "Unknown name at position " + r;
          },
          q = function () {
            if (b.charAt(r) != a.charAt(s))
              throw "Unexpected literal at position " + r;
            r++;
          },
          r = 0;
        for (var s = 0; s < a.length; s++)
          if (m) a.charAt(s) == "'" && !n("'") ? (m = !1) : q();
          else
            switch (a.charAt(s)) {
              case "d":
                k = o("d");
                break;
              case "D":
                p("D", e, f);
                break;
              case "o":
                l = o("o");
                break;
              case "m":
                j = o("m");
                break;
              case "M":
                j = p("M", g, h);
                break;
              case "y":
                i = o("y");
                break;
              case "@":
                var t = new Date(o("@"));
                (i = t.getFullYear()),
                  (j = t.getMonth() + 1),
                  (k = t.getDate());
                break;
              case "!":
                var t = new Date((o("!") - this._ticksTo1970) / 1e4);
                (i = t.getFullYear()),
                  (j = t.getMonth() + 1),
                  (k = t.getDate());
                break;
              case "'":
                n("'") ? q() : (m = !0);
                break;
              default:
                q();
            }
        if (r < b.length)
          throw "Extra/unparsed characters found in date: " + b.substring(r);
        i == -1
          ? (i = new Date().getFullYear())
          : i < 100 &&
            (i +=
              new Date().getFullYear() -
              (new Date().getFullYear() % 100) +
              (i <= d ? 0 : -100));
        if (l > -1) {
          (j = 1), (k = l);
          do {
            var u = this._getDaysInMonth(i, j - 1);
            if (k <= u) break;
            j++, (k -= u);
          } while (!0);
        }
        var t = this._daylightSavingAdjust(new Date(i, j - 1, k));
        if (t.getFullYear() != i || t.getMonth() + 1 != j || t.getDate() != k)
          throw "Invalid date";
        return t;
      },
      ATOM: "yy-mm-dd",
      COOKIE: "D, dd M yy",
      ISO_8601: "yy-mm-dd",
      RFC_822: "D, d M y",
      RFC_850: "DD, dd-M-y",
      RFC_1036: "D, d M y",
      RFC_1123: "D, d M yy",
      RFC_2822: "D, d M yy",
      RSS: "D, d M y",
      TICKS: "!",
      TIMESTAMP: "@",
      W3C: "yy-mm-dd",
      _ticksTo1970:
        (718685 + Math.floor(492.5) - Math.floor(19.7) + Math.floor(4.925)) *
        24 *
        60 *
        60 *
        1e7,
      formatDate: function (a, b, c) {
        if (!b) return "";
        var d = (c ? c.dayNamesShort : null) || this._defaults.dayNamesShort,
          e = (c ? c.dayNames : null) || this._defaults.dayNames,
          f = (c ? c.monthNamesShort : null) || this._defaults.monthNamesShort,
          g = (c ? c.monthNames : null) || this._defaults.monthNames,
          h = function (b) {
            var c = m + 1 < a.length && a.charAt(m + 1) == b;
            return c && m++, c;
          },
          i = function (a, b, c) {
            var d = "" + b;
            if (h(a)) while (d.length < c) d = "0" + d;
            return d;
          },
          j = function (a, b, c, d) {
            return h(a) ? d[b] : c[b];
          },
          k = "",
          l = !1;
        if (b)
          for (var m = 0; m < a.length; m++)
            if (l)
              a.charAt(m) == "'" && !h("'") ? (l = !1) : (k += a.charAt(m));
            else
              switch (a.charAt(m)) {
                case "d":
                  k += i("d", b.getDate(), 2);
                  break;
                case "D":
                  k += j("D", b.getDay(), d, e);
                  break;
                case "o":
                  k += i(
                    "o",
                    Math.round(
                      (new Date(
                        b.getFullYear(),
                        b.getMonth(),
                        b.getDate()
                      ).getTime() -
                        new Date(b.getFullYear(), 0, 0).getTime()) /
                        864e5
                    ),
                    3
                  );
                  break;
                case "m":
                  k += i("m", b.getMonth() + 1, 2);
                  break;
                case "M":
                  k += j("M", b.getMonth(), f, g);
                  break;
                case "y":
                  k += h("y")
                    ? b.getFullYear()
                    : (b.getYear() % 100 < 10 ? "0" : "") + (b.getYear() % 100);
                  break;
                case "@":
                  k += b.getTime();
                  break;
                case "!":
                  k += b.getTime() * 1e4 + this._ticksTo1970;
                  break;
                case "'":
                  h("'") ? (k += "'") : (l = !0);
                  break;
                default:
                  k += a.charAt(m);
              }
        return k;
      },
      _possibleChars: function (a) {
        var b = "",
          c = !1,
          d = function (b) {
            var c = e + 1 < a.length && a.charAt(e + 1) == b;
            return c && e++, c;
          };
        for (var e = 0; e < a.length; e++)
          if (c) a.charAt(e) == "'" && !d("'") ? (c = !1) : (b += a.charAt(e));
          else
            switch (a.charAt(e)) {
              case "d":
              case "m":
              case "y":
              case "@":
                b += "0123456789";
                break;
              case "D":
              case "M":
                return null;
              case "'":
                d("'") ? (b += "'") : (c = !0);
                break;
              default:
                b += a.charAt(e);
            }
        return b;
      },
      _get: function (a, b) {
        return a.settings[b] !== undefined ? a.settings[b] : this._defaults[b];
      },
      _setDateFromField: function (a, b) {
        if (a.input.val() == a.lastVal) return;
        var c = this._get(a, "dateFormat"),
          d = (a.lastVal = a.input ? a.input.val() : null),
          e,
          f;
        e = f = this._getDefaultDate(a);
        var g = this._getFormatConfig(a);
        try {
          e = this.parseDate(c, d, g) || f;
        } catch (h) {
          this.log(h), (d = b ? "" : d);
        }
        (a.selectedDay = e.getDate()),
          (a.drawMonth = a.selectedMonth = e.getMonth()),
          (a.drawYear = a.selectedYear = e.getFullYear()),
          (a.currentDay = d ? e.getDate() : 0),
          (a.currentMonth = d ? e.getMonth() : 0),
          (a.currentYear = d ? e.getFullYear() : 0),
          this._adjustInstDate(a);
      },
      _getDefaultDate: function (a) {
        return this._restrictMinMax(
          a,
          this._determineDate(a, this._get(a, "defaultDate"), new Date())
        );
      },
      _determineDate: function (a, b, c) {
        var d = function (a) {
            var b = new Date();
            return b.setDate(b.getDate() + a), b;
          },
          e = function (b) {
            try {
              return $.datepicker.parseDate(
                $.datepicker._get(a, "dateFormat"),
                b,
                $.datepicker._getFormatConfig(a)
              );
            } catch (c) {}
            var d =
                (b.toLowerCase().match(/^c/)
                  ? $.datepicker._getDate(a)
                  : null) || new Date(),
              e = d.getFullYear(),
              f = d.getMonth(),
              g = d.getDate(),
              h = /([+-]?[0-9]+)\s*(d|D|w|W|m|M|y|Y)?/g,
              i = h.exec(b);
            while (i) {
              switch (i[2] || "d") {
                case "d":
                case "D":
                  g += parseInt(i[1], 10);
                  break;
                case "w":
                case "W":
                  g += parseInt(i[1], 10) * 7;
                  break;
                case "m":
                case "M":
                  (f += parseInt(i[1], 10)),
                    (g = Math.min(g, $.datepicker._getDaysInMonth(e, f)));
                  break;
                case "y":
                case "Y":
                  (e += parseInt(i[1], 10)),
                    (g = Math.min(g, $.datepicker._getDaysInMonth(e, f)));
              }
              i = h.exec(b);
            }
            return new Date(e, f, g);
          },
          f =
            b == null || b === ""
              ? c
              : typeof b == "string"
              ? e(b)
              : typeof b == "number"
              ? isNaN(b)
                ? c
                : d(b)
              : new Date(b.getTime());
        return (
          (f = f && f.toString() == "Invalid Date" ? c : f),
          f &&
            (f.setHours(0),
            f.setMinutes(0),
            f.setSeconds(0),
            f.setMilliseconds(0)),
          this._daylightSavingAdjust(f)
        );
      },
      _daylightSavingAdjust: function (a) {
        return a
          ? (a.setHours(a.getHours() > 12 ? a.getHours() + 2 : 0), a)
          : null;
      },
      _setDate: function (a, b, c) {
        var d = !b,
          e = a.selectedMonth,
          f = a.selectedYear,
          g = this._restrictMinMax(a, this._determineDate(a, b, new Date()));
        (a.selectedDay = a.currentDay = g.getDate()),
          (a.drawMonth = a.selectedMonth = a.currentMonth = g.getMonth()),
          (a.drawYear = a.selectedYear = a.currentYear = g.getFullYear()),
          (e != a.selectedMonth || f != a.selectedYear) &&
            !c &&
            this._notifyChange(a),
          this._adjustInstDate(a),
          a.input && a.input.val(d ? "" : this._formatDate(a));
      },
      _getDate: function (a) {
        var b =
          !a.currentYear || (a.input && a.input.val() == "")
            ? null
            : this._daylightSavingAdjust(
                new Date(a.currentYear, a.currentMonth, a.currentDay)
              );
        return b;
      },
      _attachHandlers: function (a) {
        var b = this._get(a, "stepMonths"),
          c = "#" + a.id.replace(/\\\\/g, "\\");
        a.dpDiv.find("[data-handler]").map(function () {
          var a = {
            prev: function () {
              window["DP_jQuery_" + dpuuid].datepicker._adjustDate(c, -b, "M");
            },
            next: function () {
              window["DP_jQuery_" + dpuuid].datepicker._adjustDate(c, +b, "M");
            },
            hide: function () {
              window["DP_jQuery_" + dpuuid].datepicker._hideDatepicker();
            },
            today: function () {
              window["DP_jQuery_" + dpuuid].datepicker._gotoToday(c);
            },
            selectDay: function () {
              return (
                window["DP_jQuery_" + dpuuid].datepicker._selectDay(
                  c,
                  +this.getAttribute("data-month"),
                  +this.getAttribute("data-year"),
                  this
                ),
                !1
              );
            },
            selectMonth: function () {
              return (
                window["DP_jQuery_" + dpuuid].datepicker._selectMonthYear(
                  c,
                  this,
                  "M"
                ),
                !1
              );
            },
            selectYear: function () {
              return (
                window["DP_jQuery_" + dpuuid].datepicker._selectMonthYear(
                  c,
                  this,
                  "Y"
                ),
                !1
              );
            },
          };
          $(this).bind(
            this.getAttribute("data-event"),
            a[this.getAttribute("data-handler")]
          );
        });
      },
      _generateHTML: function (a) {
        var b = new Date();
        b = this._daylightSavingAdjust(
          new Date(b.getFullYear(), b.getMonth(), b.getDate())
        );
        var c = this._get(a, "isRTL"),
          d = this._get(a, "showButtonPanel"),
          e = this._get(a, "hideIfNoPrevNext"),
          f = this._get(a, "navigationAsDateFormat"),
          g = this._getNumberOfMonths(a),
          h = this._get(a, "showCurrentAtPos"),
          i = this._get(a, "stepMonths"),
          j = g[0] != 1 || g[1] != 1,
          k = this._daylightSavingAdjust(
            a.currentDay
              ? new Date(a.currentYear, a.currentMonth, a.currentDay)
              : new Date(9999, 9, 9)
          ),
          l = this._getMinMaxDate(a, "min"),
          m = this._getMinMaxDate(a, "max"),
          n = a.drawMonth - h,
          o = a.drawYear;
        n < 0 && ((n += 12), o--);
        if (m) {
          var p = this._daylightSavingAdjust(
            new Date(
              m.getFullYear(),
              m.getMonth() - g[0] * g[1] + 1,
              m.getDate()
            )
          );
          p = l && p < l ? l : p;
          while (this._daylightSavingAdjust(new Date(o, n, 1)) > p)
            n--, n < 0 && ((n = 11), o--);
        }
        (a.drawMonth = n), (a.drawYear = o);
        var q = this._get(a, "prevText");
        q = f
          ? this.formatDate(
              q,
              this._daylightSavingAdjust(new Date(o, n - i, 1)),
              this._getFormatConfig(a)
            )
          : q;
        var r = this._canAdjustMonth(a, -1, o, n)
            ? '<a class="ui-datepicker-prev ui-corner-all" data-handler="prev" data-event="click" title="' +
              q +
              '"><span class="ui-icon ui-icon-circle-triangle-' +
              (c ? "e" : "w") +
              '">' +
              q +
              "</span></a>"
            : e
            ? ""
            : '<a class="ui-datepicker-prev ui-corner-all ui-state-disabled" title="' +
              q +
              '"><span class="ui-icon ui-icon-circle-triangle-' +
              (c ? "e" : "w") +
              '">' +
              q +
              "</span></a>",
          s = this._get(a, "nextText");
        s = f
          ? this.formatDate(
              s,
              this._daylightSavingAdjust(new Date(o, n + i, 1)),
              this._getFormatConfig(a)
            )
          : s;
        var t = this._canAdjustMonth(a, 1, o, n)
            ? '<a class="ui-datepicker-next ui-corner-all" data-handler="next" data-event="click" title="' +
              s +
              '"><span class="ui-icon ui-icon-circle-triangle-' +
              (c ? "w" : "e") +
              '">' +
              s +
              "</span></a>"
            : e
            ? ""
            : '<a class="ui-datepicker-next ui-corner-all ui-state-disabled" title="' +
              s +
              '"><span class="ui-icon ui-icon-circle-triangle-' +
              (c ? "w" : "e") +
              '">' +
              s +
              "</span></a>",
          u = this._get(a, "currentText"),
          v = this._get(a, "gotoCurrent") && a.currentDay ? k : b;
        u = f ? this.formatDate(u, v, this._getFormatConfig(a)) : u;
        var w = a.inline
            ? ""
            : '<button type="button" class="ui-datepicker-close ui-state-default ui-priority-primary ui-corner-all" data-handler="hide" data-event="click">' +
              this._get(a, "closeText") +
              "</button>",
          x = d
            ? '<div class="ui-datepicker-buttonpane ui-widget-content">' +
              (c ? w : "") +
              (this._isInRange(a, v)
                ? '<button type="button" class="ui-datepicker-current ui-state-default ui-priority-secondary ui-corner-all" data-handler="today" data-event="click">' +
                  u +
                  "</button>"
                : "") +
              (c ? "" : w) +
              "</div>"
            : "",
          y = parseInt(this._get(a, "firstDay"), 10);
        y = isNaN(y) ? 0 : y;
        var z = this._get(a, "showWeek"),
          A = this._get(a, "dayNames"),
          B = this._get(a, "dayNamesShort"),
          C = this._get(a, "dayNamesMin"),
          D = this._get(a, "monthNames"),
          E = this._get(a, "monthNamesShort"),
          F = this._get(a, "beforeShowDay"),
          G = this._get(a, "showOtherMonths"),
          H = this._get(a, "selectOtherMonths"),
          I = this._get(a, "calculateWeek") || this.iso8601Week,
          J = this._getDefaultDate(a),
          K = "";
        for (var L = 0; L < g[0]; L++) {
          var M = "";
          this.maxRows = 4;
          for (var N = 0; N < g[1]; N++) {
            var O = this._daylightSavingAdjust(new Date(o, n, a.selectedDay)),
              P = " ui-corner-all",
              Q = "";
            if (j) {
              Q += '<div class="ui-datepicker-group';
              if (g[1] > 1)
                switch (N) {
                  case 0:
                    (Q += " ui-datepicker-group-first"),
                      (P = " ui-corner-" + (c ? "right" : "left"));
                    break;
                  case g[1] - 1:
                    (Q += " ui-datepicker-group-last"),
                      (P = " ui-corner-" + (c ? "left" : "right"));
                    break;
                  default:
                    (Q += " ui-datepicker-group-middle"), (P = "");
                }
              Q += '">';
            }
            Q +=
              '<div class="ui-datepicker-header ui-widget-header ui-helper-clearfix' +
              P +
              '">' +
              (/all|left/.test(P) && L == 0 ? (c ? t : r) : "") +
              (/all|right/.test(P) && L == 0 ? (c ? r : t) : "") +
              this._generateMonthYearHeader(
                a,
                n,
                o,
                l,
                m,
                L > 0 || N > 0,
                D,
                E
              ) +
              '</div><table class="ui-datepicker-calendar"><thead>' +
              "<tr>";
            var R = z
              ? '<th class="ui-datepicker-week-col">' +
                this._get(a, "weekHeader") +
                "</th>"
              : "";
            for (var S = 0; S < 7; S++) {
              var T = (S + y) % 7;
              R +=
                "<th" +
                ((S + y + 6) % 7 >= 5
                  ? ' class="ui-datepicker-week-end"'
                  : "") +
                ">" +
                '<span title="' +
                A[T] +
                '">' +
                C[T] +
                "</span></th>";
            }
            Q += R + "</tr></thead><tbody>";
            var U = this._getDaysInMonth(o, n);
            o == a.selectedYear &&
              n == a.selectedMonth &&
              (a.selectedDay = Math.min(a.selectedDay, U));
            var V = (this._getFirstDayOfMonth(o, n) - y + 7) % 7,
              W = Math.ceil((V + U) / 7),
              X = j ? (this.maxRows > W ? this.maxRows : W) : W;
            this.maxRows = X;
            var Y = this._daylightSavingAdjust(new Date(o, n, 1 - V));
            for (var Z = 0; Z < X; Z++) {
              Q += "<tr>";
              var _ = z
                ? '<td class="ui-datepicker-week-col">' +
                  this._get(a, "calculateWeek")(Y) +
                  "</td>"
                : "";
              for (var S = 0; S < 7; S++) {
                var ba = F
                    ? F.apply(a.input ? a.input[0] : null, [Y])
                    : [!0, ""],
                  bb = Y.getMonth() != n,
                  bc = (bb && !H) || !ba[0] || (l && Y < l) || (m && Y > m);
                (_ +=
                  '<td class="' +
                  ((S + y + 6) % 7 >= 5 ? " ui-datepicker-week-end" : "") +
                  (bb ? " ui-datepicker-other-month" : "") +
                  ((Y.getTime() == O.getTime() &&
                    n == a.selectedMonth &&
                    a._keyEvent) ||
                  (J.getTime() == Y.getTime() && J.getTime() == O.getTime())
                    ? " " + this._dayOverClass
                    : "") +
                  (bc
                    ? " " + this._unselectableClass + " ui-state-disabled"
                    : "") +
                  (bb && !G
                    ? ""
                    : " " +
                      ba[1] +
                      (Y.getTime() == k.getTime()
                        ? " " + this._currentClass
                        : "") +
                      (Y.getTime() == b.getTime()
                        ? " ui-datepicker-today"
                        : "")) +
                  '"' +
                  ((!bb || G) && ba[2] ? ' title="' + ba[2] + '"' : "") +
                  (bc
                    ? ""
                    : ' data-handler="selectDay" data-event="click" data-month="' +
                      Y.getMonth() +
                      '" data-year="' +
                      Y.getFullYear() +
                      '"') +
                  ">" +
                  (bb && !G
                    ? "&#xa0;"
                    : bc
                    ? '<span class="ui-state-default">' +
                      Y.getDate() +
                      "</span>"
                    : '<a class="ui-state-default' +
                      (Y.getTime() == b.getTime()
                        ? " ui-state-highlight"
                        : "") +
                      (Y.getTime() == k.getTime() ? " ui-state-active" : "") +
                      (bb ? " ui-priority-secondary" : "") +
                      '" href="#">' +
                      Y.getDate() +
                      "</a>") +
                  "</td>"),
                  Y.setDate(Y.getDate() + 1),
                  (Y = this._daylightSavingAdjust(Y));
              }
              Q += _ + "</tr>";
            }
            n++,
              n > 11 && ((n = 0), o++),
              (Q +=
                "</tbody></table>" +
                (j
                  ? "</div>" +
                    (g[0] > 0 && N == g[1] - 1
                      ? '<div class="ui-datepicker-row-break"></div>'
                      : "")
                  : "")),
              (M += Q);
          }
          K += M;
        }
        return (
          (K +=
            x +
            ($.browser.msie && parseInt($.browser.version, 10) < 7 && !a.inline
              ? '<iframe src="javascript:false;" class="ui-datepicker-cover" frameborder="0"></iframe>'
              : "")),
          (a._keyEvent = !1),
          K
        );
      },
      _generateMonthYearHeader: function (a, b, c, d, e, f, g, h) {
        var i = this._get(a, "changeMonth"),
          j = this._get(a, "changeYear"),
          k = this._get(a, "showMonthAfterYear"),
          l = '<div class="ui-datepicker-title">',
          m = "";
        if (f || !i)
          m += '<span class="ui-datepicker-month">' + g[b] + "</span>";
        else {
          var n = d && d.getFullYear() == c,
            o = e && e.getFullYear() == c;
          m +=
            '<select class="ui-datepicker-month" data-handler="selectMonth" data-event="change">';
          for (var p = 0; p < 12; p++)
            (!n || p >= d.getMonth()) &&
              (!o || p <= e.getMonth()) &&
              (m +=
                '<option value="' +
                p +
                '"' +
                (p == b ? ' selected="selected"' : "") +
                ">" +
                h[p] +
                "</option>");
          m += "</select>";
        }
        k || (l += m + (f || !i || !j ? "&#xa0;" : ""));
        if (!a.yearshtml) {
          a.yearshtml = "";
          if (f || !j) l += '<span class="ui-datepicker-year">' + c + "</span>";
          else {
            var q = this._get(a, "yearRange").split(":"),
              r = new Date().getFullYear(),
              s = function (a) {
                var b = a.match(/c[+-].*/)
                  ? c + parseInt(a.substring(1), 10)
                  : a.match(/[+-].*/)
                  ? r + parseInt(a, 10)
                  : parseInt(a, 10);
                return isNaN(b) ? r : b;
              },
              t = s(q[0]),
              u = Math.max(t, s(q[1] || ""));
            (t = d ? Math.max(t, d.getFullYear()) : t),
              (u = e ? Math.min(u, e.getFullYear()) : u),
              (a.yearshtml +=
                '<select class="ui-datepicker-year" data-handler="selectYear" data-event="change">');
            for (; t <= u; t++)
              a.yearshtml +=
                '<option value="' +
                t +
                '"' +
                (t == c ? ' selected="selected"' : "") +
                ">" +
                t +
                "</option>";
            (a.yearshtml += "</select>"),
              (l += a.yearshtml),
              (a.yearshtml = null);
          }
        }
        return (
          (l += this._get(a, "yearSuffix")),
          k && (l += (f || !i || !j ? "&#xa0;" : "") + m),
          (l += "</div>"),
          l
        );
      },
      _adjustInstDate: function (a, b, c) {
        var d = a.drawYear + (c == "Y" ? b : 0),
          e = a.drawMonth + (c == "M" ? b : 0),
          f =
            Math.min(a.selectedDay, this._getDaysInMonth(d, e)) +
            (c == "D" ? b : 0),
          g = this._restrictMinMax(
            a,
            this._daylightSavingAdjust(new Date(d, e, f))
          );
        (a.selectedDay = g.getDate()),
          (a.drawMonth = a.selectedMonth = g.getMonth()),
          (a.drawYear = a.selectedYear = g.getFullYear()),
          (c == "M" || c == "Y") && this._notifyChange(a);
      },
      _restrictMinMax: function (a, b) {
        var c = this._getMinMaxDate(a, "min"),
          d = this._getMinMaxDate(a, "max"),
          e = c && b < c ? c : b;
        return (e = d && e > d ? d : e), e;
      },
      _notifyChange: function (a) {
        var b = this._get(a, "onChangeMonthYear");
        b &&
          b.apply(a.input ? a.input[0] : null, [
            a.selectedYear,
            a.selectedMonth + 1,
            a,
          ]);
      },
      _getNumberOfMonths: function (a) {
        var b = this._get(a, "numberOfMonths");
        return b == null ? [1, 1] : typeof b == "number" ? [1, b] : b;
      },
      _getMinMaxDate: function (a, b) {
        return this._determineDate(a, this._get(a, b + "Date"), null);
      },
      _getDaysInMonth: function (a, b) {
        return 32 - this._daylightSavingAdjust(new Date(a, b, 32)).getDate();
      },
      _getFirstDayOfMonth: function (a, b) {
        return new Date(a, b, 1).getDay();
      },
      _canAdjustMonth: function (a, b, c, d) {
        var e = this._getNumberOfMonths(a),
          f = this._daylightSavingAdjust(
            new Date(c, d + (b < 0 ? b : e[0] * e[1]), 1)
          );
        return (
          b < 0 &&
            f.setDate(this._getDaysInMonth(f.getFullYear(), f.getMonth())),
          this._isInRange(a, f)
        );
      },
      _isInRange: function (a, b) {
        var c = this._getMinMaxDate(a, "min"),
          d = this._getMinMaxDate(a, "max");
        return (
          (!c || b.getTime() >= c.getTime()) &&
          (!d || b.getTime() <= d.getTime())
        );
      },
      _getFormatConfig: function (a) {
        var b = this._get(a, "shortYearCutoff");
        return (
          (b =
            typeof b != "string"
              ? b
              : (new Date().getFullYear() % 100) + parseInt(b, 10)),
          {
            shortYearCutoff: b,
            dayNamesShort: this._get(a, "dayNamesShort"),
            dayNames: this._get(a, "dayNames"),
            monthNamesShort: this._get(a, "monthNamesShort"),
            monthNames: this._get(a, "monthNames"),
          }
        );
      },
      _formatDate: function (a, b, c, d) {
        b ||
          ((a.currentDay = a.selectedDay),
          (a.currentMonth = a.selectedMonth),
          (a.currentYear = a.selectedYear));
        var e = b
          ? typeof b == "object"
            ? b
            : this._daylightSavingAdjust(new Date(d, c, b))
          : this._daylightSavingAdjust(
              new Date(a.currentYear, a.currentMonth, a.currentDay)
            );
        return this.formatDate(
          this._get(a, "dateFormat"),
          e,
          this._getFormatConfig(a)
        );
      },
    }),
      ($.fn.datepicker = function (a) {
        if (!this.length) return this;
        $.datepicker.initialized ||
          ($(document)
            .mousedown($.datepicker._checkExternalClick)
            .find("body")
            .append($.datepicker.dpDiv),
          ($.datepicker.initialized = !0));
        var b = Array.prototype.slice.call(arguments, 1);
        return typeof a != "string" ||
          (a != "isDisabled" && a != "getDate" && a != "widget")
          ? a == "option" &&
            arguments.length == 2 &&
            typeof arguments[1] == "string"
            ? $.datepicker["_" + a + "Datepicker"].apply(
                $.datepicker,
                [this[0]].concat(b)
              )
            : this.each(function () {
                typeof a == "string"
                  ? $.datepicker["_" + a + "Datepicker"].apply(
                      $.datepicker,
                      [this].concat(b)
                    )
                  : $.datepicker._attachDatepicker(this, a);
              })
          : $.datepicker["_" + a + "Datepicker"].apply(
              $.datepicker,
              [this[0]].concat(b)
            );
      }),
      ($.datepicker = new Datepicker()),
      ($.datepicker.initialized = !1),
      ($.datepicker.uuid = new Date().getTime()),
      ($.datepicker.version = "1.8.24"),
      (window["DP_jQuery_" + dpuuid] = $);
  })(jQuery),
  (function (a, b) {
    var c = "ui-dialog ui-widget ui-widget-content ui-corner-all ",
      d = {
        buttons: !0,
        height: !0,
        maxHeight: !0,
        maxWidth: !0,
        minHeight: !0,
        minWidth: !0,
        width: !0,
      },
      e = { maxHeight: !0, maxWidth: !0, minHeight: !0, minWidth: !0 };
    a.widget("ui.dialog", {
      options: {
        autoOpen: !0,
        buttons: {},
        closeOnEscape: !0,
        closeText: "close",
        dialogClass: "",
        draggable: !0,
        hide: null,
        height: "auto",
        maxHeight: !1,
        maxWidth: !1,
        minHeight: 150,
        minWidth: 150,
        modal: !1,
        position: {
          my: "center",
          at: "center",
          collision: "fit",
          using: function (b) {
            var c = a(this).css(b).offset().top;
            c < 0 && a(this).css("top", b.top - c);
          },
        },
        resizable: !0,
        show: null,
        stack: !0,
        title: "",
        width: 300,
        zIndex: 1e3,
      },
      _create: function () {
        (this.originalTitle = this.element.attr("title")),
          typeof this.originalTitle != "string" && (this.originalTitle = ""),
          (this.options.title = this.options.title || this.originalTitle);
        var b = this,
          d = b.options,
          e = d.title || "&#160;",
          f = a.ui.dialog.getTitleId(b.element),
          g = (b.uiDialog = a("<div></div>"))
            .appendTo(document.body)
            .hide()
            .addClass(c + d.dialogClass)
            .css({ zIndex: d.zIndex })
            .attr("tabIndex", -1)
            .css("outline", 0)
            .keydown(function (c) {
              d.closeOnEscape &&
                !c.isDefaultPrevented() &&
                c.keyCode &&
                c.keyCode === a.ui.keyCode.ESCAPE &&
                (b.close(c), c.preventDefault());
            })
            .attr({ role: "dialog", "aria-labelledby": f })
            .mousedown(function (a) {
              b.moveToTop(!1, a);
            }),
          h = b.element
            .show()
            .removeAttr("title")
            .addClass("ui-dialog-content ui-widget-content")
            .appendTo(g),
          i = (b.uiDialogTitlebar = a("<div></div>"))
            .addClass(
              "ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix"
            )
            .prependTo(g),
          j = a('<a href="#"></a>')
            .addClass("ui-dialog-titlebar-close ui-corner-all")
            .attr("role", "button")
            .hover(
              function () {
                j.addClass("ui-state-hover");
              },
              function () {
                j.removeClass("ui-state-hover");
              }
            )
            .focus(function () {
              j.addClass("ui-state-focus");
            })
            .blur(function () {
              j.removeClass("ui-state-focus");
            })
            .click(function (a) {
              return b.close(a), !1;
            })
            .appendTo(i),
          k = (b.uiDialogTitlebarCloseText = a("<span></span>"))
            .addClass("ui-icon ui-icon-closethick")
            .text(d.closeText)
            .appendTo(j),
          l = a("<span></span>")
            .addClass("ui-dialog-title")
            .attr("id", f)
            .html(e)
            .prependTo(i);
        a.isFunction(d.beforeclose) &&
          !a.isFunction(d.beforeClose) &&
          (d.beforeClose = d.beforeclose),
          i.find("*").add(i).disableSelection(),
          d.draggable && a.fn.draggable && b._makeDraggable(),
          d.resizable && a.fn.resizable && b._makeResizable(),
          b._createButtons(d.buttons),
          (b._isOpen = !1),
          a.fn.bgiframe && g.bgiframe();
      },
      _init: function () {
        this.options.autoOpen && this.open();
      },
      destroy: function () {
        var a = this;
        return (
          a.overlay && a.overlay.destroy(),
          a.uiDialog.hide(),
          a.element
            .unbind(".dialog")
            .removeData("dialog")
            .removeClass("ui-dialog-content ui-widget-content")
            .hide()
            .appendTo("body"),
          a.uiDialog.remove(),
          a.originalTitle && a.element.attr("title", a.originalTitle),
          a
        );
      },
      widget: function () {
        return this.uiDialog;
      },
      close: function (b) {
        var c = this,
          d,
          e;
        if (!1 === c._trigger("beforeClose", b)) return;
        return (
          c.overlay && c.overlay.destroy(),
          c.uiDialog.unbind("keypress.ui-dialog"),
          (c._isOpen = !1),
          c.options.hide
            ? c.uiDialog.hide(c.options.hide, function () {
                c._trigger("close", b);
              })
            : (c.uiDialog.hide(), c._trigger("close", b)),
          a.ui.dialog.overlay.resize(),
          c.options.modal &&
            ((d = 0),
            a(".ui-dialog").each(function () {
              this !== c.uiDialog[0] &&
                ((e = a(this).css("z-index")),
                isNaN(e) || (d = Math.max(d, e)));
            }),
            (a.ui.dialog.maxZ = d)),
          c
        );
      },
      isOpen: function () {
        return this._isOpen;
      },
      moveToTop: function (b, c) {
        var d = this,
          e = d.options,
          f;
        return (e.modal && !b) || (!e.stack && !e.modal)
          ? d._trigger("focus", c)
          : (e.zIndex > a.ui.dialog.maxZ && (a.ui.dialog.maxZ = e.zIndex),
            d.overlay &&
              ((a.ui.dialog.maxZ += 1),
              d.overlay.$el.css(
                "z-index",
                (a.ui.dialog.overlay.maxZ = a.ui.dialog.maxZ)
              )),
            (f = {
              scrollTop: d.element.scrollTop(),
              scrollLeft: d.element.scrollLeft(),
            }),
            (a.ui.dialog.maxZ += 1),
            d.uiDialog.css("z-index", a.ui.dialog.maxZ),
            d.element.attr(f),
            d._trigger("focus", c),
            d);
      },
      open: function () {
        if (this._isOpen) return;
        var b = this,
          c = b.options,
          d = b.uiDialog;
        return (
          (b.overlay = c.modal ? new a.ui.dialog.overlay(b) : null),
          b._size(),
          b._position(c.position),
          d.show(c.show),
          b.moveToTop(!0),
          c.modal &&
            d.bind("keydown.ui-dialog", function (b) {
              if (b.keyCode !== a.ui.keyCode.TAB) return;
              var c = a(":tabbable", this),
                d = c.filter(":first"),
                e = c.filter(":last");
              if (b.target === e[0] && !b.shiftKey) return d.focus(1), !1;
              if (b.target === d[0] && b.shiftKey) return e.focus(1), !1;
            }),
          a(
            b.element
              .find(":tabbable")
              .get()
              .concat(
                d.find(".ui-dialog-buttonpane :tabbable").get().concat(d.get())
              )
          )
            .eq(0)
            .focus(),
          (b._isOpen = !0),
          b._trigger("open"),
          b
        );
      },
      _createButtons: function (b) {
        var c = this,
          d = !1,
          e = a("<div></div>").addClass(
            "ui-dialog-buttonpane ui-widget-content ui-helper-clearfix"
          ),
          f = a("<div></div>").addClass("ui-dialog-buttonset").appendTo(e);
        c.uiDialog.find(".ui-dialog-buttonpane").remove(),
          typeof b == "object" &&
            b !== null &&
            a.each(b, function () {
              return !(d = !0);
            }),
          d &&
            (a.each(b, function (b, d) {
              d = a.isFunction(d) ? { click: d, text: b } : d;
              var e = a('<button type="button"></button>')
                .click(function () {
                  d.click.apply(c.element[0], arguments);
                })
                .appendTo(f);
              a.each(d, function (a, b) {
                if (a === "click") return;
                a in e ? e[a](b) : e.attr(a, b);
              }),
                a.fn.button && e.button();
            }),
            e.appendTo(c.uiDialog));
      },
      _makeDraggable: function () {
        function f(a) {
          return { position: a.position, offset: a.offset };
        }
        var b = this,
          c = b.options,
          d = a(document),
          e;
        b.uiDialog.draggable({
          cancel: ".ui-dialog-content, .ui-dialog-titlebar-close",
          handle: ".ui-dialog-titlebar",
          containment: "document",
          start: function (d, g) {
            (e = c.height === "auto" ? "auto" : a(this).height()),
              a(this).height(a(this).height()).addClass("ui-dialog-dragging"),
              b._trigger("dragStart", d, f(g));
          },
          drag: function (a, c) {
            b._trigger("drag", a, f(c));
          },
          stop: function (g, h) {
            (c.position = [
              h.position.left - d.scrollLeft(),
              h.position.top - d.scrollTop(),
            ]),
              a(this).removeClass("ui-dialog-dragging").height(e),
              b._trigger("dragStop", g, f(h)),
              a.ui.dialog.overlay.resize();
          },
        });
      },
      _makeResizable: function (c) {
        function h(a) {
          return {
            originalPosition: a.originalPosition,
            originalSize: a.originalSize,
            position: a.position,
            size: a.size,
          };
        }
        c = c === b ? this.options.resizable : c;
        var d = this,
          e = d.options,
          f = d.uiDialog.css("position"),
          g = typeof c == "string" ? c : "n,e,s,w,se,sw,ne,nw";
        d.uiDialog
          .resizable({
            cancel: ".ui-dialog-content",
            containment: "document",
            alsoResize: d.element,
            maxWidth: e.maxWidth,
            maxHeight: e.maxHeight,
            minWidth: e.minWidth,
            minHeight: d._minHeight(),
            handles: g,
            start: function (b, c) {
              a(this).addClass("ui-dialog-resizing"),
                d._trigger("resizeStart", b, h(c));
            },
            resize: function (a, b) {
              d._trigger("resize", a, h(b));
            },
            stop: function (b, c) {
              a(this).removeClass("ui-dialog-resizing"),
                (e.height = a(this).height()),
                (e.width = a(this).width()),
                d._trigger("resizeStop", b, h(c)),
                a.ui.dialog.overlay.resize();
            },
          })
          .css("position", f)
          .find(".ui-resizable-se")
          .addClass("ui-icon ui-icon-grip-diagonal-se");
      },
      _minHeight: function () {
        var a = this.options;
        return a.height === "auto"
          ? a.minHeight
          : Math.min(a.minHeight, a.height);
      },
      _position: function (b) {
        var c = [],
          d = [0, 0],
          e;
        if (b) {
          if (typeof b == "string" || (typeof b == "object" && "0" in b))
            (c = b.split ? b.split(" ") : [b[0], b[1]]),
              c.length === 1 && (c[1] = c[0]),
              a.each(["left", "top"], function (a, b) {
                +c[a] === c[a] && ((d[a] = c[a]), (c[a] = b));
              }),
              (b = { my: c.join(" "), at: c.join(" "), offset: d.join(" ") });
          b = a.extend({}, a.ui.dialog.prototype.options.position, b);
        } else b = a.ui.dialog.prototype.options.position;
        (e = this.uiDialog.is(":visible")),
          e || this.uiDialog.show(),
          this.uiDialog
            .css({ top: 0, left: 0 })
            .position(a.extend({ of: window }, b)),
          e || this.uiDialog.hide();
      },
      _setOptions: function (b) {
        var c = this,
          f = {},
          g = !1;
        a.each(b, function (a, b) {
          c._setOption(a, b), a in d && (g = !0), a in e && (f[a] = b);
        }),
          g && this._size(),
          this.uiDialog.is(":data(resizable)") &&
            this.uiDialog.resizable("option", f);
      },
      _setOption: function (b, d) {
        var e = this,
          f = e.uiDialog;
        switch (b) {
          case "beforeclose":
            b = "beforeClose";
            break;
          case "buttons":
            e._createButtons(d);
            break;
          case "closeText":
            e.uiDialogTitlebarCloseText.text("" + d);
            break;
          case "dialogClass":
            f.removeClass(e.options.dialogClass).addClass(c + d);
            break;
          case "disabled":
            d
              ? f.addClass("ui-dialog-disabled")
              : f.removeClass("ui-dialog-disabled");
            break;
          case "draggable":
            var g = f.is(":data(draggable)");
            g && !d && f.draggable("destroy"), !g && d && e._makeDraggable();
            break;
          case "position":
            e._position(d);
            break;
          case "resizable":
            var h = f.is(":data(resizable)");
            h && !d && f.resizable("destroy"),
              h && typeof d == "string" && f.resizable("option", "handles", d),
              !h && d !== !1 && e._makeResizable(d);
            break;
          case "title":
            a(".ui-dialog-title", e.uiDialogTitlebar).html(
              "" + (d || "&#160;")
            );
        }
        a.Widget.prototype._setOption.apply(e, arguments);
      },
      _size: function () {
        var b = this.options,
          c,
          d,
          e = this.uiDialog.is(":visible");
        this.element.show().css({ width: "auto", minHeight: 0, height: 0 }),
          b.minWidth > b.width && (b.width = b.minWidth),
          (c = this.uiDialog.css({ height: "auto", width: b.width }).height()),
          (d = Math.max(0, b.minHeight - c));
        if (b.height === "auto")
          if (a.support.minHeight)
            this.element.css({ minHeight: d, height: "auto" });
          else {
            this.uiDialog.show();
            var f = this.element.css("height", "auto").height();
            e || this.uiDialog.hide(), this.element.height(Math.max(f, d));
          }
        else this.element.height(Math.max(b.height - c, 0));
        this.uiDialog.is(":data(resizable)") &&
          this.uiDialog.resizable("option", "minHeight", this._minHeight());
      },
    }),
      a.extend(a.ui.dialog, {
        version: "1.8.24",
        uuid: 0,
        maxZ: 0,
        getTitleId: function (a) {
          var b = a.attr("id");
          return (
            b || ((this.uuid += 1), (b = this.uuid)), "ui-dialog-title-" + b
          );
        },
        overlay: function (b) {
          this.$el = a.ui.dialog.overlay.create(b);
        },
      }),
      a.extend(a.ui.dialog.overlay, {
        instances: [],
        oldInstances: [],
        maxZ: 0,
        events: a
          .map(
            "focus,mousedown,mouseup,keydown,keypress,click".split(","),
            function (a) {
              return a + ".dialog-overlay";
            }
          )
          .join(" "),
        create: function (b) {
          this.instances.length === 0 &&
            (setTimeout(function () {
              a.ui.dialog.overlay.instances.length &&
                a(document).bind(a.ui.dialog.overlay.events, function (b) {
                  if (a(b.target).zIndex() < a.ui.dialog.overlay.maxZ)
                    return !1;
                });
            }, 1),
            a(document).bind("keydown.dialog-overlay", function (c) {
              b.options.closeOnEscape &&
                !c.isDefaultPrevented() &&
                c.keyCode &&
                c.keyCode === a.ui.keyCode.ESCAPE &&
                (b.close(c), c.preventDefault());
            }),
            a(window).bind(
              "resize.dialog-overlay",
              a.ui.dialog.overlay.resize
            ));
          var c = (
            this.oldInstances.pop() ||
            a("<div></div>").addClass("ui-widget-overlay")
          )
            .appendTo(document.body)
            .css({ width: this.width(), height: this.height() });
          return a.fn.bgiframe && c.bgiframe(), this.instances.push(c), c;
        },
        destroy: function (b) {
          var c = a.inArray(b, this.instances);
          c != -1 && this.oldInstances.push(this.instances.splice(c, 1)[0]),
            this.instances.length === 0 &&
              a([document, window]).unbind(".dialog-overlay"),
            b.remove();
          var d = 0;
          a.each(this.instances, function () {
            d = Math.max(d, this.css("z-index"));
          }),
            (this.maxZ = d);
        },
        height: function () {
          var b, c;
          return a.browser.msie && a.browser.version < 7
            ? ((b = Math.max(
                document.documentElement.scrollHeight,
                document.body.scrollHeight
              )),
              (c = Math.max(
                document.documentElement.offsetHeight,
                document.body.offsetHeight
              )),
              b < c ? a(window).height() + "px" : b + "px")
            : a(document).height() + "px";
        },
        width: function () {
          var b, c;
          return a.browser.msie
            ? ((b = Math.max(
                document.documentElement.scrollWidth,
                document.body.scrollWidth
              )),
              (c = Math.max(
                document.documentElement.offsetWidth,
                document.body.offsetWidth
              )),
              b < c ? a(window).width() + "px" : b + "px")
            : a(document).width() + "px";
        },
        resize: function () {
          var b = a([]);
          a.each(a.ui.dialog.overlay.instances, function () {
            b = b.add(this);
          }),
            b
              .css({ width: 0, height: 0 })
              .css({
                width: a.ui.dialog.overlay.width(),
                height: a.ui.dialog.overlay.height(),
              });
        },
      }),
      a.extend(a.ui.dialog.overlay.prototype, {
        destroy: function () {
          a.ui.dialog.overlay.destroy(this.$el);
        },
      });
  })(jQuery),
  (function (a, b) {
    a.ui = a.ui || {};
    var c = /left|center|right/,
      d = /top|center|bottom/,
      e = "center",
      f = {},
      g = a.fn.position,
      h = a.fn.offset;
    (a.fn.position = function (b) {
      if (!b || !b.of) return g.apply(this, arguments);
      b = a.extend({}, b);
      var h = a(b.of),
        i = h[0],
        j = (b.collision || "flip").split(" "),
        k = b.offset ? b.offset.split(" ") : [0, 0],
        l,
        m,
        n;
      return (
        i.nodeType === 9
          ? ((l = h.width()), (m = h.height()), (n = { top: 0, left: 0 }))
          : i.setTimeout
          ? ((l = h.width()),
            (m = h.height()),
            (n = { top: h.scrollTop(), left: h.scrollLeft() }))
          : i.preventDefault
          ? ((b.at = "left top"),
            (l = m = 0),
            (n = { top: b.of.pageY, left: b.of.pageX }))
          : ((l = h.outerWidth()), (m = h.outerHeight()), (n = h.offset())),
        a.each(["my", "at"], function () {
          var a = (b[this] || "").split(" ");
          a.length === 1 &&
            (a = c.test(a[0])
              ? a.concat([e])
              : d.test(a[0])
              ? [e].concat(a)
              : [e, e]),
            (a[0] = c.test(a[0]) ? a[0] : e),
            (a[1] = d.test(a[1]) ? a[1] : e),
            (b[this] = a);
        }),
        j.length === 1 && (j[1] = j[0]),
        (k[0] = parseInt(k[0], 10) || 0),
        k.length === 1 && (k[1] = k[0]),
        (k[1] = parseInt(k[1], 10) || 0),
        b.at[0] === "right"
          ? (n.left += l)
          : b.at[0] === e && (n.left += l / 2),
        b.at[1] === "bottom" ? (n.top += m) : b.at[1] === e && (n.top += m / 2),
        (n.left += k[0]),
        (n.top += k[1]),
        this.each(function () {
          var c = a(this),
            d = c.outerWidth(),
            g = c.outerHeight(),
            h = parseInt(a.curCSS(this, "marginLeft", !0)) || 0,
            i = parseInt(a.curCSS(this, "marginTop", !0)) || 0,
            o = d + h + (parseInt(a.curCSS(this, "marginRight", !0)) || 0),
            p = g + i + (parseInt(a.curCSS(this, "marginBottom", !0)) || 0),
            q = a.extend({}, n),
            r;
          b.my[0] === "right"
            ? (q.left -= d)
            : b.my[0] === e && (q.left -= d / 2),
            b.my[1] === "bottom"
              ? (q.top -= g)
              : b.my[1] === e && (q.top -= g / 2),
            f.fractions ||
              ((q.left = Math.round(q.left)), (q.top = Math.round(q.top))),
            (r = { left: q.left - h, top: q.top - i }),
            a.each(["left", "top"], function (c, e) {
              a.ui.position[j[c]] &&
                a.ui.position[j[c]][e](q, {
                  targetWidth: l,
                  targetHeight: m,
                  elemWidth: d,
                  elemHeight: g,
                  collisionPosition: r,
                  collisionWidth: o,
                  collisionHeight: p,
                  offset: k,
                  my: b.my,
                  at: b.at,
                });
            }),
            a.fn.bgiframe && c.bgiframe(),
            c.offset(a.extend(q, { using: b.using }));
        })
      );
    }),
      (a.ui.position = {
        fit: {
          left: function (b, c) {
            var d = a(window),
              e =
                c.collisionPosition.left +
                c.collisionWidth -
                d.width() -
                d.scrollLeft();
            b.left =
              e > 0
                ? b.left - e
                : Math.max(b.left - c.collisionPosition.left, b.left);
          },
          top: function (b, c) {
            var d = a(window),
              e =
                c.collisionPosition.top +
                c.collisionHeight -
                d.height() -
                d.scrollTop();
            b.top =
              e > 0
                ? b.top - e
                : Math.max(b.top - c.collisionPosition.top, b.top);
          },
        },
        flip: {
          left: function (b, c) {
            if (c.at[0] === e) return;
            var d = a(window),
              f =
                c.collisionPosition.left +
                c.collisionWidth -
                d.width() -
                d.scrollLeft(),
              g =
                c.my[0] === "left"
                  ? -c.elemWidth
                  : c.my[0] === "right"
                  ? c.elemWidth
                  : 0,
              h = c.at[0] === "left" ? c.targetWidth : -c.targetWidth,
              i = -2 * c.offset[0];
            b.left +=
              c.collisionPosition.left < 0 ? g + h + i : f > 0 ? g + h + i : 0;
          },
          top: function (b, c) {
            if (c.at[1] === e) return;
            var d = a(window),
              f =
                c.collisionPosition.top +
                c.collisionHeight -
                d.height() -
                d.scrollTop(),
              g =
                c.my[1] === "top"
                  ? -c.elemHeight
                  : c.my[1] === "bottom"
                  ? c.elemHeight
                  : 0,
              h = c.at[1] === "top" ? c.targetHeight : -c.targetHeight,
              i = -2 * c.offset[1];
            b.top +=
              c.collisionPosition.top < 0 ? g + h + i : f > 0 ? g + h + i : 0;
          },
        },
      }),
      a.offset.setOffset ||
        ((a.offset.setOffset = function (b, c) {
          /static/.test(a.curCSS(b, "position")) &&
            (b.style.position = "relative");
          var d = a(b),
            e = d.offset(),
            f = parseInt(a.curCSS(b, "top", !0), 10) || 0,
            g = parseInt(a.curCSS(b, "left", !0), 10) || 0,
            h = { top: c.top - e.top + f, left: c.left - e.left + g };
          "using" in c ? c.using.call(b, h) : d.css(h);
        }),
        (a.fn.offset = function (b) {
          var c = this[0];
          return !c || !c.ownerDocument
            ? null
            : b
            ? a.isFunction(b)
              ? this.each(function (c) {
                  a(this).offset(b.call(this, c, a(this).offset()));
                })
              : this.each(function () {
                  a.offset.setOffset(this, b);
                })
            : h.call(this);
        })),
      a.curCSS || (a.curCSS = a.css),
      (function () {
        var b = document.getElementsByTagName("body")[0],
          c = document.createElement("div"),
          d,
          e,
          g,
          h,
          i;
        (d = document.createElement(b ? "div" : "body")),
          (g = {
            visibility: "hidden",
            width: 0,
            height: 0,
            border: 0,
            margin: 0,
            background: "none",
          }),
          b &&
            a.extend(g, {
              position: "absolute",
              left: "-1000px",
              top: "-1000px",
            });
        for (var j in g) d.style[j] = g[j];
        d.appendChild(c),
          (e = b || document.documentElement),
          e.insertBefore(d, e.firstChild),
          (c.style.cssText =
            "position: absolute; left: 10.7432222px; top: 10.432325px; height: 30px; width: 201px;"),
          (h = a(c)
            .offset(function (a, b) {
              return b;
            })
            .offset()),
          (d.innerHTML = ""),
          e.removeChild(d),
          (i = h.top + h.left + (b ? 2e3 : 0)),
          (f.fractions = i > 21 && i < 22);
      })();
  })(jQuery),
  (function (a, b) {
    a.widget("ui.progressbar", {
      options: { value: 0, max: 100 },
      min: 0,
      _create: function () {
        this.element
          .addClass("ui-progressbar ui-widget ui-widget-content ui-corner-all")
          .attr({
            role: "progressbar",
            "aria-valuemin": this.min,
            "aria-valuemax": this.options.max,
            "aria-valuenow": this._value(),
          }),
          (this.valueDiv = a(
            "<div class='ui-progressbar-value ui-widget-header ui-corner-left'></div>"
          ).appendTo(this.element)),
          (this.oldValue = this._value()),
          this._refreshValue();
      },
      destroy: function () {
        this.element
          .removeClass(
            "ui-progressbar ui-widget ui-widget-content ui-corner-all"
          )
          .removeAttr("role")
          .removeAttr("aria-valuemin")
          .removeAttr("aria-valuemax")
          .removeAttr("aria-valuenow"),
          this.valueDiv.remove(),
          a.Widget.prototype.destroy.apply(this, arguments);
      },
      value: function (a) {
        return a === b ? this._value() : (this._setOption("value", a), this);
      },
      _setOption: function (b, c) {
        b === "value" &&
          ((this.options.value = c),
          this._refreshValue(),
          this._value() === this.options.max && this._trigger("complete")),
          a.Widget.prototype._setOption.apply(this, arguments);
      },
      _value: function () {
        var a = this.options.value;
        return (
          typeof a != "number" && (a = 0),
          Math.min(this.options.max, Math.max(this.min, a))
        );
      },
      _percentage: function () {
        return (100 * this._value()) / this.options.max;
      },
      _refreshValue: function () {
        var a = this.value(),
          b = this._percentage();
        this.oldValue !== a && ((this.oldValue = a), this._trigger("change")),
          this.valueDiv
            .toggle(a > this.min)
            .toggleClass("ui-corner-right", a === this.options.max)
            .width(b.toFixed(0) + "%"),
          this.element.attr("aria-valuenow", a);
      },
    }),
      a.extend(a.ui.progressbar, { version: "1.8.24" });
  })(jQuery),
  (function (a, b) {
    var c = 5;
    a.widget("ui.slider", a.ui.mouse, {
      widgetEventPrefix: "slide",
      options: {
        animate: !1,
        distance: 0,
        max: 100,
        min: 0,
        orientation: "horizontal",
        range: !1,
        step: 1,
        value: 0,
        values: null,
      },
      _create: function () {
        var b = this,
          d = this.options,
          e = this.element
            .find(".ui-slider-handle")
            .addClass("ui-state-default ui-corner-all"),
          f =
            "<a class='ui-slider-handle ui-state-default ui-corner-all' href='#'></a>",
          g = (d.values && d.values.length) || 1,
          h = [];
        (this._keySliding = !1),
          (this._mouseSliding = !1),
          (this._animateOff = !0),
          (this._handleIndex = null),
          this._detectOrientation(),
          this._mouseInit(),
          this.element.addClass(
            "ui-slider ui-slider-" +
              this.orientation +
              " ui-widget" +
              " ui-widget-content" +
              " ui-corner-all" +
              (d.disabled ? " ui-slider-disabled ui-disabled" : "")
          ),
          (this.range = a([])),
          d.range &&
            (d.range === !0 &&
              (d.values || (d.values = [this._valueMin(), this._valueMin()]),
              d.values.length &&
                d.values.length !== 2 &&
                (d.values = [d.values[0], d.values[0]])),
            (this.range = a("<div></div>")
              .appendTo(this.element)
              .addClass(
                "ui-slider-range ui-widget-header" +
                  (d.range === "min" || d.range === "max"
                    ? " ui-slider-range-" + d.range
                    : "")
              )));
        for (var i = e.length; i < g; i += 1) h.push(f);
        (this.handles = e.add(a(h.join("")).appendTo(b.element))),
          (this.handle = this.handles.eq(0)),
          this.handles
            .add(this.range)
            .filter("a")
            .click(function (a) {
              a.preventDefault();
            })
            .hover(
              function () {
                d.disabled || a(this).addClass("ui-state-hover");
              },
              function () {
                a(this).removeClass("ui-state-hover");
              }
            )
            .focus(function () {
              d.disabled
                ? a(this).blur()
                : (a(".ui-slider .ui-state-focus").removeClass(
                    "ui-state-focus"
                  ),
                  a(this).addClass("ui-state-focus"));
            })
            .blur(function () {
              a(this).removeClass("ui-state-focus");
            }),
          this.handles.each(function (b) {
            a(this).data("index.ui-slider-handle", b);
          }),
          this.handles
            .keydown(function (d) {
              var e = a(this).data("index.ui-slider-handle"),
                f,
                g,
                h,
                i;
              if (b.options.disabled) return;
              switch (d.keyCode) {
                case a.ui.keyCode.HOME:
                case a.ui.keyCode.END:
                case a.ui.keyCode.PAGE_UP:
                case a.ui.keyCode.PAGE_DOWN:
                case a.ui.keyCode.UP:
                case a.ui.keyCode.RIGHT:
                case a.ui.keyCode.DOWN:
                case a.ui.keyCode.LEFT:
                  d.preventDefault();
                  if (!b._keySliding) {
                    (b._keySliding = !0),
                      a(this).addClass("ui-state-active"),
                      (f = b._start(d, e));
                    if (f === !1) return;
                  }
              }
              (i = b.options.step),
                b.options.values && b.options.values.length
                  ? (g = h = b.values(e))
                  : (g = h = b.value());
              switch (d.keyCode) {
                case a.ui.keyCode.HOME:
                  h = b._valueMin();
                  break;
                case a.ui.keyCode.END:
                  h = b._valueMax();
                  break;
                case a.ui.keyCode.PAGE_UP:
                  h = b._trimAlignValue(
                    g + (b._valueMax() - b._valueMin()) / c
                  );
                  break;
                case a.ui.keyCode.PAGE_DOWN:
                  h = b._trimAlignValue(
                    g - (b._valueMax() - b._valueMin()) / c
                  );
                  break;
                case a.ui.keyCode.UP:
                case a.ui.keyCode.RIGHT:
                  if (g === b._valueMax()) return;
                  h = b._trimAlignValue(g + i);
                  break;
                case a.ui.keyCode.DOWN:
                case a.ui.keyCode.LEFT:
                  if (g === b._valueMin()) return;
                  h = b._trimAlignValue(g - i);
              }
              b._slide(d, e, h);
            })
            .keyup(function (c) {
              var d = a(this).data("index.ui-slider-handle");
              b._keySliding &&
                ((b._keySliding = !1),
                b._stop(c, d),
                b._change(c, d),
                a(this).removeClass("ui-state-active"));
            }),
          this._refreshValue(),
          (this._animateOff = !1);
      },
      destroy: function () {
        return (
          this.handles.remove(),
          this.range.remove(),
          this.element
            .removeClass(
              "ui-slider ui-slider-horizontal ui-slider-vertical ui-slider-disabled ui-widget ui-widget-content ui-corner-all"
            )
            .removeData("slider")
            .unbind(".slider"),
          this._mouseDestroy(),
          this
        );
      },
      _mouseCapture: function (b) {
        var c = this.options,
          d,
          e,
          f,
          g,
          h,
          i,
          j,
          k,
          l;
        return c.disabled
          ? !1
          : ((this.elementSize = {
              width: this.element.outerWidth(),
              height: this.element.outerHeight(),
            }),
            (this.elementOffset = this.element.offset()),
            (d = { x: b.pageX, y: b.pageY }),
            (e = this._normValueFromMouse(d)),
            (f = this._valueMax() - this._valueMin() + 1),
            (h = this),
            this.handles.each(function (b) {
              var c = Math.abs(e - h.values(b));
              f > c && ((f = c), (g = a(this)), (i = b));
            }),
            c.range === !0 &&
              this.values(1) === c.min &&
              ((i += 1), (g = a(this.handles[i]))),
            (j = this._start(b, i)),
            j === !1
              ? !1
              : ((this._mouseSliding = !0),
                (h._handleIndex = i),
                g.addClass("ui-state-active").focus(),
                (k = g.offset()),
                (l = !a(b.target).parents().andSelf().is(".ui-slider-handle")),
                (this._clickOffset = l
                  ? { left: 0, top: 0 }
                  : {
                      left: b.pageX - k.left - g.width() / 2,
                      top:
                        b.pageY -
                        k.top -
                        g.height() / 2 -
                        (parseInt(g.css("borderTopWidth"), 10) || 0) -
                        (parseInt(g.css("borderBottomWidth"), 10) || 0) +
                        (parseInt(g.css("marginTop"), 10) || 0),
                    }),
                this.handles.hasClass("ui-state-hover") || this._slide(b, i, e),
                (this._animateOff = !0),
                !0));
      },
      _mouseStart: function (a) {
        return !0;
      },
      _mouseDrag: function (a) {
        var b = { x: a.pageX, y: a.pageY },
          c = this._normValueFromMouse(b);
        return this._slide(a, this._handleIndex, c), !1;
      },
      _mouseStop: function (a) {
        return (
          this.handles.removeClass("ui-state-active"),
          (this._mouseSliding = !1),
          this._stop(a, this._handleIndex),
          this._change(a, this._handleIndex),
          (this._handleIndex = null),
          (this._clickOffset = null),
          (this._animateOff = !1),
          !1
        );
      },
      _detectOrientation: function () {
        this.orientation =
          this.options.orientation === "vertical" ? "vertical" : "horizontal";
      },
      _normValueFromMouse: function (a) {
        var b, c, d, e, f;
        return (
          this.orientation === "horizontal"
            ? ((b = this.elementSize.width),
              (c =
                a.x -
                this.elementOffset.left -
                (this._clickOffset ? this._clickOffset.left : 0)))
            : ((b = this.elementSize.height),
              (c =
                a.y -
                this.elementOffset.top -
                (this._clickOffset ? this._clickOffset.top : 0))),
          (d = c / b),
          d > 1 && (d = 1),
          d < 0 && (d = 0),
          this.orientation === "vertical" && (d = 1 - d),
          (e = this._valueMax() - this._valueMin()),
          (f = this._valueMin() + d * e),
          this._trimAlignValue(f)
        );
      },
      _start: function (a, b) {
        var c = { handle: this.handles[b], value: this.value() };
        return (
          this.options.values &&
            this.options.values.length &&
            ((c.value = this.values(b)), (c.values = this.values())),
          this._trigger("start", a, c)
        );
      },
      _slide: function (a, b, c) {
        var d, e, f;
        this.options.values && this.options.values.length
          ? ((d = this.values(b ? 0 : 1)),
            this.options.values.length === 2 &&
              this.options.range === !0 &&
              ((b === 0 && c > d) || (b === 1 && c < d)) &&
              (c = d),
            c !== this.values(b) &&
              ((e = this.values()),
              (e[b] = c),
              (f = this._trigger("slide", a, {
                handle: this.handles[b],
                value: c,
                values: e,
              })),
              (d = this.values(b ? 0 : 1)),
              f !== !1 && this.values(b, c, !0)))
          : c !== this.value() &&
            ((f = this._trigger("slide", a, {
              handle: this.handles[b],
              value: c,
            })),
            f !== !1 && this.value(c));
      },
      _stop: function (a, b) {
        var c = { handle: this.handles[b], value: this.value() };
        this.options.values &&
          this.options.values.length &&
          ((c.value = this.values(b)), (c.values = this.values())),
          this._trigger("stop", a, c);
      },
      _change: function (a, b) {
        if (!this._keySliding && !this._mouseSliding) {
          var c = { handle: this.handles[b], value: this.value() };
          this.options.values &&
            this.options.values.length &&
            ((c.value = this.values(b)), (c.values = this.values())),
            this._trigger("change", a, c);
        }
      },
      value: function (a) {
        if (arguments.length) {
          (this.options.value = this._trimAlignValue(a)),
            this._refreshValue(),
            this._change(null, 0);
          return;
        }
        return this._value();
      },
      values: function (b, c) {
        var d, e, f;
        if (arguments.length > 1) {
          (this.options.values[b] = this._trimAlignValue(c)),
            this._refreshValue(),
            this._change(null, b);
          return;
        }
        if (!arguments.length) return this._values();
        if (!a.isArray(arguments[0]))
          return this.options.values && this.options.values.length
            ? this._values(b)
            : this.value();
        (d = this.options.values), (e = arguments[0]);
        for (f = 0; f < d.length; f += 1)
          (d[f] = this._trimAlignValue(e[f])), this._change(null, f);
        this._refreshValue();
      },
      _setOption: function (b, c) {
        var d,
          e = 0;
        a.isArray(this.options.values) && (e = this.options.values.length),
          a.Widget.prototype._setOption.apply(this, arguments);
        switch (b) {
          case "disabled":
            c
              ? (this.handles.filter(".ui-state-focus").blur(),
                this.handles.removeClass("ui-state-hover"),
                this.handles.propAttr("disabled", !0),
                this.element.addClass("ui-disabled"))
              : (this.handles.propAttr("disabled", !1),
                this.element.removeClass("ui-disabled"));
            break;
          case "orientation":
            this._detectOrientation(),
              this.element
                .removeClass("ui-slider-horizontal ui-slider-vertical")
                .addClass("ui-slider-" + this.orientation),
              this._refreshValue();
            break;
          case "value":
            (this._animateOff = !0),
              this._refreshValue(),
              this._change(null, 0),
              (this._animateOff = !1);
            break;
          case "values":
            (this._animateOff = !0), this._refreshValue();
            for (d = 0; d < e; d += 1) this._change(null, d);
            this._animateOff = !1;
        }
      },
      _value: function () {
        var a = this.options.value;
        return (a = this._trimAlignValue(a)), a;
      },
      _values: function (a) {
        var b, c, d;
        if (arguments.length)
          return (b = this.options.values[a]), (b = this._trimAlignValue(b)), b;
        c = this.options.values.slice();
        for (d = 0; d < c.length; d += 1) c[d] = this._trimAlignValue(c[d]);
        return c;
      },
      _trimAlignValue: function (a) {
        if (a <= this._valueMin()) return this._valueMin();
        if (a >= this._valueMax()) return this._valueMax();
        var b = this.options.step > 0 ? this.options.step : 1,
          c = (a - this._valueMin()) % b,
          d = a - c;
        return (
          Math.abs(c) * 2 >= b && (d += c > 0 ? b : -b),
          parseFloat(d.toFixed(5))
        );
      },
      _valueMin: function () {
        return this.options.min;
      },
      _valueMax: function () {
        return this.options.max;
      },
      _refreshValue: function () {
        var b = this.options.range,
          c = this.options,
          d = this,
          e = this._animateOff ? !1 : c.animate,
          f,
          g = {},
          h,
          i,
          j,
          k;
        this.options.values && this.options.values.length
          ? this.handles.each(function (b, i) {
              (f =
                ((d.values(b) - d._valueMin()) /
                  (d._valueMax() - d._valueMin())) *
                100),
                (g[d.orientation === "horizontal" ? "left" : "bottom"] =
                  f + "%"),
                a(this).stop(1, 1)[e ? "animate" : "css"](g, c.animate),
                d.options.range === !0 &&
                  (d.orientation === "horizontal"
                    ? (b === 0 &&
                        d.range
                          .stop(1, 1)
                          [e ? "animate" : "css"]({ left: f + "%" }, c.animate),
                      b === 1 &&
                        d.range[e ? "animate" : "css"](
                          { width: f - h + "%" },
                          { queue: !1, duration: c.animate }
                        ))
                    : (b === 0 &&
                        d.range
                          .stop(1, 1)
                          [e ? "animate" : "css"](
                            { bottom: f + "%" },
                            c.animate
                          ),
                      b === 1 &&
                        d.range[e ? "animate" : "css"](
                          { height: f - h + "%" },
                          { queue: !1, duration: c.animate }
                        ))),
                (h = f);
            })
          : ((i = this.value()),
            (j = this._valueMin()),
            (k = this._valueMax()),
            (f = k !== j ? ((i - j) / (k - j)) * 100 : 0),
            (g[d.orientation === "horizontal" ? "left" : "bottom"] = f + "%"),
            this.handle.stop(1, 1)[e ? "animate" : "css"](g, c.animate),
            b === "min" &&
              this.orientation === "horizontal" &&
              this.range
                .stop(1, 1)
                [e ? "animate" : "css"]({ width: f + "%" }, c.animate),
            b === "max" &&
              this.orientation === "horizontal" &&
              this.range[e ? "animate" : "css"](
                { width: 100 - f + "%" },
                { queue: !1, duration: c.animate }
              ),
            b === "min" &&
              this.orientation === "vertical" &&
              this.range
                .stop(1, 1)
                [e ? "animate" : "css"]({ height: f + "%" }, c.animate),
            b === "max" &&
              this.orientation === "vertical" &&
              this.range[e ? "animate" : "css"](
                { height: 100 - f + "%" },
                { queue: !1, duration: c.animate }
              ));
      },
    }),
      a.extend(a.ui.slider, { version: "1.8.24" });
  })(jQuery),
  (function (a, b) {
    function e() {
      return ++c;
    }
    function f() {
      return ++d;
    }
    var c = 0,
      d = 0;
    a.widget("ui.tabs", {
      options: {
        add: null,
        ajaxOptions: null,
        cache: !1,
        cookie: null,
        collapsible: !1,
        disable: null,
        disabled: [],
        enable: null,
        event: "click",
        fx: null,
        idPrefix: "ui-tabs-",
        load: null,
        panelTemplate: "<div></div>",
        remove: null,
        select: null,
        show: null,
        spinner: "<em>Loading&#8230;</em>",
        tabTemplate: "<li><a href='#{href}'><span>#{label}</span></a></li>",
      },
      _create: function () {
        this._tabify(!0);
      },
      _setOption: function (a, b) {
        if (a == "selected") {
          if (this.options.collapsible && b == this.options.selected) return;
          this.select(b);
        } else (this.options[a] = b), this._tabify();
      },
      _tabId: function (a) {
        return (
          (a.title &&
            a.title.replace(/\s/g, "_").replace(/[^\w\u00c0-\uFFFF-]/g, "")) ||
          this.options.idPrefix + e()
        );
      },
      _sanitizeSelector: function (a) {
        return a.replace(/:/g, "\\:");
      },
      _cookie: function () {
        var b =
          this.cookie ||
          (this.cookie = this.options.cookie.name || "ui-tabs-" + f());
        return a.cookie.apply(null, [b].concat(a.makeArray(arguments)));
      },
      _ui: function (a, b) {
        return { tab: a, panel: b, index: this.anchors.index(a) };
      },
      _cleanup: function () {
        this.lis
          .filter(".ui-state-processing")
          .removeClass("ui-state-processing")
          .find("span:data(label.tabs)")
          .each(function () {
            var b = a(this);
            b.html(b.data("label.tabs")).removeData("label.tabs");
          });
      },
      _tabify: function (c) {
        function m(b, c) {
          b.css("display", ""),
            !a.support.opacity &&
              c.opacity &&
              b[0].style.removeAttribute("filter");
        }
        var d = this,
          e = this.options,
          f = /^#.+/;
        (this.list = this.element.find("ol,ul").eq(0)),
          (this.lis = a(" > li:has(a[href])", this.list)),
          (this.anchors = this.lis.map(function () {
            return a("a", this)[0];
          })),
          (this.panels = a([])),
          this.anchors.each(function (b, c) {
            var g = a(c).attr("href"),
              h = g.split("#")[0],
              i;
            h &&
              (h === location.toString().split("#")[0] ||
                ((i = a("base")[0]) && h === i.href)) &&
              ((g = c.hash), (c.href = g));
            if (f.test(g))
              d.panels = d.panels.add(d.element.find(d._sanitizeSelector(g)));
            else if (g && g !== "#") {
              a.data(c, "href.tabs", g),
                a.data(c, "load.tabs", g.replace(/#.*$/, ""));
              var j = d._tabId(c);
              c.href = "#" + j;
              var k = d.element.find("#" + j);
              k.length ||
                ((k = a(e.panelTemplate)
                  .attr("id", j)
                  .addClass("ui-tabs-panel ui-widget-content ui-corner-bottom")
                  .insertAfter(d.panels[b - 1] || d.list)),
                k.data("destroy.tabs", !0)),
                (d.panels = d.panels.add(k));
            } else e.disabled.push(b);
          }),
          c
            ? (this.element.addClass(
                "ui-tabs ui-widget ui-widget-content ui-corner-all"
              ),
              this.list.addClass(
                "ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all"
              ),
              this.lis.addClass("ui-state-default ui-corner-top"),
              this.panels.addClass(
                "ui-tabs-panel ui-widget-content ui-corner-bottom"
              ),
              e.selected === b
                ? (location.hash &&
                    this.anchors.each(function (a, b) {
                      if (b.hash == location.hash) return (e.selected = a), !1;
                    }),
                  typeof e.selected != "number" &&
                    e.cookie &&
                    (e.selected = parseInt(d._cookie(), 10)),
                  typeof e.selected != "number" &&
                    this.lis.filter(".ui-tabs-selected").length &&
                    (e.selected = this.lis.index(
                      this.lis.filter(".ui-tabs-selected")
                    )),
                  (e.selected = e.selected || (this.lis.length ? 0 : -1)))
                : e.selected === null && (e.selected = -1),
              (e.selected =
                (e.selected >= 0 && this.anchors[e.selected]) || e.selected < 0
                  ? e.selected
                  : 0),
              (e.disabled = a
                .unique(
                  e.disabled.concat(
                    a.map(
                      this.lis.filter(".ui-state-disabled"),
                      function (a, b) {
                        return d.lis.index(a);
                      }
                    )
                  )
                )
                .sort()),
              a.inArray(e.selected, e.disabled) != -1 &&
                e.disabled.splice(a.inArray(e.selected, e.disabled), 1),
              this.panels.addClass("ui-tabs-hide"),
              this.lis.removeClass("ui-tabs-selected ui-state-active"),
              e.selected >= 0 &&
                this.anchors.length &&
                (d.element
                  .find(d._sanitizeSelector(d.anchors[e.selected].hash))
                  .removeClass("ui-tabs-hide"),
                this.lis
                  .eq(e.selected)
                  .addClass("ui-tabs-selected ui-state-active"),
                d.element.queue("tabs", function () {
                  d._trigger(
                    "show",
                    null,
                    d._ui(
                      d.anchors[e.selected],
                      d.element.find(
                        d._sanitizeSelector(d.anchors[e.selected].hash)
                      )[0]
                    )
                  );
                }),
                this.load(e.selected)),
              a(window).bind("unload", function () {
                d.lis.add(d.anchors).unbind(".tabs"),
                  (d.lis = d.anchors = d.panels = null);
              }))
            : (e.selected = this.lis.index(
                this.lis.filter(".ui-tabs-selected")
              )),
          this.element[e.collapsible ? "addClass" : "removeClass"](
            "ui-tabs-collapsible"
          ),
          e.cookie && this._cookie(e.selected, e.cookie);
        for (var g = 0, h; (h = this.lis[g]); g++)
          a(h)[
            a.inArray(g, e.disabled) != -1 && !a(h).hasClass("ui-tabs-selected")
              ? "addClass"
              : "removeClass"
          ]("ui-state-disabled");
        e.cache === !1 && this.anchors.removeData("cache.tabs"),
          this.lis.add(this.anchors).unbind(".tabs");
        if (e.event !== "mouseover") {
          var i = function (a, b) {
              b.is(":not(.ui-state-disabled)") && b.addClass("ui-state-" + a);
            },
            j = function (a, b) {
              b.removeClass("ui-state-" + a);
            };
          this.lis.bind("mouseover.tabs", function () {
            i("hover", a(this));
          }),
            this.lis.bind("mouseout.tabs", function () {
              j("hover", a(this));
            }),
            this.anchors.bind("focus.tabs", function () {
              i("focus", a(this).closest("li"));
            }),
            this.anchors.bind("blur.tabs", function () {
              j("focus", a(this).closest("li"));
            });
        }
        var k, l;
        e.fx &&
          (a.isArray(e.fx) ? ((k = e.fx[0]), (l = e.fx[1])) : (k = l = e.fx));
        var n = l
            ? function (b, c) {
                a(b).closest("li").addClass("ui-tabs-selected ui-state-active"),
                  c
                    .hide()
                    .removeClass("ui-tabs-hide")
                    .animate(l, l.duration || "normal", function () {
                      m(c, l), d._trigger("show", null, d._ui(b, c[0]));
                    });
              }
            : function (b, c) {
                a(b).closest("li").addClass("ui-tabs-selected ui-state-active"),
                  c.removeClass("ui-tabs-hide"),
                  d._trigger("show", null, d._ui(b, c[0]));
              },
          o = k
            ? function (a, b) {
                b.animate(k, k.duration || "normal", function () {
                  d.lis.removeClass("ui-tabs-selected ui-state-active"),
                    b.addClass("ui-tabs-hide"),
                    m(b, k),
                    d.element.dequeue("tabs");
                });
              }
            : function (a, b, c) {
                d.lis.removeClass("ui-tabs-selected ui-state-active"),
                  b.addClass("ui-tabs-hide"),
                  d.element.dequeue("tabs");
              };
        this.anchors.bind(e.event + ".tabs", function () {
          var b = this,
            c = a(b).closest("li"),
            f = d.panels.filter(":not(.ui-tabs-hide)"),
            g = d.element.find(d._sanitizeSelector(b.hash));
          if (
            (c.hasClass("ui-tabs-selected") && !e.collapsible) ||
            c.hasClass("ui-state-disabled") ||
            c.hasClass("ui-state-processing") ||
            d.panels.filter(":animated").length ||
            d._trigger("select", null, d._ui(this, g[0])) === !1
          )
            return this.blur(), !1;
          (e.selected = d.anchors.index(this)), d.abort();
          if (e.collapsible) {
            if (c.hasClass("ui-tabs-selected"))
              return (
                (e.selected = -1),
                e.cookie && d._cookie(e.selected, e.cookie),
                d.element
                  .queue("tabs", function () {
                    o(b, f);
                  })
                  .dequeue("tabs"),
                this.blur(),
                !1
              );
            if (!f.length)
              return (
                e.cookie && d._cookie(e.selected, e.cookie),
                d.element.queue("tabs", function () {
                  n(b, g);
                }),
                d.load(d.anchors.index(this)),
                this.blur(),
                !1
              );
          }
          e.cookie && d._cookie(e.selected, e.cookie);
          if (g.length)
            f.length &&
              d.element.queue("tabs", function () {
                o(b, f);
              }),
              d.element.queue("tabs", function () {
                n(b, g);
              }),
              d.load(d.anchors.index(this));
          else throw "jQuery UI Tabs: Mismatching fragment identifier.";
          a.browser.msie && this.blur();
        }),
          this.anchors.bind("click.tabs", function () {
            return !1;
          });
      },
      _getIndex: function (a) {
        return (
          typeof a == "string" &&
            (a = this.anchors.index(
              this.anchors.filter("[href$='" + a + "']")
            )),
          a
        );
      },
      destroy: function () {
        var b = this.options;
        return (
          this.abort(),
          this.element
            .unbind(".tabs")
            .removeClass(
              "ui-tabs ui-widget ui-widget-content ui-corner-all ui-tabs-collapsible"
            )
            .removeData("tabs"),
          this.list.removeClass(
            "ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all"
          ),
          this.anchors.each(function () {
            var b = a.data(this, "href.tabs");
            b && (this.href = b);
            var c = a(this).unbind(".tabs");
            a.each(["href", "load", "cache"], function (a, b) {
              c.removeData(b + ".tabs");
            });
          }),
          this.lis
            .unbind(".tabs")
            .add(this.panels)
            .each(function () {
              a.data(this, "destroy.tabs")
                ? a(this).remove()
                : a(this).removeClass(
                    [
                      "ui-state-default",
                      "ui-corner-top",
                      "ui-tabs-selected",
                      "ui-state-active",
                      "ui-state-hover",
                      "ui-state-focus",
                      "ui-state-disabled",
                      "ui-tabs-panel",
                      "ui-widget-content",
                      "ui-corner-bottom",
                      "ui-tabs-hide",
                    ].join(" ")
                  );
            }),
          b.cookie && this._cookie(null, b.cookie),
          this
        );
      },
      add: function (c, d, e) {
        e === b && (e = this.anchors.length);
        var f = this,
          g = this.options,
          h = a(
            g.tabTemplate.replace(/#\{href\}/g, c).replace(/#\{label\}/g, d)
          ),
          i = c.indexOf("#") ? this._tabId(a("a", h)[0]) : c.replace("#", "");
        h.addClass("ui-state-default ui-corner-top").data("destroy.tabs", !0);
        var j = f.element.find("#" + i);
        return (
          j.length ||
            (j = a(g.panelTemplate).attr("id", i).data("destroy.tabs", !0)),
          j.addClass(
            "ui-tabs-panel ui-widget-content ui-corner-bottom ui-tabs-hide"
          ),
          e >= this.lis.length
            ? (h.appendTo(this.list), j.appendTo(this.list[0].parentNode))
            : (h.insertBefore(this.lis[e]), j.insertBefore(this.panels[e])),
          (g.disabled = a.map(g.disabled, function (a, b) {
            return a >= e ? ++a : a;
          })),
          this._tabify(),
          this.anchors.length == 1 &&
            ((g.selected = 0),
            h.addClass("ui-tabs-selected ui-state-active"),
            j.removeClass("ui-tabs-hide"),
            this.element.queue("tabs", function () {
              f._trigger("show", null, f._ui(f.anchors[0], f.panels[0]));
            }),
            this.load(0)),
          this._trigger("add", null, this._ui(this.anchors[e], this.panels[e])),
          this
        );
      },
      remove: function (b) {
        b = this._getIndex(b);
        var c = this.options,
          d = this.lis.eq(b).remove(),
          e = this.panels.eq(b).remove();
        return (
          d.hasClass("ui-tabs-selected") &&
            this.anchors.length > 1 &&
            this.select(b + (b + 1 < this.anchors.length ? 1 : -1)),
          (c.disabled = a.map(
            a.grep(c.disabled, function (a, c) {
              return a != b;
            }),
            function (a, c) {
              return a >= b ? --a : a;
            }
          )),
          this._tabify(),
          this._trigger("remove", null, this._ui(d.find("a")[0], e[0])),
          this
        );
      },
      enable: function (b) {
        b = this._getIndex(b);
        var c = this.options;
        if (a.inArray(b, c.disabled) == -1) return;
        return (
          this.lis.eq(b).removeClass("ui-state-disabled"),
          (c.disabled = a.grep(c.disabled, function (a, c) {
            return a != b;
          })),
          this._trigger(
            "enable",
            null,
            this._ui(this.anchors[b], this.panels[b])
          ),
          this
        );
      },
      disable: function (a) {
        a = this._getIndex(a);
        var b = this,
          c = this.options;
        return (
          a != c.selected &&
            (this.lis.eq(a).addClass("ui-state-disabled"),
            c.disabled.push(a),
            c.disabled.sort(),
            this._trigger(
              "disable",
              null,
              this._ui(this.anchors[a], this.panels[a])
            )),
          this
        );
      },
      select: function (a) {
        a = this._getIndex(a);
        if (a == -1)
          if (this.options.collapsible && this.options.selected != -1)
            a = this.options.selected;
          else return this;
        return this.anchors.eq(a).trigger(this.options.event + ".tabs"), this;
      },
      load: function (b) {
        b = this._getIndex(b);
        var c = this,
          d = this.options,
          e = this.anchors.eq(b)[0],
          f = a.data(e, "load.tabs");
        this.abort();
        if (
          !f ||
          (this.element.queue("tabs").length !== 0 && a.data(e, "cache.tabs"))
        ) {
          this.element.dequeue("tabs");
          return;
        }
        this.lis.eq(b).addClass("ui-state-processing");
        if (d.spinner) {
          var g = a("span", e);
          g.data("label.tabs", g.html()).html(d.spinner);
        }
        return (
          (this.xhr = a.ajax(
            a.extend({}, d.ajaxOptions, {
              url: f,
              success: function (f, g) {
                c.element.find(c._sanitizeSelector(e.hash)).html(f),
                  c._cleanup(),
                  d.cache && a.data(e, "cache.tabs", !0),
                  c._trigger("load", null, c._ui(c.anchors[b], c.panels[b]));
                try {
                  d.ajaxOptions.success(f, g);
                } catch (h) {}
              },
              error: function (a, f, g) {
                c._cleanup(),
                  c._trigger("load", null, c._ui(c.anchors[b], c.panels[b]));
                try {
                  d.ajaxOptions.error(a, f, b, e);
                } catch (g) {}
              },
            })
          )),
          c.element.dequeue("tabs"),
          this
        );
      },
      abort: function () {
        return (
          this.element.queue([]),
          this.panels.stop(!1, !0),
          this.element.queue("tabs", this.element.queue("tabs").splice(-2, 2)),
          this.xhr && (this.xhr.abort(), delete this.xhr),
          this._cleanup(),
          this
        );
      },
      url: function (a, b) {
        return (
          this.anchors.eq(a).removeData("cache.tabs").data("load.tabs", b), this
        );
      },
      length: function () {
        return this.anchors.length;
      },
    }),
      a.extend(a.ui.tabs, { version: "1.8.24" }),
      a.extend(a.ui.tabs.prototype, {
        rotation: null,
        rotate: function (a, b) {
          var c = this,
            d = this.options,
            e =
              c._rotate ||
              (c._rotate = function (b) {
                clearTimeout(c.rotation),
                  (c.rotation = setTimeout(function () {
                    var a = d.selected;
                    c.select(++a < c.anchors.length ? a : 0);
                  }, a)),
                  b && b.stopPropagation();
              }),
            f =
              c._unrotate ||
              (c._unrotate = b
                ? function (a) {
                    e();
                  }
                : function (a) {
                    a.clientX && c.rotate(null);
                  });
          return (
            a
              ? (this.element.bind("tabsshow", e),
                this.anchors.bind(d.event + ".tabs", f),
                e())
              : (clearTimeout(c.rotation),
                this.element.unbind("tabsshow", e),
                this.anchors.unbind(d.event + ".tabs", f),
                delete this._rotate,
                delete this._unrotate),
            this
          );
        },
      });
  })(jQuery);
/*################ jquery-date-picker/jquery-ui.min.js ends ###################*/

/*################ resp_common.min.js starts ###################*/
!(function (t) {
  t(document).ready(function () {
    var e = t('a[rel*="showVideo"], a[data-rel*="showVideo"]');
    e.length &&
      e.click(function () {
        return (
          t.fancybox({
            autoScale: !1,
            scrolling: "yes",
            transitionIn: "elastic",
            transitionOut: "elastic",
            title: this.title,
            width: 450,
            height: 350,
            href: this.href.replace(new RegExp("watch\\?v=", "i"), "v/"),
            type: "swf",
            swf: { wmode: "transparent", allowfullscreen: "true" },
          }),
          !1
        );
      });
    var i = t('a[rel*="showZoomImage"], a[data-rel*="showZoomImage"]');
    i.length &&
      i.fancybox({
        transitionIn: "elastic",
        transitionOut: "elastic",
        autoScale: !1,
        scrolling: !0,
        titlePosition: "inside",
      }),
      t(".youtube_video_popup").fancybox({
        openEffect: "none",
        closeEffect: "none",
        maxWidth: 450,
        maxHeight: 350,
        helpers: { media: {} },
      });
  }),
    (t.fn.addZoomIcon = function () {
      this.length &&
        ((img = document.createElement("img")),
        (img.src = SRC),
        (img.className = "pa"),
        (W = Math.floor((Width / 100) * Percentage)),
        (H = Math.floor((Height / 100) * Percentage)),
        (W2 = Math.floor((Width / 100) * (Percentage + 10))),
        (H2 = Math.floor((Height / 100) * (Percentage + 10))),
        "left" == XPos
          ? (img.style.left = "1px")
          : "center" == XPos
          ? (img.style.left = Math.floor(TargetWidth / 2 - W / 2) + "px")
          : "right" == XPos
          ? (img.style.right = "1px")
          : (img.style.left = XPos + "px"),
        "top" == YPos
          ? (img.style.top = "1px")
          : "center" == YPos
          ? (img.style.top = Math.floor(TargetHeight / 2 - H / 2) + "px")
          : "bottom" == YPos
          ? (img.style.bottom = "1px")
          : (img.style.top = YPos + "px"),
        t(this).addClass("pr dib"),
        t(this).append(img),
        t("img:last", this).css({ opacity: MinAlpha, width: W, height: W }),
        t(this).hover(
          function () {
            t("img:last", this)
              .stop(!0, !0)
              .animate({ opacity: MaxAlpha, width: W2, height: H2 }, 500);
          },
          function () {
            t("img:last", this).animate(
              { opacity: MinAlpha, width: W, height: H },
              500
            );
          }
        ));
    });
})(jQuery),
  jQuery(window).load(function () {
    setTimeout(function () {
      jQuery(document).innerHeight();
      var t = jQuery("header").height(),
        e = jQuery("#middle").height(),
        i = jQuery("footer").outerHeight(),
        o = jQuery(window).height(),
        a = t + e + i,
        n = o - a;
      a <= o && jQuery("footer").css("margin-top", n);
    }, 1e3);
  });
/*################ resp_common.min.js ends ###################*/

/*################ Modernizr2.7.1.js starts ###################*/
window.Modernizr = (function (e, t, n) {
  function A(e) {
    f.cssText = e;
  }
  function O(e, t) {
    return A(p.join(e + ";") + (t || ""));
  }
  function M(e, t) {
    return typeof e === t;
  }
  function _(e, t) {
    return !!~("" + e).indexOf(t);
  }
  function D(e, t) {
    for (var r in e) {
      var i = e[r];
      if (!_(i, "-") && f[i] !== n) {
        return t == "pfx" ? i : true;
      }
    }
    return false;
  }
  function P(e, t, r) {
    for (var i in e) {
      var s = t[e[i]];
      if (s !== n) {
        if (r === false) return e[i];
        if (M(s, "function")) {
          return s.bind(r || t);
        }
        return s;
      }
    }
    return false;
  }
  function H(e, t, n) {
    var r = e.charAt(0).toUpperCase() + e.slice(1),
      i = (e + " " + v.join(r + " ") + r).split(" ");
    if (M(t, "string") || M(t, "undefined")) {
      return D(i, t);
    } else {
      i = (e + " " + m.join(r + " ") + r).split(" ");
      return P(i, t, n);
    }
  }
  function B() {
    i["input"] = (function (n) {
      for (var r = 0, i = n.length; r < i; r++) {
        w[n[r]] = !!(n[r] in l);
      }
      if (w.list) {
        w.list = !!(t.createElement("datalist") && e.HTMLDataListElement);
      }
      return w;
    })(
      "autocomplete autofocus list placeholder max min multiple pattern required step".split(
        " "
      )
    );
    i["inputtypes"] = (function (e) {
      for (var r = 0, i, s, u, a = e.length; r < a; r++) {
        l.setAttribute("type", (s = e[r]));
        i = l.type !== "text";
        if (i) {
          l.value = c;
          l.style.cssText = "position:absolute;visibility:hidden;";
          if (/^range$/.test(s) && l.style.WebkitAppearance !== n) {
            o.appendChild(l);
            u = t.defaultView;
            i =
              u.getComputedStyle &&
              u.getComputedStyle(l, null).WebkitAppearance !== "textfield" &&
              l.offsetHeight !== 0;
            o.removeChild(l);
          } else if (/^(search|tel)$/.test(s)) {
          } else if (/^(url|email)$/.test(s)) {
            i = l.checkValidity && l.checkValidity() === false;
          } else {
            i = l.value != c;
          }
        }
        b[e[r]] = !!i;
      }
      return b;
    })(
      "search tel url email datetime date month week time datetime-local number range color".split(
        " "
      )
    );
  }
  var r = "2.7.1",
    i = {},
    s = true,
    o = t.documentElement,
    u = "modernizr",
    a = t.createElement(u),
    f = a.style,
    l = t.createElement("input"),
    c = ":)",
    h = {}.toString,
    p = " -webkit- -moz- -o- -ms- ".split(" "),
    d = "Webkit Moz O ms",
    v = d.split(" "),
    m = d.toLowerCase().split(" "),
    g = { svg: "http://www.w3.org/2000/svg" },
    y = {},
    b = {},
    w = {},
    E = [],
    S = E.slice,
    x,
    T = function (e, n, r, i) {
      var s,
        a,
        f,
        l,
        c = t.createElement("div"),
        h = t.body,
        p = h || t.createElement("body");
      if (parseInt(r, 10)) {
        while (r--) {
          f = t.createElement("div");
          f.id = i ? i[r] : u + (r + 1);
          c.appendChild(f);
        }
      }
      s = ["&#173;", '<style id="s', u, '">', e, "</style>"].join("");
      c.id = u;
      (h ? c : p).innerHTML += s;
      p.appendChild(c);
      if (!h) {
        p.style.background = "";
        p.style.overflow = "hidden";
        l = o.style.overflow;
        o.style.overflow = "hidden";
        o.appendChild(p);
      }
      a = n(c, e);
      if (!h) {
        p.parentNode.removeChild(p);
        o.style.overflow = l;
      } else {
        c.parentNode.removeChild(c);
      }
      return !!a;
    },
    N = function (t) {
      var n = e.matchMedia || e.msMatchMedia;
      if (n) {
        return n(t).matches;
      }
      var r;
      T(
        "@media " + t + " { #" + u + " { position: absolute; } }",
        function (t) {
          r =
            (e.getComputedStyle ? getComputedStyle(t, null) : t.currentStyle)[
              "position"
            ] == "absolute";
        }
      );
      return r;
    },
    C = (function () {
      function r(r, i) {
        i = i || t.createElement(e[r] || "div");
        r = "on" + r;
        var s = r in i;
        if (!s) {
          if (!i.setAttribute) {
            i = t.createElement("div");
          }
          if (i.setAttribute && i.removeAttribute) {
            i.setAttribute(r, "");
            s = M(i[r], "function");
            if (!M(i[r], "undefined")) {
              i[r] = n;
            }
            i.removeAttribute(r);
          }
        }
        i = null;
        return s;
      }
      var e = {
        select: "input",
        change: "input",
        submit: "form",
        reset: "form",
        error: "img",
        load: "img",
        abort: "img",
      };
      return r;
    })(),
    k = {}.hasOwnProperty,
    L;
  if (!M(k, "undefined") && !M(k.call, "undefined")) {
    L = function (e, t) {
      return k.call(e, t);
    };
  } else {
    L = function (e, t) {
      return t in e && M(e.constructor.prototype[t], "undefined");
    };
  }
  if (!Function.prototype.bind) {
    Function.prototype.bind = function (t) {
      var n = this;
      if (typeof n != "function") {
        throw new TypeError();
      }
      var r = S.call(arguments, 1),
        i = function () {
          if (this instanceof i) {
            var e = function () {};
            e.prototype = n.prototype;
            var s = new e();
            var o = n.apply(s, r.concat(S.call(arguments)));
            if (Object(o) === o) {
              return o;
            }
            return s;
          } else {
            return n.apply(t, r.concat(S.call(arguments)));
          }
        };
      return i;
    };
  }
  y["flexbox"] = function () {
    return H("flexWrap");
  };
  y["flexboxlegacy"] = function () {
    return H("boxDirection");
  };
  y["canvas"] = function () {
    var e = t.createElement("canvas");
    return !!(e.getContext && e.getContext("2d"));
  };
  y["canvastext"] = function () {
    return !!(
      i["canvas"] &&
      M(t.createElement("canvas").getContext("2d").fillText, "function")
    );
  };
  y["webgl"] = function () {
    return !!e.WebGLRenderingContext;
  };
  y["touch"] = function () {
    var n;
    if (
      "ontouchstart" in e ||
      (e.DocumentTouch && t instanceof DocumentTouch)
    ) {
      n = true;
    } else {
      T(
        [
          "@media (",
          p.join("touch-enabled),("),
          u,
          ")",
          "{#modernizr{top:9px;position:absolute}}",
        ].join(""),
        function (e) {
          n = e.offsetTop === 9;
        }
      );
    }
    return n;
  };
  y["geolocation"] = function () {
    return "geolocation" in navigator;
  };
  y["postmessage"] = function () {
    return !!e.postMessage;
  };
  y["websqldatabase"] = function () {
    return !!e.openDatabase;
  };
  y["indexedDB"] = function () {
    return !!H("indexedDB", e);
  };
  y["hashchange"] = function () {
    return C("hashchange", e) && (t.documentMode === n || t.documentMode > 7);
  };
  y["history"] = function () {
    return !!(e.history && history.pushState);
  };
  y["draganddrop"] = function () {
    var e = t.createElement("div");
    return "draggable" in e || ("ondragstart" in e && "ondrop" in e);
  };
  y["websockets"] = function () {
    return "WebSocket" in e || "MozWebSocket" in e;
  };
  y["rgba"] = function () {
    A("background-color:rgba(150,255,150,.5)");
    return _(f.backgroundColor, "rgba");
  };
  y["hsla"] = function () {
    A("background-color:hsla(120,40%,100%,.5)");
    return _(f.backgroundColor, "rgba") || _(f.backgroundColor, "hsla");
  };
  y["multiplebgs"] = function () {
    A("background:url(https://),url(https://),red url(https://)");
    return /(url\s*\(.*?){3}/.test(f.background);
  };
  y["backgroundsize"] = function () {
    return H("backgroundSize");
  };
  y["borderimage"] = function () {
    return H("borderImage");
  };
  y["borderradius"] = function () {
    return H("borderRadius");
  };
  y["boxshadow"] = function () {
    return H("boxShadow");
  };
  y["textshadow"] = function () {
    return t.createElement("div").style.textShadow === "";
  };
  y["opacity"] = function () {
    O("opacity:.55");
    return /^0.55$/.test(f.opacity);
  };
  y["cssanimations"] = function () {
    return H("animationName");
  };
  y["csscolumns"] = function () {
    return H("columnCount");
  };
  y["cssgradients"] = function () {
    var e = "background-image:",
      t = "gradient(linear,left top,right bottom,from(#9f9),to(white));",
      n = "linear-gradient(left top,#9f9, white);";
    A(
      (e + "-webkit- ".split(" ").join(t + e) + p.join(n + e)).slice(
        0,
        -e.length
      )
    );
    return _(f.backgroundImage, "gradient");
  };
  y["cssreflections"] = function () {
    return H("boxReflect");
  };
  y["csstransforms"] = function () {
    return !!H("transform");
  };
  y["csstransforms3d"] = function () {
    var e = !!H("perspective");
    if (e && "webkitPerspective" in o.style) {
      T(
        "@media (transform-3d),(-webkit-transform-3d){#modernizr{left:9px;position:absolute;height:3px;}}",
        function (t, n) {
          e = t.offsetLeft === 9 && t.offsetHeight === 3;
        }
      );
    }
    return e;
  };
  y["csstransitions"] = function () {
    return H("transition");
  };
  y["fontface"] = function () {
    var e;
    T('@font-face {font-family:"font";src:url("https://")}', function (n, r) {
      var i = t.getElementById("smodernizr"),
        s = i.sheet || i.styleSheet,
        o = s
          ? s.cssRules && s.cssRules[0]
            ? s.cssRules[0].cssText
            : s.cssText || ""
          : "";
      e = /src/i.test(o) && o.indexOf(r.split(" ")[0]) === 0;
    });
    return e;
  };
  y["generatedcontent"] = function () {
    var e;
    T(
      [
        "#",
        u,
        "{font:0/0 a}#",
        u,
        ':after{content:"',
        c,
        '";visibility:hidden;font:3px/1 a}',
      ].join(""),
      function (t) {
        e = t.offsetHeight >= 3;
      }
    );
    return e;
  };
  y["video"] = function () {
    var e = t.createElement("video"),
      n = false;
    try {
      if ((n = !!e.canPlayType)) {
        n = new Boolean(n);
        n.ogg = e.canPlayType('video/ogg; codecs="theora"').replace(/^no$/, "");
        n.h264 = e
          .canPlayType('video/mp4; codecs="avc1.42E01E"')
          .replace(/^no$/, "");
        n.webm = e
          .canPlayType('video/webm; codecs="vp8, vorbis"')
          .replace(/^no$/, "");
      }
    } catch (r) {}
    return n;
  };
  y["audio"] = function () {
    var e = t.createElement("audio"),
      n = false;
    try {
      if ((n = !!e.canPlayType)) {
        n = new Boolean(n);
        n.ogg = e.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/, "");
        n.mp3 = e.canPlayType("audio/mpeg;").replace(/^no$/, "");
        n.wav = e.canPlayType('audio/wav; codecs="1"').replace(/^no$/, "");
        n.m4a = (
          e.canPlayType("audio/x-m4a;") || e.canPlayType("audio/aac;")
        ).replace(/^no$/, "");
      }
    } catch (r) {}
    return n;
  };
  y["localstorage"] = function () {
    try {
      localStorage.setItem(u, u);
      localStorage.removeItem(u);
      return true;
    } catch (e) {
      return false;
    }
  };
  y["sessionstorage"] = function () {
    try {
      sessionStorage.setItem(u, u);
      sessionStorage.removeItem(u);
      return true;
    } catch (e) {
      return false;
    }
  };
  y["webworkers"] = function () {
    return !!e.Worker;
  };
  y["applicationcache"] = function () {
    return !!e.applicationCache;
  };
  y["svg"] = function () {
    return (
      !!t.createElementNS && !!t.createElementNS(g.svg, "svg").createSVGRect
    );
  };
  y["inlinesvg"] = function () {
    var e = t.createElement("div");
    e.innerHTML = "<svg/>";
    return (e.firstChild && e.firstChild.namespaceURI) == g.svg;
  };
  y["smil"] = function () {
    return (
      !!t.createElementNS &&
      /SVGAnimate/.test(h.call(t.createElementNS(g.svg, "animate")))
    );
  };
  y["svgclippaths"] = function () {
    return (
      !!t.createElementNS &&
      /SVGClipPath/.test(h.call(t.createElementNS(g.svg, "clipPath")))
    );
  };
  for (var j in y) {
    if (L(y, j)) {
      x = j.toLowerCase();
      i[x] = y[j]();
      E.push((i[x] ? "" : "no-") + x);
    }
  }
  i.input || B();
  i.addTest = function (e, t) {
    if (typeof e == "object") {
      for (var r in e) {
        if (L(e, r)) {
          i.addTest(r, e[r]);
        }
      }
    } else {
      e = e.toLowerCase();
      if (i[e] !== n) {
        return i;
      }
      t = typeof t == "function" ? t() : t;
      if (typeof s !== "undefined" && s) {
        o.className += " " + (t ? "" : "no-") + e;
      }
      i[e] = t;
    }
    return i;
  };
  A("");
  a = l = null;
  (function (e, t) {
    function c(e, t) {
      var n = e.createElement("p"),
        r = e.getElementsByTagName("head")[0] || e.documentElement;
      n.innerHTML = "x<style>" + t + "</style>";
      return r.insertBefore(n.lastChild, r.firstChild);
    }
    function h() {
      var e = y.elements;
      return typeof e == "string" ? e.split(" ") : e;
    }
    function p(e) {
      var t = f[e[u]];
      if (!t) {
        t = {};
        a++;
        e[u] = a;
        f[a] = t;
      }
      return t;
    }
    function d(e, n, r) {
      if (!n) {
        n = t;
      }
      if (l) {
        return n.createElement(e);
      }
      if (!r) {
        r = p(n);
      }
      var o;
      if (r.cache[e]) {
        o = r.cache[e].cloneNode();
      } else if (s.test(e)) {
        o = (r.cache[e] = r.createElem(e)).cloneNode();
      } else {
        o = r.createElem(e);
      }
      return o.canHaveChildren && !i.test(e) && !o.tagUrn
        ? r.frag.appendChild(o)
        : o;
    }
    function v(e, n) {
      if (!e) {
        e = t;
      }
      if (l) {
        return e.createDocumentFragment();
      }
      n = n || p(e);
      var r = n.frag.cloneNode(),
        i = 0,
        s = h(),
        o = s.length;
      for (; i < o; i++) {
        r.createElement(s[i]);
      }
      return r;
    }
    function m(e, t) {
      if (!t.cache) {
        t.cache = {};
        t.createElem = e.createElement;
        t.createFrag = e.createDocumentFragment;
        t.frag = t.createFrag();
      }
      e.createElement = function (n) {
        if (!y.shivMethods) {
          return t.createElem(n);
        }
        return d(n, e, t);
      };
      e.createDocumentFragment = Function(
        "h,f",
        "return function(){" +
          "var n=f.cloneNode(),c=n.createElement;" +
          "h.shivMethods&&(" +
          h()
            .join()
            .replace(/[\w\-]+/g, function (e) {
              t.createElem(e);
              t.frag.createElement(e);
              return 'c("' + e + '")';
            }) +
          ");return n}"
      )(y, t.frag);
    }
    function g(e) {
      if (!e) {
        e = t;
      }
      var n = p(e);
      if (y.shivCSS && !o && !n.hasCSS) {
        n.hasCSS = !!c(
          e,
          "article,aside,dialog,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}" +
            "mark{background:#FF0;color:#000}" +
            "template{display:none}"
        );
      }
      if (!l) {
        m(e, n);
      }
      return e;
    }
    var n = "3.7.0";
    var r = e.html5 || {};
    var i =
      /^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i;
    var s =
      /^(?:a|b|code|div|fieldset|h1|h2|h3|h4|h5|h6|i|label|li|ol|p|q|span|strong|style|table|tbody|td|th|tr|ul)$/i;
    var o;
    var u = "_html5shiv";
    var a = 0;
    var f = {};
    var l;
    (function () {
      try {
        var e = t.createElement("a");
        e.innerHTML = "<xyz></xyz>";
        o = "hidden" in e;
        l =
          e.childNodes.length == 1 ||
          (function () {
            t.createElement("a");
            var e = t.createDocumentFragment();
            return (
              typeof e.cloneNode == "undefined" ||
              typeof e.createDocumentFragment == "undefined" ||
              typeof e.createElement == "undefined"
            );
          })();
      } catch (n) {
        o = true;
        l = true;
      }
    })();
    var y = {
      elements:
        r.elements ||
        "abbr article aside audio bdi canvas data datalist details dialog figcaption figure footer header hgroup main mark meter nav output progress section summary template time video",
      version: n,
      shivCSS: r.shivCSS !== false,
      supportsUnknownElements: l,
      shivMethods: r.shivMethods !== false,
      type: "default",
      shivDocument: g,
      createElement: d,
      createDocumentFragment: v,
    };
    e.html5 = y;
    g(t);
  })(this, t);
  i._version = r;
  i._prefixes = p;
  i._domPrefixes = m;
  i._cssomPrefixes = v;
  i.mq = N;
  i.hasEvent = C;
  i.testProp = function (e) {
    return D([e]);
  };
  i.testAllProps = H;
  i.testStyles = T;
  i.prefixed = function (e, t, n) {
    if (!t) {
      return H(e, "pfx");
    } else {
      return H(e, t, n);
    }
  };
  o.className =
    o.className.replace(/(^|\s)no-js(\s|$)/, "$1$2") +
    (s ? " js " + E.join(" ") : "");
  return i;
})(this, this.document);
/*################ Modernizr2.7.1.js ends ###################*/

/*################ catalog-image-jquery/jquery.fancybox.min.js starts ###################*/
// ==================================================
// fancyBox v3.1.20
//
// Licensed GPLv3 for open source use
// or fancyBox Commercial License for commercial use
//
// http://fancyapps.com/fancybox/
// Copyright 2017 fancyApps
//
// ==================================================
!(function (t, e, n, o) {
  "use strict";
  function i(t) {
    var e = t.currentTarget,
      o = t.data ? t.data.options : {},
      i = t.data ? t.data.items : [],
      a = n(e).attr("data-fancybox") || "",
      s = 0;
    t.preventDefault(),
      t.stopPropagation(),
      a
        ? ((i = i.length
            ? i.filter('[data-fancybox="' + a + '"]')
            : n('[data-fancybox="' + a + '"]')),
          (s = i.index(e)),
          s < 0 && (s = 0))
        : (i = [e]),
      n.fancybox.open(i, o, s);
  }
  if (n) {
    if (n.fn.fancybox) return void n.error("fancyBox already initialized");
    var a = {
        loop: !1,
        margin: [44, 0],
        gutter: 50,
        keyboard: !0,
        arrows: !0,
        infobar: !1,
        toolbar: !0,
        buttons: ["slideShow", "fullScreen", "thumbs", "close"],
        idleTime: 4,
        smallBtn: "auto",
        protect: !1,
        modal: !1,
        image: { preload: "auto" },
        ajax: { settings: { data: { fancybox: !0 } } },
        iframe: {
          tpl: '<iframe id="fancybox-frame{rnd}" name="fancybox-frame{rnd}" class="fancybox-iframe" frameborder="0" vspace="0" hspace="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen allowtransparency="true" src=""></iframe>',
          preload: !0,
          css: {},
          attr: { scrolling: "auto" },
        },
        animationEffect: "zoom",
        animationDuration: 366,
        zoomOpacity: "auto",
        transitionEffect: "fade",
        transitionDuration: 366,
        slideClass: "",
        baseClass: "",
        baseTpl:
          '<div class="fancybox-container" role="dialog" tabindex="-1"><div class="fancybox-bg"></div><div class="fancybox-inner"><div class="fancybox-infobar"><button data-fancybox-prev title="{{PREV}}" class="fancybox-button fancybox-button--left"></button><div class="fancybox-infobar__body"><span data-fancybox-index></span>&nbsp;/&nbsp;<span data-fancybox-count></span></div><button data-fancybox-next title="{{NEXT}}" class="fancybox-button fancybox-button--right"></button></div><div class="fancybox-toolbar">{{BUTTONS}}</div><div class="fancybox-navigation"><button data-fancybox-prev title="{{PREV}}" class="fancybox-arrow fancybox-arrow--left" /><button data-fancybox-next title="{{NEXT}}" class="fancybox-arrow fancybox-arrow--right" /></div><div class="fancybox-stage"></div><div class="fancybox-caption-wrap"><div class="fancybox-caption"></div></div></div></div>',
        spinnerTpl: '<div class="fancybox-loading"></div>',
        errorTpl: '<div class="fancybox-error"><p>{{ERROR}}<p></div>',
        btnTpl: {
          slideShow:
            '<button data-fancybox-play class="fancybox-button fancybox-button--play" title="{{PLAY_START}}"></button>',
          fullScreen:
            '<button data-fancybox-fullscreen class="fancybox-button fancybox-button--fullscreen" title="{{FULL_SCREEN}}"></button>',
          thumbs:
            '<button data-fancybox-thumbs class="fancybox-button fancybox-button--thumbs" title="{{THUMBS}}"></button>',
          close:
            '<button data-fancybox-close class="fancybox-button fancybox-button--close" title="{{CLOSE}}"></button>',
          smallBtn:
            '<button data-fancybox-close class="fancybox-close-small" title="{{CLOSE}}"></button>',
        },
        parentEl: "body",
        autoFocus: !0,
        backFocus: !0,
        trapFocus: !0,
        fullScreen: { autoStart: !1 },
        touch: { vertical: !0, momentum: !0 },
        hash: null,
        media: {},
        slideShow: { autoStart: !1, speed: 4e3 },
        thumbs: { autoStart: !1, hideOnClose: !0 },
        onInit: n.noop,
        beforeLoad: n.noop,
        afterLoad: n.noop,
        beforeShow: n.noop,
        afterShow: n.noop,
        beforeClose: n.noop,
        afterClose: n.noop,
        onActivate: n.noop,
        onDeactivate: n.noop,
        clickContent: function (t, e) {
          return "image" === t.type && "zoom";
        },
        clickSlide: "close",
        clickOutside: "close",
        dblclickContent: !1,
        dblclickSlide: !1,
        dblclickOutside: !1,
        mobile: {
          clickContent: function (t, e) {
            return "image" === t.type && "toggleControls";
          },
          clickSlide: function (t, e) {
            return "image" === t.type ? "toggleControls" : "close";
          },
          dblclickContent: function (t, e) {
            return "image" === t.type && "zoom";
          },
          dblclickSlide: function (t, e) {
            return "image" === t.type && "zoom";
          },
        },
        lang: "en",
        i18n: {
          en: {
            CLOSE: "Close",
            NEXT: "Next",
            PREV: "Previous",
            ERROR:
              "The requested content cannot be loaded. <br/> Please try again later.",
            PLAY_START: "Start slideshow",
            PLAY_STOP: "Pause slideshow",
            FULL_SCREEN: "Full screen",
            THUMBS: "Thumbnails",
          },
          de: {
            CLOSE: "Schliessen",
            NEXT: "Weiter",
            PREV: "Zurück",
            ERROR:
              "Die angeforderten Daten konnten nicht geladen werden. <br/> Bitte versuchen Sie es später nochmal.",
            PLAY_START: "Diaschau starten",
            PLAY_STOP: "Diaschau beenden",
            FULL_SCREEN: "Vollbild",
            THUMBS: "Vorschaubilder",
          },
        },
      },
      s = n(t),
      r = n(e),
      c = 0,
      l = function (t) {
        return t && t.hasOwnProperty && t instanceof n;
      },
      u = (function () {
        return (
          t.requestAnimationFrame ||
          t.webkitRequestAnimationFrame ||
          t.mozRequestAnimationFrame ||
          t.oRequestAnimationFrame ||
          function (e) {
            return t.setTimeout(e, 1e3 / 60);
          }
        );
      })(),
      d = (function () {
        var t,
          n = e.createElement("fakeelement"),
          i = {
            transition: "transitionend",
            OTransition: "oTransitionEnd",
            MozTransition: "transitionend",
            WebkitTransition: "webkitTransitionEnd",
          };
        for (t in i) if (n.style[t] !== o) return i[t];
      })(),
      f = function (t) {
        return t && t.length && t[0].offsetHeight;
      },
      h = function (t, o, i) {
        var s = this;
        (s.opts = n.extend(!0, { index: i }, a, o || {})),
          o && n.isArray(o.buttons) && (s.opts.buttons = o.buttons),
          (s.id = s.opts.id || ++c),
          (s.group = []),
          (s.currIndex = parseInt(s.opts.index, 10) || 0),
          (s.prevIndex = null),
          (s.prevPos = null),
          (s.currPos = 0),
          (s.firstRun = null),
          s.createGroup(t),
          s.group.length &&
            ((s.$lastFocus = n(e.activeElement).blur()),
            (s.slides = {}),
            s.init(t));
      };
    n.extend(h.prototype, {
      init: function () {
        var t,
          e,
          o,
          i = this,
          a = i.group[i.currIndex].opts;
        (i.scrollTop = r.scrollTop()),
          (i.scrollLeft = r.scrollLeft()),
          n.fancybox.getInstance() ||
            n.fancybox.isMobile ||
            "hidden" === n("body").css("overflow") ||
            ((t = n("body").width()),
            n("html").addClass("fancybox-enabled"),
            (t = n("body").width() - t),
            t > 1 &&
              n("head").append(
                '<style id="fancybox-style-noscroll" type="text/css">.compensate-for-scrollbar, .fancybox-enabled body { margin-right: ' +
                  t +
                  "px; }</style>"
              )),
          (o = ""),
          n.each(a.buttons, function (t, e) {
            o += a.btnTpl[e] || "";
          }),
          (e = n(i.translate(i, a.baseTpl.replace("{{BUTTONS}}", o)))
            .addClass("fancybox-is-hidden")
            .attr("id", "fancybox-container-" + i.id)
            .addClass(a.baseClass)
            .data("FancyBox", i)
            .prependTo(a.parentEl)),
          (i.$refs = { container: e }),
          ["bg", "inner", "infobar", "toolbar", "stage", "caption"].forEach(
            function (t) {
              i.$refs[t] = e.find(".fancybox-" + t);
            }
          ),
          (!a.arrows || i.group.length < 2) &&
            e.find(".fancybox-navigation").remove(),
          a.infobar || i.$refs.infobar.remove(),
          a.toolbar || i.$refs.toolbar.remove(),
          i.trigger("onInit"),
          i.activate(),
          i.jumpTo(i.currIndex);
      },
      translate: function (t, e) {
        var n = t.opts.i18n[t.opts.lang];
        return e.replace(/\{\{(\w+)\}\}/g, function (t, e) {
          var i = n[e];
          return i === o ? t : i;
        });
      },
      createGroup: function (t) {
        var e = this,
          i = n.makeArray(t);
        n.each(i, function (t, i) {
          var a,
            s,
            r,
            c,
            l = {},
            u = {},
            d = [];
          n.isPlainObject(i)
            ? ((l = i), (u = i.opts || i))
            : "object" === n.type(i) && n(i).length
            ? ((a = n(i)),
              (d = a.data()),
              (u = "options" in d ? d.options : {}),
              (u = "object" === n.type(u) ? u : {}),
              (l.src = "src" in d ? d.src : u.src || a.attr("href")),
              ["width", "height", "thumb", "type", "filter"].forEach(function (
                t
              ) {
                t in d && (u[t] = d[t]);
              }),
              "srcset" in d && (u.image = { srcset: d.srcset }),
              (u.$orig = a),
              l.type || l.src || ((l.type = "inline"), (l.src = i)))
            : (l = { type: "html", src: i + "" }),
            (l.opts = n.extend(!0, {}, e.opts, u)),
            n.fancybox.isMobile &&
              (l.opts = n.extend(!0, {}, l.opts, l.opts.mobile)),
            (s = l.type || l.opts.type),
            (r = l.src || ""),
            !s &&
              r &&
              (r.match(
                /(^data:image\/[a-z0-9+\/=]*,)|(\.(jp(e|g|eg)|gif|png|bmp|webp|svg|ico)((\?|#).*)?$)/i
              )
                ? (s = "image")
                : r.match(/\.(pdf)((\?|#).*)?$/i)
                ? (s = "pdf")
                : "#" === r.charAt(0) && (s = "inline")),
            (l.type = s),
            (l.index = e.group.length),
            l.opts.$orig && !l.opts.$orig.length && delete l.opts.$orig,
            !l.opts.$thumb &&
              l.opts.$orig &&
              (l.opts.$thumb = l.opts.$orig.find("img:first")),
            l.opts.$thumb && !l.opts.$thumb.length && delete l.opts.$thumb,
            "function" === n.type(l.opts.caption)
              ? (l.opts.caption = l.opts.caption.apply(i, [e, l]))
              : "caption" in d && (l.opts.caption = d.caption),
            (l.opts.caption = l.opts.caption === o ? "" : l.opts.caption + ""),
            "ajax" === s &&
              ((c = r.split(/\s+/, 2)),
              c.length > 1 &&
                ((l.src = c.shift()), (l.opts.filter = c.shift()))),
            "auto" == l.opts.smallBtn &&
              (n.inArray(s, ["html", "inline", "ajax"]) > -1
                ? ((l.opts.toolbar = !1), (l.opts.smallBtn = !0))
                : (l.opts.smallBtn = !1)),
            "pdf" === s && ((l.type = "iframe"), (l.opts.iframe.preload = !1)),
            l.opts.modal &&
              (l.opts = n.extend(!0, l.opts, {
                infobar: 0,
                toolbar: 0,
                smallBtn: 0,
                keyboard: 0,
                slideShow: 0,
                fullScreen: 0,
                thumbs: 0,
                touch: 0,
                clickContent: !1,
                clickSlide: !1,
                clickOutside: !1,
                dblclickContent: !1,
                dblclickSlide: !1,
                dblclickOutside: !1,
              })),
            e.group.push(l);
        });
      },
      addEvents: function () {
        var o = this;
        o.removeEvents(),
          o.$refs.container
            .on("click.fb-close", "[data-fancybox-close]", function (t) {
              t.stopPropagation(), t.preventDefault(), o.close(t);
            })
            .on(
              "click.fb-prev touchend.fb-prev",
              "[data-fancybox-prev]",
              function (t) {
                t.stopPropagation(), t.preventDefault(), o.previous();
              }
            )
            .on(
              "click.fb-next touchend.fb-next",
              "[data-fancybox-next]",
              function (t) {
                t.stopPropagation(), t.preventDefault(), o.next();
              }
            ),
          s.on("orientationchange.fb resize.fb", function (t) {
            t && t.originalEvent && "resize" === t.originalEvent.type
              ? u(function () {
                  o.update();
                })
              : (o.$refs.stage.hide(),
                setTimeout(function () {
                  o.$refs.stage.show(), o.update();
                }, 500));
          }),
          r.on("focusin.fb", function (t) {
            var i = n.fancybox ? n.fancybox.getInstance() : null;
            i.isClosing ||
              !i.current ||
              !i.current.opts.trapFocus ||
              n(t.target).hasClass("fancybox-container") ||
              n(t.target).is(e) ||
              (i &&
                "fixed" !== n(t.target).css("position") &&
                !i.$refs.container.has(t.target).length &&
                (t.stopPropagation(),
                i.focus(),
                s.scrollTop(o.scrollTop).scrollLeft(o.scrollLeft)));
          }),
          r.on("keydown.fb", function (t) {
            var e = o.current,
              i = t.keyCode || t.which;
            if (
              e &&
              e.opts.keyboard &&
              !n(t.target).is("input") &&
              !n(t.target).is("textarea")
            )
              return 8 === i || 27 === i
                ? (t.preventDefault(), void o.close(t))
                : 37 === i || 38 === i
                ? (t.preventDefault(), void o.previous())
                : 39 === i || 40 === i
                ? (t.preventDefault(), void o.next())
                : void o.trigger("afterKeydown", t, i);
          }),
          o.group[o.currIndex].opts.idleTime &&
            ((o.idleSecondsCounter = 0),
            r.on(
              "mousemove.fb-idle mouseenter.fb-idle mouseleave.fb-idle mousedown.fb-idle touchstart.fb-idle touchmove.fb-idle scroll.fb-idle keydown.fb-idle",
              function () {
                (o.idleSecondsCounter = 0),
                  o.isIdle && o.showControls(),
                  (o.isIdle = !1);
              }
            ),
            (o.idleInterval = t.setInterval(function () {
              o.idleSecondsCounter++,
                o.idleSecondsCounter >= o.group[o.currIndex].opts.idleTime &&
                  ((o.isIdle = !0),
                  (o.idleSecondsCounter = 0),
                  o.hideControls());
            }, 1e3)));
      },
      removeEvents: function () {
        var e = this;
        s.off("orientationchange.fb resize.fb"),
          r.off("focusin.fb keydown.fb .fb-idle"),
          this.$refs.container.off(".fb-close .fb-prev .fb-next"),
          e.idleInterval &&
            (t.clearInterval(e.idleInterval), (e.idleInterval = null));
      },
      previous: function (t) {
        return this.jumpTo(this.currPos - 1, t);
      },
      next: function (t) {
        return this.jumpTo(this.currPos + 1, t);
      },
      jumpTo: function (t, e, i) {
        var a,
          s,
          r,
          c,
          l,
          u,
          d,
          h = this,
          p = h.group.length;
        if (!(h.isSliding || h.isClosing || (h.isAnimating && h.firstRun))) {
          if (
            ((t = parseInt(t, 10)),
            (s = h.current ? h.current.opts.loop : h.opts.loop),
            !s && (t < 0 || t >= p))
          )
            return !1;
          if (
            ((a = h.firstRun = null === h.firstRun),
            !(p < 2 && !a && h.isSliding))
          ) {
            if (
              ((c = h.current),
              (h.prevIndex = h.currIndex),
              (h.prevPos = h.currPos),
              (r = h.createSlide(t)),
              p > 1 &&
                ((s || r.index > 0) && h.createSlide(t - 1),
                (s || r.index < p - 1) && h.createSlide(t + 1)),
              (h.current = r),
              (h.currIndex = r.index),
              (h.currPos = r.pos),
              h.trigger("beforeShow", a),
              h.updateControls(),
              (u = n.fancybox.getTranslate(r.$slide)),
              (r.isMoved =
                (0 !== u.left || 0 !== u.top) &&
                !r.$slide.hasClass("fancybox-animated")),
              (r.forcedDuration = o),
              n.isNumeric(e)
                ? (r.forcedDuration = e)
                : (e = r.opts[a ? "animationDuration" : "transitionDuration"]),
              (e = parseInt(e, 10)),
              a)
            )
              return (
                r.opts.animationEffect &&
                  e &&
                  h.$refs.container.css("transition-duration", e + "ms"),
                h.$refs.container.removeClass("fancybox-is-hidden"),
                f(h.$refs.container),
                h.$refs.container.addClass("fancybox-is-open"),
                r.$slide.addClass("fancybox-slide--current"),
                h.loadSlide(r),
                void h.preload()
              );
            n.each(h.slides, function (t, e) {
              n.fancybox.stop(e.$slide);
            }),
              r.$slide
                .removeClass("fancybox-slide--next fancybox-slide--previous")
                .addClass("fancybox-slide--current"),
              r.isMoved
                ? ((l = Math.round(r.$slide.width())),
                  n.each(h.slides, function (t, o) {
                    var i = o.pos - r.pos;
                    n.fancybox.animate(
                      o.$slide,
                      { top: 0, left: i * l + i * o.opts.gutter },
                      e,
                      function () {
                        o.$slide
                          .removeAttr("style")
                          .removeClass(
                            "fancybox-slide--next fancybox-slide--previous"
                          ),
                          o.pos === h.currPos &&
                            ((r.isMoved = !1), h.complete());
                      }
                    );
                  }))
                : h.$refs.stage.children().removeAttr("style"),
              r.isLoaded ? h.revealContent(r) : h.loadSlide(r),
              h.preload(),
              c.pos !== r.pos &&
                ((d =
                  "fancybox-slide--" + (c.pos > r.pos ? "next" : "previous")),
                c.$slide.removeClass(
                  "fancybox-slide--complete fancybox-slide--current fancybox-slide--next fancybox-slide--previous"
                ),
                (c.isComplete = !1),
                e &&
                  (r.isMoved || r.opts.transitionEffect) &&
                  (r.isMoved
                    ? c.$slide.addClass(d)
                    : ((d =
                        "fancybox-animated " +
                        d +
                        " fancybox-fx-" +
                        r.opts.transitionEffect),
                      n.fancybox.animate(c.$slide, d, e, function () {
                        c.$slide.removeClass(d).removeAttr("style");
                      }))));
          }
        }
      },
      createSlide: function (t) {
        var e,
          o,
          i = this;
        return (
          (o = t % i.group.length),
          (o = o < 0 ? i.group.length + o : o),
          !i.slides[t] &&
            i.group[o] &&
            ((e = n('<div class="fancybox-slide"></div>').appendTo(
              i.$refs.stage
            )),
            (i.slides[t] = n.extend(!0, {}, i.group[o], {
              pos: t,
              $slide: e,
              isLoaded: !1,
            })),
            i.updateSlide(i.slides[t])),
          i.slides[t]
        );
      },
      scaleToActual: function (t, e, i) {
        var a,
          s,
          r,
          c,
          l,
          u = this,
          d = u.current,
          f = d.$content,
          h = parseInt(d.$slide.width(), 10),
          p = parseInt(d.$slide.height(), 10),
          g = d.width,
          b = d.height;
        "image" != d.type ||
          d.hasError ||
          !f ||
          u.isAnimating ||
          (n.fancybox.stop(f),
          (u.isAnimating = !0),
          (t = t === o ? 0.5 * h : t),
          (e = e === o ? 0.5 * p : e),
          (a = n.fancybox.getTranslate(f)),
          (c = g / a.width),
          (l = b / a.height),
          (s = 0.5 * h - 0.5 * g),
          (r = 0.5 * p - 0.5 * b),
          g > h &&
            ((s = a.left * c - (t * c - t)),
            s > 0 && (s = 0),
            s < h - g && (s = h - g)),
          b > p &&
            ((r = a.top * l - (e * l - e)),
            r > 0 && (r = 0),
            r < p - b && (r = p - b)),
          u.updateCursor(g, b),
          n.fancybox.animate(
            f,
            { top: r, left: s, scaleX: c, scaleY: l },
            i || 330,
            function () {
              u.isAnimating = !1;
            }
          ),
          u.SlideShow && u.SlideShow.isActive && u.SlideShow.stop());
      },
      scaleToFit: function (t) {
        var e,
          o = this,
          i = o.current,
          a = i.$content;
        "image" != i.type ||
          i.hasError ||
          !a ||
          o.isAnimating ||
          (n.fancybox.stop(a),
          (o.isAnimating = !0),
          (e = o.getFitPos(i)),
          o.updateCursor(e.width, e.height),
          n.fancybox.animate(
            a,
            {
              top: e.top,
              left: e.left,
              scaleX: e.width / a.width(),
              scaleY: e.height / a.height(),
            },
            t || 330,
            function () {
              o.isAnimating = !1;
            }
          ));
      },
      getFitPos: function (t) {
        var e,
          o,
          i,
          a,
          r,
          c = this,
          l = t.$content,
          u = t.width,
          d = t.height,
          f = t.opts.margin;
        return (
          !(!l || !l.length || (!u && !d)) &&
          ("number" === n.type(f) && (f = [f, f]),
          2 == f.length && (f = [f[0], f[1], f[0], f[1]]),
          s.width() < 800 && (f = [0, 0, 0, 0]),
          (e = parseInt(c.$refs.stage.width(), 10) - (f[1] + f[3])),
          (o = parseInt(c.$refs.stage.height(), 10) - (f[0] + f[2])),
          (i = Math.min(1, e / u, o / d)),
          (a = Math.floor(i * u)),
          (r = Math.floor(i * d)),
          {
            top: Math.floor(0.5 * (o - r)) + f[0],
            left: Math.floor(0.5 * (e - a)) + f[3],
            width: a,
            height: r,
          })
        );
      },
      update: function () {
        var t = this;
        n.each(t.slides, function (e, n) {
          t.updateSlide(n);
        });
      },
      updateSlide: function (t) {
        var e = this,
          o = t.$content;
        o &&
          (t.width || t.height) &&
          (n.fancybox.stop(o),
          n.fancybox.setTranslate(o, e.getFitPos(t)),
          t.pos === e.currPos && e.updateCursor()),
          t.$slide.trigger("refresh"),
          e.trigger("onUpdate", t);
      },
      updateCursor: function (t, e) {
        var n,
          i = this,
          a = i.$refs.container.removeClass(
            "fancybox-is-zoomable fancybox-can-zoomIn fancybox-can-drag fancybox-can-zoomOut"
          );
        i.current &&
          !i.isClosing &&
          (i.isZoomable()
            ? (a.addClass("fancybox-is-zoomable"),
              (n =
                t !== o && e !== o
                  ? t < i.current.width && e < i.current.height
                  : i.isScaledDown()),
              n
                ? a.addClass("fancybox-can-zoomIn")
                : i.current.opts.touch
                ? a.addClass("fancybox-can-drag")
                : a.addClass("fancybox-can-zoomOut"))
            : i.current.opts.touch && a.addClass("fancybox-can-drag"));
      },
      isZoomable: function () {
        var t,
          e = this,
          o = e.current;
        if (o && !e.isClosing)
          return !!(
            "image" === o.type &&
            o.isLoaded &&
            !o.hasError &&
            ("zoom" === o.opts.clickContent ||
              (n.isFunction(o.opts.clickContent) &&
                "zoom" === o.opts.clickContent(o))) &&
            ((t = e.getFitPos(o)), o.width > t.width || o.height > t.height)
          );
      },
      isScaledDown: function () {
        var t = this,
          e = t.current,
          o = e.$content,
          i = !1;
        return (
          o &&
            ((i = n.fancybox.getTranslate(o)),
            (i = i.width < e.width || i.height < e.height)),
          i
        );
      },
      canPan: function () {
        var t = this,
          e = t.current,
          n = e.$content,
          o = !1;
        return (
          n &&
            ((o = t.getFitPos(e)),
            (o =
              Math.abs(n.width() - o.width) > 1 ||
              Math.abs(n.height() - o.height) > 1)),
          o
        );
      },
      loadSlide: function (t) {
        var e,
          o,
          i,
          a = this;
        if (!t.isLoading && !t.isLoaded) {
          switch (
            ((t.isLoading = !0),
            a.trigger("beforeLoad", t),
            (e = t.type),
            (o = t.$slide),
            o
              .off("refresh")
              .trigger("onReset")
              .addClass("fancybox-slide--" + (e || "unknown"))
              .addClass(t.opts.slideClass),
            e)
          ) {
            case "image":
              a.setImage(t);
              break;
            case "iframe":
              a.setIframe(t);
              break;
            case "html":
              a.setContent(t, t.src || t.content);
              break;
            case "inline":
              n(t.src).length ? a.setContent(t, n(t.src)) : a.setError(t);
              break;
            case "ajax":
              a.showLoading(t),
                (i = n.ajax(
                  n.extend({}, t.opts.ajax.settings, {
                    url: t.src,
                    success: function (e, n) {
                      "success" === n && a.setContent(t, e);
                    },
                    error: function (e, n) {
                      e && "abort" !== n && a.setError(t);
                    },
                  })
                )),
                o.one("onReset", function () {
                  i.abort();
                });
              break;
            default:
              a.setError(t);
          }
          return !0;
        }
      },
      setImage: function (e) {
        var o,
          i,
          a,
          s,
          r = this,
          c = e.opts.image.srcset;
        if (c) {
          (a = t.devicePixelRatio || 1),
            (s = t.innerWidth * a),
            (i = c.split(",").map(function (t) {
              var e = {};
              return (
                t
                  .trim()
                  .split(/\s+/)
                  .forEach(function (t, n) {
                    var o = parseInt(t.substring(0, t.length - 1), 10);
                    return 0 === n
                      ? (e.url = t)
                      : void (
                          o && ((e.value = o), (e.postfix = t[t.length - 1]))
                        );
                  }),
                e
              );
            })),
            i.sort(function (t, e) {
              return t.value - e.value;
            });
          for (var l = 0; l < i.length; l++) {
            var u = i[l];
            if (
              ("w" === u.postfix && u.value >= s) ||
              ("x" === u.postfix && u.value >= a)
            ) {
              o = u;
              break;
            }
          }
          !o && i.length && (o = i[i.length - 1]),
            o &&
              ((e.src = o.url),
              e.width &&
                e.height &&
                "w" == o.postfix &&
                ((e.height = (e.width / e.height) * o.value),
                (e.width = o.value)));
        }
        (e.$content = n('<div class="fancybox-image-wrap"></div>')
          .addClass("fancybox-is-hidden")
          .appendTo(e.$slide)),
          e.opts.preload !== !1 &&
          e.opts.width &&
          e.opts.height &&
          (e.opts.thumb || e.opts.$thumb)
            ? ((e.width = e.opts.width),
              (e.height = e.opts.height),
              (e.$ghost = n("<img />")
                .one("error", function () {
                  n(this).remove(), (e.$ghost = null), r.setBigImage(e);
                })
                .one("load", function () {
                  r.afterLoad(e), r.setBigImage(e);
                })
                .addClass("fancybox-image")
                .appendTo(e.$content)
                .attr("src", e.opts.thumb || e.opts.$thumb.attr("src"))))
            : r.setBigImage(e);
      },
      setBigImage: function (t) {
        var e = this,
          o = n("<img />");
        (t.$image = o
          .one("error", function () {
            e.setError(t);
          })
          .one("load", function () {
            clearTimeout(t.timouts),
              (t.timouts = null),
              e.isClosing ||
                ((t.width = this.naturalWidth),
                (t.height = this.naturalHeight),
                t.opts.image.srcset &&
                  o.attr("sizes", "100vw").attr("srcset", t.opts.image.srcset),
                e.hideLoading(t),
                t.$ghost
                  ? (t.timouts = setTimeout(function () {
                      (t.timouts = null), t.$ghost.hide();
                    }, Math.min(300, Math.max(1e3, t.height / 1600))))
                  : e.afterLoad(t));
          })
          .addClass("fancybox-image")
          .attr("src", t.src)
          .appendTo(t.$content)),
          o[0].complete
            ? o.trigger("load")
            : o[0].error
            ? o.trigger("error")
            : (t.timouts = setTimeout(function () {
                o[0].complete || t.hasError || e.showLoading(t);
              }, 100));
      },
      setIframe: function (t) {
        var e,
          i = this,
          a = t.opts.iframe,
          s = t.$slide;
        (t.$content = n(
          '<div class="fancybox-content' +
            (a.preload ? " fancybox-is-hidden" : "") +
            '"></div>'
        )
          .css(a.css)
          .appendTo(s)),
          (e = n(a.tpl.replace(/\{rnd\}/g, new Date().getTime()))
            .attr(a.attr)
            .appendTo(t.$content)),
          a.preload
            ? (i.showLoading(t),
              e.on("load.fb error.fb", function (e) {
                (this.isReady = 1), t.$slide.trigger("refresh"), i.afterLoad(t);
              }),
              s.on("refresh.fb", function () {
                var n,
                  i,
                  s,
                  r,
                  c,
                  l = t.$content;
                if (1 === e[0].isReady) {
                  try {
                    (n = e.contents()), (i = n.find("body"));
                  } catch (t) {}
                  i &&
                    i.length &&
                    (a.css.width === o || a.css.height === o) &&
                    ((s =
                      e[0].contentWindow.document.documentElement.scrollWidth),
                    (r = Math.ceil(i.outerWidth(!0) + (l.width() - s))),
                    (c = Math.ceil(i.outerHeight(!0))),
                    l.css({
                      width:
                        a.css.width === o
                          ? r + (l.outerWidth() - l.innerWidth())
                          : a.css.width,
                      height:
                        a.css.height === o
                          ? c + (l.outerHeight() - l.innerHeight())
                          : a.css.height,
                    })),
                    l.removeClass("fancybox-is-hidden");
                }
              }))
            : this.afterLoad(t),
          e.attr("src", t.src),
          t.opts.smallBtn === !0 &&
            t.$content.prepend(i.translate(t, t.opts.btnTpl.smallBtn)),
          s.one("onReset", function () {
            try {
              n(this).find("iframe").hide().attr("src", "//about:blank");
            } catch (t) {}
            n(this).empty(), (t.isLoaded = !1);
          });
      },
      setContent: function (t, e) {
        var o = this;
        o.isClosing ||
          (o.hideLoading(t),
          t.$slide.empty(),
          l(e) && e.parent().length
            ? (e.parent(".fancybox-slide--inline").trigger("onReset"),
              (t.$placeholder = n("<div></div>").hide().insertAfter(e)),
              e.css("display", "inline-block"))
            : t.hasError ||
              ("string" === n.type(e) &&
                ((e = n("<div>").append(n.trim(e)).contents()),
                3 === e[0].nodeType && (e = n("<div>").html(e))),
              t.opts.filter && (e = n("<div>").html(e).find(t.opts.filter))),
          t.$slide.one("onReset", function () {
            t.$placeholder &&
              (t.$placeholder.after(e.hide()).remove(),
              (t.$placeholder = null)),
              t.$smallBtn && (t.$smallBtn.remove(), (t.$smallBtn = null)),
              t.hasError || (n(this).empty(), (t.isLoaded = !1));
          }),
          (t.$content = n(e).appendTo(t.$slide)),
          t.opts.smallBtn &&
            !t.$smallBtn &&
            (t.$smallBtn = n(o.translate(t, t.opts.btnTpl.smallBtn)).appendTo(
              t.$content
            )),
          this.afterLoad(t));
      },
      setError: function (t) {
        (t.hasError = !0),
          t.$slide.removeClass("fancybox-slide--" + t.type),
          this.setContent(t, this.translate(t, t.opts.errorTpl));
      },
      showLoading: function (t) {
        var e = this;
        (t = t || e.current),
          t &&
            !t.$spinner &&
            (t.$spinner = n(e.opts.spinnerTpl).appendTo(t.$slide));
      },
      hideLoading: function (t) {
        var e = this;
        (t = t || e.current),
          t && t.$spinner && (t.$spinner.remove(), delete t.$spinner);
      },
      afterLoad: function (t) {
        var e = this;
        e.isClosing ||
          ((t.isLoading = !1),
          (t.isLoaded = !0),
          e.trigger("afterLoad", t),
          e.hideLoading(t),
          t.opts.protect &&
            t.$content &&
            !t.hasError &&
            (t.$content.on("contextmenu.fb", function (t) {
              return 2 == t.button && t.preventDefault(), !0;
            }),
            "image" === t.type &&
              n('<div class="fancybox-spaceball"></div>').appendTo(t.$content)),
          e.revealContent(t));
      },
      revealContent: function (t) {
        var e,
          i,
          a,
          s,
          r,
          c = this,
          l = t.$slide,
          u = !1;
        return (
          (e = t.opts[c.firstRun ? "animationEffect" : "transitionEffect"]),
          (a = t.opts[c.firstRun ? "animationDuration" : "transitionDuration"]),
          (a = parseInt(t.forcedDuration === o ? a : t.forcedDuration, 10)),
          (!t.isMoved && t.pos === c.currPos && a) || (e = !1),
          "zoom" !== e ||
            (t.pos === c.currPos &&
              a &&
              "image" === t.type &&
              !t.hasError &&
              (u = c.getThumbPos(t))) ||
            (e = "fade"),
          "zoom" === e
            ? ((r = c.getFitPos(t)),
              (r.scaleX = Math.round((r.width / u.width) * 100) / 100),
              (r.scaleY = Math.round((r.height / u.height) * 100) / 100),
              delete r.width,
              delete r.height,
              (s = t.opts.zoomOpacity),
              "auto" == s &&
                (s = Math.abs(t.width / t.height - u.width / u.height) > 0.1),
              s && ((u.opacity = 0.1), (r.opacity = 1)),
              n.fancybox.setTranslate(
                t.$content.removeClass("fancybox-is-hidden"),
                u
              ),
              f(t.$content),
              void n.fancybox.animate(t.$content, r, a, function () {
                c.complete();
              }))
            : (c.updateSlide(t),
              e
                ? (n.fancybox.stop(l),
                  (i =
                    "fancybox-animated fancybox-slide--" +
                    (t.pos > c.prevPos ? "next" : "previous") +
                    " fancybox-fx-" +
                    e),
                  l
                    .removeAttr("style")
                    .removeClass(
                      "fancybox-slide--current fancybox-slide--next fancybox-slide--previous"
                    )
                    .addClass(i),
                  t.$content.removeClass("fancybox-is-hidden"),
                  f(l),
                  void n.fancybox.animate(
                    l,
                    "fancybox-slide--current",
                    a,
                    function (e) {
                      l.removeClass(i).removeAttr("style"),
                        t.pos === c.currPos && c.complete();
                    },
                    !0
                  ))
                : (f(l),
                  t.$content.removeClass("fancybox-is-hidden"),
                  void (t.pos === c.currPos && c.complete())))
        );
      },
      getThumbPos: function (o) {
        var i,
          a = this,
          s = !1,
          r = function (e) {
            for (
              var o, i = e[0], a = i.getBoundingClientRect(), s = [];
              null !== i.parentElement;

            )
              ("hidden" !== n(i.parentElement).css("overflow") &&
                "auto" !== n(i.parentElement).css("overflow")) ||
                s.push(i.parentElement.getBoundingClientRect()),
                (i = i.parentElement);
            return (
              (o = s.every(function (t) {
                var e = Math.min(a.right, t.right) - Math.max(a.left, t.left),
                  n = Math.min(a.bottom, t.bottom) - Math.max(a.top, t.top);
                return e > 0 && n > 0;
              })),
              o &&
                a.bottom > 0 &&
                a.right > 0 &&
                a.left < n(t).width() &&
                a.top < n(t).height()
            );
          },
          c = o.opts.$thumb,
          l = c ? c.offset() : 0;
        return (
          l &&
            c[0].ownerDocument === e &&
            r(c) &&
            ((i = a.$refs.stage.offset()),
            (s = {
              top: l.top - i.top + parseFloat(c.css("border-top-width") || 0),
              left:
                l.left - i.left + parseFloat(c.css("border-left-width") || 0),
              width: c.width(),
              height: c.height(),
              scaleX: 1,
              scaleY: 1,
            })),
          s
        );
      },
      complete: function () {
        var t = this,
          o = t.current,
          i = {};
        o.isMoved ||
          !o.isLoaded ||
          o.isComplete ||
          ((o.isComplete = !0),
          o.$slide.siblings().trigger("onReset"),
          f(o.$slide),
          o.$slide.addClass("fancybox-slide--complete"),
          n.each(t.slides, function (e, o) {
            o.pos >= t.currPos - 1 && o.pos <= t.currPos + 1
              ? (i[o.pos] = o)
              : o && (n.fancybox.stop(o.$slide), o.$slide.unbind().remove());
          }),
          (t.slides = i),
          t.updateCursor(),
          t.trigger("afterShow"),
          (n(e.activeElement).is("[disabled]") ||
            (o.opts.autoFocus && "image" != o.type && "iframe" !== o.type)) &&
            t.focus());
      },
      preload: function () {
        var t,
          e,
          n = this;
        n.group.length < 2 ||
          ((t = n.slides[n.currPos + 1]),
          (e = n.slides[n.currPos - 1]),
          t && "image" === t.type && n.loadSlide(t),
          e && "image" === e.type && n.loadSlide(e));
      },
      focus: function () {
        var t,
          e = this.current;
        this.isClosing ||
          ((t =
            e && e.isComplete
              ? e.$slide
                  .find("button,:input,[tabindex],a")
                  .filter(":not([disabled]):visible:first")
              : null),
          (t = t && t.length ? t : this.$refs.container),
          t.focus());
      },
      activate: function () {
        var t = this;
        n(".fancybox-container").each(function () {
          var e = n(this).data("FancyBox");
          e && e.uid !== t.uid && !e.isClosing && e.trigger("onDeactivate");
        }),
          t.current &&
            (t.$refs.container.index() > 0 &&
              t.$refs.container.prependTo(e.body),
            t.updateControls()),
          t.trigger("onActivate"),
          t.addEvents();
      },
      close: function (t, e) {
        var o,
          i,
          a,
          s,
          r,
          c,
          l = this,
          f = l.current,
          h = function () {
            l.cleanUp(t);
          };
        return (
          !l.isClosing &&
          ((l.isClosing = !0),
          l.trigger("beforeClose", t) === !1
            ? ((l.isClosing = !1),
              u(function () {
                l.update();
              }),
              !1)
            : (l.removeEvents(),
              f.timouts && clearTimeout(f.timouts),
              (a = f.$content),
              (o = f.opts.animationEffect),
              (i = n.isNumeric(e) ? e : o ? f.opts.animationDuration : 0),
              f.$slide
                .off(d)
                .removeClass(
                  "fancybox-slide--complete fancybox-slide--next fancybox-slide--previous fancybox-animated"
                ),
              f.$slide.siblings().trigger("onReset").remove(),
              i &&
                l.$refs.container
                  .removeClass("fancybox-is-open")
                  .addClass("fancybox-is-closing"),
              l.hideLoading(f),
              l.hideControls(),
              l.updateCursor(),
              "zoom" !== o ||
                (t !== !0 &&
                  a &&
                  i &&
                  "image" === f.type &&
                  !f.hasError &&
                  (c = l.getThumbPos(f))) ||
                (o = "fade"),
              "zoom" === o
                ? (n.fancybox.stop(a),
                  (r = n.fancybox.getTranslate(a)),
                  (r.width = r.width * r.scaleX),
                  (r.height = r.height * r.scaleY),
                  (s = f.opts.zoomOpacity),
                  "auto" == s &&
                    (s =
                      Math.abs(f.width / f.height - c.width / c.height) > 0.1),
                  s && (c.opacity = 0),
                  (r.scaleX = r.width / c.width),
                  (r.scaleY = r.height / c.height),
                  (r.width = c.width),
                  (r.height = c.height),
                  n.fancybox.setTranslate(f.$content, r),
                  n.fancybox.animate(f.$content, c, i, h),
                  !0)
                : (o && i
                    ? t === !0
                      ? setTimeout(h, i)
                      : n.fancybox.animate(
                          f.$slide.removeClass("fancybox-slide--current"),
                          "fancybox-animated fancybox-slide--previous fancybox-fx-" +
                            o,
                          i,
                          h
                        )
                    : h(),
                  !0)))
        );
      },
      cleanUp: function (t) {
        var e,
          o = this;
        o.current.$slide.trigger("onReset"),
          o.$refs.container.empty().remove(),
          o.trigger("afterClose", t),
          o.$lastFocus && !o.current.focusBack && o.$lastFocus.focus(),
          (o.current = null),
          (e = n.fancybox.getInstance()),
          e
            ? e.activate()
            : (s.scrollTop(o.scrollTop).scrollLeft(o.scrollLeft),
              n("html").removeClass("fancybox-enabled"),
              n("#fancybox-style-noscroll").remove());
      },
      trigger: function (t, e) {
        var o,
          i = Array.prototype.slice.call(arguments, 1),
          a = this,
          s = e && e.opts ? e : a.current;
        return (
          s ? i.unshift(s) : (s = a),
          i.unshift(a),
          n.isFunction(s.opts[t]) && (o = s.opts[t].apply(s, i)),
          o === !1
            ? o
            : void ("afterClose" === t
                ? r.trigger(t + ".fb", i)
                : a.$refs.container.trigger(t + ".fb", i))
        );
      },
      updateControls: function (t) {
        var e = this,
          o = e.current,
          i = o.index,
          a = o.opts,
          s = a.caption,
          r = e.$refs.caption;
        o.$slide.trigger("refresh"),
          (e.$caption = s && s.length ? r.html(s) : null),
          e.isHiddenControls || e.showControls(),
          n("[data-fancybox-count]").html(e.group.length),
          n("[data-fancybox-index]").html(i + 1),
          n("[data-fancybox-prev]").prop("disabled", !a.loop && i <= 0),
          n("[data-fancybox-next]").prop(
            "disabled",
            !a.loop && i >= e.group.length - 1
          );
      },
      hideControls: function () {
        (this.isHiddenControls = !0),
          this.$refs.container.removeClass(
            "fancybox-show-infobar fancybox-show-toolbar fancybox-show-caption fancybox-show-nav"
          );
      },
      showControls: function () {
        var t = this,
          e = t.current ? t.current.opts : t.opts,
          n = t.$refs.container;
        (t.isHiddenControls = !1),
          (t.idleSecondsCounter = 0),
          n
            .toggleClass("fancybox-show-toolbar", !(!e.toolbar || !e.buttons))
            .toggleClass(
              "fancybox-show-infobar",
              !!(e.infobar && t.group.length > 1)
            )
            .toggleClass(
              "fancybox-show-nav",
              !!(e.arrows && t.group.length > 1)
            )
            .toggleClass("fancybox-is-modal", !!e.modal),
          t.$caption
            ? n.addClass("fancybox-show-caption ")
            : n.removeClass("fancybox-show-caption");
      },
      toggleControls: function () {
        this.isHiddenControls ? this.showControls() : this.hideControls();
      },
    }),
      (n.fancybox = {
        version: "3.1.20",
        defaults: a,
        getInstance: function (t) {
          var e = n(
              '.fancybox-container:not(".fancybox-is-closing"):first'
            ).data("FancyBox"),
            o = Array.prototype.slice.call(arguments, 1);
          return (
            e instanceof h &&
            ("string" === n.type(t)
              ? e[t].apply(e, o)
              : "function" === n.type(t) && t.apply(e, o),
            e)
          );
        },
        open: function (t, e, n) {
          return new h(t, e, n);
        },
        close: function (t) {
          var e = this.getInstance();
          e && (e.close(), t === !0 && this.close());
        },
        destroy: function () {
          this.close(!0), r.off("click.fb-start");
        },
        isMobile:
          e.createTouch !== o &&
          /Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(
            navigator.userAgent
          ),
        use3d: (function () {
          var n = e.createElement("div");
          return (
            t.getComputedStyle &&
            t.getComputedStyle(n).getPropertyValue("transform") &&
            !(e.documentMode && e.documentMode < 11)
          );
        })(),
        getTranslate: function (t) {
          var e;
          if (!t || !t.length) return !1;
          if (
            ((e = t.eq(0).css("transform")),
            e && e.indexOf("matrix") !== -1
              ? ((e = e.split("(")[1]),
                (e = e.split(")")[0]),
                (e = e.split(",")))
              : (e = []),
            e.length)
          )
            (e =
              e.length > 10
                ? [e[13], e[12], e[0], e[5]]
                : [e[5], e[4], e[0], e[3]]),
              (e = e.map(parseFloat));
          else {
            e = [0, 0, 1, 1];
            var n = /\.*translate\((.*)px,(.*)px\)/i,
              o = n.exec(t.eq(0).attr("style"));
            o && ((e[0] = parseFloat(o[2])), (e[1] = parseFloat(o[1])));
          }
          return {
            top: e[0],
            left: e[1],
            scaleX: e[2],
            scaleY: e[3],
            opacity: parseFloat(t.css("opacity")),
            width: t.width(),
            height: t.height(),
          };
        },
        setTranslate: function (t, e) {
          var n = "",
            i = {};
          if (t && e)
            return (
              (e.left === o && e.top === o) ||
                ((n =
                  (e.left === o ? t.position().left : e.left) +
                  "px, " +
                  (e.top === o ? t.position().top : e.top) +
                  "px"),
                (n = this.use3d
                  ? "translate3d(" + n + ", 0px)"
                  : "translate(" + n + ")")),
              e.scaleX !== o &&
                e.scaleY !== o &&
                (n =
                  (n.length ? n + " " : "") +
                  "scale(" +
                  e.scaleX +
                  ", " +
                  e.scaleY +
                  ")"),
              n.length && (i.transform = n),
              e.opacity !== o && (i.opacity = e.opacity),
              e.width !== o && (i.width = e.width),
              e.height !== o && (i.height = e.height),
              t.css(i)
            );
        },
        animate: function (t, e, i, a, s) {
          var r = d || "transitionend";
          n.isFunction(i) && ((a = i), (i = null)),
            n.isPlainObject(e) || t.removeAttr("style"),
            t.on(r, function (i) {
              (!i ||
                !i.originalEvent ||
                (t.is(i.originalEvent.target) &&
                  "z-index" != i.originalEvent.propertyName)) &&
                (t.off(r),
                n.isPlainObject(e)
                  ? e.scaleX !== o &&
                    e.scaleY !== o &&
                    (t.css("transition-duration", "0ms"),
                    (e.width = t.width() * e.scaleX),
                    (e.height = t.height() * e.scaleY),
                    (e.scaleX = 1),
                    (e.scaleY = 1),
                    n.fancybox.setTranslate(t, e))
                  : s !== !0 && t.removeClass(e),
                n.isFunction(a) && a(i));
            }),
            n.isNumeric(i) && t.css("transition-duration", i + "ms"),
            n.isPlainObject(e) ? n.fancybox.setTranslate(t, e) : t.addClass(e),
            t.data(
              "timer",
              setTimeout(function () {
                t.trigger("transitionend");
              }, i + 16)
            );
        },
        stop: function (t) {
          clearTimeout(t.data("timer")), t.off(d);
        },
      }),
      (n.fn.fancybox = function (t) {
        var e;
        return (
          (t = t || {}),
          (e = t.selector || !1),
          e
            ? n("body")
                .off("click.fb-start", e)
                .on("click.fb-start", e, { items: n(e), options: t }, i)
            : this.off("click.fb-start").on(
                "click.fb-start",
                { items: this, options: t },
                i
              ),
          this
        );
      }),
      r.on("click.fb-start", "[data-fancybox]", i);
  }
})(window, document, window.jQuery),
  (function (t) {
    "use strict";
    var e = function (e, n, o) {
        if (e)
          return (
            (o = o || ""),
            "object" === t.type(o) && (o = t.param(o, !0)),
            t.each(n, function (t, n) {
              e = e.replace("$" + t, n || "");
            }),
            o.length && (e += (e.indexOf("?") > 0 ? "&" : "?") + o),
            e
          );
      },
      n = {
        youtube: {
          matcher:
            /(youtube\.com|youtu\.be|youtube\-nocookie\.com)\/(watch\?(.*&)?v=|v\/|u\/|embed\/?)?(videoseries\?list=(.*)|[\w-]{11}|\?listType=(.*)&list=(.*))(.*)/i,
          params: {
            autoplay: 1,
            autohide: 1,
            fs: 1,
            rel: 0,
            hd: 1,
            wmode: "transparent",
            enablejsapi: 1,
            html5: 1,
          },
          paramPlace: 8,
          type: "iframe",
          url: "//www.youtube.com/embed/$4",
          thumb: "//img.youtube.com/vi/$4/hqdefault.jpg",
        },
        vimeo: {
          matcher: /^.+vimeo.com\/(.*\/)?([\d]+)(.*)?/,
          params: {
            autoplay: 1,
            hd: 1,
            show_title: 1,
            show_byline: 1,
            show_portrait: 0,
            fullscreen: 1,
            api: 1,
          },
          paramPlace: 3,
          type: "iframe",
          url: "//player.vimeo.com/video/$2",
        },
        metacafe: {
          matcher: /metacafe.com\/watch\/(\d+)\/(.*)?/,
          type: "iframe",
          url: "//www.metacafe.com/embed/$1/?ap=1",
        },
        dailymotion: {
          matcher: /dailymotion.com\/video\/(.*)\/?(.*)/,
          params: { additionalInfos: 0, autoStart: 1 },
          type: "iframe",
          url: "//www.dailymotion.com/embed/video/$1",
        },
        vine: {
          matcher: /vine.co\/v\/([a-zA-Z0-9\?\=\-]+)/,
          type: "iframe",
          url: "//vine.co/v/$1/embed/simple",
        },
        instagram: {
          matcher: /(instagr\.am|instagram\.com)\/p\/([a-zA-Z0-9_\-]+)\/?/i,
          type: "image",
          url: "//$1/p/$2/media/?size=l",
        },
        google_maps: {
          matcher:
            /(maps\.)?google\.([a-z]{2,3}(\.[a-z]{2})?)\/(((maps\/(place\/(.*)\/)?\@(.*),(\d+.?\d+?)z))|(\?ll=))(.*)?/i,
          type: "iframe",
          url: function (t) {
            return (
              "//maps.google." +
              t[2] +
              "/?ll=" +
              (t[9]
                ? t[9] +
                  "&z=" +
                  Math.floor(t[10]) +
                  (t[12] ? t[12].replace(/^\//, "&") : "")
                : t[12]) +
              "&output=" +
              (t[12] && t[12].indexOf("layer=c") > 0 ? "svembed" : "embed")
            );
          },
        },
      };
    t(document).on("onInit.fb", function (o, i) {
      t.each(i.group, function (o, i) {
        var a,
          s,
          r,
          c,
          l,
          u,
          d,
          f = i.src || "",
          h = !1;
        i.type ||
          ((a = t.extend(!0, {}, n, i.opts.media)),
          t.each(a, function (n, o) {
            if (((r = f.match(o.matcher)), (u = {}), (d = n), r)) {
              if (((h = o.type), o.paramPlace && r[o.paramPlace])) {
                (l = r[o.paramPlace]),
                  "?" == l[0] && (l = l.substring(1)),
                  (l = l.split("&"));
                for (var a = 0; a < l.length; ++a) {
                  var p = l[a].split("=", 2);
                  2 == p.length &&
                    (u[p[0]] = decodeURIComponent(p[1].replace(/\+/g, " ")));
                }
              }
              return (
                (c = t.extend(!0, {}, o.params, i.opts[n], u)),
                (f =
                  "function" === t.type(o.url)
                    ? o.url.call(this, r, c, i)
                    : e(o.url, r, c)),
                (s =
                  "function" === t.type(o.thumb)
                    ? o.thumb.call(this, r, c, i)
                    : e(o.thumb, r)),
                "vimeo" === d && (f = f.replace("&%23", "#")),
                !1
              );
            }
          }),
          h
            ? ((i.src = f),
              (i.type = h),
              i.opts.thumb ||
                (i.opts.$thumb && i.opts.$thumb.length) ||
                (i.opts.thumb = s),
              "iframe" === h &&
                (t.extend(!0, i.opts, {
                  iframe: { preload: !1, attr: { scrolling: "no" } },
                }),
                (i.contentProvider = d),
                (i.opts.slideClass +=
                  " fancybox-slide--" +
                  ("google_maps" == d ? "map" : "video"))))
            : (i.type = "image"));
      });
    });
  })(window.jQuery),
  (function (t, e, n) {
    "use strict";
    var o = (function () {
        return (
          t.requestAnimationFrame ||
          t.webkitRequestAnimationFrame ||
          t.mozRequestAnimationFrame ||
          t.oRequestAnimationFrame ||
          function (e) {
            return t.setTimeout(e, 1e3 / 60);
          }
        );
      })(),
      i = (function () {
        return (
          t.cancelAnimationFrame ||
          t.webkitCancelAnimationFrame ||
          t.mozCancelAnimationFrame ||
          t.oCancelAnimationFrame ||
          function (e) {
            t.clearTimeout(e);
          }
        );
      })(),
      a = function (e) {
        var n = [];
        (e = e.originalEvent || e || t.e),
          (e =
            e.touches && e.touches.length
              ? e.touches
              : e.changedTouches && e.changedTouches.length
              ? e.changedTouches
              : [e]);
        for (var o in e)
          e[o].pageX
            ? n.push({ x: e[o].pageX, y: e[o].pageY })
            : e[o].clientX && n.push({ x: e[o].clientX, y: e[o].clientY });
        return n;
      },
      s = function (t, e, n) {
        return e && t
          ? "x" === n
            ? t.x - e.x
            : "y" === n
            ? t.y - e.y
            : Math.sqrt(Math.pow(t.x - e.x, 2) + Math.pow(t.y - e.y, 2))
          : 0;
      },
      r = function (t) {
        if (
          t.is("a,button,input,select,textarea") ||
          n.isFunction(t.get(0).onclick)
        )
          return !0;
        for (var e = 0, o = t[0].attributes, i = o.length; e < i; e++)
          if ("data-fancybox-" === o[e].nodeName.substr(0, 14)) return !0;
        return !1;
      },
      c = function (e) {
        var n = t.getComputedStyle(e)["overflow-y"],
          o = t.getComputedStyle(e)["overflow-x"],
          i =
            ("scroll" === n || "auto" === n) && e.scrollHeight > e.clientHeight,
          a = ("scroll" === o || "auto" === o) && e.scrollWidth > e.clientWidth;
        return i || a;
      },
      l = function (t) {
        for (var e = !1; ; ) {
          if ((e = c(t.get(0)))) break;
          if (
            ((t = t.parent()),
            !t.length || t.hasClass("fancybox-stage") || t.is("body"))
          )
            break;
        }
        return e;
      },
      u = function (t) {
        var e = this;
        (e.instance = t),
          (e.$bg = t.$refs.bg),
          (e.$stage = t.$refs.stage),
          (e.$container = t.$refs.container),
          e.destroy(),
          e.$container.on(
            "touchstart.fb.touch mousedown.fb.touch",
            n.proxy(e, "ontouchstart")
          );
      };
    (u.prototype.destroy = function () {
      this.$container.off(".fb.touch");
    }),
      (u.prototype.ontouchstart = function (o) {
        var i = this,
          c = n(o.target),
          u = i.instance,
          d = u.current,
          f = d.$content,
          h = "touchstart" == o.type;
        if (
          (h && i.$container.off("mousedown.fb.touch"),
          !d || i.instance.isAnimating || i.instance.isClosing)
        )
          return o.stopPropagation(), void o.preventDefault();
        if (
          (!o.originalEvent || 2 != o.originalEvent.button) &&
          c.length &&
          !r(c) &&
          !r(c.parent()) &&
          !(o.originalEvent.clientX > c[0].clientWidth + c.offset().left) &&
          ((i.startPoints = a(o)),
          i.startPoints && !(i.startPoints.length > 1 && u.isSliding))
        ) {
          if (
            ((i.$target = c),
            (i.$content = f),
            (i.canTap = !0),
            n(e).off(".fb.touch"),
            n(e).on(
              h
                ? "touchend.fb.touch touchcancel.fb.touch"
                : "mouseup.fb.touch mouseleave.fb.touch",
              n.proxy(i, "ontouchend")
            ),
            n(e).on(
              h ? "touchmove.fb.touch" : "mousemove.fb.touch",
              n.proxy(i, "ontouchmove")
            ),
            o.stopPropagation(),
            (!u.current.opts.touch && !u.canPan()) ||
              (!c.is(i.$stage) && !i.$stage.find(c).length))
          )
            return void (c.is("img") && o.preventDefault());
          (n.fancybox.isMobile && (l(i.$target) || l(i.$target.parent()))) ||
            o.preventDefault(),
            (i.canvasWidth = Math.round(d.$slide[0].clientWidth)),
            (i.canvasHeight = Math.round(d.$slide[0].clientHeight)),
            (i.startTime = new Date().getTime()),
            (i.distanceX = i.distanceY = i.distance = 0),
            (i.isPanning = !1),
            (i.isSwiping = !1),
            (i.isZooming = !1),
            (i.sliderStartPos = i.sliderLastPos || { top: 0, left: 0 }),
            (i.contentStartPos = n.fancybox.getTranslate(i.$content)),
            (i.contentLastPos = null),
            1 !== i.startPoints.length ||
              i.isZooming ||
              ((i.canTap = !u.isSliding),
              "image" === d.type &&
              (i.contentStartPos.width > i.canvasWidth + 1 ||
                i.contentStartPos.height > i.canvasHeight + 1)
                ? (n.fancybox.stop(i.$content),
                  i.$content.css("transition-duration", "0ms"),
                  (i.isPanning = !0))
                : (i.isSwiping = !0),
              i.$container.addClass("fancybox-controls--isGrabbing")),
            2 !== i.startPoints.length ||
              u.isAnimating ||
              d.hasError ||
              "image" !== d.type ||
              (!d.isLoaded && !d.$ghost) ||
              ((i.isZooming = !0),
              (i.isSwiping = !1),
              (i.isPanning = !1),
              n.fancybox.stop(i.$content),
              i.$content.css("transition-duration", "0ms"),
              (i.centerPointStartX =
                0.5 * (i.startPoints[0].x + i.startPoints[1].x) -
                n(t).scrollLeft()),
              (i.centerPointStartY =
                0.5 * (i.startPoints[0].y + i.startPoints[1].y) -
                n(t).scrollTop()),
              (i.percentageOfImageAtPinchPointX =
                (i.centerPointStartX - i.contentStartPos.left) /
                i.contentStartPos.width),
              (i.percentageOfImageAtPinchPointY =
                (i.centerPointStartY - i.contentStartPos.top) /
                i.contentStartPos.height),
              (i.startDistanceBetweenFingers = s(
                i.startPoints[0],
                i.startPoints[1]
              )));
        }
      }),
      (u.prototype.ontouchmove = function (t) {
        var e = this;
        if (
          ((e.newPoints = a(t)),
          n.fancybox.isMobile && (l(e.$target) || l(e.$target.parent())))
        )
          return t.stopPropagation(), void (e.canTap = !1);
        if (
          (e.instance.current.opts.touch || e.instance.canPan()) &&
          e.newPoints &&
          e.newPoints.length &&
          ((e.distanceX = s(e.newPoints[0], e.startPoints[0], "x")),
          (e.distanceY = s(e.newPoints[0], e.startPoints[0], "y")),
          (e.distance = s(e.newPoints[0], e.startPoints[0])),
          e.distance > 0)
        ) {
          if (!e.$target.is(e.$stage) && !e.$stage.find(e.$target).length)
            return;
          t.stopPropagation(),
            t.preventDefault(),
            e.isSwiping
              ? e.onSwipe()
              : e.isPanning
              ? e.onPan()
              : e.isZooming && e.onZoom();
        }
      }),
      (u.prototype.onSwipe = function () {
        var e,
          a = this,
          s = a.isSwiping,
          r = a.sliderStartPos.left || 0;
        s === !0
          ? Math.abs(a.distance) > 10 &&
            ((a.canTap = !1),
            a.instance.group.length < 2 && a.instance.opts.touch.vertical
              ? (a.isSwiping = "y")
              : a.instance.isSliding ||
                a.instance.opts.touch.vertical === !1 ||
                ("auto" === a.instance.opts.touch.vertical &&
                  n(t).width() > 800)
              ? (a.isSwiping = "x")
              : ((e = Math.abs(
                  (180 * Math.atan2(a.distanceY, a.distanceX)) / Math.PI
                )),
                (a.isSwiping = e > 45 && e < 135 ? "y" : "x")),
            (a.instance.isSliding = a.isSwiping),
            (a.startPoints = a.newPoints),
            n.each(a.instance.slides, function (t, e) {
              n.fancybox.stop(e.$slide),
                e.$slide.css("transition-duration", "0ms"),
                (e.inTransition = !1),
                e.pos === a.instance.current.pos &&
                  (a.sliderStartPos.left = n.fancybox.getTranslate(
                    e.$slide
                  ).left);
            }),
            a.instance.SlideShow &&
              a.instance.SlideShow.isActive &&
              a.instance.SlideShow.stop())
          : ("x" == s &&
              (a.distanceX > 0 &&
              (a.instance.group.length < 2 ||
                (0 === a.instance.current.index &&
                  !a.instance.current.opts.loop))
                ? (r += Math.pow(a.distanceX, 0.8))
                : a.distanceX < 0 &&
                  (a.instance.group.length < 2 ||
                    (a.instance.current.index === a.instance.group.length - 1 &&
                      !a.instance.current.opts.loop))
                ? (r -= Math.pow(-a.distanceX, 0.8))
                : (r += a.distanceX)),
            (a.sliderLastPos = {
              top: "x" == s ? 0 : a.sliderStartPos.top + a.distanceY,
              left: r,
            }),
            a.requestId && (i(a.requestId), (a.requestId = null)),
            (a.requestId = o(function () {
              a.sliderLastPos &&
                (n.each(a.instance.slides, function (t, e) {
                  var o = e.pos - a.instance.currPos;
                  n.fancybox.setTranslate(e.$slide, {
                    top: a.sliderLastPos.top,
                    left:
                      a.sliderLastPos.left +
                      o * a.canvasWidth +
                      o * e.opts.gutter,
                  });
                }),
                a.$container.addClass("fancybox-is-sliding"));
            })));
      }),
      (u.prototype.onPan = function () {
        var t,
          e,
          a,
          s = this;
        (s.canTap = !1),
          (t =
            s.contentStartPos.width > s.canvasWidth
              ? s.contentStartPos.left + s.distanceX
              : s.contentStartPos.left),
          (e = s.contentStartPos.top + s.distanceY),
          (a = s.limitMovement(
            t,
            e,
            s.contentStartPos.width,
            s.contentStartPos.height
          )),
          (a.scaleX = s.contentStartPos.scaleX),
          (a.scaleY = s.contentStartPos.scaleY),
          (s.contentLastPos = a),
          s.requestId && (i(s.requestId), (s.requestId = null)),
          (s.requestId = o(function () {
            n.fancybox.setTranslate(s.$content, s.contentLastPos);
          }));
      }),
      (u.prototype.limitMovement = function (t, e, n, o) {
        var i,
          a,
          s,
          r,
          c = this,
          l = c.canvasWidth,
          u = c.canvasHeight,
          d = c.contentStartPos.left,
          f = c.contentStartPos.top,
          h = c.distanceX,
          p = c.distanceY;
        return (
          (i = Math.max(0, 0.5 * l - 0.5 * n)),
          (a = Math.max(0, 0.5 * u - 0.5 * o)),
          (s = Math.min(l - n, 0.5 * l - 0.5 * n)),
          (r = Math.min(u - o, 0.5 * u - 0.5 * o)),
          n > l &&
            (h > 0 && t > i && (t = i - 1 + Math.pow(-i + d + h, 0.8) || 0),
            h < 0 && t < s && (t = s + 1 - Math.pow(s - d - h, 0.8) || 0)),
          o > u &&
            (p > 0 && e > a && (e = a - 1 + Math.pow(-a + f + p, 0.8) || 0),
            p < 0 && e < r && (e = r + 1 - Math.pow(r - f - p, 0.8) || 0)),
          { top: e, left: t }
        );
      }),
      (u.prototype.limitPosition = function (t, e, n, o) {
        var i = this,
          a = i.canvasWidth,
          s = i.canvasHeight;
        return (
          n > a
            ? ((t = t > 0 ? 0 : t), (t = t < a - n ? a - n : t))
            : (t = Math.max(0, a / 2 - n / 2)),
          o > s
            ? ((e = e > 0 ? 0 : e), (e = e < s - o ? s - o : e))
            : (e = Math.max(0, s / 2 - o / 2)),
          { top: e, left: t }
        );
      }),
      (u.prototype.onZoom = function () {
        var e = this,
          a = e.contentStartPos.width,
          r = e.contentStartPos.height,
          c = e.contentStartPos.left,
          l = e.contentStartPos.top,
          u = s(e.newPoints[0], e.newPoints[1]),
          d = u / e.startDistanceBetweenFingers,
          f = Math.floor(a * d),
          h = Math.floor(r * d),
          p = (a - f) * e.percentageOfImageAtPinchPointX,
          g = (r - h) * e.percentageOfImageAtPinchPointY,
          b = (e.newPoints[0].x + e.newPoints[1].x) / 2 - n(t).scrollLeft(),
          m = (e.newPoints[0].y + e.newPoints[1].y) / 2 - n(t).scrollTop(),
          y = b - e.centerPointStartX,
          v = m - e.centerPointStartY,
          x = c + (p + y),
          w = l + (g + v),
          $ = {
            top: w,
            left: x,
            scaleX: e.contentStartPos.scaleX * d,
            scaleY: e.contentStartPos.scaleY * d,
          };
        (e.canTap = !1),
          (e.newWidth = f),
          (e.newHeight = h),
          (e.contentLastPos = $),
          e.requestId && (i(e.requestId), (e.requestId = null)),
          (e.requestId = o(function () {
            n.fancybox.setTranslate(e.$content, e.contentLastPos);
          }));
      }),
      (u.prototype.ontouchend = function (t) {
        var o = this,
          s = Math.max(new Date().getTime() - o.startTime, 1),
          r = o.isSwiping,
          c = o.isPanning,
          l = o.isZooming;
        return (
          (o.endPoints = a(t)),
          o.$container.removeClass("fancybox-controls--isGrabbing"),
          n(e).off(".fb.touch"),
          o.requestId && (i(o.requestId), (o.requestId = null)),
          (o.isSwiping = !1),
          (o.isPanning = !1),
          (o.isZooming = !1),
          o.canTap
            ? o.onTap(t)
            : ((o.speed = 366),
              (o.velocityX = (o.distanceX / s) * 0.5),
              (o.velocityY = (o.distanceY / s) * 0.5),
              (o.speedX = Math.max(
                0.5 * o.speed,
                Math.min(1.5 * o.speed, (1 / Math.abs(o.velocityX)) * o.speed)
              )),
              void (c ? o.endPanning() : l ? o.endZooming() : o.endSwiping(r)))
        );
      }),
      (u.prototype.endSwiping = function (t) {
        var e = this,
          o = !1;
        (e.instance.isSliding = !1),
          (e.sliderLastPos = null),
          "y" == t && Math.abs(e.distanceY) > 50
            ? (n.fancybox.animate(
                e.instance.current.$slide,
                {
                  top: e.sliderStartPos.top + e.distanceY + 150 * e.velocityY,
                  opacity: 0,
                },
                150
              ),
              (o = e.instance.close(!0, 300)))
            : "x" == t && e.distanceX > 50 && e.instance.group.length > 1
            ? (o = e.instance.previous(e.speedX))
            : "x" == t &&
              e.distanceX < -50 &&
              e.instance.group.length > 1 &&
              (o = e.instance.next(e.speedX)),
          o !== !1 ||
            ("x" != t && "y" != t) ||
            e.instance.jumpTo(e.instance.current.index, 150),
          e.$container.removeClass("fancybox-is-sliding");
      }),
      (u.prototype.endPanning = function () {
        var t,
          e,
          o,
          i = this;
        i.contentLastPos &&
          (i.instance.current.opts.touch.momentum === !1
            ? ((t = i.contentLastPos.left), (e = i.contentLastPos.top))
            : ((t = i.contentLastPos.left + i.velocityX * i.speed),
              (e = i.contentLastPos.top + i.velocityY * i.speed)),
          (o = i.limitPosition(
            t,
            e,
            i.contentStartPos.width,
            i.contentStartPos.height
          )),
          (o.width = i.contentStartPos.width),
          (o.height = i.contentStartPos.height),
          n.fancybox.animate(i.$content, o, 330));
      }),
      (u.prototype.endZooming = function () {
        var t,
          e,
          o,
          i,
          a = this,
          s = a.instance.current,
          r = a.newWidth,
          c = a.newHeight;
        a.contentLastPos &&
          ((t = a.contentLastPos.left),
          (e = a.contentLastPos.top),
          (i = { top: e, left: t, width: r, height: c, scaleX: 1, scaleY: 1 }),
          n.fancybox.setTranslate(a.$content, i),
          r < a.canvasWidth && c < a.canvasHeight
            ? a.instance.scaleToFit(150)
            : r > s.width || c > s.height
            ? a.instance.scaleToActual(
                a.centerPointStartX,
                a.centerPointStartY,
                150
              )
            : ((o = a.limitPosition(t, e, r, c)),
              n.fancybox.setTranslate(
                a.content,
                n.fancybox.getTranslate(a.$content)
              ),
              n.fancybox.animate(a.$content, o, 150)));
      }),
      (u.prototype.onTap = function (t) {
        var e,
          o = this,
          i = n(t.target),
          s = o.instance,
          r = s.current,
          c = (t && a(t)) || o.startPoints,
          l = c[0] ? c[0].x - o.$stage.offset().left : 0,
          u = c[0] ? c[0].y - o.$stage.offset().top : 0,
          d = function (e) {
            var i = r.opts[e];
            if ((n.isFunction(i) && (i = i.apply(s, [r, t])), i))
              switch (i) {
                case "close":
                  s.close(o.startEvent);
                  break;
                case "toggleControls":
                  s.toggleControls(!0);
                  break;
                case "next":
                  s.next();
                  break;
                case "nextOrClose":
                  s.group.length > 1 ? s.next() : s.close(o.startEvent);
                  break;
                case "zoom":
                  "image" == r.type &&
                    (r.isLoaded || r.$ghost) &&
                    (s.canPan()
                      ? s.scaleToFit()
                      : s.isScaledDown()
                      ? s.scaleToActual(l, u)
                      : s.group.length < 2 && s.close(o.startEvent));
              }
          };
        if (
          !(
            (t.originalEvent && 2 == t.originalEvent.button) ||
            s.isSliding ||
            l > i[0].clientWidth + i.offset().left
          )
        ) {
          if (
            i.is(
              ".fancybox-bg,.fancybox-inner,.fancybox-outer,.fancybox-container"
            )
          )
            e = "Outside";
          else if (i.is(".fancybox-slide")) e = "Slide";
          else {
            if (!s.current.$content || !s.current.$content.has(t.target).length)
              return;
            e = "Content";
          }
          if (o.tapped) {
            if (
              (clearTimeout(o.tapped),
              (o.tapped = null),
              Math.abs(l - o.tapX) > 50 ||
                Math.abs(u - o.tapY) > 50 ||
                s.isSliding)
            )
              return this;
            d("dblclick" + e);
          } else
            (o.tapX = l),
              (o.tapY = u),
              r.opts["dblclick" + e] &&
              r.opts["dblclick" + e] !== r.opts["click" + e]
                ? (o.tapped = setTimeout(function () {
                    (o.tapped = null), d("click" + e);
                  }, 300))
                : d("click" + e);
          return this;
        }
      }),
      n(e).on("onActivate.fb", function (t, e) {
        e && !e.Guestures && (e.Guestures = new u(e));
      }),
      n(e).on("beforeClose.fb", function (t, e) {
        e && e.Guestures && e.Guestures.destroy();
      });
  })(window, document, window.jQuery),
  (function (t, e) {
    "use strict";
    var n = function (t) {
      (this.instance = t), this.init();
    };
    e.extend(n.prototype, {
      timer: null,
      isActive: !1,
      $button: null,
      speed: 3e3,
      init: function () {
        var t = this;
        (t.$button = t.instance.$refs.toolbar
          .find("[data-fancybox-play]")
          .on("click", function () {
            t.toggle();
          })),
          (t.instance.group.length < 2 ||
            !t.instance.group[t.instance.currIndex].opts.slideShow) &&
            t.$button.hide();
      },
      set: function () {
        var t = this;
        t.instance &&
        t.instance.current &&
        (t.instance.current.opts.loop ||
          t.instance.currIndex < t.instance.group.length - 1)
          ? (t.timer = setTimeout(function () {
              t.instance.next();
            }, t.instance.current.opts.slideShow.speed || t.speed))
          : (t.stop(),
            (t.instance.idleSecondsCounter = 0),
            t.instance.showControls());
      },
      clear: function () {
        var t = this;
        clearTimeout(t.timer), (t.timer = null);
      },
      start: function () {
        var t = this,
          e = t.instance.current;
        t.instance &&
          e &&
          (e.opts.loop || e.index < t.instance.group.length - 1) &&
          ((t.isActive = !0),
          t.$button
            .attr("title", e.opts.i18n[e.opts.lang].PLAY_STOP)
            .addClass("fancybox-button--pause"),
          e.isComplete && t.set());
      },
      stop: function () {
        var t = this,
          e = t.instance.current;
        t.clear(),
          t.$button
            .attr("title", e.opts.i18n[e.opts.lang].PLAY_START)
            .removeClass("fancybox-button--pause"),
          (t.isActive = !1);
      },
      toggle: function () {
        var t = this;
        t.isActive ? t.stop() : t.start();
      },
    }),
      e(t).on({
        "onInit.fb": function (t, e) {
          e && !e.SlideShow && (e.SlideShow = new n(e));
        },
        "beforeShow.fb": function (t, e, n, o) {
          var i = e && e.SlideShow;
          o
            ? i && n.opts.slideShow.autoStart && i.start()
            : i && i.isActive && i.clear();
        },
        "afterShow.fb": function (t, e, n) {
          var o = e && e.SlideShow;
          o && o.isActive && o.set();
        },
        "afterKeydown.fb": function (n, o, i, a, s) {
          var r = o && o.SlideShow;
          !r ||
            !i.opts.slideShow ||
            (80 !== s && 32 !== s) ||
            e(t.activeElement).is("button,a,input") ||
            (a.preventDefault(), r.toggle());
        },
        "beforeClose.fb onDeactivate.fb": function (t, e) {
          var n = e && e.SlideShow;
          n && n.stop();
        },
      }),
      e(t).on("visibilitychange", function () {
        var n = e.fancybox.getInstance(),
          o = n && n.SlideShow;
        o && o.isActive && (t.hidden ? o.clear() : o.set());
      });
  })(document, window.jQuery),
  (function (t, e) {
    "use strict";
    var n = (function () {
      var e,
        n,
        o,
        i = [
          [
            "requestFullscreen",
            "exitFullscreen",
            "fullscreenElement",
            "fullscreenEnabled",
            "fullscreenchange",
            "fullscreenerror",
          ],
          [
            "webkitRequestFullscreen",
            "webkitExitFullscreen",
            "webkitFullscreenElement",
            "webkitFullscreenEnabled",
            "webkitfullscreenchange",
            "webkitfullscreenerror",
          ],
          [
            "webkitRequestFullScreen",
            "webkitCancelFullScreen",
            "webkitCurrentFullScreenElement",
            "webkitCancelFullScreen",
            "webkitfullscreenchange",
            "webkitfullscreenerror",
          ],
          [
            "mozRequestFullScreen",
            "mozCancelFullScreen",
            "mozFullScreenElement",
            "mozFullScreenEnabled",
            "mozfullscreenchange",
            "mozfullscreenerror",
          ],
          [
            "msRequestFullscreen",
            "msExitFullscreen",
            "msFullscreenElement",
            "msFullscreenEnabled",
            "MSFullscreenChange",
            "MSFullscreenError",
          ],
        ],
        a = {};
      for (n = 0; n < i.length; n++)
        if (((e = i[n]), e && e[1] in t)) {
          for (o = 0; o < e.length; o++) a[i[0][o]] = e[o];
          return a;
        }
      return !1;
    })();
    if (!n) return void (e.fancybox.defaults.btnTpl.fullScreen = !1);
    var o = {
      request: function (e) {
        (e = e || t.documentElement),
          e[n.requestFullscreen](e.ALLOW_KEYBOARD_INPUT);
      },
      exit: function () {
        t[n.exitFullscreen]();
      },
      toggle: function (e) {
        (e = e || t.documentElement),
          this.isFullscreen() ? this.exit() : this.request(e);
      },
      isFullscreen: function () {
        return Boolean(t[n.fullscreenElement]);
      },
      enabled: function () {
        return Boolean(t[n.fullscreenEnabled]);
      },
    };
    e(t).on({
      "onInit.fb": function (t, e) {
        var n,
          i = e.$refs.toolbar.find("[data-fancybox-fullscreen]");
        e && !e.FullScreen && e.group[e.currIndex].opts.fullScreen
          ? ((n = e.$refs.container),
            n.on(
              "click.fb-fullscreen",
              "[data-fancybox-fullscreen]",
              function (t) {
                t.stopPropagation(), t.preventDefault(), o.toggle(n[0]);
              }
            ),
            e.opts.fullScreen &&
              e.opts.fullScreen.autoStart === !0 &&
              o.request(n[0]),
            (e.FullScreen = o))
          : i.hide();
      },
      "afterKeydown.fb": function (t, e, n, o, i) {
        e &&
          e.FullScreen &&
          70 === i &&
          (o.preventDefault(), e.FullScreen.toggle(e.$refs.container[0]));
      },
      "beforeClose.fb": function (t) {
        t && t.FullScreen && o.exit();
      },
    }),
      e(t).on(n.fullscreenchange, function () {
        var t = e.fancybox.getInstance();
        t.current &&
          "image" === t.current.type &&
          t.isAnimating &&
          (t.current.$content.css("transition", "none"),
          (t.isAnimating = !1),
          t.update(!0, !0, 0));
      });
  })(document, window.jQuery),
  (function (t, e) {
    "use strict";
    var n = function (t) {
      (this.instance = t), this.init();
    };
    e.extend(n.prototype, {
      $button: null,
      $grid: null,
      $list: null,
      isVisible: !1,
      init: function () {
        var t = this,
          e = t.instance.group[0],
          n = t.instance.group[1];
        (t.$button = t.instance.$refs.toolbar.find("[data-fancybox-thumbs]")),
          t.instance.group.length > 1 &&
          t.instance.group[t.instance.currIndex].opts.thumbs &&
          ("image" == e.type || e.opts.thumb || e.opts.$thumb) &&
          ("image" == n.type || n.opts.thumb || n.opts.$thumb)
            ? (t.$button.on("click", function () {
                t.toggle();
              }),
              (t.isActive = !0))
            : (t.$button.hide(), (t.isActive = !1));
      },
      create: function () {
        var t,
          n,
          o = this.instance;
        (this.$grid = e('<div class="fancybox-thumbs"></div>').appendTo(
          o.$refs.container
        )),
          (t = "<ul>"),
          e.each(o.group, function (e, o) {
            (n =
              o.opts.thumb ||
              (o.opts.$thumb ? o.opts.$thumb.attr("src") : null)),
              n || "image" !== o.type || (n = o.src),
              n &&
                n.length &&
                (t +=
                  '<li data-index="' +
                  e +
                  '"  tabindex="0" class="fancybox-thumbs-loading"><img data-src="' +
                  n +
                  '" /></li>');
          }),
          (t += "</ul>"),
          (this.$list = e(t)
            .appendTo(this.$grid)
            .on("click", "li", function () {
              o.jumpTo(e(this).data("index"));
            })),
          this.$list
            .find("img")
            .hide()
            .one("load", function () {
              var t,
                n,
                o,
                i,
                a = e(this).parent().removeClass("fancybox-thumbs-loading"),
                s = a.outerWidth(),
                r = a.outerHeight();
              (t = this.naturalWidth || this.width),
                (n = this.naturalHeight || this.height),
                (o = t / s),
                (i = n / r),
                o >= 1 &&
                  i >= 1 &&
                  (o > i ? ((t /= i), (n = r)) : ((t = s), (n /= o))),
                e(this)
                  .css({
                    width: Math.floor(t),
                    height: Math.floor(n),
                    "margin-top": Math.min(0, Math.floor(0.3 * r - 0.3 * n)),
                    "margin-left": Math.min(0, Math.floor(0.5 * s - 0.5 * t)),
                  })
                  .show();
            })
            .each(function () {
              this.src = e(this).data("src");
            });
      },
      focus: function () {
        this.instance.current &&
          this.$list
            .children()
            .removeClass("fancybox-thumbs-active")
            .filter('[data-index="' + this.instance.current.index + '"]')
            .addClass("fancybox-thumbs-active")
            .focus();
      },
      close: function () {
        this.$grid.hide();
      },
      update: function () {
        this.instance.$refs.container.toggleClass(
          "fancybox-show-thumbs",
          this.isVisible
        ),
          this.isVisible
            ? (this.$grid || this.create(),
              this.instance.trigger("onThumbsShow"),
              this.focus())
            : this.$grid && this.instance.trigger("onThumbsHide"),
          this.instance.update();
      },
      hide: function () {
        (this.isVisible = !1), this.update();
      },
      show: function () {
        (this.isVisible = !0), this.update();
      },
      toggle: function () {
        (this.isVisible = !this.isVisible), this.update();
      },
    }),
      e(t).on({
        "onInit.fb": function (t, e) {
          e && !e.Thumbs && (e.Thumbs = new n(e));
        },
        "beforeShow.fb": function (t, e, n, o) {
          var i = e && e.Thumbs;
          if (i && i.isActive) {
            if (n.modal) return i.$button.hide(), void i.hide();
            o && e.opts.thumbs.autoStart === !0 && i.show(),
              i.isVisible && i.focus();
          }
        },
        "afterKeydown.fb": function (t, e, n, o, i) {
          var a = e && e.Thumbs;
          a && a.isActive && 71 === i && (o.preventDefault(), a.toggle());
        },
        "beforeClose.fb": function (t, e) {
          var n = e && e.Thumbs;
          n && n.isVisible && e.opts.thumbs.hideOnClose !== !1 && n.close();
        },
      });
  })(document, window.jQuery),
  (function (t, e, n) {
    "use strict";
    function o() {
      var t = e.location.hash.substr(1),
        n = t.split("-"),
        o =
          n.length > 1 && /^\+?\d+$/.test(n[n.length - 1])
            ? parseInt(n.pop(-1), 10) || 1
            : 1,
        i = n.join("-");
      return o < 1 && (o = 1), { hash: t, index: o, gallery: i };
    }
    function i(t) {
      var e;
      "" !== t.gallery &&
        ((e = n("[data-fancybox='" + n.escapeSelector(t.gallery) + "']").eq(
          t.index - 1
        )),
        e.length
          ? e.trigger("click")
          : n("#" + n.escapeSelector(t.gallery)).trigger("click"));
    }
    function a(t) {
      var e;
      return (
        !!t &&
        ((e = t.current ? t.current.opts : t.opts),
        e.$orig ? e.$orig.data("fancybox") : e.hash || "")
      );
    }
    n.escapeSelector ||
      (n.escapeSelector = function (t) {
        var e = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\x80-\uFFFF\w-]/g,
          n = function (t, e) {
            return e
              ? "\0" === t
                ? "�"
                : t.slice(0, -1) +
                  "\\" +
                  t.charCodeAt(t.length - 1).toString(16) +
                  " "
              : "\\" + t;
          };
        return (t + "").replace(e, n);
      });
    var s = null,
      r = null;
    n(function () {
      setTimeout(function () {
        n.fancybox.defaults.hash !== !1 &&
          (n(t).on({
            "onInit.fb": function (t, e) {
              var n, i;
              e.group[e.currIndex].opts.hash !== !1 &&
                ((n = o()),
                (i = a(e)),
                i &&
                  n.gallery &&
                  i == n.gallery &&
                  (e.currIndex = n.index - 1));
            },
            "beforeShow.fb": function (n, o, i, c) {
              var l;
              i.opts.hash !== !1 &&
                ((l = a(o)),
                l &&
                  "" !== l &&
                  (e.location.hash.indexOf(l) < 0 &&
                    (o.opts.origHash = e.location.hash),
                  (s = l + (o.group.length > 1 ? "-" + (i.index + 1) : "")),
                  "replaceState" in e.history
                    ? (r && clearTimeout(r),
                      (r = setTimeout(function () {
                        e.history[c ? "pushState" : "replaceState"](
                          {},
                          t.title,
                          e.location.pathname + e.location.search + "#" + s
                        ),
                          (r = null);
                      }, 300)))
                    : (e.location.hash = s)));
            },
            "beforeClose.fb": function (o, i, c) {
              var l, u;
              r && clearTimeout(r),
                c.opts.hash !== !1 &&
                  ((l = a(i)),
                  (u = i && i.opts.origHash ? i.opts.origHash : ""),
                  l &&
                    "" !== l &&
                    ("replaceState" in history
                      ? e.history.replaceState(
                          {},
                          t.title,
                          e.location.pathname + e.location.search + u
                        )
                      : ((e.location.hash = u),
                        n(e).scrollTop(i.scrollTop).scrollLeft(i.scrollLeft))),
                  (s = null));
            },
          }),
          n(e).on("hashchange.fb", function () {
            var t = o();
            n.fancybox.getInstance()
              ? !s ||
                s === t.gallery + "-" + t.index ||
                (1 === t.index && s == t.gallery) ||
                ((s = null), n.fancybox.close())
              : "" !== t.gallery && i(t);
          }),
          n(e).one("unload.fb popstate.fb", function () {
            n.fancybox.getInstance("close", !0, 0);
          }),
          i(o()));
      }, 50);
    });
  })(document, window, window.jQuery);
/*################ catalog-image-jquery/jquery.fancybox.min.js ends ###################*/

/*################ jquery.photo.gallery.min.js starts ###################*/
!(function (e) {
  e.fn.PhotoGallery = function (a) {
    var n = {
      EnableTitle: !0,
      TitleContainer: "#GalleryTitleContainer",
      BigImageName: "GalleryBigImage",
      BigImageClass: "dtc vam ac",
      BigImageBorderWidth: 5,
      ThumbImageName: "GalleryThumbnail",
      ThumbImageClass: "bdr cp",
      ThumbImageBorderWidth: 2,
      EnableButtonControl: !0,
      PrevButton: ".prev",
      NextButton: ".next",
      ThumbBorderChange: !0,
      ThumbAlphaChange: !0,
      ThumbAlphaClass: "alpha50",
    };
    return this.each(function () {
      var a = e.extend({}, n, a),
        l = e(this);
      if (a.EnableTitle) var t = e(a.TitleContainer + " p", l);
      if (
        (a.EnableButtonControl ||
          e(a.PrevButton + "," + a.NextButton, l).hide(),
        e("span[rel=" + a.BigImageName + "]", l).length > 0)
      )
        var m = e("span[rel=" + a.BigImageName + "]", l),
          r = e("img[rel=" + a.ThumbImageName + "]", l);
      else
        (m = e("img[rel=" + a.BigImageName + "]", l).length
          ? e("img[rel=" + a.BigImageName + "]", l)
          : e("img[data-rel=" + a.BigImageName + "]", l)),
          (r = e("img[rel=" + a.ThumbImageName + "]", l).length
            ? e("img[rel=" + a.ThumbImageName + "]", l)
            : e("img[data-rel=" + a.ThumbImageName + "]", l));
      var h = r.length,
        s = 0;
      for (i = 0; i < h; i++)
        a.EnableTitle && e(t[i]).css({ display: "none" }),
          e(m[i])
            .addClass(a.BigImageClass)
            .css({
              borderWidth: parseInt(a.BigImageBorderWidth) + "px",
              display: "none",
            }),
          e(r[i])
            .addClass(a.ThumbImageClass)
            .css({ borderWidth: parseInt(a.ThumbImageBorderWidth) + "px" }),
          a.ThumbBorderChange && b(e(r[i])),
          a.ThumbAlphaChange && u(e(r[i]));
      function g(a) {
        e(a, l).css("display", "none");
      }
      function o(a) {
        e(a, l).css("display", "");
      }
      function u(e) {
        e.addClass(a.ThumbAlphaClass);
      }
      function d(e) {
        e.removeClass(a.ThumbAlphaClass);
      }
      function b(e) {
        e.css("border-style", "dashed");
      }
      function c(e) {
        e.css("border-style", "solid");
      }
      function T() {
        for (i = 0; i < h; i++)
          a.EnableTitle && g(e(t[i])),
            g(m[i]),
            a.ThumbBorderChange && b(e(r[i])),
            a.ThumbAlphaChange && u(e(r[i]));
        a.EnableTitle && o(e(t[s])),
          o(m[s]),
          a.ThumbBorderChange && c(e(r[s])),
          a.ThumbAlphaChange && d(e(r[s]));
      }
      e(m[0]).css("display", ""),
        a.EnableTitle && e(t[0]).css("display", ""),
        a.ThumbBorderChange && c(e(r[0])),
        a.ThumbAlphaChange && d(e(r[0])),
        e("img[rel=" + a.ThumbImageName + "]", l).each(function (a) {
          e(this).click(function (e) {
            (s = a), T();
          });
        }),
        a.EnableButtonControl &&
          (e(a.PrevButton, l).click(function () {
            s > 0 ? s-- : (s = h - 1), T();
          }),
          e(a.NextButton, l).click(function () {
            s == h - 1 ? (s = 0) : s++, T();
          }));
    });
  };
})(jQuery);
/*################ jquery.photo.gallery.min.js ends ###################*/

/*################ jquery.paging.photo.gallery.min.js starts ###################*/
!(function (s) {
  s.fn.PagingPhotoGallery = function (a) {
    var e = {
      AParentClasses: "paging ac pt5px",
      AOnClasses: "dib bdr w15px on b cd",
      AOffClasses: "dib bdr w15px",
    };
    return this.each(function () {
      var a,
        n = s.extend({}, e, n),
        l = s(this),
        f = s("> p", l).length;
      if (f > 1) {
        for (a = '<p class="' + n.AParentClasses + '">', i = 0; i < f; i++)
          a +=
            '<a href="javascript:void(0);" class="' +
            n.AOffClasses +
            '">' +
            (i + 1) +
            "</a> ";
        (a += "</p>"),
          l.append(a),
          s(".paging a:eq(0)", l)
            .removeClass(n.AOffClasses)
            .addClass(n.AOnClasses),
          s(".paging a", l).each(function (a) {
            s(this).click(function () {
              for (i = 0; i < f; i++)
                s("p:eq(" + i + ")", l).hide(),
                  s(".paging a:eq(" + i + ")", l)
                    .removeClass(n.AOnClasses)
                    .addClass(n.AOffClasses);
              s("p:eq(" + a + ")", l).fadeIn("slow"),
                s(".paging a:eq(" + a + ")", l).addClass(n.AOnClasses);
            });
          });
      }
    });
  };
})(jQuery);
/*################ jquery.paging.photo.gallery.min.js ends ###################*/
